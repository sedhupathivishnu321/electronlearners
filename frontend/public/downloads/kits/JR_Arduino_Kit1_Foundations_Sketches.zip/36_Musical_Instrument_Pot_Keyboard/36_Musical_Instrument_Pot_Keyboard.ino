// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Passive piezo + -> D8, - -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
#define POT A0
#define PIEZO 8
#define BTN1 2
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

int scale[14] = {262, 294, 330, 349, 392, 440, 494, 523, 587, 659, 698, 784, 880, 988};
String names = "C4D4E4F4G4A4B4C5D5E5F5G5A5B5";
int lastNote = -1;

void colourFor(int n) {
  int seg = n % 7;
  int r = 0, g = 0, b = 0;
  if (seg == 0) { r = 255; }
  else if (seg == 1) { r = 255; g = 120; }
  else if (seg == 2) { r = 255; g = 255; }
  else if (seg == 3) { g = 255; }
  else if (seg == 4) { g = 255; b = 255; }
  else if (seg == 5) { b = 255; }
  else { r = 200; b = 255; }
  if (n >= 7) { r = r / 2; g = g / 2; b = b / 2; }       // higher octave dimmer
  setRGB(r, g, b);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int n = map(analogRead(POT), 0, 1023, 0, 13);
  colourFor(n);
  if (n != lastNote) { lastNote = n; Serial.println(names.substring(n * 2, n * 2 + 2)); }
  if (digitalRead(BTN1) == LOW) tone(PIEZO, scale[n]);
  else noTone(PIEZO);
  delay(10);
}
