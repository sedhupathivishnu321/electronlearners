Kit 1 - Foundations
Project 36: Musical Instrument: Pot Keyboard (Advanced)

The pot picks a note over two octaves, the button plays it, and the RGB colour shows the note.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1
  Piezo Passive Buzzer x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Passive piezo + -> D8, - -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-36-pot-keyboard
