Kit 1 - Foundations
Project 38: Software PWM Chaser (Advanced)

Gamma-corrected brightness profiles are computed in software and chased across four LEDs; pot = speed.

Parts:
  Resistor 220 ohm 1/4W x5
  LED 5mm Red x1
  LED 5mm Green x1
  RGB LED common cathode 5mm x1
  Potentiometer 10k (rotary) x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  10k pot: ends to 5V and GND, wiper -> A0
  4 "channels": red LED, green LED, RGB red, RGB blue. Each follows a shifted brightness wave.

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-38-pwm-chaser
