// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// 10k pot: ends to 5V and GND, wiper -> A0
#define RED_LED 3
#define GREEN_LED 5
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define POT A0

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

// 4 "channels": red LED, green LED, RGB red, RGB blue. Each follows a shifted brightness wave.
float wave(float phase) {
  float s = (sin(phase) + 1.0) / 2.0;       // 0..1
  return pow(s, 2.2) * 255.0;                // gamma correction so fades look even
}

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float speed = 0.5 + analogRead(POT) / 256.0;      // 0.5 .. 4.5 rad/s
  float t = millis() / 1000.0 * speed;
  analogWrite(RED_LED, wave(t));
  analogWrite(GREEN_LED, wave(t - 1.0));
  setRGB(wave(t - 2.0), 0, wave(t - 3.0));
  delay(10);
}
