Kit 1 - Foundations
Project 14: LED Fade Breathing Effect (Intermediate)

A sine-shaped fade mimics breathing.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3

Circuit notes:
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-14-breathing
