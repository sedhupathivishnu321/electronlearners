// ---- Circuit (Kit 1) ----
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

void setup() {
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
}

void loop() {
  float t = millis() / 1000.0;
  float v = (exp(sin(t * 1.2)) - 0.36787944) * 108.0;   // classic breathing curve 0..255
  setRGB(v * 0.2, v * 0.5, v);
  delay(10);
}
