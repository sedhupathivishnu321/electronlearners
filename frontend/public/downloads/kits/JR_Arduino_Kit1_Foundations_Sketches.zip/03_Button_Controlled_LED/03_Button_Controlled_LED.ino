// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
#define BTN1 2
#define RED_LED 3

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
}

void loop() {
  if (digitalRead(BTN1) == LOW) digitalWrite(RED_LED, HIGH);
  else digitalWrite(RED_LED, LOW);
}
