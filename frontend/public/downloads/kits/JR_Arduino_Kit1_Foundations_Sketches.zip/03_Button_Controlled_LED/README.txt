Kit 1 - Foundations
Project 3: Button-Controlled LED (Basic)

Hold the push button to light the LED (INPUT_PULLUP, pressed = LOW).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Push Button tactile 6x6 x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-03-button-led
