// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Second push button between D4 and GND (INPUT_PULLUP)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Active buzzer + -> D12, - -> GND
#define BTN1 2
#define BTN2 4
#define RED_LED 3
#define GREEN_LED 5
#define BUZZER 12

int score1 = 0, score2 = 0;

void winner(int p) {
  if (p == 1) { digitalWrite(RED_LED, HIGH); score1++; } else { digitalWrite(GREEN_LED, HIGH); score2++; }
  Serial.print("Player "); Serial.print(p); Serial.println(" wins the round!");
  Serial.print("Score  P1 "); Serial.print(score1); Serial.print(" : "); Serial.print(score2); Serial.println(" P2");
  delay(1500);
  digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, LOW);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP); pinMode(BTN2, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Quick draw! Wait for the BEEP, then hit your button first.");
}

void loop() {
  delay(1500);
  Serial.println("Ready...");
  unsigned long wait = random(1500, 4500);
  unsigned long t0 = millis();
  while (millis() - t0 < wait) {
    if (digitalRead(BTN1) == LOW) { Serial.println("P1 jumped the gun!"); winner(2); return; }
    if (digitalRead(BTN2) == LOW) { Serial.println("P2 jumped the gun!"); winner(1); return; }
  }
  digitalWrite(BUZZER, HIGH);
  while (true) {
    if (digitalRead(BTN1) == LOW) { digitalWrite(BUZZER, LOW); winner(1); return; }
    if (digitalRead(BTN2) == LOW) { digitalWrite(BUZZER, LOW); winner(2); return; }
  }
}
