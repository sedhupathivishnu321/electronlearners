Kit 1 - Foundations
Project 46: Two-Player Quick-Draw Game (Advanced)

First to hit their button after the BEEP wins (red = player 1, green = player 2); jumping the gun loses.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x2
  Buzzer Active 5V x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Second push button between D4 and GND (INPUT_PULLUP)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Active buzzer + -> D12, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-46-quick-draw
