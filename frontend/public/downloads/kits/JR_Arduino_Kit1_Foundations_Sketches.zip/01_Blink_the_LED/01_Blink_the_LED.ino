// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
#define RED_LED 3

unsigned long last = 0;
bool on = false;

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (millis() - last >= 500) {
    last = millis();
    on = !on;
    digitalWrite(RED_LED, on);
    Serial.println(on ? "LED ON" : "LED OFF");
  }
}
