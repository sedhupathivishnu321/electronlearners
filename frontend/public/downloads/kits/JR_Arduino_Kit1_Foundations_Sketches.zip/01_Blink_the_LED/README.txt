Kit 1 - Foundations
Project 1: Blink the LED (Basic)

Red LED blinks once a second using millis() instead of delay().

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-01-blink
