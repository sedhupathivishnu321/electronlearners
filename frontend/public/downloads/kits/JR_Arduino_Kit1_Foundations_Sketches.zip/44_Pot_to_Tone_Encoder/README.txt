Kit 1 - Foundations
Project 44: Pot-to-Tone Encoder (Advanced)

Encodes the pot reading as 4 tone pulses (high = 1, low = 0); Serial Plotter shows pot, code and ambient light.

Parts:
  Potentiometer 10k (rotary) x1
  Piezo Passive Buzzer x1
  LDR Light Sensor Module x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Passive piezo + -> D8, - -> GND
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-44-tone-encoder
