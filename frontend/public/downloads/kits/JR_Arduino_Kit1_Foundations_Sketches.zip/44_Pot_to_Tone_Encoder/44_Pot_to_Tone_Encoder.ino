// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Passive piezo + -> D8, - -> GND
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
#define POT A0
#define PIEZO 8
#define LDR A1

int lastCode = -1;

void setup() {
  Serial.begin(9600);
}

void sendCode(int code) {
  for (int i = 3; i >= 0; i--) {
    int bit = (code >> i) & 1;
    tone(PIEZO, bit ? 1500 : 600, 120);       // 1 = high tone, 0 = low tone
    delay(180);
  }
}

void loop() {
  int pot = analogRead(POT);
  int code = pot / 64;                          // 0..15
  Serial.print("pot:"); Serial.print(pot);
  Serial.print(" code:"); Serial.print(code * 64);
  Serial.print(" light:"); Serial.println(1023 - analogRead(LDR));
  if (code != lastCode) {
    lastCode = code;
    sendCode(code);
  }
  delay(100);
}
