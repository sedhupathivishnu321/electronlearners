// ---- Circuit (Kit 1) ----
// Passive piezo + -> D8, - -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define PIEZO 8
#define BTN1 2

#define C4 262
#define D4 294
#define E4 330
#define F4 349
#define G4 392
#define A4 440
#define B4 494
#define C5 523

int melody[] = {C4, C4, D4, C4, F4, E4, C4, C4, D4, C4, G4, F4};
int beats[]  = { 1,  1,  2,  2,  2,  4,  1,  1,  2,  2,  2,  4};

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  Serial.println("Press the button to play");
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    for (int i = 0; i < 12; i++) {
      int dur = beats[i] * 200;
      tone(PIEZO, melody[i], dur);
      delay(dur + 40);
    }
    Serial.println("done");
    delay(300);
  }
}
