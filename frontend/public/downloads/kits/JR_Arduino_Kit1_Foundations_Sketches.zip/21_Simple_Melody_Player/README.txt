Kit 1 - Foundations
Project 21: Simple Melody Player (Intermediate)

Press the button to play 'Happy Birthday' from note and duration tables.

Parts:
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1

Circuit notes:
  Passive piezo + -> D8, - -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-21-melody
