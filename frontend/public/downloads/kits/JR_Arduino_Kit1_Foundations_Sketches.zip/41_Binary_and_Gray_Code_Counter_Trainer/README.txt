Kit 1 - Foundations
Project 41: Binary and Gray-Code Counter Trainer (Advanced)

Count 0-15 on 4 LEDs; the slide switch toggles binary / Gray code.

Parts:
  Resistor 220 ohm 1/4W x5
  LED 5mm Red x1
  LED 5mm Green x1
  RGB LED common cathode 5mm x1
  Push Button tactile 6x6 x1
  Slide Switch SPDT x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-41-counter-trainer
