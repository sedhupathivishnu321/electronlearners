// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RED_LED 3
#define GREEN_LED 5
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define SLIDE 7
#define BTN1 2

bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}
int count = 0;

int toGray(int n) { return n ^ (n >> 1); }

void show() {
  int code = (digitalRead(SLIDE) == LOW) ? count : toGray(count);
  digitalWrite(RED_LED, code & 1);
  digitalWrite(GREEN_LED, (code >> 1) & 1);
  digitalWrite(RGB_R, (code >> 2) & 1);
  digitalWrite(RGB_G, (code >> 3) & 1);
  Serial.print(digitalRead(SLIDE) == LOW ? "binary " : "gray   ");
  Serial.print(count);
  Serial.print(" -> ");
  for (int i = 3; i >= 0; i--) Serial.print((code >> i) & 1);
  Serial.println();
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Button = count up, slide switch = binary / Gray code");
  show();
}

void loop() {
  if (pressed()) { count = (count + 1) % 16; show(); }
}
