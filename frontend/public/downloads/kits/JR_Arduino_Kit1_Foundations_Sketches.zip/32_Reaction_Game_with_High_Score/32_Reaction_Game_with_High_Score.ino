// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Active buzzer + -> D12, - -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define BTN1 2
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BUZZER 12
#define GREEN_LED 5

#include <EEPROM.h>
void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

int best = 9999;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  best = EEPROM.read(0) * 256 + EEPROM.read(1);
  if (best == 0 || best == 65535) best = 9999;
  Serial.print("High score to beat: "); Serial.print(best); Serial.println(" ms");
}

void loop() {
  setRGB(0, 0, 60);
  Serial.println("Wait for GREEN...");
  unsigned long wait = random(2000, 5000);
  unsigned long t0 = millis();
  while (millis() - t0 < wait) {
    if (digitalRead(BTN1) == LOW) {
      Serial.println("Too early! Penalty.");
      setRGB(255, 0, 0); digitalWrite(BUZZER, HIGH); delay(600); digitalWrite(BUZZER, LOW);
      while (digitalRead(BTN1) == LOW) { }
      return;
    }
  }
  digitalWrite(GREEN_LED, HIGH);
  t0 = millis();
  while (digitalRead(BTN1) == HIGH) { }
  int ms = millis() - t0;
  digitalWrite(GREEN_LED, LOW);
  Serial.print("Your time: "); Serial.print(ms); Serial.println(" ms");
  if (ms < best) {
    best = ms;
    EEPROM.write(0, best / 256); EEPROM.write(1, best % 256);
    Serial.println("NEW HIGH SCORE!");
    setRGB(255, 200, 0);                                  // gold
    for (int i = 0; i < 3; i++) { digitalWrite(BUZZER, HIGH); delay(100); digitalWrite(BUZZER, LOW); delay(100); }
  } else if (ms < 350) setRGB(0, 255, 0);                 // great
  else if (ms < 600) setRGB(255, 120, 0);                 // ok
  else setRGB(255, 0, 0);                                 // slow
  while (digitalRead(BTN1) == LOW) { }
  delay(2000);
}
