Kit 1 - Foundations
Project 32: Reaction Game with High Score (Advanced)

Best time is saved in EEPROM; the RGB colour shows your rank; buzzer feedback.

Parts:
  Resistor 220 ohm 1/4W x4
  LED 5mm Green x1
  RGB LED common cathode 5mm x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Active buzzer + -> D12, - -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-32-reaction-game
