Kit 1 - Foundations
Project 6: Potentiometer Brightness Dimmer (Basic)

The pot sets the PWM brightness of the green LED.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Potentiometer 10k (rotary) x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-06-pot-dimmer
