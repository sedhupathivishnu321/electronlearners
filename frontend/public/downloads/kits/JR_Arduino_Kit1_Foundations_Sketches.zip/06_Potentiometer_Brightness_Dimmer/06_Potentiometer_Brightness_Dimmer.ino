// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define POT A0
#define GREEN_LED 5

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int raw = analogRead(POT);
  analogWrite(GREEN_LED, raw / 4);
  Serial.print("pot=");
  Serial.print(raw);
  Serial.print("  brightness=");
  Serial.print(map(raw, 0, 1023, 0, 100));
  Serial.println("%");
  delay(200);
}
