Kit 1 - Foundations
Project 50: Security Panel Simulator (Advanced)

Long-press to arm / disarm, slide switch = door contact, entry delay, then siren. RGB shows the status.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Slide Switch SPDT x1
  Buzzer Active 5V x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Active buzzer + -> D12, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-50-security-panel
