// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Active buzzer + -> D12, - -> GND
#define BTN1 2
#define SLIDE 7
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BUZZER 12

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

enum { DISARMED, EXIT_DELAY, ARMED, ENTRY_DELAY, ALARM };
int state = DISARMED;
unsigned long since = 0;
unsigned long downAt = 0;
bool btnDown = false;

bool longPress() {                            // true once when a 1.2 s press completes
  bool d = (digitalRead(BTN1) == LOW);
  if (d && !btnDown) { btnDown = true; downAt = millis(); }
  if (!d) btnDown = false;
  if (btnDown && millis() - downAt >= 1200) { btnDown = false; downAt = millis(); while (digitalRead(BTN1) == LOW) { } return true; }
  return false;
}

void go(int s, String msg) {
  state = s; since = millis();
  Serial.println(msg);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP); pinMode(SLIDE, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Hold button 1.2 s = arm / disarm. Slide switch HIGH = door open.");
  setRGB(0, 255, 0);
}

void loop() {
  bool doorOpen = (digitalRead(SLIDE) == HIGH);
  bool hold = longPress();
  bool blink = (millis() / 250) % 2;

  if (state == DISARMED) {
    setRGB(0, 255, 0);
    if (hold) go(EXIT_DELAY, "Arming - leave now (5 s)");
  } else if (state == EXIT_DELAY) {
    if (blink) setRGB(255, 120, 0); else setRGB(0, 0, 0);
    if (hold) go(DISARMED, "Disarmed");
    else if (millis() - since > 5000) go(ARMED, "ARMED");
  } else if (state == ARMED) {
    setRGB(0, 0, 255);
    if (hold) go(DISARMED, "Disarmed");
    else if (doorOpen) go(ENTRY_DELAY, "Door opened! Disarm within 5 s");
  } else if (state == ENTRY_DELAY) {
    if (blink) setRGB(255, 120, 0); else setRGB(0, 0, 0);
    digitalWrite(BUZZER, (millis() / 500) % 2);
    if (hold) { digitalWrite(BUZZER, LOW); go(DISARMED, "Disarmed"); }
    else if (millis() - since > 5000) go(ALARM, "ALARM!");
  } else {
    digitalWrite(BUZZER, blink);
    if (blink) setRGB(255, 0, 0); else setRGB(0, 0, 0);
    if (hold) { digitalWrite(BUZZER, LOW); go(DISARMED, "Alarm cleared - disarmed"); }
  }
}
