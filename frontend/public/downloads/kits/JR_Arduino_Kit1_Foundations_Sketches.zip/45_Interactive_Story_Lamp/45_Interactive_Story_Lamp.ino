// ---- Circuit (Kit 1) ----
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 10k pot: ends to 5V and GND, wiper -> A0
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Passive piezo + -> D8, - -> GND
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BTN1 2
#define POT A0
#define SLIDE 7
#define PIEZO 8

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}
bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}

int scene = 0;
unsigned long since = 0;
unsigned long flashAt = 0;
bool flash = false;

void render(int s, int bright) {
  int r = 0, g = 0, b = 0;
  if (s == 0) { r = 255; g = 160; b = 60; }         // dawn
  else if (s == 1) { r = 20; g = 200; b = 60; }      // forest
  else if (s == 2) { r = 255; g = 70; b = 10; }      // sunset
  else {                                             // storm: dark blue with lightning
    r = 10; g = 10; b = 90;
    if (flash) { r = 255; g = 255; b = 255; }
  }
  setRGB(r * bright / 255, g * bright / 255, b * bright / 255);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Story lamp: button = next scene, slide HIGH = auto advance, pot = brightness");
}

void next() {
  scene = (scene + 1) % 4;
  since = millis();
  tone(PIEZO, 400 + scene * 150, 120);
  Serial.print("Scene "); Serial.println(scene);
}

void loop() {
  if (pressed()) next();
  if (digitalRead(SLIDE) == HIGH && millis() - since > 5000) next();
  if (scene == 3 && millis() > flashAt) {            // random lightning
    flash = !flash;
    flashAt = millis() + (flash ? 60 : random(400, 2500));
  }
  render(scene, map(analogRead(POT), 0, 1023, 20, 255));
  delay(10);
}
