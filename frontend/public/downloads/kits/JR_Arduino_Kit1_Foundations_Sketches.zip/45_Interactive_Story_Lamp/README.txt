Kit 1 - Foundations
Project 45: Interactive Story Lamp (Advanced)

Four colour scenes (dawn, forest, sunset, storm). Button = next, slide = auto-advance, pot = brightness.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Slide Switch SPDT x1
  Potentiometer 10k (rotary) x1
  Piezo Passive Buzzer x1

Circuit notes:
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  10k pot: ends to 5V and GND, wiper -> A0
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Passive piezo + -> D8, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-45-story-lamp
