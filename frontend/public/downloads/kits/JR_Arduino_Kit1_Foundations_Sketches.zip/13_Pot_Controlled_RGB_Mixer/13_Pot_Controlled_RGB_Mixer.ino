// ---- Circuit (Kit 1) ----
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// 10k pot: ends to 5V and GND, wiper -> A0
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define POT A0
#define BTN1 2

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}
bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}

int level[3] = {0, 0, 0};
int channel = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Button = next channel, pot = value");
}

void loop() {
  if (pressed()) {
    channel = (channel + 1) % 3;
    Serial.print("editing channel ");
    Serial.println(channel == 0 ? "RED" : (channel == 1 ? "GREEN" : "BLUE"));
  }
  level[channel] = analogRead(POT) / 4;
  setRGB(level[0], level[1], level[2]);
  delay(20);
}
