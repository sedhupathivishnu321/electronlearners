Kit 1 - Foundations
Project 13: Pot-Controlled RGB Mixer (Intermediate)

The button picks R, G or B; the pot sets that channel.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1

Circuit notes:
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  10k pot: ends to 5V and GND, wiper -> A0
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-13-rgb-mixer
