Kit 1 - Foundations
Project 43: Dark Room Intruder Logger (Advanced)

Watches for sudden light flashes in a dark room, logs severity and time over Serial, and beeps accordingly.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-43-intruder-logger
