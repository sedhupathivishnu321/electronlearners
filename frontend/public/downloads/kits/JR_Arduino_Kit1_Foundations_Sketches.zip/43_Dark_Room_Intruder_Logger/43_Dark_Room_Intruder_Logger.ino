// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define LDR A1
#define BUZZER 12
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

float baseline = 800;      // slow-moving average of the ambient level
int events = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  baseline = analogRead(LDR);
  Serial.println("Armed. Light flashes (LDR 'light level' slider) are logged. Button prints summary.");
}

void loop() {
  int v = analogRead(LDR);
  int jump = baseline - v;                   // positive = suddenly brighter
  digitalWrite(GREEN_LED, (millis() / 1000) % 2);     // heartbeat = monitoring
  if (jump > 120) {
    events++;
    int severity = jump > 400 ? 3 : (jump > 250 ? 2 : 1);
    Serial.print("["); Serial.print(millis() / 1000); Serial.print(" s] flash #"); Serial.print(events);
    Serial.print(" severity "); Serial.println(severity);
    for (int i = 0; i < severity; i++) {
      digitalWrite(BUZZER, HIGH); digitalWrite(RED_LED, HIGH); delay(120);
      digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW); delay(120);
    }
    delay(1500);
    baseline = analogRead(LDR);
  } else {
    baseline = baseline * 0.98 + v * 0.02;
  }
  if (digitalRead(BTN1) == LOW) {
    Serial.print("Summary: "); Serial.print(events); Serial.println(" events");
    delay(500);
  }
  delay(40);
}
