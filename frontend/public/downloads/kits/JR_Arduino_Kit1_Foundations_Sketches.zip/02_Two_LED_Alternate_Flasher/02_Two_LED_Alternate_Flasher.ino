// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define RED_LED 3
#define GREEN_LED 5

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
}

void loop() {
  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);
  delay(300);
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);
  delay(300);
}
