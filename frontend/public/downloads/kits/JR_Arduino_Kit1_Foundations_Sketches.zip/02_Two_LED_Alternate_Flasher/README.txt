Kit 1 - Foundations
Project 2: Two-LED Alternate Flasher (Basic)

Red and green flash alternately like a railway crossing.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-02-alternate
