// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// Passive piezo + -> D8, - -> GND
#define LDR A1
#define PIEZO 8

void setup() {
  Serial.begin(9600);
}

void loop() {
  int dark = analogRead(LDR);
  int freq = map(dark, 0, 1023, 2000, 200);   // brighter = higher pitch
  tone(PIEZO, freq);
  Serial.println(freq);
  delay(80);
}
