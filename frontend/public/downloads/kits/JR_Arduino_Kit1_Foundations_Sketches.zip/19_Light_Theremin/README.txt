Kit 1 - Foundations
Project 19: Light Theremin (Intermediate)

The light level on the LDR changes the pitch on the piezo.

Parts:
  Piezo Passive Buzzer x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  Passive piezo + -> D8, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-19-light-theremin
