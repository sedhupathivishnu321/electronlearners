// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Active buzzer + -> D12, - -> GND
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2
#define BUZZER 12

enum { CARS_GO, CARS_WAIT, CARS_STOP, WALK };
int state = CARS_GO;
unsigned long since = 0;
unsigned long lastTick = 0;
bool requested = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(GREEN_LED, HIGH);
  Serial.begin(9600);
  Serial.println("Cars: GO");
}

void loop() {
  if (digitalRead(BTN1) == LOW) requested = true;
  unsigned long t = millis() - since;

  if (state == CARS_GO && requested && t > 3000) {
    state = CARS_STOP; since = millis(); requested = false;
    digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH);
    Serial.println("Cars: STOP - pedestrians may cross");
  } else if (state == CARS_STOP && t > 1500) {
    state = WALK; since = millis();
  } else if (state == WALK) {
    if (millis() - lastTick > 300) {            // ticking while walk signal is on
      lastTick = millis();
      digitalWrite(BUZZER, !digitalRead(BUZZER));
    }
    if (t > 5000) {
      state = CARS_GO; since = millis();
      digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH);
      Serial.println("Cars: GO");
    }
  }
}
