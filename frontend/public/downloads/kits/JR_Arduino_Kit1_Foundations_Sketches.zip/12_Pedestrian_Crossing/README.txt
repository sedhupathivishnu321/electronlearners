Kit 1 - Foundations
Project 12: Pedestrian Crossing (Intermediate)

Press the button: cars stop, buzzer ticks, then traffic resumes.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Active buzzer + -> D12, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-12-pedestrian
