// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// 10k pot: ends to 5V and GND, wiper -> A0
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define LDR A1
#define POT A0
#define GREEN_LED 5

bool lampOn = false;

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int dark = analogRead(LDR);
  int threshold = analogRead(POT);
  if (!lampOn && dark > threshold + 25) lampOn = true;
  if (lampOn && dark < threshold - 25) lampOn = false;
  digitalWrite(GREEN_LED, lampOn);
  Serial.print("dark=");
  Serial.print(dark);
  Serial.print(" threshold=");
  Serial.print(threshold);
  Serial.println(lampOn ? " LAMP ON" : " lamp off");
  delay(250);
}
