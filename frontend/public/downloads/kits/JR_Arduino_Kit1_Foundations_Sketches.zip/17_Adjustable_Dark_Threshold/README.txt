Kit 1 - Foundations
Project 17: Adjustable Dark Threshold (Intermediate)

Pot sets the darkness level that switches the lamp; hysteresis avoids flicker.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Potentiometer 10k (rotary) x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  10k pot: ends to 5V and GND, wiper -> A0
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-17-dark-threshold
