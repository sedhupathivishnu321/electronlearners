Kit 1 - Foundations
Project 24: Reaction Timer (Intermediate)

Wait for the green LED and beep, press as fast as you can; time shown in ms.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Active buzzer + -> D12, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-24-reaction
