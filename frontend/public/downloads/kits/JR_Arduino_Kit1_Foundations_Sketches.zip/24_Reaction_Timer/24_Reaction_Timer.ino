// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Active buzzer + -> D12, - -> GND
#define BTN1 2
#define GREEN_LED 5
#define BUZZER 12

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Get ready... press the button when the LED lights.");
}

void loop() {
  delay(random(2000, 5000));
  if (digitalRead(BTN1) == LOW) {
    Serial.println("False start! Release the button.");
    while (digitalRead(BTN1) == LOW) { }
    delay(500);
    return;
  }
  digitalWrite(GREEN_LED, HIGH);
  digitalWrite(BUZZER, HIGH);
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == HIGH) { }
  unsigned long ms = millis() - t0;
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(BUZZER, LOW);
  Serial.print("Reaction time: ");
  Serial.print(ms);
  Serial.println(" ms");
  while (digitalRead(BTN1) == LOW) { }
  delay(1500);
}
