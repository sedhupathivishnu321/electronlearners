// ---- Circuit (Kit 1) ----
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
#define SLIDE 7
#define RED_LED 3

unsigned long last = 0;
bool on = false;

void setup() {
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int interval = (digitalRead(SLIDE) == LOW) ? 800 : 150;
  if (millis() - last >= interval) {
    last = millis();
    on = !on;
    digitalWrite(RED_LED, on);
  }
}
