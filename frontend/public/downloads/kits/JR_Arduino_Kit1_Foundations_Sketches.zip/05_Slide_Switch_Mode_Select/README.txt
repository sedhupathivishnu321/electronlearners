Kit 1 - Foundations
Project 5: Slide-Switch Mode Select (Basic)

The slide switch picks a slow or fast blink (click the lever while running).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Slide Switch SPDT x1

Circuit notes:
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-05-slide-mode
