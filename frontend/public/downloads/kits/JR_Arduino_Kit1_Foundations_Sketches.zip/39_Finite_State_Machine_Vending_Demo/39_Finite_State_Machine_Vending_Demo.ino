// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 10k pot: ends to 5V and GND, wiper -> A0
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Passive piezo + -> D8, - -> GND
#define BTN1 2
#define POT A0
#define RED_LED 3
#define GREEN_LED 5
#define PIEZO 8

enum { IDLE, COINS, DISPENSE, REFUND };
int state = IDLE;
int coins = 0;
int price = 3;
int lastBtn = HIGH;
unsigned long since = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("Vending demo: pot = item price (1-5), button = insert a coin");
}

void loop() {
  price = map(analogRead(POT), 0, 1023, 1, 5);
  int b = digitalRead(BTN1);
  bool coin = (lastBtn == HIGH && b == LOW);
  lastBtn = b;
  if (coin) delay(30);

  if (state == IDLE || state == COINS) {
    if (coin) {
      coins++; since = millis(); state = COINS;
      tone(PIEZO, 880, 80);
      Serial.print("coins "); Serial.print(coins); Serial.print(" / price "); Serial.println(price);
    }
    if (state == COINS && coins >= price) { state = DISPENSE; since = millis(); Serial.println("Dispensing item"); }
    else if (state == COINS && millis() - since > 6000) { state = REFUND; since = millis(); Serial.println("Timeout - refund"); }
  }
  if (state == DISPENSE) {
    digitalWrite(GREEN_LED, (millis() / 150) % 2);
    if (millis() - since > 1500) {
      digitalWrite(GREEN_LED, LOW);
      int change = coins - price;
      coins = 0;
      if (change > 0) { Serial.print("Change: "); Serial.println(change); state = REFUND; since = millis(); coins = change; }
      else state = IDLE;
    }
  }
  if (state == REFUND) {
    digitalWrite(RED_LED, (millis() / 150) % 2);
    if (millis() - since > 1200) { digitalWrite(RED_LED, LOW); coins = 0; state = IDLE; Serial.println("Ready"); }
  }
}
