Kit 1 - Foundations
Project 39: Finite-State-Machine Vending Demo (Advanced)

Button = coin, pot picks the item price; the machine dispenses and returns change.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1
  Piezo Passive Buzzer x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  10k pot: ends to 5V and GND, wiper -> A0
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Passive piezo + -> D8, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-39-vending
