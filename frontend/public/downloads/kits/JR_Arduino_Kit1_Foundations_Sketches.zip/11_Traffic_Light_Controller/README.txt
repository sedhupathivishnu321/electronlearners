Kit 1 - Foundations
Project 11: Traffic Light Controller (Intermediate)

Green, yellow and red LEDs in a timed non-blocking state machine.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Yellow LED anode -> 220 ohm -> D6 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-11-traffic
