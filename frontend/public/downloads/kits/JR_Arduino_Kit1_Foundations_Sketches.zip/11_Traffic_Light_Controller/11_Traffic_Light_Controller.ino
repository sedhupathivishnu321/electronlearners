// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Yellow LED anode -> 220 ohm -> D6 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define RED_LED 3
#define YELLOW_LED 6
#define GREEN_LED 5

enum { GO, AMBER, STOP };
int state = GO;
unsigned long since = 0;

void show() {
  digitalWrite(GREEN_LED, state == GO);
  digitalWrite(RED_LED, state == STOP);
  digitalWrite(YELLOW_LED, state == AMBER);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  Serial.begin(9600);
  show();
}

void loop() {
  unsigned long dwell = (state == AMBER) ? 1500 : 4000;
  if (millis() - since >= dwell) {
    since = millis();
    if (state == GO) state = AMBER;
    else if (state == AMBER) state = STOP;
    else state = GO;
    show();
    Serial.println(state == GO ? "GO" : (state == AMBER ? "AMBER" : "STOP"));
  }
}
