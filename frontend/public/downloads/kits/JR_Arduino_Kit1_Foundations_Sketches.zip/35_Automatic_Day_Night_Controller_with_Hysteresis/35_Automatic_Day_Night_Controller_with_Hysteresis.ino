// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// 10k pot: ends to 5V and GND, wiper -> A0
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define LDR A1
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define POT A0
#define BTN1 2

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}
bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}

bool night = false;
int override = 0;           // 0 auto, 1 force on, 2 force off
float level = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Button cycles: AUTO / FORCE ON / FORCE OFF");
}

void loop() {
  if (pressed()) {
    override = (override + 1) % 3;
    Serial.println(override == 0 ? "AUTO" : (override == 1 ? "FORCE ON" : "FORCE OFF"));
  }
  int dark = analogRead(LDR);
  int threshold = map(analogRead(POT), 0, 1023, 300, 800);
  if (!night && dark > threshold + 30) { night = true; Serial.println("Night - lamp fading in"); }
  if (night && dark < threshold - 30) { night = false; Serial.println("Day - lamp fading out"); }

  bool want = (override == 0) ? night : (override == 1);
  float target = want ? 1.0 : 0.0;
  level += (target - level) * 0.03;                  // smooth fade
  setRGB(level * 255, level * 150, level * 40);      // warm white
  delay(20);
}
