Kit 1 - Foundations
Project 35: Automatic Day/Night Controller with Hysteresis (Advanced)

A warm RGB lamp fades in at night with pot-set sensitivity; the button overrides.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  10k pot: ends to 5V and GND, wiper -> A0
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-35-day-night
