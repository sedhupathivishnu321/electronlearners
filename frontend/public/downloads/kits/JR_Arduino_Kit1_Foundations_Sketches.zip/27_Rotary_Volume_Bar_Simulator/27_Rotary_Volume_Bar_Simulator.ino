// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define POT A0
#define RED_LED 3
#define GREEN_LED 5

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int pct = map(analogRead(POT), 0, 1023, 0, 100);
  digitalWrite(GREEN_LED, pct >= 25);
  digitalWrite(RED_LED, pct >= 75);            // red = "too loud"
  Serial.print("[");
  for (int i = 0; i < 10; i++) Serial.print(i < pct / 10 ? "#" : "-");
  Serial.print("] ");
  Serial.print(pct);
  Serial.println("%");
  delay(250);
}
