Kit 1 - Foundations
Project 27: Rotary Volume Bar Simulator (Intermediate)

Pot value shown as percent, a text bar and a 2-LED level indicator.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Potentiometer 10k (rotary) x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-27-level-bar
