// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
#define RED_LED 3
#define GREEN_LED 5
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Commands:  r1 / r0  red LED,  g1 / g0  green LED,  c R G B  RGB colour (0-255)");
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    if (cmd == 'r') {
      int v = Serial.parseInt();
      digitalWrite(RED_LED, v);
      Serial.println(v ? "red ON" : "red OFF");
    } else if (cmd == 'g') {
      int v = Serial.parseInt();
      digitalWrite(GREEN_LED, v);
      Serial.println(v ? "green ON" : "green OFF");
    } else if (cmd == 'c') {
      int r = Serial.parseInt();
      int g = Serial.parseInt();
      int b = Serial.parseInt();
      setRGB(r, g, b);
      Serial.print("rgb = ");
      Serial.print(r); Serial.print(", ");
      Serial.print(g); Serial.print(", ");
      Serial.println(b);
    }
  }
}
