Kit 1 - Foundations
Project 30: Serial LED Command Console (Intermediate)

Type commands in the Serial tab: r1, g0, c 255 0 40 (RGB colour).

Parts:
  Resistor 220 ohm 1/4W x5
  LED 5mm Red x1
  LED 5mm Green x1
  RGB LED common cathode 5mm x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-30-serial-console
