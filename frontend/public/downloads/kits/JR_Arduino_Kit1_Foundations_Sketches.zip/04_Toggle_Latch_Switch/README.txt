Kit 1 - Foundations
Project 4: Toggle Latch Switch (Basic)

Each press toggles the green LED; edge detection with debounce.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-04-toggle
