// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define BTN1 2
#define GREEN_LED 5

bool state = false;
int last = HIGH;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int now = digitalRead(BTN1);
  if (last == HIGH && now == LOW) {
    state = !state;
    digitalWrite(GREEN_LED, state);
    Serial.println(state ? "latched ON" : "latched OFF");
    delay(30);
  }
  last = now;
}
