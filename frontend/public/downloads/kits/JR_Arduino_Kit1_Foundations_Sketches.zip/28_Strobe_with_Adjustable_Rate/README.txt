Kit 1 - Foundations
Project 28: Strobe with Adjustable Rate (Intermediate)

Pot sets 1-20 Hz; the slide switch picks the red or green LED.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Slide Switch SPDT x1
  Potentiometer 10k (rotary) x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-28-strobe
