// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define POT A0
#define SLIDE 7
#define RED_LED 3
#define GREEN_LED 5

unsigned long last = 0;
bool on = false;

void setup() {
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int hz = map(analogRead(POT), 0, 1023, 1, 20);
  int half = 500 / hz;
  if (millis() - last >= half) {
    last = millis();
    on = !on;
    int led = (digitalRead(SLIDE) == LOW) ? RED_LED : GREEN_LED;
    int other = (led == RED_LED) ? GREEN_LED : RED_LED;
    digitalWrite(other, LOW);
    digitalWrite(led, on);
  }
}
