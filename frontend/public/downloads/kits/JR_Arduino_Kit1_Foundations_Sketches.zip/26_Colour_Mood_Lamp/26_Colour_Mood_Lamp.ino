// ---- Circuit (Kit 1) ----
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BTN1 2

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}
bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}

float hue = 0;
bool frozen = false;

void hsv(float h) {
  float x = h * 6.0;
  int seg = (int)x;
  float f = x - seg;
  int up = (int)(f * 255);
  int down = 255 - up;
  if (seg == 0) setRGB(255, up, 0);
  else if (seg == 1) setRGB(down, 255, 0);
  else if (seg == 2) setRGB(0, 255, up);
  else if (seg == 3) setRGB(0, down, 255);
  else if (seg == 4) setRGB(up, 0, 255);
  else setRGB(255, 0, down);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    frozen = !frozen;
    Serial.println(frozen ? "colour frozen" : "drifting");
  }
  if (!frozen) {
    hue += 0.002;
    if (hue >= 1.0) hue = 0;
  }
  hsv(hue);
  delay(15);
}
