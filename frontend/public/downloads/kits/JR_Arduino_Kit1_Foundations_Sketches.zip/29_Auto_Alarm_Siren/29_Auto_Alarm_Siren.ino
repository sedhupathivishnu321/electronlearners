// ---- Circuit (Kit 1) ----
// Passive piezo + -> D8, - -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define PIEZO 8
#define BTN1 2

int f = 600;
int step = 20;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    tone(PIEZO, f);
    f += step;
    if (f >= 1200 || f <= 600) step = -step;
    delay(8);
  } else {
    noTone(PIEZO);
    f = 600;
    step = 20;
  }
}
