Kit 1 - Foundations
Project 29: Auto Alarm Siren (Intermediate)

Hold the button: a two-tone siren sweeps up and down on the piezo.

Parts:
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1

Circuit notes:
  Passive piezo + -> D8, - -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-29-siren
