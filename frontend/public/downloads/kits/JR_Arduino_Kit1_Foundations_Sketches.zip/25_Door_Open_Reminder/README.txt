Kit 1 - Foundations
Project 25: Door-Open Reminder (Intermediate)

The slide switch is a door contact: left open for 5 s and the buzzer reminds you.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Slide Switch SPDT x1
  Buzzer Active 5V x1

Circuit notes:
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-25-door-reminder
