// ---- Circuit (Kit 1) ----
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
#define SLIDE 7
#define BUZZER 12
#define RED_LED 3

unsigned long openSince = 0;
bool wasOpen = false;

void setup() {
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Slide switch: LOW = door closed, HIGH = door open");
}

void loop() {
  bool open = (digitalRead(SLIDE) == HIGH);
  if (open && !wasOpen) { openSince = millis(); Serial.println("Door opened"); }
  if (!open && wasOpen) { Serial.println("Door closed"); }
  wasOpen = open;

  digitalWrite(RED_LED, open);
  if (open && millis() - openSince > 5000) {
    digitalWrite(BUZZER, (millis() / 500) % 2);      // reminder beeps
  } else {
    digitalWrite(BUZZER, LOW);
  }
}
