// ---- Circuit (Kit 1) ----
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

int colours[7][3] = {
  {255, 0, 0}, {0, 255, 0}, {0, 0, 255}, {255, 180, 0}, {0, 255, 255}, {255, 0, 255}, {255, 255, 255}
};

void setup() {
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  for (int i = 0; i < 7; i++) {
    setRGB(colours[i][0], colours[i][1], colours[i][2]);
    Serial.print("colour ");
    Serial.println(i);
    delay(700);
  }
}
