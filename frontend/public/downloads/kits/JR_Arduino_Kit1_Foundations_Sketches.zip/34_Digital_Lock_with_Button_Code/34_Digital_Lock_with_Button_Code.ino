// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Active buzzer + -> D12, - -> GND
#define BTN1 2
#define RED_LED 3
#define GREEN_LED 5
#define BUZZER 12

// code: S L S S  (0 = short press, 1 = long press >= 400 ms)
int secret[4] = {0, 1, 0, 0};
int entry[4];
int count = 0;
unsigned long lastPress = 0;

void alarm() {
  Serial.println("WRONG CODE - ALARM");
  for (int i = 0; i < 6; i++) {
    digitalWrite(BUZZER, HIGH); digitalWrite(RED_LED, HIGH); delay(120);
    digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW); delay(120);
  }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  digitalWrite(RED_LED, HIGH);                     // locked
  Serial.begin(9600);
  Serial.println("LOCKED. Enter code: short, long, short, short");
}

void loop() {
  if (count > 0 && millis() - lastPress > 4000) { count = 0; Serial.println("timeout - code cleared"); }
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW) { }
    int isLong = (millis() - t0 >= 400) ? 1 : 0;
    entry[count++] = isLong;
    lastPress = millis();
    Serial.println(isLong ? "L" : "S");
    delay(40);
    if (count == 4) {
      bool ok = true;
      for (int i = 0; i < 4; i++) if (entry[i] != secret[i]) ok = false;
      count = 0;
      if (ok) {
        Serial.println("UNLOCKED");
        digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH);
        delay(3000);
        digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH);
        Serial.println("LOCKED again");
      } else alarm();
      digitalWrite(RED_LED, HIGH);
    }
  }
}
