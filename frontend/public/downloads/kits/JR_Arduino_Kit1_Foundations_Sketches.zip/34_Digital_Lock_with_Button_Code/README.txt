Kit 1 - Foundations
Project 34: Digital Lock with Button Code (Advanced)

Unlock with a short-long-short-short press code; wrong code sounds the alarm.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Active buzzer + -> D12, - -> GND
  code: S L S S  (0 = short press, 1 = long press >= 400 ms)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-34-code-lock
