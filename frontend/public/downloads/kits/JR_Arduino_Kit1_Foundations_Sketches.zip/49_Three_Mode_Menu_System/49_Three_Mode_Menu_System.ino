// ---- Circuit (Kit 1) ----
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
#define SLIDE 7
#define BTN1 2
#define RED_LED 3
#define GREEN_LED 5
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}
bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}

int mode = 0;
int phase = 0;
unsigned long last = 0;

void blinkMode(int n) {                    // announce the mode with n red blinks
  for (int i = 0; i < n; i++) {
    digitalWrite(RED_LED, HIGH); delay(150);
    digitalWrite(RED_LED, LOW); delay(150);
  }
}

void allOff() {
  digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, LOW); setRGB(0, 0, 0);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP); pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Button = next program, slide switch = speed");
  blinkMode(1);
}

void loop() {
  if (pressed()) {
    mode = (mode + 1) % 3;
    allOff();
    Serial.print("Program "); Serial.println(mode + 1);
    blinkMode(mode + 1);
    phase = 0;
  }
  int step = (digitalRead(SLIDE) == LOW) ? 400 : 120;
  if (millis() - last >= step) {
    last = millis();
    phase++;
    if (mode == 0) {                                   // alternate
      digitalWrite(RED_LED, phase % 2); digitalWrite(GREEN_LED, (phase + 1) % 2);
    } else if (mode == 1) {                            // colour fade steps
      int c = phase % 6;
      if (c == 0) setRGB(255, 0, 0); else if (c == 1) setRGB(255, 160, 0); else if (c == 2) setRGB(0, 255, 0);
      else if (c == 3) setRGB(0, 255, 255); else if (c == 4) setRGB(0, 0, 255); else setRGB(255, 0, 255);
    } else {                                           // chaser across 4 outputs
      int c = phase % 4;
      digitalWrite(RED_LED, c == 0); digitalWrite(GREEN_LED, c == 1);
      setRGB(c == 2 ? 255 : 0, 0, c == 3 ? 255 : 0);
    }
  }
}
