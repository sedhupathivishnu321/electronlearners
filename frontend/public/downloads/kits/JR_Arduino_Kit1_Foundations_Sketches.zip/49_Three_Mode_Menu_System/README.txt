Kit 1 - Foundations
Project 49: Three-Mode Menu System (Advanced)

Button = next LED program (alternate / colour fade / chaser); slide switch = slow / fast; mode shown by blink count.

Parts:
  Resistor 220 ohm 1/4W x5
  LED 5mm Red x1
  LED 5mm Green x1
  RGB LED common cathode 5mm x1
  Push Button tactile 6x6 x1
  Slide Switch SPDT x1

Circuit notes:
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-49-menu
