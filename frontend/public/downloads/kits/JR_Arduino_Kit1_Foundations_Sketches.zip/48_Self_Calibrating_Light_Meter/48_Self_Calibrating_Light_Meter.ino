// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define LDR A1
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

int lo = 1023, hi = 0;
bool calibrating = true;
unsigned long calStart = 0;

void startCal() {
  lo = 1023; hi = 0; calibrating = true; calStart = millis();
  Serial.println("Calibrating for 5 s: move the LDR light slider from dark to bright...");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  startCal();
}

void loop() {
  int v = 1023 - analogRead(LDR);                // convert to "brightness"
  if (calibrating) {
    if (v < lo) lo = v;
    if (v > hi) hi = v;
    digitalWrite(RED_LED, (millis() / 200) % 2);
    digitalWrite(GREEN_LED, (millis() / 200) % 2);
    if (millis() - calStart > 5000) {
      calibrating = false;
      digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, LOW);
      Serial.print("Range "); Serial.print(lo); Serial.print(" .. "); Serial.println(hi);
    }
  } else {
    int pct = 0;
    if (hi > lo) pct = constrain(map(v, lo, hi, 0, 100), 0, 100);
    digitalWrite(RED_LED, pct > 33);
    digitalWrite(GREEN_LED, pct > 66);
    Serial.print("light "); Serial.print(pct); Serial.println("%");
    if (digitalRead(BTN1) == LOW) { startCal(); delay(300); }
  }
  delay(150);
}
