Kit 1 - Foundations
Project 16: LDR Night Lamp (Intermediate)

The green lamp turns on automatically when the LDR reading says it is dark.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-16-ldr-lamp
