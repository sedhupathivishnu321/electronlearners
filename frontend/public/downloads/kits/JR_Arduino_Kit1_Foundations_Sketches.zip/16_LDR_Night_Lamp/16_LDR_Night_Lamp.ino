// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define LDR A1
#define GREEN_LED 5

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int dark = analogRead(LDR);              // module: higher value = darker
  digitalWrite(GREEN_LED, dark > 600);
  Serial.print("darkness=");
  Serial.println(dark);
  delay(200);
}
