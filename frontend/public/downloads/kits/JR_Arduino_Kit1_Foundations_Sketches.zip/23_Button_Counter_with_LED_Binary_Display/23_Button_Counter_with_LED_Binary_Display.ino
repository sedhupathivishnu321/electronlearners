// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}
int count = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    count = (count + 1) % 4;
    digitalWrite(RED_LED, count & 1);
    digitalWrite(GREEN_LED, (count >> 1) & 1);
    Serial.print("count = ");
    Serial.print(count);
    Serial.print("  binary = ");
    Serial.print((count >> 1) & 1);
    Serial.println(count & 1);
  }
}
