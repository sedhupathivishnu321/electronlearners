// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
#define LDR A1
#define BUZZER 12
#define RED_LED 3
#define BTN1 2
#define SLIDE 7

bool armed = false;
bool tripped = false;
int beamLevel = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Slide switch HIGH = ARM. Alarm resets with switch LOW then button.");
}

void loop() {
  bool want = digitalRead(SLIDE) == HIGH;
  if (want && !armed) {
    delay(300);
    beamLevel = analogRead(LDR);                       // learn the normal beam level
    armed = true; tripped = false;
    Serial.print("ARMED, beam level = "); Serial.println(beamLevel);
  }
  if (!want && armed) { armed = false; Serial.println("DISARMED"); }

  if (armed && !tripped && analogRead(LDR) > beamLevel + 150) {
    tripped = true;
    Serial.println("BEAM BROKEN - ALARM!");
  }
  if (tripped) {
    digitalWrite(BUZZER, (millis() / 150) % 2);
    digitalWrite(RED_LED, (millis() / 150) % 2);
    if (!armed && digitalRead(BTN1) == LOW) {          // disarm switch + button = reset
      tripped = false;
      digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW);
      Serial.println("Alarm reset");
    }
  } else {
    digitalWrite(BUZZER, LOW);
    digitalWrite(RED_LED, LOW);
  }
}
