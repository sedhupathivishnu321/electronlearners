Kit 1 - Foundations
Project 37: Light-Following Tone Alarm (Security Beam) (Advanced)

Arm with the slide switch; breaking the light beam latches the alarm until reset.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Push Button tactile 6x6 x1
  Slide Switch SPDT x1
  Buzzer Active 5V x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-37-beam-alarm
