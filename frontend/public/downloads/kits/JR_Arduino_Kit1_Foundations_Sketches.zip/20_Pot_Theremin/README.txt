Kit 1 - Foundations
Project 20: Pot Theremin (Intermediate)

The pot sets a continuous pitch; the button silences it.

Parts:
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1
  Piezo Passive Buzzer x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Passive piezo + -> D8, - -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-20-pot-theremin
