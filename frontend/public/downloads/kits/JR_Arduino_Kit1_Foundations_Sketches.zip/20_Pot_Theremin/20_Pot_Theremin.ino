// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Passive piezo + -> D8, - -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define POT A0
#define PIEZO 8
#define BTN1 2

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
}

void loop() {
  int freq = map(analogRead(POT), 0, 1023, 150, 2000);
  if (digitalRead(BTN1) == LOW) noTone(PIEZO);
  else tone(PIEZO, freq);
  Serial.println(freq);
  delay(60);
}
