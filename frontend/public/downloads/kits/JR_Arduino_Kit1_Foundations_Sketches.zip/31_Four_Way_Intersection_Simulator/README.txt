Kit 1 - Foundations
Project 31: Four-Way Intersection Simulator (Advanced)

Two-road signal with pedestrian request, ticking buzzer and automatic night flashing from the LDR (or the slide switch).

Parts:
  Resistor 220 ohm 1/4W x5
  LED 5mm Red x1
  LED 5mm Green x1
  RGB LED common cathode 5mm x1
  Push Button tactile 6x6 x1
  Slide Switch SPDT x1
  Buzzer Active 5V x1
  LDR Light Sensor Module x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
  Active buzzer + -> D12, - -> GND
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  Road A uses the red/green LEDs. Road B uses the RGB LED (red / amber / green).

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-31-intersection
