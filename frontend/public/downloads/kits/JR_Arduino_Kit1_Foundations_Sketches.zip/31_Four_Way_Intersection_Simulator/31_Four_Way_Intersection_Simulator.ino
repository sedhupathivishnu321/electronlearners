// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Slide switch COM -> D7, one side -> GND (INPUT_PULLUP: LOW = side 1, HIGH = side 2)
// Active buzzer + -> D12, - -> GND
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
#define RED_LED 3
#define GREEN_LED 5
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BTN1 2
#define SLIDE 7
#define BUZZER 12
#define LDR A1

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

// Road A uses the red/green LEDs. Road B uses the RGB LED (red / amber / green).
enum { A_GO, A_AMBER, ALL_RED_1, B_GO, B_AMBER, ALL_RED_2, FLASH };
int state = ALL_RED_1;
unsigned long since = 0;
bool pedRequest = false;
unsigned long tick = 0;

void roadA(bool red, bool green) { digitalWrite(RED_LED, red); digitalWrite(GREEN_LED, green); }
void roadB(int r) {            // 0 red, 1 amber, 2 green, 3 off
  if (r == 0) setRGB(255, 0, 0);
  else if (r == 1) setRGB(255, 90, 0);
  else if (r == 2) setRGB(0, 255, 0);
  else setRGB(0, 0, 0);
}

void apply() {
  if (state == A_GO) { roadA(false, true); roadB(0); }
  else if (state == A_AMBER) { roadA(false, false); roadB(0); }
  else if (state == B_GO) { roadA(true, false); roadB(2); }
  else if (state == B_AMBER) { roadA(true, false); roadB(1); }
  else if (state == ALL_RED_1 || state == ALL_RED_2) { roadA(true, false); roadB(0); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(SLIDE, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  apply();
}

void loop() {
  bool night = analogRead(LDR) > 750 || digitalRead(SLIDE) == HIGH;    // dark or forced flash mode
  if (digitalRead(BTN1) == LOW) pedRequest = true;

  if (night) {
    if (state != FLASH) { state = FLASH; Serial.println("NIGHT MODE: flashing amber"); }
    bool on = (millis() / 500) % 2;
    roadA(false, false);
    if (on) setRGB(255, 90, 0); else setRGB(0, 0, 0);
    digitalWrite(BUZZER, LOW);
    return;
  }
  if (state == FLASH) { state = ALL_RED_1; since = millis(); apply(); Serial.println("DAY MODE"); }

  unsigned long dwell = 4000;
  if (state == A_AMBER || state == B_AMBER) dwell = 1500;
  if (state == ALL_RED_1 || state == ALL_RED_2) dwell = pedRequest ? 6000 : 1000;   // long red = pedestrian walk
  if (millis() - since >= dwell) {
    since = millis();
    state = (state + 1) % 6;
    if (state == A_GO || state == B_GO) pedRequest = false;
    apply();
    Serial.print("phase "); Serial.println(state);
  }
  bool walking = (state == ALL_RED_1 || state == ALL_RED_2) && pedRequest;
  if (walking && millis() - tick > 250) { tick = millis(); digitalWrite(BUZZER, !digitalRead(BUZZER)); }
  if (!walking) digitalWrite(BUZZER, LOW);
}
