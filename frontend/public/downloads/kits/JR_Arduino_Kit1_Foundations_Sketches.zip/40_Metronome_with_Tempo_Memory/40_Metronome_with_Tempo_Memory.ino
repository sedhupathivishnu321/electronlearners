// ---- Circuit (Kit 1) ----
// 10k pot: ends to 5V and GND, wiper -> A0
// Passive piezo + -> D8, - -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define POT A0
#define PIEZO 8
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BTN1 2

#include <EEPROM.h>
void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

int bpm = 100;
int beat = 0;
unsigned long next = 0;
int lastShown = 0;
int lastBtn = HIGH;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  int saved = EEPROM.read(0);
  if (saved >= 40 && saved <= 208) Serial.print("Saved tempo: ");
  if (saved >= 40 && saved <= 208) Serial.println(saved);
  Serial.println("Pot = tempo, button = save tempo");
}

void loop() {
  bpm = map(analogRead(POT), 0, 1023, 40, 208);
  if (abs(bpm - lastShown) >= 3) { lastShown = bpm; Serial.print("BPM "); Serial.println(bpm); }

  int b = digitalRead(BTN1);
  if (lastBtn == HIGH && b == LOW) { EEPROM.write(0, bpm); Serial.print("Saved "); Serial.println(bpm); delay(30); }
  lastBtn = b;

  if (millis() >= next) {
    next = millis() + 60000UL / bpm;
    bool accent = (beat % 4 == 0);
    tone(PIEZO, accent ? 1200 : 800, 40);
    if (accent) setRGB(255, 0, 0); else setRGB(0, 0, 255);
    beat++;
  }
  if (millis() > next - 60000UL / bpm + 70) setRGB(0, 0, 0);       // flash lasts ~70 ms
}
