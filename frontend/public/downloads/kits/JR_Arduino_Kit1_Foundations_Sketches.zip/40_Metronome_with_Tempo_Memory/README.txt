Kit 1 - Foundations
Project 40: Metronome with Tempo Memory (Advanced)

Pot sets 40-208 BPM; accent every 4th beat; the button stores the tempo in EEPROM.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1
  Piezo Passive Buzzer x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0
  Passive piezo + -> D8, - -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-40-metronome
