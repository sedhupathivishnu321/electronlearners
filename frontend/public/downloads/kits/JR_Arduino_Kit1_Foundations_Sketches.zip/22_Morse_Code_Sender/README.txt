Kit 1 - Foundations
Project 22: Morse Code Sender (Intermediate)

Type text in the Serial tab and it is blinked and beeped as Morse.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Active buzzer + -> D12, - -> GND
  A-Z, codes separated by '|'

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-22-morse
