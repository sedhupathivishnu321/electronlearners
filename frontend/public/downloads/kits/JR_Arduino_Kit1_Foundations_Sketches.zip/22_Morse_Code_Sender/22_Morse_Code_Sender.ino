// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Active buzzer + -> D12, - -> GND
#define RED_LED 3
#define BUZZER 12

// A-Z, codes separated by '|'
String table = ".-|-...|-.-.|-..|.|..-.|--.|....|..|.---|-.-|.-..|--|-.|---|.--.|--.-|.-.|...|-|..-|...-|.--|-..-|-.--|--..";
int UNIT = 120;

String lookup(int index) {                 // pick the index-th code out of the table
  int start = 0;
  for (int i = 0; i < index; i++) start = table.indexOf('|', start) + 1;
  int end = table.indexOf('|', start);
  if (end < 0) end = table.length();
  return table.substring(start, end);
}

void signal(int ms) {
  digitalWrite(RED_LED, HIGH);
  digitalWrite(BUZZER, HIGH);
  delay(ms);
  digitalWrite(RED_LED, LOW);
  digitalWrite(BUZZER, LOW);
  delay(UNIT);
}

void sendLetter(char c) {
  if (c == ' ') { delay(UNIT * 4); return; }
  if (c >= 'a' && c <= 'z') c = c - 32;
  if (c < 'A' || c > 'Z') return;
  String code = lookup(c - 'A');
  Serial.print(c);
  Serial.print(" ");
  Serial.println(code);
  for (int i = 0; i < code.length(); i++) {
    if (code.charAt(i) == '.') signal(UNIT); else signal(UNIT * 3);
  }
  delay(UNIT * 2);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Type text and press Send. Sending SOS first:");
  sendLetter('S'); sendLetter('O'); sendLetter('S');
}

void loop() {
  while (Serial.available() > 0) sendLetter(Serial.read());
}
