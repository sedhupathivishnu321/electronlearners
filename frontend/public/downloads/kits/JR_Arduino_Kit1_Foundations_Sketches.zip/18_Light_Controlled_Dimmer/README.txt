Kit 1 - Foundations
Project 18: Light-Controlled Dimmer (Intermediate)

The darker the room, the brighter the red LED.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-18-ldr-dimmer
