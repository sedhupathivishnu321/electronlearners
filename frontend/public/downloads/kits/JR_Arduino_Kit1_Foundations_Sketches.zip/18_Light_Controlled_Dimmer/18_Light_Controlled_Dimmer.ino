// ---- Circuit (Kit 1) ----
// LDR module: VCC -> 5V, GND -> GND, AO -> A1 (bright = low reading, dark = high)
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
#define LDR A1
#define RED_LED 3

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int dark = analogRead(LDR);
  analogWrite(RED_LED, dark / 4);
  Serial.println(dark);
  delay(100);
}
