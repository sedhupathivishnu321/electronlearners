// ---- Circuit (Kit 1) ----
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Active buzzer + -> D12, - -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 10k pot: ends to 5V and GND, wiper -> A0
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BUZZER 12
#define BTN1 2
#define POT A0

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}
bool pressedLast = HIGH;
bool pressed() {
  bool now = digitalRead(BTN1);
  bool hit = (pressedLast == HIGH && now == LOW);
  pressedLast = now;
  if (hit) delay(25);
  return hit;
}

enum { WAITING, RISING, RINGING };
int state = WAITING;
unsigned long since = 0;
unsigned long riseMs = 20000;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Pot sets sunrise duration (10-60 s). Press the button to start the sunrise.");
}

void loop() {
  if (state == WAITING) {
    setRGB(0, 0, 0);
    if (pressed()) {
      riseMs = map(analogRead(POT), 0, 1023, 10, 60) * 1000UL;
      state = RISING; since = millis();
      Serial.print("Sunrise started, "); Serial.print(riseMs / 1000); Serial.println(" s");
    }
  } else if (state == RISING) {
    float p = (float)(millis() - since) / riseMs;       // 0..1
    if (p >= 1.0) { state = RINGING; since = millis(); Serial.println("GOOD MORNING!"); return; }
    setRGB(255 * p, 140 * p * p, 40 * p * p * p);       // red -> orange -> warm white
    if (pressed()) { state = WAITING; Serial.println("cancelled"); }
  } else {
    setRGB(255, 200, 120);
    digitalWrite(BUZZER, (millis() / 300) % 2);
    if (pressed()) {
      digitalWrite(BUZZER, LOW);
      state = WAITING;
      Serial.println("stopped");
    }
  }
}
