Kit 1 - Foundations
Project 47: Sunrise Alarm Clock Simulator (Advanced)

The RGB lamp slowly brightens over a pot-set time, then the buzzer wakes you; button = snooze / stop.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1
  Potentiometer 10k (rotary) x1
  Buzzer Active 5V x1

Circuit notes:
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Active buzzer + -> D12, - -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  10k pot: ends to 5V and GND, wiper -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-47-sunrise-alarm
