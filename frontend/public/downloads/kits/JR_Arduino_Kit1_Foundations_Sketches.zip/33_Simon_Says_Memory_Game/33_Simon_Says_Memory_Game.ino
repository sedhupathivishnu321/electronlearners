// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Second push button between D4 and GND (INPUT_PULLUP)
// Passive piezo + -> D8, - -> GND
#define RED_LED 3
#define GREEN_LED 5
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11
#define BTN1 2
#define BTN2 4
#define PIEZO 8

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

int seq[32];
int level = 0;

void flash(int which) {                 // 0 = red (button 1), 1 = green (button 2)
  int led = which == 0 ? RED_LED : GREEN_LED;
  digitalWrite(led, HIGH);
  tone(PIEZO, which == 0 ? 330 : 523, 250);
  delay(300);
  digitalWrite(led, LOW);
  delay(150);
}

int waitInput() {
  while (true) {
    if (digitalRead(BTN1) == LOW) { while (digitalRead(BTN1) == LOW) { } delay(30); return 0; }
    if (digitalRead(BTN2) == LOW) { while (digitalRead(BTN2) == LOW) { } delay(30); return 1; }
  }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP); pinMode(BTN2, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("Simon: watch, then repeat. Red button = red, black button = green.");
  delay(1500);
}

void loop() {
  seq[level] = random(0, 2);
  level++;
  setRGB(0, 0, 40 + level * 10);        // blue grows brighter with each level
  for (int i = 0; i < level; i++) flash(seq[i]);
  Serial.print("Level "); Serial.println(level);
  for (int i = 0; i < level; i++) {
    int pressed = waitInput();
    flash(pressed);
    if (pressed != seq[i]) {
      Serial.print("Wrong! You reached level "); Serial.println(level - 1);
      setRGB(255, 0, 0);
      tone(PIEZO, 120, 800);
      delay(1500);
      level = 0;
      return;
    }
  }
  delay(600);
}
