Kit 1 - Foundations
Project 33: Simon Says Memory Game (Advanced)

Repeat the growing red/green pattern with the two buttons; RGB shows your level.

Parts:
  Resistor 220 ohm 1/4W x5
  LED 5mm Red x1
  LED 5mm Green x1
  RGB LED common cathode 5mm x1
  Push Button tactile 6x6 x2
  Piezo Passive Buzzer x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Second push button between D4 and GND (INPUT_PULLUP)
  Passive piezo + -> D8, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-33-simon
