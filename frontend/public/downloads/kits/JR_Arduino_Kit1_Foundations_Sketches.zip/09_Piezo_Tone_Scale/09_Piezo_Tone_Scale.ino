// ---- Circuit (Kit 1) ----
// Passive piezo + -> D8, - -> GND
#define PIEZO 8

#define NOTE_C4 262
#define NOTE_D4 294
#define NOTE_E4 330
#define NOTE_F4 349
#define NOTE_G4 392
#define NOTE_A4 440
#define NOTE_B4 494
#define NOTE_C5 523

int notes[8] = {NOTE_C4, NOTE_D4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_A4, NOTE_B4, NOTE_C5};

void setup() {
  Serial.begin(9600);
}

void loop() {
  for (int i = 0; i < 8; i++) {
    tone(PIEZO, notes[i], 250);
    Serial.print("note ");
    Serial.print(i + 1);
    Serial.print(" = ");
    Serial.print(notes[i]);
    Serial.println(" Hz");
    delay(320);
  }
  delay(1000);
}
