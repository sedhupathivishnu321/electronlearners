Kit 1 - Foundations
Project 9: Piezo Tone Scale (Basic)

Plays C-D-E-F-G-A-B-C with tone() on the passive buzzer.

Parts:
  Piezo Passive Buzzer x1

Circuit notes:
  Passive piezo + -> D8, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-09-piezo-scale
