Kit 1 - Foundations
Project 10: Serial Monitor Hello and Echo (Basic)

Prints a greeting, echoes what you type in the Serial tab and blinks the LED per byte.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-10-serial-echo
