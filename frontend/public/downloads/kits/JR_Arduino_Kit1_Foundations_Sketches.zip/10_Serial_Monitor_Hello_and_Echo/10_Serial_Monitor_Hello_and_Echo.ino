// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
#define RED_LED 3

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("Hello, JR Learners!");
  Serial.println("Type something and press Send - I will echo it back.");
}

void loop() {
  while (Serial.available() > 0) {
    char c = Serial.read();
    Serial.print("You typed: ");
    Serial.println(c);
    digitalWrite(RED_LED, HIGH);
    delay(80);
    digitalWrite(RED_LED, LOW);
  }
}
