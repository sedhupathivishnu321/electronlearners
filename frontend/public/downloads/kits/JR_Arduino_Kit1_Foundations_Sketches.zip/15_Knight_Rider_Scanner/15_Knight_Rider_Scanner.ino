// ---- Circuit (Kit 1) ----
// Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
#define RED_LED 3
#define GREEN_LED 5
#define POT A0

int pos = 0;
int dir = 1;

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
}

void loop() {
  analogWrite(GREEN_LED, pos);
  analogWrite(RED_LED, 255 - pos);
  pos += dir * 5;
  if (pos >= 255) { pos = 255; dir = -1; }
  if (pos <= 0) { pos = 0; dir = 1; }
  delay(map(analogRead(POT), 0, 1023, 4, 60));
}
