Kit 1 - Foundations
Project 15: Knight Rider Scanner (Intermediate)

Light sweeps between red and green by cross-fading; the pot sets the speed.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Potentiometer 10k (rotary) x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3 (PWM), cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-15-scanner
