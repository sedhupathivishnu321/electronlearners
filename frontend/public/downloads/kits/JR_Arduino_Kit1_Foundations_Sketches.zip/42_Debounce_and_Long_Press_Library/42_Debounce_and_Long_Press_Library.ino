// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11
#define BTN1 2
#define RGB_R 9
#define RGB_G 10
#define RGB_B 11

void setRGB(int r, int g, int b) {
  analogWrite(RGB_R, r);
  analogWrite(RGB_G, g);
  analogWrite(RGB_B, b);
}

enum { NONE, CLICK, DOUBLE, LONGPRESS };
int palette[6][3] = {{255,0,0},{255,120,0},{0,255,0},{0,255,255},{0,0,255},{255,0,255}};
int colour = 0;
int brightness = 255;
bool lampOn = true;

// ---- tiny button library: returns an event once per gesture
bool pressedNow = false;
unsigned long downAt = 0, upAt = 0;
int clicks = 0;
int poll() {
  bool down = (digitalRead(BTN1) == LOW);
  unsigned long now = millis();
  if (down && !pressedNow) { pressedNow = true; downAt = now; }
  if (!down && pressedNow) {
    pressedNow = false;
    if (now - downAt > 30) {
      if (now - downAt >= 700) { clicks = 0; return LONGPRESS; }
      clicks++; upAt = now;
    }
  }
  if (clicks > 0 && !pressedNow && now - upAt > 300) {
    int c = clicks; clicks = 0;
    return c >= 2 ? DOUBLE : CLICK;
  }
  return NONE;
}

void render() {
  if (!lampOn) { setRGB(0, 0, 0); return; }
  setRGB(palette[colour][0] * brightness / 255, palette[colour][1] * brightness / 255, palette[colour][2] * brightness / 255);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RGB_R, OUTPUT); pinMode(RGB_G, OUTPUT); pinMode(RGB_B, OUTPUT);
  Serial.begin(9600);
  Serial.println("click = next colour | double-click = on/off | long press = brightness");
  render();
}

void loop() {
  int e = poll();
  if (e == CLICK) { colour = (colour + 1) % 6; Serial.println("click"); }
  if (e == DOUBLE) { lampOn = !lampOn; Serial.println("double-click"); }
  if (e == LONGPRESS) { brightness = (brightness > 70) ? brightness - 90 : 255; Serial.print("long press, brightness "); Serial.println(brightness); }
  if (e != NONE) render();
}
