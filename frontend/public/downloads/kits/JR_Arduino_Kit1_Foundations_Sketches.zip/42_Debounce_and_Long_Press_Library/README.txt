Kit 1 - Foundations
Project 42: Debounce and Long-Press Library (Advanced)

One button, three gestures: click = next colour, double-click = off, long press = brightness.

Parts:
  RGB LED common cathode 5mm x1
  Resistor 220 ohm 1/4W x3
  Push Button tactile 6x6 x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  RGB LED (common cathode -> GND): R-220-D9, G-220-D10, B-220-D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-42-button-events
