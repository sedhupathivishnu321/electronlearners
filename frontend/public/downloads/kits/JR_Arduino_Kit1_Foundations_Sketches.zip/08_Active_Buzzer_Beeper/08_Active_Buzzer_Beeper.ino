// ---- Circuit (Kit 1) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Active buzzer + -> D12, - -> GND
#define BTN1 2
#define BUZZER 12

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    digitalWrite(BUZZER, HIGH);
    while (digitalRead(BTN1) == LOW) { /* wait for release */ }
    unsigned long held = millis() - t0;
    if (held < 400) delay(80);          // short press: short beep
    else delay(400);                    // long press: long beep
    digitalWrite(BUZZER, LOW);
    Serial.print("held ms: ");
    Serial.println(held);
    delay(100);
  }
}
