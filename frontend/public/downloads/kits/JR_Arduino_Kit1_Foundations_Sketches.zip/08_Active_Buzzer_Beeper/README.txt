Kit 1 - Foundations
Project 8: Active Buzzer Beeper (Basic)

Short press = short beep, hold longer = long beep.

Parts:
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Active buzzer + -> D12, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k1-08-active-beeper
