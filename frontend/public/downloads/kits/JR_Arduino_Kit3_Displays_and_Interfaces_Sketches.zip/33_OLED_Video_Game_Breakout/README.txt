Kit 3 - Displays and Interfaces
Project 33: OLED Video Game: Breakout (Advanced)

Breakout on the OLED: the encoder moves the paddle, the button launches the ball, the LCD shows lives and score.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  0.96in OLED I2C SSD1306 x1
  Rotary Encoder KY-040 x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-33-breakout
