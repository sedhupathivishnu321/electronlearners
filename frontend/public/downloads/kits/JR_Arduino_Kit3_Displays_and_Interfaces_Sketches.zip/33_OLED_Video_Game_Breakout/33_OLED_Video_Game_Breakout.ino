// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int padX = 52;                                  // paddle left edge, 24 px wide
float bx = 64, by = 57, vx = 1.2, vy = -1.6;
bool bricks[24];
int lives = 3, score = 0, bricksLeft = 24;
bool launched = false, finished = false;
unsigned long lastFrame = 0;

void showStatus() {
  if (finished) {
    lcdRow(0, bricksLeft == 0 ? "YOU WIN!" : "GAME OVER");
    lcdRow(1, "Score: " + String(score));
  } else {
    lcdRow(0, "Lives: " + String(lives));
    lcdRow(1, "Score: " + String(score));
  }
}

void newGame() {
  for (int i = 0; i < 24; i++) bricks[i] = true;
  bricksLeft = 24; lives = 3; score = 0; finished = false; launched = false;
  showStatus();
}

void render() {
  oled.clearDisplay();
  for (int i = 0; i < 24; i++) if (bricks[i]) oled.fillRect((i % 8) * 16 + 1, 8 + (i / 8) * 6, 14, 5, SSD1306_WHITE);
  oled.fillRect(padX, 60, 24, 3, SSD1306_WHITE);
  oled.fillCircle(bx, by, 2, SSD1306_WHITE);
  oled.display();
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  encBegin();
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.init();
  lcd.backlight();
  Serial.begin(9600);
  newGame();
  render();
}

void loop() {
  int s = encStep();
  if (s != 0) padX = constrain(padX + s * 4, 0, 104);
  if (pressed()) {
    if (finished) newGame();
    else if (!launched) { launched = true; vx = 1.2; vy = -1.6; }
  }
  if (millis() - lastFrame < 25) return;
  lastFrame = millis();
  if (!launched) { bx = padX + 12; by = 57; }
  else if (!finished) {
    bx += vx; by += vy;
    if (bx < 2) { bx = 2; vx = -vx; }
    if (bx > 125) { bx = 125; vx = -vx; }
    if (by < 2) { by = 2; vy = -vy; }
    if (vy > 0 && by >= 57 && by <= 61 && bx >= padX - 2 && bx <= padX + 26) {      // paddle: aim with the hit position
      vy = -vy; by = 57;
      vx = (bx - (padX + 12)) / 8.0;
    }
    if (by >= 8 && by < 26) {
      int cell = ((int)((by - 8) / 6)) * 8 + (int)(bx / 16);
      if (bricks[cell]) {
        bricks[cell] = false; bricksLeft--; score += 10; vy = -vy;
        if (bricksLeft == 0) finished = true;
        showStatus();
      }
    }
    if (by > 63) {
      lives--;
      launched = false;
      if (lives == 0) finished = true;
      showStatus();
    }
  }
  render();
}
