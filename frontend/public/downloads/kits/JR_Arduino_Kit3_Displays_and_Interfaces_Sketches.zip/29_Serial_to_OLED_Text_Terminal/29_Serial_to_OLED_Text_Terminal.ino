// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)


#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

String screen = "";

void redraw() {
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.print(screen);
  oled.print("_");
  oled.display();
}

void setup() {
  Serial.begin(9600);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  screen = "OLED terminal ready.\n";
  redraw();
  Serial.println("Type something and press Send");
}

void loop() {
  bool changed = false;
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\r') continue;
    screen += c;
    changed = true;
  }
  if (changed) {
    while (screen.length() > 126) screen = screen.substring(21);   // drop the oldest text so the screen scrolls
    redraw();
  }
}
