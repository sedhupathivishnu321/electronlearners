Kit 3 - Displays and Interfaces
Project 22: Scoreboard (Intermediate)

One button, two teams: a short press scores for team A, a long press (over 0.6 s) for team B. Shows AA:BB.

Parts:
  Push Button tactile 6x6 x1
  TM1637 4-digit 7-segment x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-22-scoreboard
