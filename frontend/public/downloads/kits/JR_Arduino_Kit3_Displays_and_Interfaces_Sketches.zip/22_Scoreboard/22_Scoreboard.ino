// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);

int scoreA = 0, scoreB = 0;

void show() {
  tm.showNumberDecEx(scoreA * 100 + scoreB, 0x40, true);   // team A on the left two digits, team B on the right
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  tm.setBrightness(7);
  show();
  Serial.begin(9600);
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW) { }
    if (millis() - t0 > 600) { scoreB = (scoreB + 1) % 100; Serial.print("Team B scores - "); }
    else                     { scoreA = (scoreA + 1) % 100; Serial.print("Team A scores - "); }
    Serial.print(scoreA); Serial.print(" : "); Serial.println(scoreB);
    show();
    delay(40);
  }
}
