Kit 3 - Displays and Interfaces
Project 1: Hello World on LCD (Basic)

Shows 'Hello, JR Learners' on the 16x2 I2C LCD.

Parts:
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-01-lcd-hello
