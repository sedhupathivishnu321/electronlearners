// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5, cathode -> GND
#define BTN1 2
#define GREEN_LED 5

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}

int best = 9999;

bool buttonDown() { return digitalRead(BTN1) == LOW; }
void waitRelease() { while (buttonDown()) { } delay(40); }

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  lcd.init();
  lcd.backlight();
  lcdRow(0, "Reaction game");
  lcdRow(1, "Press to start");
  Serial.begin(9600);
}

void loop() {
  if (!buttonDown()) return;
  waitRelease();
  lcdRow(0, "Wait for green..");
  lcdRow(1, "");
  randomSeed(micros());
  unsigned long goAt = millis() + random(2000, 5000);
  bool early = false;
  while (millis() < goAt) {
    if (buttonDown()) { early = true; break; }
  }
  if (early) {
    lcdRow(0, "Too soon!");
    lcdRow(1, "Press to retry");
    waitRelease();
    return;
  }
  digitalWrite(GREEN_LED, HIGH);
  unsigned long t0 = millis();
  while (!buttonDown()) { }
  int ms = millis() - t0;
  digitalWrite(GREEN_LED, LOW);
  if (ms < best) best = ms;
  lcdRow(0, "Time: " + String(ms) + " ms");
  lcdRow(1, "Best: " + String(best) + " ms");
  Serial.print("reaction "); Serial.print(ms); Serial.println(" ms");
  waitRelease();
}
