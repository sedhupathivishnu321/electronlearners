Kit 3 - Displays and Interfaces
Project 30: Reaction Time Game on LCD (Intermediate)

Press to start, wait for the green LED, then press as fast as you can. The LCD shows your time and best time.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-30-reaction
