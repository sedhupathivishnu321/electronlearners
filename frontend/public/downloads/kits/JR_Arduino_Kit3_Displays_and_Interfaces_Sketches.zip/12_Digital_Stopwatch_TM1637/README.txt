Kit 3 - Displays and Interfaces
Project 12: Digital Stopwatch (TM1637) (Intermediate)

Short press = start / stop. Hold the button for 1 s while stopped = reset. Shows SS:hh (seconds and hundredths).

Parts:
  Push Button tactile 6x6 x1
  TM1637 4-digit 7-segment x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-12-stopwatch
