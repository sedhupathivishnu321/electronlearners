// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);

bool running = false;
unsigned long startMs = 0, accum = 0;

unsigned long elapsed() {
  return running ? accum + (millis() - startMs) : accum;
}

void show() {
  unsigned long cs = elapsed() / 10;       // hundredths of a second
  int secs = (cs / 100) % 100;
  int hund = cs % 100;
  tm.showNumberDecEx(secs * 100 + hund, 0x40, true);    // 0x40 lights the colon
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  tm.setBrightness(7);
  show();
  Serial.begin(9600);
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 1000) show();
    if (digitalRead(BTN1) == LOW) {                       // still held: long press
      if (!running) { accum = 0; Serial.println("reset"); }
      while (digitalRead(BTN1) == LOW) show();
    } else if (running) {                                 // short press: stop
      accum += millis() - startMs;
      running = false;
      Serial.print("stopped at "); Serial.print(accum / 1000.0, 2); Serial.println(" s");
    } else {                                              // short press: start
      startMs = millis();
      running = true;
      Serial.println("running");
    }
    delay(30);
  }
  show();
  delay(10);
}
