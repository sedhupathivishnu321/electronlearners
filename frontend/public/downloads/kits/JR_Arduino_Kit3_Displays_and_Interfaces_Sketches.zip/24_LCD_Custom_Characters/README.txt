Kit 3 - Displays and Interfaces
Project 24: LCD Custom Characters (Intermediate)

Defines your own 5x8 characters: a beating heart, a charging battery and a moving arrow.

Parts:
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-24-lcd-custom
