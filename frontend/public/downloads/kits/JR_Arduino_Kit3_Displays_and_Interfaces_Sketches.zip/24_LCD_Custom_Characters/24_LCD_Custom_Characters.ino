// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}

byte heartBig[8]   = {0x00, 0x0A, 0x1F, 0x1F, 0x1F, 0x0E, 0x04, 0x00};
byte heartSmall[8] = {0x00, 0x00, 0x0A, 0x1F, 0x0E, 0x04, 0x00, 0x00};
byte bat0[8] = {0x0E, 0x1B, 0x11, 0x11, 0x11, 0x11, 0x1F, 0x00};
byte bat1[8] = {0x0E, 0x1B, 0x11, 0x11, 0x1F, 0x1F, 0x1F, 0x00};
byte bat2[8] = {0x0E, 0x1B, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x00};
byte bat3[8] = {0x0E, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x00};
byte arrow[8] = {0x00, 0x04, 0x02, 0x1F, 0x02, 0x04, 0x00, 0x00};

int tick = 0;

void setup() {
  lcd.init();
  lcd.backlight();
  lcd.createChar(0, heartBig);
  lcd.createChar(1, heartSmall);
  lcd.createChar(2, bat0);
  lcd.createChar(3, bat1);
  lcd.createChar(4, bat2);
  lcd.createChar(5, bat3);
  lcd.createChar(6, arrow);
  lcdRow(0, "Custom chars");
}

void loop() {
  lcd.setCursor(0, 1);
  lcd.write(tick % 2 == 0 ? 0 : 1);        // heart beats
  lcd.print(" ");
  lcd.write(2 + tick % 4);                 // battery fills up
  lcd.print(" ");
  for (int i = 0; i < 8; i++) {            // arrow runs along the row
    if (i == tick % 8) lcd.write(6); else lcd.print(" ");
  }
  tick++;
  delay(400);
}
