Kit 3 - Displays and Interfaces
Project 17: Binary Clock Display (Intermediate)

Seconds counter in binary on the 8 LEDs and in decimal on the LCD.

Parts:
  Shift Register 74HC595 x1
  Resistor 220 ohm 1/4W x8
  LED 5mm Red x2
  LED 5mm Yellow x2
  LED 5mm Green x2
  LED 5mm Blue x2
  16x2 LCD I2C x1

Circuit notes:
  74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-17-binary-clock
