// ---- Circuit (Kit 3) ----
// 74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define SR_DATA 12
#define SR_CLOCK 13
#define SR_LATCH A2

void srWrite(byte v) {                      // send 8 bits to the 74HC595 and latch them onto Q0-Q7
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, v);
  digitalWrite(SR_LATCH, HIGH);
}
void srBegin() {
  pinMode(SR_DATA, OUTPUT); pinMode(SR_CLOCK, OUTPUT); pinMode(SR_LATCH, OUTPUT);
  srWrite(0);
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}

unsigned long seconds = 0;

String binary8(int v) {
  String s = "";
  for (int i = 7; i >= 0; i--) s += (bitRead(v, i) ? "1" : "0");
  return s;
}

void setup() {
  srBegin();
  lcd.init();
  lcd.backlight();
}

void loop() {
  int v = seconds % 256;
  srWrite(v);
  lcdRow(0, "Seconds: " + String(v));
  lcdRow(1, "Binary: " + binary8(v));
  seconds++;
  delay(1000);
}
