// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);

int px = -1, py = -1;

void setup() {
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  pinMode(JOY_SW, INPUT_PULLUP);
}

void loop() {
  int col = constrain(map(analogRead(JOY_X), 0, 1023, 0, 8), 0, 7);     // 0..1023 -> 8 zones
  int row = constrain(map(analogRead(JOY_Y), 0, 1023, 0, 8), 0, 7);
  if (col != px || row != py) {
    bool trail = (digitalRead(JOY_SW) == LOW);
    if (px >= 0 && !trail) mat.setLed(0, py, px, false);   // erase the old dot unless drawing a trail
    mat.setLed(0, row, col, true);
    px = col; py = row;
  }
  delay(30);
}
