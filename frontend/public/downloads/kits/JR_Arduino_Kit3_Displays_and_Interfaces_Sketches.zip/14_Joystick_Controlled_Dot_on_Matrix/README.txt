Kit 3 - Displays and Interfaces
Project 14: Joystick-Controlled Dot on Matrix (Intermediate)

Move one LED around the 8x8 matrix with the joystick. Hold the joystick button to leave a trail.

Parts:
  8x8 LED Matrix MAX7219 x1
  Joystick Module x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-14-joystick-dot
