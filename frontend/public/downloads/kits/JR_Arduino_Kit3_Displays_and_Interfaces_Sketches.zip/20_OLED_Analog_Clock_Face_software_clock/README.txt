Kit 3 - Displays and Interfaces
Project 20: OLED Analog Clock Face (software clock) (Intermediate)

Analog clock with hour, minute and second hands driven by millis(), plus a digital readout.

Parts:
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-20-oled-clock
