// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)


#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

String two(int v) {
  return v < 10 ? String("0") + String(v) : String(v);
}

void hand(int cx, int cy, float deg, int len) {
  float a = (deg - 90) * 3.14159 / 180.0;
  oled.drawLine(cx, cy, cx + len * cos(a), cy + len * sin(a), SSD1306_WHITE);
}

void setup() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
}

void loop() {
  long t = 10 * 3600L + 8 * 60L + millis() / 1000;          // the clock starts at 10:08:00
  int s = t % 60, m = (t / 60) % 60, h = (t / 3600) % 12;
  oled.clearDisplay();
  oled.drawCircle(32, 32, 30, SSD1306_WHITE);
  for (int i = 0; i < 12; i++) {                            // 12 hour ticks
    float a = i * 30 * 3.14159 / 180.0;
    oled.drawLine(32 + 26 * cos(a), 32 + 26 * sin(a), 32 + 29 * cos(a), 32 + 29 * sin(a), SSD1306_WHITE);
  }
  hand(32, 32, h * 30 + m * 0.5, 15);
  hand(32, 32, m * 6, 23);
  hand(32, 32, s * 6, 27);
  oled.setTextSize(1);
  oled.setCursor(72, 20);
  oled.print(two(h == 0 ? 12 : h)); oled.print(":"); oled.print(two(m));
  oled.setCursor(72, 32);
  oled.print(":"); oled.print(two(s));
  oled.display();
  delay(100);
}
