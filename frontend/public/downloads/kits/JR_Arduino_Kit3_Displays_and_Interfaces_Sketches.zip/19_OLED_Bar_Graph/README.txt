Kit 3 - Displays and Interfaces
Project 19: OLED Bar Graph (Intermediate)

Live bar and scrolling history of the joystick X axis on the OLED.

Parts:
  0.96in OLED I2C SSD1306 x1
  Joystick Module x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-19-oled-bargraph
