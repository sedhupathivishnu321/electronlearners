// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

int hist[32];

void setup() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  for (int i = 0; i < 32; i++) hist[i] = 0;
}

void loop() {
  int v = analogRead(JOY_X);
  for (int i = 0; i < 31; i++) hist[i] = hist[i + 1];     // scroll the history left
  hist[31] = map(v, 0, 1023, 0, 40);

  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.print("Joystick X: ");
  oled.print(map(v, 0, 1023, 0, 100));
  oled.print("%");
  oled.drawRect(0, 12, 128, 9, SSD1306_WHITE);
  oled.fillRect(2, 14, map(v, 0, 1023, 0, 124), 5, SSD1306_WHITE);
  for (int i = 0; i < 32; i++) oled.fillRect(i * 4, 63 - hist[i], 3, hist[i] + 1, SSD1306_WHITE);
  oled.display();
  delay(60);
}
