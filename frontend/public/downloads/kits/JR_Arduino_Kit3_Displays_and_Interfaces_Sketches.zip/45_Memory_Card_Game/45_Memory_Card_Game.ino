// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define BTN1 2

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int MASKS[8] = {1, 2, 4, 8, 6, 9, 3, 12};   // eight different 2x2 patterns (TL = 1, TR = 2, BL = 4, BR = 8); a hidden card is all four LEDs
int card[16];
bool matched[16], faceUp[16];
int cur = 0, moves = 0, pairs = 0, first = -1;
bool dealt = false, reveal = false;         // reveal = show both flipped cards steadily (no cursor blink)

void drawCards() {
  bool blink = reveal || (millis() / 250) % 2 == 0;
  for (int i = 0; i < 16; i++) {
    int r0 = (i / 4) * 2, c0 = (i % 4) * 2;
    int m = (dealt && (matched[i] || faceUp[i])) ? card[i] : 15;
    if (i == cur && !blink) m = 0;                       // the selected card blinks
    mat.setLed(0, r0, c0, m & 1);
    mat.setLed(0, r0, c0 + 1, m & 2);
    mat.setLed(0, r0 + 1, c0, m & 4);
    mat.setLed(0, r0 + 1, c0 + 1, m & 8);
  }
}

void status() {
  if (!dealt) { lcdRow(0, "Memory game"); lcdRow(1, "Press to deal"); }
  else if (pairs == 8) { lcdRow(0, "Won in " + String(moves) + " moves!"); lcdRow(1, "Press to replay"); }
  else { lcdRow(0, "Moves: " + String(moves)); lcdRow(1, "Pairs: " + String(pairs) + "/8"); }
}

void deal() {
  randomSeed(micros());                                  // the moment you press is the random seed
  for (int i = 0; i < 16; i++) { card[i] = MASKS[i / 2]; matched[i] = false; faceUp[i] = false; }
  for (int i = 15; i > 0; i--) { int j = random(0, i + 1); int t = card[i]; card[i] = card[j]; card[j] = t; }   // shuffle
  moves = 0; pairs = 0; first = -1; cur = 0; dealt = true;
  status();
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(JOY_SW, INPUT_PULLUP);
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  lcd.init();
  lcd.backlight();
  Serial.begin(9600);
  status();
}

void loop() {
  int d = joyDir();
  if (d == 1 && cur % 4 > 0) cur--;
  if (d == 2 && cur % 4 < 3) cur++;
  if (d == 3 && cur >= 4) cur -= 4;
  if (d == 4 && cur < 12) cur += 4;
  if (pressed() || joyClicked()) {
    if (!dealt || pairs == 8) deal();
    else if (!matched[cur] && !faceUp[cur]) {
      faceUp[cur] = true;
      if (first < 0) first = cur;
      else {
        moves++;
        if (card[first] == card[cur]) { matched[first] = true; matched[cur] = true; pairs++; faceUp[first] = false; faceUp[cur] = false; }
        else { reveal = true; drawCards(); delay(900); reveal = false; faceUp[first] = false; faceUp[cur] = false; }
        first = -1;
        status();
      }
    }
  }
  drawCards();
  delay(20);
}
