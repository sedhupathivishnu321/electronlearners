Kit 3 - Displays and Interfaces
Project 45: Memory Card Game (Advanced)

Sixteen hidden cards (each a 2x2 block of the matrix, 8 pairs of patterns). Joystick picks a card, the button flips it; the LCD counts moves and pairs.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  8x8 LED Matrix MAX7219 x1
  Joystick Module x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-45-memory-game
