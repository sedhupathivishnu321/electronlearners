// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);

// each frame = 8 bytes (one per row)
byte HEART[] = {
  0x00, 0x00, 0x14, 0x3E, 0x3E, 0x1C, 0x08, 0x00,     // small
  0x00, 0x66, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C, 0x18,     // big
  0x00, 0x00, 0x14, 0x3E, 0x3E, 0x1C, 0x08, 0x00,     // small
  0x00, 0x00, 0x00, 0x14, 0x1C, 0x08, 0x00, 0x00      // tiny
};
byte RAIN[] = {0x42, 0x00, 0x10, 0x00, 0x84, 0x00, 0x21, 0x00};   // drops: the pattern falls one row per frame

void drawFrame(int row, byte bits) {
  mat.setRow(0, row, bits);
}

void setup() {
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
}

void loop() {
  for (int rep = 0; rep < 3; rep++) {                    // heartbeat x3
    for (int f = 0; f < 4; f++) {
      for (int r = 0; r < 8; r++) drawFrame(r, HEART[f * 8 + r]);
      delay(f == 1 ? 200 : 150);
    }
  }
  for (int k = 0; k < 24; k++) {                         // rain: rotate the pattern downwards
    for (int r = 0; r < 8; r++) drawFrame(r, RAIN[(r - k % 8 + 8) % 8]);
    delay(110);
  }
}
