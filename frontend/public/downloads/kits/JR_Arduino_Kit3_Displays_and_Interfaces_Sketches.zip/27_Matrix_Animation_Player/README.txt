Kit 3 - Displays and Interfaces
Project 27: Matrix Animation Player (Intermediate)

Plays animations stored in a table: a heartbeat, then falling rain.

Parts:
  8x8 LED Matrix MAX7219 x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  each frame = 8 bytes (one per row)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-27-matrix-animation
