Kit 3 - Displays and Interfaces
Project 26: Number Guessing Game (Intermediate)

Dial a guess (1-100) with the encoder, press the button to try. The LCD says TOO LOW / TOO HIGH until you win.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  Rotary Encoder KY-040 x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-26-number-guess
