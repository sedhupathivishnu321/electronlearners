// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int secret = 0, guess = 50, tries = 0;

void showGuess(String hint) {
  lcdRow(0, "Guess: " + String(guess));
  lcdRow(1, hint);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  encBegin();
  lcd.init();
  lcd.backlight();
  showGuess("Turn, then press");
  Serial.begin(9600);
}

void loop() {
  int s = encStep();
  if (s != 0) {
    if (secret == 0) { randomSeed(micros()); secret = random(1, 101); }   // seeded by the moment you first touch the knob
    guess = constrain(guess + s, 1, 100);
    showGuess("Turn, then press");
  }
  if (pressed() && secret != 0) {
    tries++;
    if (guess < secret) showGuess("TOO LOW");
    else if (guess > secret) showGuess("TOO HIGH");
    else {
      lcdRow(0, "YOU WIN! It was " + String(secret));
      lcdRow(1, "Tries: " + String(tries));
      Serial.print("won in "); Serial.print(tries); Serial.println(" tries");
      while (!pressed()) { }               // press again for a new game
      secret = 0; tries = 0; guess = 50;
      showGuess("New game");
    }
  }
}
