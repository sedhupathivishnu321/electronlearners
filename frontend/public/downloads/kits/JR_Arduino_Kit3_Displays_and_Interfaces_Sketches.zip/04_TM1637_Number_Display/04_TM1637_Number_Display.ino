// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
#define TM_CLK 10
#define TM_DIO 11

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);

int n = 0;

void setup() {
  tm.setBrightness(7);
}

void loop() {
  tm.showNumberDec(n, true);               // true = keep the leading zeros
  n = n + 7;                               // step of 7 so every digit changes
  if (n > 9999) n = 0;
  delay(100);
}
