Kit 3 - Displays and Interfaces
Project 4: TM1637 Number Display (Basic)

Counts 0000-9999 on the 4-digit display.

Parts:
  TM1637 4-digit 7-segment x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-04-tm-number
