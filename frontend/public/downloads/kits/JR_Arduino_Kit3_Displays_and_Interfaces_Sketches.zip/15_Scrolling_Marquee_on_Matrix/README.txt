Kit 3 - Displays and Interfaces
Project 15: Scrolling Marquee on Matrix (Intermediate)

Scrolls a message across the 8x8 matrix using a 5x7 font table.

Parts:
  8x8 LED Matrix MAX7219 x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-15-matrix-marquee
