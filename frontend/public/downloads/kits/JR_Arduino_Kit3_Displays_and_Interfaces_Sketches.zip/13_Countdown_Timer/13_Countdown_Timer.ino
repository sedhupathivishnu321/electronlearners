// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define TM_CLK 10
#define TM_DIO 11
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define RED_LED 3

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}

int setSecs = 30;
bool counting = false;
long endMs = 0;

void showTime(long secs) {
  tm.showNumberDecEx((secs / 60) * 100 + secs % 60, 0x40, true);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  encBegin();
  tm.setBrightness(7);
  showTime(setSecs);
  Serial.begin(9600);
}

void loop() {
  if (!counting) {
    int s = encStep();
    if (s != 0) { setSecs = constrain(setSecs + s * 5, 5, 5999); showTime(setSecs); }
    if (encClicked()) {
      counting = true;
      endMs = millis() + setSecs * 1000L;
      Serial.print("countdown started: "); Serial.print(setSecs); Serial.println(" s");
    }
  } else {
    long left = endMs - millis();
    if (left <= 0) {
      Serial.println("TIME UP");
      for (int i = 0; i < 6; i++) {
        digitalWrite(RED_LED, HIGH); showTime(0); delay(200);
        digitalWrite(RED_LED, LOW); tm.clear(); delay(200);
      }
      counting = false;
      showTime(setSecs);
    } else {
      showTime((left + 999) / 1000);
    }
  }
}
