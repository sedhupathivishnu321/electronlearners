Kit 3 - Displays and Interfaces
Project 13: Countdown Timer (Intermediate)

Turn the encoder to set MM:SS (5 s per click), push the shaft to start. At zero the display and red LED flash.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  TM1637 4-digit 7-segment x1
  Rotary Encoder KY-040 x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-13-countdown
