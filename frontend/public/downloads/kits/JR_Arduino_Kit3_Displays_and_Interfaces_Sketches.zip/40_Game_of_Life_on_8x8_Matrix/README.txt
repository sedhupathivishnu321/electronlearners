Kit 3 - Displays and Interfaces
Project 40: Game of Life on 8x8 Matrix (Advanced)

Conway's Life with wrap-around edges. Edit mode: joystick moves the blinking cursor, its button flips a cell. The push button starts / pauses; the TM1637 shows the generation.

Parts:
  Push Button tactile 6x6 x1
  TM1637 4-digit 7-segment x1
  8x8 LED Matrix MAX7219 x1
  Joystick Module x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-40-game-of-life
