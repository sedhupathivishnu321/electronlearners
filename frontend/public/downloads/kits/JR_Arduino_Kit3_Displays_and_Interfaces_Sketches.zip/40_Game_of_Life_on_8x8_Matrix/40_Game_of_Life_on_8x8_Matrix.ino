// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

byte g[8], nxt[8];
int cx = 0, cy = 0, gen = 0;
bool running = false;
unsigned long last = 0;

bool cell(int r, int c) {
  r = (r + 8) % 8; c = (c + 8) % 8;                 // the board wraps around
  return (g[r] >> (7 - c)) & 1;
}

void draw() {
  bool blink = (millis() / 250) % 2 == 0;
  for (int r = 0; r < 8; r++) {
    byte row = g[r];
    if (!running && r == cy && blink) row = row ^ (0x80 >> cx);
    mat.setRow(0, r, row);
  }
}

void stepLife() {
  for (int r = 0; r < 8; r++) {
    byte row = 0;
    for (int c = 0; c < 8; c++) {
      int n = 0;
      for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) if (dr != 0 || dc != 0) n += cell(r + dr, c + dc);
      bool alive = cell(r, c);
      if ((alive && (n == 2 || n == 3)) || (!alive && n == 3)) row = row | (0x80 >> c);
    }
    nxt[r] = row;
  }
  for (int r = 0; r < 8; r++) g[r] = nxt[r];
  gen++;
  tm.showNumberDec(gen);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(JOY_SW, INPUT_PULLUP);
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  tm.setBrightness(7);
  tm.showNumberDec(0);
  g[0] = 0x20; g[1] = 0x10; g[2] = 0x70;            // a glider to start with
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    running = !running;
    Serial.println(running ? "running" : "edit mode");
  }
  if (!running) {
    int d = joyDir();
    if (d == 1) cx = (cx + 7) % 8;
    if (d == 2) cx = (cx + 1) % 8;
    if (d == 3) cy = (cy + 7) % 8;
    if (d == 4) cy = (cy + 1) % 8;
    if (joyClicked()) g[cy] = g[cy] ^ (0x80 >> cx);
  } else if (millis() - last >= 300) {
    last = millis();
    stepLife();
  }
  draw();
  delay(20);
}
