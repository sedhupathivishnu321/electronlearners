Kit 3 - Displays and Interfaces
Project 11: Scrolling Text on LCD (Intermediate)

A long message scrolls across the second row of the 16x2 display like a marquee.

Parts:
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-11-lcd-marquee
