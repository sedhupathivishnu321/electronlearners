// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}

String msg = "                Welcome to JR Learners Kit 3 - Displays and Interfaces!                ";
int pos = 0;

void setup() {
  lcd.init();
  lcd.backlight();
  lcdRow(0, "Marquee demo");
}

void loop() {
  lcdRow(1, msg.substring(pos, pos + 16));   // a 16-character window sliding over the message
  pos++;
  if (pos > msg.length() - 16) pos = 0;
  delay(250);
}
