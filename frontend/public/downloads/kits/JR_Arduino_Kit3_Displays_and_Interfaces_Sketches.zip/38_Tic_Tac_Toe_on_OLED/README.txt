Kit 3 - Displays and Interfaces
Project 38: Tic-Tac-Toe on OLED (Advanced)

Two players share the board: the joystick moves the cursor, the button places X or O. The LCD keeps the score.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  0.96in OLED I2C SSD1306 x1
  Joystick Module x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-38-tictactoe
