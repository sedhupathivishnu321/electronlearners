// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define BTN1 2

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int board[9];                               // 0 empty, 1 = X, 2 = O
int LINES[24] = {0,1,2, 3,4,5, 6,7,8, 0,3,6, 1,4,7, 2,5,8, 0,4,8, 2,4,6};
int cur = 4, turn = 1, winner = 0, winsX = 0, winsO = 0;     // winner: 0 playing, 1 X, 2 O, 3 draw

int checkWinner() {
  for (int l = 0; l < 8; l++) {
    int a = board[LINES[l * 3]], b = board[LINES[l * 3 + 1]], c = board[LINES[l * 3 + 2]];
    if (a != 0 && a == b && b == c) return a;
  }
  for (int i = 0; i < 9; i++) if (board[i] == 0) return 0;
  return 3;
}

void render() {
  oled.clearDisplay();
  oled.drawLine(22, 2, 22, 62, SSD1306_WHITE); oled.drawLine(42, 2, 42, 62, SSD1306_WHITE);
  oled.drawLine(2, 22, 62, 22, SSD1306_WHITE); oled.drawLine(2, 42, 62, 42, SSD1306_WHITE);
  for (int i = 0; i < 9; i++) {
    int cx = 2 + (i % 3) * 20 + 10, cy = 2 + (i / 3) * 20 + 10;
    if (board[i] == 1) { oled.drawLine(cx - 6, cy - 6, cx + 6, cy + 6, SSD1306_WHITE); oled.drawLine(cx - 6, cy + 6, cx + 6, cy - 6, SSD1306_WHITE); }
    if (board[i] == 2) oled.drawCircle(cx, cy, 6, SSD1306_WHITE);
  }
  if (winner == 0) oled.drawRect(2 + (cur % 3) * 20 + 2, 2 + (cur / 3) * 20 + 2, 16, 16, SSD1306_WHITE);   // cursor
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(70, 6);  oled.print("TIC TAC");
  oled.setCursor(70, 16); oled.print("TOE");
  oled.setCursor(70, 34);
  if (winner == 0) oled.print(turn == 1 ? "X turn" : "O turn");
  else if (winner == 3) oled.print("DRAW");
  else oled.print(winner == 1 ? "X WINS!" : "O WINS!");
  oled.display();
}

void showScore() {
  lcdRow(0, "X:" + String(winsX) + "  O:" + String(winsO));
  lcdRow(1, winner == 0 ? (turn == 1 ? "X to move" : "O to move") : (winner == 3 ? "Draw - press" : "Press for next"));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(JOY_SW, INPUT_PULLUP);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.init();
  lcd.backlight();
  Serial.begin(9600);
  render();
  showScore();
}

void loop() {
  int d = joyDir();
  if (winner == 0 && d != 0) {
    if (d == 1 && cur % 3 > 0) cur--;
    if (d == 2 && cur % 3 < 2) cur++;
    if (d == 3 && cur >= 3) cur -= 3;
    if (d == 4 && cur < 6) cur += 3;
    render();
  }
  if (pressed()) {
    if (winner != 0) {                                   // start the next game
      for (int i = 0; i < 9; i++) board[i] = 0;
      winner = 0; turn = 1; cur = 4;
    } else if (board[cur] == 0) {
      board[cur] = turn;
      winner = checkWinner();
      if (winner == 1) winsX++;
      else if (winner == 2) winsO++;
      else turn = 3 - turn;
      if (winner != 0) { Serial.print("result: "); Serial.println(winner == 3 ? "draw" : (winner == 1 ? "X wins" : "O wins")); }
    }
    render();
    showScore();
  }
}
