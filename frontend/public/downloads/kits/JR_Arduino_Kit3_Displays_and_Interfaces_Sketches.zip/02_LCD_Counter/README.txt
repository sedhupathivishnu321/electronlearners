Kit 3 - Displays and Interfaces
Project 2: LCD Counter (Basic)

Counts up once a second on the LCD.

Parts:
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-02-lcd-counter
