Kit 3 - Displays and Interfaces
Project 39: Menu-Driven Settings System (Advanced)

Two-level menu on the LCD (encoder = move / click, button = back). Settings are stored in EEPROM and previewed live on the OLED.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  0.96in OLED I2C SSD1306 x1
  Rotary Encoder KY-040 x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  EEPROM map: 0 = LCD light, 1 = OLED title size, 2 = start value, 3 = boot count, 10 = "saved" marker

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-39-settings-menu
