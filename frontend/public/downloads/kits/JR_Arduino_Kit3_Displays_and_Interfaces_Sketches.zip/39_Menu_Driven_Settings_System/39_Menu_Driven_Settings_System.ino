// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
#include <EEPROM.h>

// EEPROM map: 0 = LCD light, 1 = OLED title size, 2 = start value, 3 = boot count, 10 = "saved" marker
int lcdLight = 1, oledSize = 1, startVal = 0, boots = 0;
int level = 0, idx = 0;                      // level 0 = main, 1 = Display, 2 = Counter

String onOff(int v) { if (v != 0) return "ON"; return "OFF"; }

int itemCount() { return level == 0 ? 3 : (level == 1 ? 3 : 2); }

String itemLabel() {
  if (level == 0) { if (idx == 0) return "Display"; if (idx == 1) return "Counter"; return "Factory reset"; }
  if (level == 1) { if (idx == 0) return "LCD light: " + onOff(lcdLight); if (idx == 1) return "OLED size: " + String(oledSize); return "< Back"; }
  if (idx == 0) return "Start value: " + String(startVal);
  return "< Back";
}

void saveSettings() {
  EEPROM.write(0, lcdLight); EEPROM.write(1, oledSize); EEPROM.write(2, startVal); EEPROM.write(10, 42);
}

void applySettings() {
  if (lcdLight) lcd.backlight(); else lcd.noBacklight();
}

void drawOled() {
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(oledSize);
  oled.setCursor(0, 0);
  oled.println("Settings");
  oled.setTextSize(1);
  oled.setCursor(0, 28);
  oled.println("LCD light  : " + onOff(lcdLight));
  oled.println("OLED title : size " + String(oledSize));
  oled.println("Start value: " + String(startVal));
  oled.println("Boot count : " + String(boots));
  oled.display();
}

void drawMenu() {
  lcdRow(0, level == 0 ? "Main menu" : (level == 1 ? "Main > Display" : "Main > Counter"));
  lcdRow(1, "> " + itemLabel());
  applySettings();
  drawOled();
}

void setup() {
  encBegin();
  Serial.begin(9600);
  if (EEPROM.read(10) == 42) { lcdLight = EEPROM.read(0); oledSize = EEPROM.read(1); startVal = EEPROM.read(2); boots = EEPROM.read(3); }
  boots++;
  EEPROM.write(3, boots);
  pinMode(BTN1, INPUT_PULLUP);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.init();
  lcd.backlight();
  Serial.print("boot #"); Serial.println(boots);
  drawMenu();
}

void loop() {
  int s = encStep();
  if (s != 0) { idx = (idx + s + itemCount()) % itemCount(); drawMenu(); }
  if (digitalRead(BTN1) == LOW) { level = 0; idx = 0; drawMenu(); delay(250); }      // button = back to the main menu
  if (encClicked()) {
    if (level == 0) {
      if (idx == 0) { level = 1; idx = 0; }
      else if (idx == 1) { level = 2; idx = 0; }
      else { lcdLight = 1; oledSize = 1; startVal = 0; saveSettings(); lcdRow(1, "Reset done"); delay(700); }
    } else if (level == 1) {
      if (idx == 0) lcdLight = lcdLight ? 0 : 1;
      else if (idx == 1) oledSize = 3 - oledSize;
      else { level = 0; idx = 0; }
      saveSettings();
    } else {
      if (idx == 0) { startVal = (startVal + 5) % 100; saveSettings(); }
      else { level = 0; idx = 0; }
    }
    drawMenu();
  }
}
