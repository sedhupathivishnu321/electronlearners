Kit 3 - Displays and Interfaces
Project 49: Mini Operating Console (Advanced)

Boot animation across all four displays, then three apps - Clock, Dice, Counter. Turn the encoder to switch apps, press the button to use them.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  0.96in OLED I2C SSD1306 x1
  TM1637 4-digit 7-segment x1
  8x8 LED Matrix MAX7219 x1
  Rotary Encoder KY-040 x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-49-mini-console
