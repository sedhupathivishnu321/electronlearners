// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TM_CLK 10
#define TM_DIO 11
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int FACE[7] = {0, 16, 257, 273, 325, 341, 365};
int app = 0, diceFace = 0, diceTotal = 0, counter = 0;
unsigned long lastDraw = 0;

String twoDigits(long v) { return v < 10 ? String("0") + String(v) : String(v); }

void showFace(int face) {
  mat.clearDisplay(0);
  for (int p = 0; p < 9; p++) {
    if (FACE[face] & (1 << p)) {
      int r0 = (p / 3) * 3, c0 = (p % 3) * 3;
      for (int dr = 0; dr < 2; dr++) for (int dc = 0; dc < 2; dc++) mat.setLed(0, r0 + dr, c0 + dc, true);
    }
  }
}

void fillCells(int n) {                                  // light the first n of the 64 LEDs, row by row
  for (int i = 0; i < 64; i++) mat.setLed(0, i / 8, i % 8, i < n);
}

void bootAnimation() {
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(2);
  oled.setCursor(22, 10);
  oled.println("JR OS");
  oled.setTextSize(1);
  oled.setCursor(22, 36);
  oled.print("version 1.0");
  oled.display();
  lcdRow(0, "Booting JR OS...");
  for (int i = 0; i < 16; i++) {
    lcd.setCursor(i, 1); lcd.print("#");                 // progress bar
    fillCells((i + 1) * 4);
    tm.showNumberDec((i + 1) * 555 % 10000, true);
    delay(70);
  }
  mat.clearDisplay(0);
  tm.clear();
}

void drawApp() {
  unsigned long secs = millis() / 1000;
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  if (app == 0) {
    oled.print("APP 1: CLOCK");
    oled.setTextSize(3);
    oled.setCursor(10, 24);
    oled.print(twoDigits(secs / 60 % 100)); oled.print(":"); oled.print(twoDigits(secs % 60));
    tm.showNumberDecEx((secs / 60 % 100) * 100 + secs % 60, 0x40, true);
    fillCells((secs % 60) * 64 / 60);
    lcdRow(0, "App 1/3: Clock");
    lcdRow(1, "Turn = next app");
  } else if (app == 1) {
    oled.print("APP 2: DICE");
    oled.setTextSize(3);
    oled.setCursor(10, 24);
    oled.print(diceFace == 0 ? "-" : String(diceFace));
    oled.setTextSize(1);
    oled.setCursor(60, 34);
    oled.print("total "); oled.print(diceTotal);
    lcdRow(0, "App 2/3: Dice");
    lcdRow(1, "Press = roll");
  } else {
    oled.print("APP 3: COUNTER");
    oled.setTextSize(3);
    oled.setCursor(10, 24);
    oled.print(counter);
    tm.showNumberDec(counter);
    fillCells(counter % 65);
    lcdRow(0, "App 3/3: Counter");
    lcdRow(1, "Press = count +1");
  }
  oled.display();
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  encBegin();
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.init();
  lcd.backlight();
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  tm.setBrightness(7);
  Serial.begin(9600);
  bootAnimation();
  Serial.println("JR OS ready");
  drawApp();
}

void loop() {
  int s = encStep();
  if (s != 0) {
    app = (app + s + 3) % 3;
    mat.clearDisplay(0);
    if (app == 1 && diceFace > 0) { showFace(diceFace); tm.showNumberDec(diceTotal); }
    if (app == 1 && diceFace == 0) tm.clear();
    drawApp();
    Serial.print("app "); Serial.println(app + 1);
  }
  if (pressed()) {
    if (app == 1) {
      randomSeed(micros());
      for (int i = 0; i < 6; i++) { showFace(random(1, 7)); delay(70); }
      diceFace = random(1, 7);
      diceTotal += diceFace;
      showFace(diceFace);
      tm.showNumberDec(diceTotal);
    }
    if (app == 2) counter++;
    drawApp();
  }
  if (millis() - lastDraw >= 500) { lastDraw = millis(); if (app == 0) drawApp(); }
}
