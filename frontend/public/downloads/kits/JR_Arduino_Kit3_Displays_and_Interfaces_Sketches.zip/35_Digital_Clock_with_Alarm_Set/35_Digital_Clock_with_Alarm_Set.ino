// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
#define TM_CLK 10
#define TM_DIO 11
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2
#define RED_LED 3
#define GREEN_LED 5

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define SECOND_MS 1000                       // length of one clock second - make it smaller to watch the alarm sooner

long tod = 12 * 3600L;                       // time of day in seconds (starts at 12:00:00)
int alarmH = 12, alarmM = 1;
int mode = 0;                                // 0 run, 1 set hour, 2 set minute, 3 alarm hour, 4 alarm minute
unsigned long ref = 0, ringStart = 0;
bool ringing = false;

void show() {
  int h = tod / 3600 % 24, m = tod / 60 % 60;
  if (mode >= 3) { h = alarmH; m = alarmM; }
  bool colon = (mode == 0) ? (tod % 2 == 0) : true;
  tm.showNumberDecEx(h * 100 + m, colon ? 0x40 : 0, true);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  encBegin();
  tm.setBrightness(7);
  digitalWrite(GREEN_LED, HIGH);             // green = alarm armed
  show();
  Serial.begin(9600);
}

void loop() {
  if (millis() - ref >= SECOND_MS) {         // one clock second has passed
    ref += SECOND_MS;
    tod = (tod + 1) % 86400;
    if (mode == 0 && tod % 60 == 0 && tod / 3600 % 24 == alarmH && tod / 60 % 60 == alarmM) {
      ringing = true; ringStart = millis();
      Serial.println("ALARM!");
    }
    show();
  }
  int s = encStep();
  if (s != 0) {
    int h = tod / 3600 % 24, m = tod / 60 % 60;
    if (mode == 1) { h = (h + s + 24) % 24; tod = h * 3600L + m * 60L; }
    if (mode == 2) { m = (m + s + 60) % 60; tod = h * 3600L + m * 60L; }
    if (mode == 3) alarmH = (alarmH + s + 24) % 24;
    if (mode == 4) alarmM = (alarmM + s + 60) % 60;
    show();
  }
  if (pressed()) {
    if (ringing) { ringing = false; Serial.println("alarm silenced"); }
    else {
      mode = (mode + 1) % 5;
      Serial.print("mode "); Serial.println(mode == 0 ? "RUN" : (mode == 1 ? "SET HOUR" : (mode == 2 ? "SET MINUTE" : (mode == 3 ? "ALARM HOUR" : "ALARM MINUTE"))));
    }
    show();
  }
  if (ringing) {
    bool flip = (millis() / 150) % 2 == 0;
    digitalWrite(RED_LED, flip); digitalWrite(GREEN_LED, !flip);
    if (millis() - ringStart > 10000) ringing = false;
  } else {
    digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH);
  }
}
