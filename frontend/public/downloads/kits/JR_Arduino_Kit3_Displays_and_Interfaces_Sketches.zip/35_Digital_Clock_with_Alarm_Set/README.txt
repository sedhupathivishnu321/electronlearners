Kit 3 - Displays and Interfaces
Project 35: Digital Clock with Alarm Set (Advanced)

Software clock on the TM1637. Button cycles RUN / set hour / set minute / alarm hour / alarm minute; the encoder changes the value. The alarm flashes the red and green LEDs.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  TM1637 4-digit 7-segment x1
  Rotary Encoder KY-040 x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-35-alarm-clock
