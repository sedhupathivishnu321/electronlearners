Kit 3 - Displays and Interfaces
Project 48: Bargraph VU on 74HC595 + OLED Trace (Advanced)

A simulated audio level drives the 8-LED VU bar with a peak-hold LED, while the OLED plots the level history. Joystick up/down = gain.

Parts:
  Shift Register 74HC595 x1
  Resistor 220 ohm 1/4W x8
  LED 5mm Red x2
  LED 5mm Yellow x2
  LED 5mm Green x2
  LED 5mm Blue x2
  0.96in OLED I2C SSD1306 x1
  Joystick Module x1

Circuit notes:
  74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-48-vu-meter
