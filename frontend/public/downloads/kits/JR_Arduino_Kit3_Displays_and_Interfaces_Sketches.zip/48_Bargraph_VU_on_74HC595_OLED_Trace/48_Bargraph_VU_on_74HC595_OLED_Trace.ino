// ---- Circuit (Kit 3) ----
// 74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define SR_DATA 12
#define SR_CLOCK 13
#define SR_LATCH A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

void srWrite(byte v) {                      // send 8 bits to the 74HC595 and latch them onto Q0-Q7
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, v);
  digitalWrite(SR_LATCH, HIGH);
}
void srBegin() {
  pinMode(SR_DATA, OUTPUT); pinMode(SR_CLOCK, OUTPUT); pinMode(SR_LATCH, OUTPUT);
  srWrite(0);
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

int hist[64];
int level = 0, peak = 0;
unsigned long last = 0, peakAt = 0;

void setup() {
  srBegin();
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  randomSeed(micros());
  Serial.begin(9600);
}

void loop() {
  if (millis() - last < 70) return;
  last = millis();
  float beat = 0.5 + 0.5 * sin(millis() / 500.0);                 // slow "music" envelope
  float gain = map(analogRead(JOY_Y), 0, 1023, 150, 40) / 100.0;  // stick up = more gain
  int raw = random(0, 101) * (0.35 + 0.65 * beat) * gain / 12.5;  // 0..8
  raw = constrain(raw, 0, 8);
  level = (raw > level) ? raw : max(level - 1, raw);              // fast attack, slow decay
  if (level >= peak) { peak = level; peakAt = millis(); }
  else if (millis() - peakAt > 600 && peak > 0) { peak--; peakAt = millis(); }   // peak hold falls slowly
  byte bar = (1 << level) - 1;
  if (peak > 0) bar = bar | (1 << (peak - 1));
  srWrite(bar);

  for (int i = 0; i < 63; i++) hist[i] = hist[i + 1];
  hist[63] = level;
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.print("VU level "); oled.print(level); oled.print("/8  peak "); oled.print(peak);
  for (int i = 1; i < 64; i++) oled.drawLine((i - 1) * 2, 63 - hist[i - 1] * 6, i * 2, 63 - hist[i] * 6, SSD1306_WHITE);
  oled.display();
}
