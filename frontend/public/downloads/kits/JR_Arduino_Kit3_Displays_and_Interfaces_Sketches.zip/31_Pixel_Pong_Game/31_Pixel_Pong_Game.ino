// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int padX = 3, bx = 3, by = 0, vx = 1, vy = 1, score = 0;
bool playing = false;
unsigned long lastStep = 0;

void draw() {
  mat.clearDisplay(0);
  mat.setLed(0, by, bx, true);
  for (int i = 0; i < 3; i++) mat.setLed(0, 7, padX + i, true);
}

void serve() {
  randomSeed(micros());
  bx = random(1, 7); by = 0; vy = 1;
  vx = (random(0, 2) == 0) ? -1 : 1;
  score = 0;
  tm.showNumberDec(0);
  playing = true;
  draw();
}

void gameOver() {
  playing = false;
  Serial.print("game over - score "); Serial.println(score);
  for (int i = 0; i < 3; i++) { mat.clearDisplay(0); delay(150); draw(); delay(150); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  encBegin();
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  tm.setBrightness(7);
  tm.showNumberDec(0);
  draw();
  Serial.begin(9600);
}

void loop() {
  int s = encStep();
  if (s != 0) { padX = constrain(padX + s, 0, 5); draw(); }
  if (!playing) {
    if (pressed()) serve();
    return;
  }
  if (millis() - lastStep >= max(70, 260 - score * 12)) {      // the ball speeds up with every return
    lastStep = millis();
    if (bx + vx < 0 || bx + vx > 7) vx = -vx;
    bx += vx;
    by += vy;
    if (by <= 0) { by = 0; vy = 1; }
    if (by >= 7) {                                              // ball reached the paddle row
      if (bx >= padX && bx <= padX + 2) { by = 6; vy = -1; score++; tm.showNumberDec(score); }
      else { draw(); gameOver(); return; }
    }
    draw();
  }
}
