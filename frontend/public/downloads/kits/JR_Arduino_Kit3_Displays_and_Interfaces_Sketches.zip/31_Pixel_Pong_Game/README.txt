Kit 3 - Displays and Interfaces
Project 31: Pixel Pong Game (Advanced)

Pong on the 8x8 matrix: the encoder moves the 3-LED paddle, the TM1637 shows your score. Press the button to serve.

Parts:
  Push Button tactile 6x6 x1
  TM1637 4-digit 7-segment x1
  8x8 LED Matrix MAX7219 x1
  Rotary Encoder KY-040 x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-31-pixel-pong
