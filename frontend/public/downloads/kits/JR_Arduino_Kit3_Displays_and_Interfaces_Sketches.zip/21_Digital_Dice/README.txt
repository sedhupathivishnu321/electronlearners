Kit 3 - Displays and Interfaces
Project 21: Digital Dice (Intermediate)

Press the button to roll: a short shuffle, then the die face on the matrix and the running total on the TM1637.

Parts:
  Push Button tactile 6x6 x1
  TM1637 4-digit 7-segment x1
  8x8 LED Matrix MAX7219 x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  the 9 pip positions of a die (3x3, row by row) as a bit mask per face

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-21-digital-dice
