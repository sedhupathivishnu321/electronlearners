// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

// the 9 pip positions of a die (3x3, row by row) as a bit mask per face
int FACE[7] = {0, 16, 257, 273, 325, 341, 365};
int total = 0;

void showFace(int face) {
  mat.clearDisplay(0);
  for (int p = 0; p < 9; p++) {
    if (FACE[face] & (1 << p)) {
      int r0 = (p / 3) * 3, c0 = (p % 3) * 3;               // every pip is a 2x2 block
      for (int dr = 0; dr < 2; dr++) for (int dc = 0; dc < 2; dc++) mat.setLed(0, r0 + dr, c0 + dc, true);
    }
  }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  tm.setBrightness(7);
  tm.showNumberDec(0);
  showFace(6);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    randomSeed(micros());
    for (int i = 0; i < 8; i++) { showFace(random(1, 7)); delay(60 + i * 15); }   // rolling...
    int face = random(1, 7);
    showFace(face);
    total += face;
    tm.showNumberDec(total);
    Serial.print("rolled "); Serial.print(face); Serial.print("  total "); Serial.println(total);
  }
}
