// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool lightOn = true;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  lcd.init();
  lcd.backlight();
  lcdRow(0, "Backlight: ON");
  lcdRow(1, "Press the button");
}

void loop() {
  if (pressed()) {
    lightOn = !lightOn;
    if (lightOn) lcd.backlight(); else lcd.noBacklight();
    lcdRow(0, lightOn ? "Backlight: ON" : "Backlight: OFF");
  }
}
