Kit 3 - Displays and Interfaces
Project 10: LCD Backlight Control (Basic)

The push button toggles the LCD backlight.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-10-lcd-backlight
