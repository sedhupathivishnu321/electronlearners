// ---- Circuit (Kit 3) ----
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

String KEYS = "0123456789+-*/=C";
int keyIdx = 0;
String expr = "";
String shown = "";                          // result text while a result is on screen
bool calcErr = false;

long applyOp(long a, char op, long b) {
  if (op == '+') return a + b;
  if (op == '-') return a - b;
  if (op == '*') return a * b;
  if (b == 0) { calcErr = true; return 0; }
  return a / b;
}

long evaluate(String e) {
  calcErr = false;
  long acc = 0, cur = 0;
  char op = '+';
  for (int i = 0; i < e.length(); i++) {
    char c = e.charAt(i);
    if (c >= '0' && c <= '9') cur = cur * 10 + (c - '0');
    else { acc = applyOp(acc, op, cur); op = c; cur = 0; }
  }
  return applyOp(acc, op, cur);
}

void draw() {
  String top = expr;
  while (top.length() > 16) top = top.substring(1);
  lcdRow(0, top);
  if (shown != "") lcdRow(1, "= " + shown);
  else lcdRow(1, "Pick [" + String(KEYS.charAt(keyIdx)) + "] push=OK");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(JOY_SW, INPUT_PULLUP);
  lcd.init();
  lcd.backlight();
  Serial.begin(9600);
  draw();
}

void loop() {
  int d = joyDir();
  if (d == 1) { keyIdx = (keyIdx + 15) % 16; shown = ""; draw(); }
  if (d == 2) { keyIdx = (keyIdx + 1) % 16; shown = ""; draw(); }
  if (pressed()) {                                       // backspace
    if (expr.length() > 0) expr = expr.substring(0, expr.length() - 1);
    shown = ""; draw();
  }
  if (joyClicked()) {
    char k = KEYS.charAt(keyIdx);
    if (k == 'C') { expr = ""; shown = ""; }
    else if (k == '=') {
      long r = evaluate(expr);
      shown = calcErr ? String("Error") : String(r);
      Serial.print(expr); Serial.print(" = "); Serial.println(shown);
      if (!calcErr) expr = String(r);                    // keep calculating with the result
    } else { expr += k; shown = ""; }
    draw();
  }
}
