Kit 3 - Displays and Interfaces
Project 41: Calculator with Joystick Keypad (Advanced)

Joystick left/right picks a key (0-9 + - * / = C), the joystick button types it, the push button is backspace. Evaluated left to right, whole numbers.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  Joystick Module x1

Circuit notes:
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-41-calculator
