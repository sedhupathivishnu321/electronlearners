Kit 3 - Displays and Interfaces
Project 32: Snake Game (Advanced)

Snake on the 8x8 matrix steered by the joystick; the TM1637 counts apples. Walls and your own tail are deadly.

Parts:
  TM1637 4-digit 7-segment x1
  8x8 LED Matrix MAX7219 x1
  Joystick Module x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-32-snake
