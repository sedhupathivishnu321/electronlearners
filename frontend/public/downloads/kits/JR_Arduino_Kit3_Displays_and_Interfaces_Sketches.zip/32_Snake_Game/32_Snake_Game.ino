// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define TM_CLK 10
#define TM_DIO 11

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);

int sx[64], sy[64];
int len = 3, dirx = 1, diry = 0, fx = 0, fy = 0, score = 0;
unsigned long lastStep = 0;

bool onSnake(int x, int y) {
  for (int i = 0; i < len; i++) if (sx[i] == x && sy[i] == y) return true;
  return false;
}

void placeFood() {
  bool ok = false;
  while (!ok) {
    fx = random(0, 8); fy = random(0, 8);
    ok = !onSnake(fx, fy);
  }
}

void draw() {
  mat.clearDisplay(0);
  for (int i = 0; i < len; i++) mat.setLed(0, sy[i], sx[i], true);
  mat.setLed(0, fy, fx, true);
}

void newGame() {
  len = 3; score = 0; dirx = 1; diry = 0;
  sx[0] = 4; sy[0] = 4; sx[1] = 3; sy[1] = 4; sx[2] = 2; sy[2] = 4;
  placeFood();
  tm.showNumberDec(0);
  draw();
}

void setup() {
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  tm.setBrightness(7);
  Serial.begin(9600);
  randomSeed(micros());
  newGame();
}

void loop() {
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512;
  if (abs(dx) > abs(dy) && abs(dx) > 250) {                       // steer, but never reverse into yourself
    if (dx > 0 && dirx != -1) { dirx = 1; diry = 0; }
    if (dx < 0 && dirx != 1) { dirx = -1; diry = 0; }
  } else if (abs(dy) > 250) {
    if (dy > 0 && diry != -1) { dirx = 0; diry = 1; }
    if (dy < 0 && diry != 1) { dirx = 0; diry = -1; }
  }
  if (millis() - lastStep < max(100, 320 - score * 15)) return;
  lastStep = millis();
  int nx = sx[0] + dirx, ny = sy[0] + diry;
  bool hitTail = onSnake(nx, ny) && !(nx == sx[len - 1] && ny == sy[len - 1]);
  if (nx < 0 || nx > 7 || ny < 0 || ny > 7 || hitTail) {
    Serial.print("crash! apples = "); Serial.println(score);
    for (int i = 0; i < 3; i++) { mat.clearDisplay(0); delay(150); draw(); delay(150); }
    delay(600);
    newGame();
    return;
  }
  bool eat = (nx == fx && ny == fy);
  if (eat && len < 63) len++;
  for (int i = len - 1; i > 0; i--) { sx[i] = sx[i - 1]; sy[i] = sy[i - 1]; }
  sx[0] = nx; sy[0] = ny;
  if (eat) { score++; tm.showNumberDec(score); placeFood(); }
  draw();
}
