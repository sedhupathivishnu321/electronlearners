Kit 3 - Displays and Interfaces
Project 6: 74HC595 LED Counter (Basic)

Counts 0-255 in binary on 8 LEDs through the shift register.

Parts:
  Shift Register 74HC595 x1
  Resistor 220 ohm 1/4W x8
  LED 5mm Red x2
  LED 5mm Yellow x2
  LED 5mm Green x2
  LED 5mm Blue x2

Circuit notes:
  74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-06-595-counter
