Kit 3 - Displays and Interfaces
Project 47: Pixel Art Editor (Advanced)

Joystick moves the cursor, its button flips a pixel, the push button saves the picture as the next frame (up to 8). Encoder turn = browse frames, encoder push = play / stop the animation (turn = speed).

Parts:
  Push Button tactile 6x6 x1
  8x8 LED Matrix MAX7219 x1
  Rotary Encoder KY-040 x1
  Joystick Module x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-47-pixel-art
