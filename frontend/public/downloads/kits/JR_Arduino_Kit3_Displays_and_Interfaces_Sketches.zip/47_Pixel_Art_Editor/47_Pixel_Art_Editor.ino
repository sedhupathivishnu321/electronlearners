// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define BTN1 2
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

byte canvas[8];
byte frames[64];
int nFrames = 0, browse = 0, cx = 0, cy = 0, playIdx = 0, speed = 300;
bool playing = false;
unsigned long last = 0;

void showCanvas(bool cursor) {
  bool blink = (millis() / 250) % 2 == 0;
  for (int r = 0; r < 8; r++) {
    byte row = canvas[r];
    if (cursor && r == cy && blink) row = row ^ (0x80 >> cx);
    mat.setRow(0, r, row);
  }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(JOY_SW, INPUT_PULLUP);
  encBegin();
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  Serial.begin(9600);
  Serial.println("edit mode: joystick = cursor / pixel, button = save frame, encoder push = play");
}

void loop() {
  if (!playing) {
    int d = joyDir();
    if (d == 1 && cx > 0) cx--;
    if (d == 2 && cx < 7) cx++;
    if (d == 3 && cy > 0) cy--;
    if (d == 4 && cy < 7) cy++;
    if (joyClicked()) canvas[cy] = canvas[cy] ^ (0x80 >> cx);
    if (pressed() && nFrames < 8) {
      for (int r = 0; r < 8; r++) frames[nFrames * 8 + r] = canvas[r];
      nFrames++;
      Serial.print("saved frame "); Serial.println(nFrames);
    }
    int s = encStep();
    if (s != 0 && nFrames > 0) {                         // browse saved frames
      browse = (browse + s + nFrames) % nFrames;
      for (int r = 0; r < 8; r++) canvas[r] = frames[browse * 8 + r];
    }
    if (encClicked() && nFrames > 0) { playing = true; playIdx = 0; last = 0; Serial.println("play"); }
    showCanvas(true);
  } else {
    int s = encStep();
    if (s != 0) speed = constrain(speed - s * 40, 60, 800);
    if (millis() - last >= speed) {
      last = millis();
      for (int r = 0; r < 8; r++) mat.setRow(0, r, frames[playIdx * 8 + r]);
      playIdx = (playIdx + 1) % nFrames;
    }
    if (encClicked() || pressed()) { playing = false; Serial.println("edit mode"); }
  }
  delay(10);
}
