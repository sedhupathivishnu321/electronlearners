Kit 3 - Displays and Interfaces
Project 43: Scrolling News Ticker with Speed Control (Advanced)

The headline scrolls across the matrix (5x7 font) and the OLED together. Turn the encoder to change the speed.

Parts:
  0.96in OLED I2C SSD1306 x1
  8x8 LED Matrix MAX7219 x1
  Rotary Encoder KY-040 x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-43-news-ticker
