// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
String FONT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 -!:";
byte FONT[] = {                            // 5x7 font, 5 column bytes per character (bit 0 = top row)
  0x7E, 0x11, 0x11, 0x11, 0x7E, 0x7F, 0x49, 0x49, 0x49, 0x36,
  0x3E, 0x41, 0x41, 0x41, 0x22, 0x7F, 0x41, 0x41, 0x22, 0x1C,
  0x7F, 0x49, 0x49, 0x49, 0x41, 0x7F, 0x09, 0x09, 0x09, 0x01,
  0x3E, 0x41, 0x49, 0x49, 0x7A, 0x7F, 0x08, 0x08, 0x08, 0x7F,
  0x00, 0x41, 0x7F, 0x41, 0x00, 0x20, 0x40, 0x41, 0x3F, 0x01,
  0x7F, 0x08, 0x14, 0x22, 0x41, 0x7F, 0x40, 0x40, 0x40, 0x40,
  0x7F, 0x02, 0x0C, 0x02, 0x7F, 0x7F, 0x04, 0x08, 0x10, 0x7F,
  0x3E, 0x41, 0x41, 0x41, 0x3E, 0x7F, 0x09, 0x09, 0x09, 0x06,
  0x3E, 0x41, 0x51, 0x21, 0x5E, 0x7F, 0x09, 0x19, 0x29, 0x46,
  0x46, 0x49, 0x49, 0x49, 0x31, 0x01, 0x01, 0x7F, 0x01, 0x01,
  0x3F, 0x40, 0x40, 0x40, 0x3F, 0x1F, 0x20, 0x40, 0x20, 0x1F,
  0x3F, 0x40, 0x38, 0x40, 0x3F, 0x63, 0x14, 0x08, 0x14, 0x63,
  0x07, 0x08, 0x70, 0x08, 0x07, 0x61, 0x51, 0x49, 0x45, 0x43,
  0x3E, 0x51, 0x49, 0x45, 0x3E, 0x00, 0x42, 0x7F, 0x40, 0x00,
  0x42, 0x61, 0x51, 0x49, 0x46, 0x21, 0x41, 0x45, 0x4B, 0x31,
  0x18, 0x14, 0x12, 0x7F, 0x10, 0x27, 0x45, 0x45, 0x45, 0x39,
  0x3C, 0x4A, 0x49, 0x49, 0x30, 0x01, 0x71, 0x09, 0x05, 0x03,
  0x36, 0x49, 0x49, 0x49, 0x36, 0x06, 0x49, 0x49, 0x29, 0x1E,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x08, 0x08, 0x08, 0x08,
  0x00, 0x00, 0x5F, 0x00, 0x00, 0x00, 0x36, 0x36, 0x00, 0x00
};
byte fontCol(char ch, int k) {              // column k (0-4) of a glyph; column 5 is the blank gap between letters
  if (k > 4) return 0;
  int i = FONT_CHARS.indexOf(ch);
  if (i < 0) return 0;
  return FONT[i * 5 + k];
}

String msg = "JR LEARNERS KIT 3 - DISPLAYS AND INTERFACES   ";
int total, shift = 0, wait = 150;
unsigned long last = 0;

void setup() {
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  encBegin();
  total = msg.length() * 6;
  Serial.begin(9600);
}

void loop() {
  int s = encStep();
  if (s != 0) {
    wait = constrain(wait - s * 20, 30, 400);            // clockwise = faster
    Serial.print("step every "); Serial.print(wait); Serial.println(" ms");
  }
  if (millis() - last < wait) return;
  last = millis();
  for (int c = 0; c < 8; c++) {
    int t = (shift + c) % total;
    byte bits = fontCol(msg.charAt(t / 6), t % 6);
    for (int r = 0; r < 8; r++) mat.setLed(0, r, c, (bits >> r) & 1);
  }
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextWrap(false);
  oled.setTextSize(2);
  oled.setCursor(128 - (shift * 2) % (total * 2 + 128), 8);       // the same text, 2 pixels per step
  oled.print(msg);
  oled.setTextSize(1);
  oled.setCursor(0, 50);
  oled.print("Speed: "); oled.print(map(wait, 400, 30, 1, 10)); oled.print("/10");
  oled.display();
  shift = (shift + 1) % total;
}
