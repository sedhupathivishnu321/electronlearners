Kit 3 - Displays and Interfaces
Project 36: Matrix Equaliser Visualizer (Advanced)

Eight animated spectrum bars on the matrix. Joystick up/down = level (gain), left/right = animation speed.

Parts:
  8x8 LED Matrix MAX7219 x1
  Joystick Module x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-36-equaliser
