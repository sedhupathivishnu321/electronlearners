// ---- Circuit (Kit 3) ----
// MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define MAT_DIN 12
#define MAT_CLK 13
#define MAT_CS A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

#include <LedControl.h>
LedControl mat = LedControl(MAT_DIN, MAT_CLK, MAT_CS, 1);

int level[8], target[8];
unsigned long last = 0;

void setup() {
  mat.shutdown(0, false);
  mat.setIntensity(0, 4);
  mat.clearDisplay(0);
  randomSeed(micros());
}

void loop() {
  int gain = map(analogRead(JOY_Y), 0, 1023, 8, 2);       // stick up = taller bars
  int wait = map(analogRead(JOY_X), 0, 1023, 200, 40);    // stick right = faster
  if (millis() - last < wait) return;
  last = millis();
  for (int c = 0; c < 8; c++) {
    if (random(0, 3) == 0) target[c] = random(0, max(1, gain - c / 3) + 1);   // low bands are livelier than high ones
    if (level[c] < target[c]) level[c]++;
    else if (level[c] > target[c]) level[c]--;
    for (int r = 0; r < 8; r++) mat.setLed(0, r, c, (7 - r) < level[c]);
  }
}
