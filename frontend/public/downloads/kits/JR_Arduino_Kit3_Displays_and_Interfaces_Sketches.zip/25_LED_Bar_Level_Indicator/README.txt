Kit 3 - Displays and Interfaces
Project 25: LED Bar Level Indicator (Intermediate)

The joystick Y position lights 0-8 LEDs as a bar through the 74HC595.

Parts:
  Shift Register 74HC595 x1
  Resistor 220 ohm 1/4W x8
  LED 5mm Red x2
  LED 5mm Yellow x2
  LED 5mm Green x2
  LED 5mm Blue x2
  Joystick Module x1

Circuit notes:
  74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-25-led-level
