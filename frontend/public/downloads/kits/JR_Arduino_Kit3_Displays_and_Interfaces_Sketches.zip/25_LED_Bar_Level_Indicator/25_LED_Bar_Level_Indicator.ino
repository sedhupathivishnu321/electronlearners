// ---- Circuit (Kit 3) ----
// 74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define SR_DATA 12
#define SR_CLOCK 13
#define SR_LATCH A2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

void srWrite(byte v) {                      // send 8 bits to the 74HC595 and latch them onto Q0-Q7
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, v);
  digitalWrite(SR_LATCH, HIGH);
}
void srBegin() {
  pinMode(SR_DATA, OUTPUT); pinMode(SR_CLOCK, OUTPUT); pinMode(SR_LATCH, OUTPUT);
  srWrite(0);
}

int lastLevel = -1;

void setup() {
  srBegin();
  Serial.begin(9600);
}

void loop() {
  int level = constrain(map(analogRead(JOY_Y), 0, 1023, 0, 9), 0, 8);     // 9 zones: 0 .. 8 LEDs
  if (level != lastLevel) {
    lastLevel = level;
    srWrite((1 << level) - 1);             // level 3 -> 00000111
    Serial.print("level "); Serial.print(level); Serial.println(" / 8");
  }
  delay(40);
}
