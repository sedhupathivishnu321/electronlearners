Kit 3 - Displays and Interfaces
Project 46: Lap Timer with Best-Lap Record (Advanced)

First press starts the timer, each later press records a lap. The TM1637 shows the running lap time, the LCD the last and best lap. Hold the button for 1 s to reset.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  TM1637 4-digit 7-segment x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-46-lap-timer
