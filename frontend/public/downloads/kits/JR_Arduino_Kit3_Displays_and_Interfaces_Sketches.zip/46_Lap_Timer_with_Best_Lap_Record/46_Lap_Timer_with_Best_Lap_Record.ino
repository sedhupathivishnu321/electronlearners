// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}

bool running = false;
unsigned long lapStart = 0, lastLap = 0, best = 0;
int laps = 0, bestLap = 0;

String secText(unsigned long ms) {
  unsigned long cs = ms / 10 % 100;
  return String(ms / 1000) + "." + (cs < 10 ? "0" : "") + String(cs) + "s";
}

void showClock() {
  unsigned long ms = running ? millis() - lapStart : 0;
  tm.showNumberDecEx((ms / 1000 % 100) * 100 + ms / 10 % 100, 0x40, true);
}

void showLaps() {
  if (laps == 0) { lcdRow(0, running ? "Running..." : "Press to start"); lcdRow(1, ""); return; }
  lcdRow(0, "Lap " + String(laps) + ": " + secText(lastLap));
  lcdRow(1, "Best L" + String(bestLap) + ": " + secText(best));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  tm.setBrightness(7);
  lcd.init();
  lcd.backlight();
  showClock();
  showLaps();
  Serial.begin(9600);
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 1000) showClock();
    if (digitalRead(BTN1) == LOW) {                      // held for a second: reset everything
      running = false; laps = 0; best = 0; bestLap = 0;
      Serial.println("reset");
      showClock(); showLaps();
      while (digitalRead(BTN1) == LOW) { }
    } else if (!running) {
      running = true; lapStart = millis(); laps = 0; best = 0;
      showLaps();
    } else {
      lastLap = millis() - lapStart;
      lapStart = millis();
      laps++;
      if (best == 0 || lastLap < best) { best = lastLap; bestLap = laps; }
      Serial.print("lap "); Serial.print(laps); Serial.print(": "); Serial.println(secText(lastLap));
      showLaps();
    }
    delay(30);
  }
  showClock();
  delay(10);
}
