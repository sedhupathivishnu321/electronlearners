// ---- Circuit (Kit 3) ----
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}

int sel = 0;

String itemName(int i) {
  if (i == 0) return "Lights";
  if (i == 1) return "Music";
  if (i == 2) return "Settings";
  return "About";
}

void drawMenu() {
  lcdRow(0, "> " + itemName(sel));
  lcdRow(1, "  " + itemName((sel + 1) % 4));
}

void setup() {
  encBegin();
  lcd.init();
  lcd.backlight();
  drawMenu();
  Serial.begin(9600);
}

void loop() {
  int s = encStep();
  if (s != 0) {
    sel = (sel + s + 4) % 4;
    drawMenu();
  }
  if (encClicked()) {
    lcdRow(0, "Selected:");
    lcdRow(1, itemName(sel));
    Serial.print("selected "); Serial.println(itemName(sel));
    delay(1500);
    drawMenu();
  }
}
