Kit 3 - Displays and Interfaces
Project 18: Encoder Menu on LCD (Intermediate)

Scroll a 4-item menu with the encoder and select with its push switch.

Parts:
  16x2 LCD I2C x1
  Rotary Encoder KY-040 x1

Circuit notes:
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-18-encoder-menu
