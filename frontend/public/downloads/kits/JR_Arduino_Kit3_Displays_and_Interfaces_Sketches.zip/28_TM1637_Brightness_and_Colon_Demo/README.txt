Kit 3 - Displays and Interfaces
Project 28: TM1637 Brightness and Colon Demo (Intermediate)

Uptime MM:SS with a blinking colon; the encoder sets the display brightness (0-7).

Parts:
  TM1637 4-digit 7-segment x1
  Rotary Encoder KY-040 x1

Circuit notes:
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-28-tm-brightness
