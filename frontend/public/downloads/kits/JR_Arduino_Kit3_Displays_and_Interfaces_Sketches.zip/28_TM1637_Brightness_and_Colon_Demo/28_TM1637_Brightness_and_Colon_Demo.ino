// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
#define TM_CLK 10
#define TM_DIO 11
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}

int bright = 4;
bool colon = false;
unsigned long lastTick = 0;

void show() {
  unsigned long secs = millis() / 1000;
  tm.showNumberDecEx((secs / 60 % 100) * 100 + secs % 60, colon ? 0x40 : 0, true);
}

void setup() {
  encBegin();
  tm.setBrightness(bright);
  show();
  Serial.begin(9600);
}

void loop() {
  int s = encStep();
  if (s != 0) {
    bright = constrain(bright + s, 0, 7);
    tm.setBrightness(bright);
    show();
    Serial.print("brightness "); Serial.println(bright);
  }
  if (millis() - lastTick >= 500) {                     // colon toggles twice a second
    lastTick = millis();
    colon = !colon;
    show();
  }
}
