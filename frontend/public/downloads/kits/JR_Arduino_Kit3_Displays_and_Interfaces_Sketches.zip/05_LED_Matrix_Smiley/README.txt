Kit 3 - Displays and Interfaces
Project 5: LED Matrix Smiley (Basic)

Draws a smiley face on the 8x8 MAX7219 matrix.

Parts:
  8x8 LED Matrix MAX7219 x1

Circuit notes:
  MAX7219 matrix: VCC 5V, GND, DIN -> D12, CLK -> D13, CS -> A2

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-05-matrix-smiley
