// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int page = 0;
int presses = 0, clicks = 0;
unsigned long lastDraw = 0;

String twoDigits(long v) {
  return v < 10 ? String("0") + String(v) : String(v);
}

void drawPage() {
  unsigned long secs = millis() / 1000;
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  if (page == 0) {
    oled.println("UPTIME");
    oled.setTextSize(2);
    oled.setCursor(0, 24);
    oled.print(twoDigits(secs / 3600)); oled.print(":"); oled.print(twoDigits(secs / 60 % 60)); oled.print(":"); oled.print(twoDigits(secs % 60));
  } else if (page == 1) {
    int x = analogRead(JOY_X), y = analogRead(JOY_Y);
    oled.println("JOYSTICK");
    oled.setCursor(0, 16); oled.print("X: "); oled.print(x);
    oled.setCursor(0, 28); oled.print("Y: "); oled.print(y);
    oled.setCursor(0, 40); oled.print("Btn: "); oled.print(digitalRead(JOY_SW) == LOW ? "PRESSED" : "released");
    oled.drawRect(80, 8, 46, 46, SSD1306_WHITE);
    oled.fillCircle(80 + map(x, 0, 1023, 3, 42) + 2, 8 + map(y, 0, 1023, 3, 42) + 2, 3, SSD1306_WHITE);
  } else {
    oled.println("COUNTERS");
    oled.setCursor(0, 16); oled.print("Button presses: "); oled.print(presses);
    oled.setCursor(0, 28); oled.print("Encoder clicks: "); oled.print(clicks);
    oled.setCursor(0, 40); oled.print("Seconds up:     "); oled.print(secs);
  }
  oled.display();
}

void showTitle() {
  lcdRow(0, "Dashboard " + String(page + 1) + "/3");
  lcdRow(1, page == 0 ? "Uptime" : (page == 1 ? "Joystick" : "Counters"));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(JOY_SW, INPUT_PULLUP);
  encBegin();
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.init();
  lcd.backlight();
  showTitle();
  drawPage();
}

void loop() {
  int s = encStep();
  if (s != 0) { page = (page + s + 3) % 3; showTitle(); drawPage(); }
  if (pressed()) presses++;
  if (encClicked()) clicks++;
  if (millis() - lastDraw >= 150) { lastDraw = millis(); drawPage(); }
}
