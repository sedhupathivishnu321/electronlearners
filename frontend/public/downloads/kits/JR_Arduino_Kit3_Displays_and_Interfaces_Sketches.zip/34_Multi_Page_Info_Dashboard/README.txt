Kit 3 - Displays and Interfaces
Project 34: Multi-Page Info Dashboard (Advanced)

Turn the encoder to flip between Uptime, Joystick and Counters pages on the OLED while the LCD names the page.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  0.96in OLED I2C SSD1306 x1
  Rotary Encoder KY-040 x1
  Joystick Module x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-34-dashboard
