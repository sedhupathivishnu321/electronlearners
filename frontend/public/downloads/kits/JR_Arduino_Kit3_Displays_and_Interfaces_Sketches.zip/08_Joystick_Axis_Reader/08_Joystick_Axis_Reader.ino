// ---- Circuit (Kit 3) ----
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

void setup() {
  Serial.begin(9600);
  pinMode(JOY_SW, INPUT_PULLUP);
}

void loop() {
  int x = analogRead(JOY_X);
  int y = analogRead(JOY_Y);
  Serial.print("X = "); Serial.print(x);
  Serial.print("   Y = "); Serial.print(y);
  Serial.print("   button = "); Serial.println(digitalRead(JOY_SW) == LOW ? "PRESSED" : "released");
  delay(300);
}
