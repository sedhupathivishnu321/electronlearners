Kit 3 - Displays and Interfaces
Project 8: Joystick Axis Reader (Basic)

Prints the X, Y and button state of the joystick.

Parts:
  Joystick Module x1

Circuit notes:
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-08-joystick-read
