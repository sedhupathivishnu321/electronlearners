// ---- Circuit (Kit 3) ----
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define BTN1 2

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

String WORDS = "ARDUINO,SENSOR,DISPLAY,SERVO,BREADBOARD,JOYSTICK,";
int wordIdx = 0, presses = 0, hits = 0, wordsDone = 0;
String target = "", typed = "";
char letter = 'A';
unsigned long startMs = 0;
bool wrong = false;

String wordAt(int n) {
  int pos = 0;
  for (int k = 0; k < n % 6; k++) pos = WORDS.indexOf(',', pos) + 1;
  return WORDS.substring(pos, WORDS.indexOf(',', pos));
}

void drawOled() {
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.print("TYPE: "); oled.print(target);
  oled.setTextSize(2);
  oled.setCursor(0, 20);
  oled.print(typed); oled.print("_");
  oled.setTextSize(1);
  oled.setCursor(0, 50);
  oled.print("< "); oled.print(String(letter)); oled.print(" >");
  if (wrong) { oled.setCursor(60, 50); oled.print("WRONG!"); }
  oled.display();
}

void drawLcd() {
  int acc = presses == 0 ? 100 : hits * 100 / presses;
  unsigned long ms = startMs == 0 ? 0 : millis() - startMs;
  int cpm = ms < 2000 ? 0 : hits * 60000L / ms;                 // correct characters per minute
  lcdRow(0, "Acc " + String(acc) + "%  " + String(cpm) + " cpm");
  lcdRow(1, "Words done: " + String(wordsDone));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.init();
  lcd.backlight();
  Serial.begin(9600);
  target = wordAt(wordIdx);
  drawOled();
  drawLcd();
}

void loop() {
  int d = joyDir();
  if (d != 0) {
    if (d == 1) letter = 'A' + (letter - 'A' + 25) % 26;
    if (d == 2) letter = 'A' + (letter - 'A' + 1) % 26;
    if (d == 3) letter = 'A' + (letter - 'A' + 5) % 26;
    if (d == 4) letter = 'A' + (letter - 'A' + 21) % 26;
    wrong = false;
    drawOled();
  }
  if (pressed()) {
    if (startMs == 0) startMs = millis();
    presses++;
    if (letter == target.charAt(typed.length())) {
      hits++; wrong = false;
      typed += letter;
      if (typed.length() == target.length()) {
        wordsDone++;
        Serial.print("word complete: "); Serial.println(target);
        drawOled();
        delay(600);
        wordIdx++; target = wordAt(wordIdx); typed = "";
      }
    } else {
      wrong = true;
    }
    drawOled();
    drawLcd();
  }
}
