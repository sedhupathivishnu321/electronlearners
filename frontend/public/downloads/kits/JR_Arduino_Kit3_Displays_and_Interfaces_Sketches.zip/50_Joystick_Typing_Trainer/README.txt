Kit 3 - Displays and Interfaces
Project 50: Joystick Typing Trainer (Advanced)

Spell the target word letter by letter: joystick left/right = previous / next letter, up/down = jump 5, push button = type it. The LCD shows accuracy and speed.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1
  0.96in OLED I2C SSD1306 x1
  Joystick Module x1

Circuit notes:
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-50-typing-trainer
