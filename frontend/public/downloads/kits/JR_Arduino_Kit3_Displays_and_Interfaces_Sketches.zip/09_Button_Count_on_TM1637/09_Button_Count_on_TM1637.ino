// ---- Circuit (Kit 3) ----
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TM_CLK 10
#define TM_DIO 11
#define BTN1 2

#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int count = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  tm.setBrightness(7);
  tm.showNumberDec(count);
}

void loop() {
  if (pressed()) {
    count = (count + 1) % 10000;
    tm.showNumberDec(count);
  }
}
