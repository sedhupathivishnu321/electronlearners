Kit 3 - Displays and Interfaces
Project 23: Etch-A-Sketch on OLED (Intermediate)

Draw with the joystick (push it past centre to move the pen); the push button clears the screen.

Parts:
  Push Button tactile 6x6 x1
  0.96in OLED I2C SSD1306 x1
  Joystick Module x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-23-etch-a-sketch
