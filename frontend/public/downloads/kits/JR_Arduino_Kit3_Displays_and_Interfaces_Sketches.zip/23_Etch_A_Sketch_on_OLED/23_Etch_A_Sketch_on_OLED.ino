// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3
#define BTN1 2

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

int x = 64, y = 32;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.clearDisplay();
  oled.drawPixel(x, y, SSD1306_WHITE);
  oled.display();
}

void loop() {
  if (digitalRead(BTN1) == LOW) {                          // shake to erase
    oled.clearDisplay();
    oled.drawPixel(x, y, SSD1306_WHITE);
    oled.display();
    delay(250);
  }
  int dx = analogRead(JOY_X) - 512;
  int dy = analogRead(JOY_Y) - 512;
  int nx = x, ny = y;
  if (dx > 150) nx++;
  if (dx < -150) nx--;
  if (dy > 150) ny++;
  if (dy < -150) ny--;
  nx = constrain(nx, 0, 127);
  ny = constrain(ny, 0, 63);
  if (nx != x || ny != y) {
    oled.drawLine(x, y, nx, ny, SSD1306_WHITE);
    x = nx; y = ny;
    oled.display();
  }
  delay(15);
}
