Kit 3 - Displays and Interfaces
Project 44: OLED Oscilloscope Simulator (Advanced)

Scrolling sine / sawtooth / square waves. The encoder sets the frequency, the button changes the waveform.

Parts:
  Push Button tactile 6x6 x1
  0.96in OLED I2C SSD1306 x1
  Rotary Encoder KY-040 x1

Circuit notes:
  SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-44-oscilloscope
