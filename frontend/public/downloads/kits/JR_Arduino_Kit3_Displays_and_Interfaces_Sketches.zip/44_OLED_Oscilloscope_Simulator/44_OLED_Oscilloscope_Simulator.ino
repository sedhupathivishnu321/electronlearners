// ---- Circuit (Kit 3) ----
// SSD1306 OLED (I2C, address 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5 (shares the bus with the LCD)
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define BTN1 2

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int wave = 0, freq = 4;                       // freq = cycles on screen
unsigned long lastFrame = 0;

float sample(int x, float phase) {
  float p = x * freq / 128.0 + phase;
  p = p - floor(p);                           // 0..1 inside one cycle
  if (wave == 0) return sin(p * 6.28318);
  if (wave == 1) return 2 * p - 1;
  return p < 0.5 ? 1 : -1;
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  encBegin();
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  Serial.begin(9600);
}

void loop() {
  int s = encStep();
  if (s != 0) { freq = constrain(freq + s, 1, 20); Serial.print("cycles "); Serial.println(freq); }
  if (pressed()) { wave = (wave + 1) % 3; Serial.print("wave "); Serial.println(wave); }
  if (millis() - lastFrame < 50) return;
  lastFrame = millis();
  float phase = millis() / 600.0;
  oled.clearDisplay();
  oled.drawRect(0, 10, 128, 54, SSD1306_WHITE);
  for (int x = 4; x < 128; x += 8) oled.drawPixel(x, 37, SSD1306_WHITE);       // centre line
  int prevY = 37 - 22 * sample(0, phase);
  for (int x = 1; x < 128; x++) {
    int y = 37 - 22 * sample(x, phase);
    oled.drawLine(x - 1, prevY, x, y, SSD1306_WHITE);
    prevY = y;
  }
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.print(wave == 0 ? "SINE" : (wave == 1 ? "SAW" : "SQUARE"));
  oled.print("  cycles: "); oled.print(freq);
  oled.display();
}
