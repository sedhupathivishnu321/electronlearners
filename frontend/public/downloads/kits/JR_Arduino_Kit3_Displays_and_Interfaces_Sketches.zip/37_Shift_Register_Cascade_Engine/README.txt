Kit 3 - Displays and Interfaces
Project 37: Shift-Register Cascade Engine (Advanced)

Six LED animation patterns on the 74HC595. Joystick left/right picks the pattern, the encoder sets the speed.

Parts:
  Shift Register 74HC595 x1
  Resistor 220 ohm 1/4W x8
  LED 5mm Red x2
  LED 5mm Yellow x2
  LED 5mm Green x2
  LED 5mm Blue x2
  Rotary Encoder KY-040 x1
  Joystick Module x1

Circuit notes:
  74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-37-cascade-engine
