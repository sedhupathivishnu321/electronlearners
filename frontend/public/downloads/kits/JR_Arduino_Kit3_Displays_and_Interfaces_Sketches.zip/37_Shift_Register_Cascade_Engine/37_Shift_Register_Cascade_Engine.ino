// ---- Circuit (Kit 3) ----
// 74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// Joystick: +5V, GND, VRx -> A0, VRy -> A1, SW -> A3 (INPUT_PULLUP)
#define SR_DATA 12
#define SR_CLOCK 13
#define SR_LATCH A2
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define JOY_X A0
#define JOY_Y A1
#define JOY_SW A3

void srWrite(byte v) {                      // send 8 bits to the 74HC595 and latch them onto Q0-Q7
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, v);
  digitalWrite(SR_LATCH, HIGH);
}
void srBegin() {
  pinMode(SR_DATA, OUTPUT); pinMode(SR_CLOCK, OUTPUT); pinMode(SR_LATCH, OUTPUT);
  srWrite(0);
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}
int joyLatched = 0;
int joyDir() {                             // one event per push: 1 = left, 2 = right, 3 = up, 4 = down, 0 = nothing new
  int dx = analogRead(JOY_X) - 512, dy = analogRead(JOY_Y) - 512, d = 0;
  if (dx < -250) d = 1; else if (dx > 250) d = 2; else if (dy < -250) d = 3; else if (dy > 250) d = 4;
  if (d == joyLatched) return 0;           // still held in the same direction
  joyLatched = d;
  return d;
}
int joySwLast = HIGH;
bool joyClicked() {                        // true once per press of the joystick button
  int now = digitalRead(JOY_SW);
  bool hit = (joySwLast == HIGH && now == LOW);
  joySwLast = now;
  if (hit) delay(20);
  return hit;
}

int pattern = 0, t = 0, wait = 120;
unsigned long last = 0;

byte frame(int p, int step) {
  if (p == 0) return 1 << (step % 8);                              // chase
  if (p == 1) { int k = step % 14; if (k > 7) k = 14 - k; return 1 << k; }     // bounce
  if (p == 2) return (1 << (step % 9)) - 1;                        // fill up, then empty
  if (p == 3) return (step % 2) ? 0xAA : 0x55;                     // alternate
  if (p == 4) return random(0, 256);                               // sparkle
  int k = step % 8;                                                // converge from both ends
  return (1 << k) | (128 >> k);
}

void setup() {
  srBegin();
  encBegin();
  Serial.begin(9600);
  Serial.println("Joystick left/right = pattern, encoder = speed");
}

void loop() {
  int d = joyDir();
  if (d == 1 || d == 2) {
    pattern = (pattern + (d == 2 ? 1 : 5)) % 6;
    t = 0;
    Serial.print("pattern "); Serial.println(pattern);
  }
  int s = encStep();
  if (s != 0) {
    wait = constrain(wait - s * 20, 20, 400);                      // clockwise = faster
    Serial.print("delay "); Serial.print(wait); Serial.println(" ms");
  }
  if (millis() - last >= wait) {
    last = millis();
    srWrite(frame(pattern, t));
    t++;
  }
}
