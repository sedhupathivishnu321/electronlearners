Kit 3 - Displays and Interfaces
Project 42: Binary-Hex-Decimal Converter Trainer (Advanced)

Dial a number 0-255 with the encoder (push = step 1 / step 16). The 8 LEDs show binary, the TM1637 hex, the LCD decimal and binary.

Parts:
  Shift Register 74HC595 x1
  Resistor 220 ohm 1/4W x8
  LED 5mm Red x2
  LED 5mm Yellow x2
  LED 5mm Green x2
  LED 5mm Blue x2
  16x2 LCD I2C x1
  TM1637 4-digit 7-segment x1
  Rotary Encoder KY-040 x1

Circuit notes:
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
  74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
  TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
  16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-42-number-trainer
