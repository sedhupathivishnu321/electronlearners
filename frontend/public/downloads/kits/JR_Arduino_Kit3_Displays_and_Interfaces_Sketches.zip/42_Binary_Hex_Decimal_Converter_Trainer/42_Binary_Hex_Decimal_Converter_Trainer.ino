// ---- Circuit (Kit 3) ----
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
// 74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
// TM1637: VCC 5V, GND, CLK -> D10, DIO -> D11
// 16x2 LCD (I2C, address 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9
#define SR_DATA 12
#define SR_CLOCK 13
#define SR_LATCH A2
#define TM_CLK 10
#define TM_DIO 11

void srWrite(byte v) {                      // send 8 bits to the 74HC595 and latch them onto Q0-Q7
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, v);
  digitalWrite(SR_LATCH, HIGH);
}
void srBegin() {
  pinMode(SR_DATA, OUTPUT); pinMode(SR_CLOCK, OUTPUT); pinMode(SR_LATCH, OUTPUT);
  srWrite(0);
}
#include <TM1637Display.h>
TM1637Display tm(TM_CLK, TM_DIO);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}

int value = 0, stepSize = 1;

String binary8(int v) {
  String s = "";
  for (int i = 7; i >= 0; i--) s += (bitRead(v, i) ? "1" : "0");
  return s;
}

void showAll() {
  srWrite(value);                                        // binary on the LEDs
  byte seg[4] = {0x76, 0, tm.encodeDigit(value >> 4), tm.encodeDigit(value & 15)};   // "H" + two hex digits
  tm.setSegments(seg);
  lcdRow(0, "Dec: " + String(value) + "  +" + String(stepSize));
  lcdRow(1, "Bin: " + binary8(value));
  Serial.print(value); Serial.print(" = 0x"); Serial.print(value, HEX); Serial.print(" = 0b"); Serial.println(binary8(value));
}

void setup() {
  srBegin();
  encBegin();
  tm.setBrightness(7);
  lcd.init();
  lcd.backlight();
  Serial.begin(9600);
  showAll();
}

void loop() {
  int s = encStep();
  if (s != 0) {
    value = (value + s * stepSize + 256) % 256;
    showAll();
  }
  if (encClicked()) {
    stepSize = (stepSize == 1) ? 16 : 1;                 // coarse / fine
    showAll();
  }
}
