Kit 3 - Displays and Interfaces
Project 7: Rotary Encoder Counter (Basic)

Counts clockwise / counter-clockwise detents and prints them. Use the inspector buttons to turn the knob.

Parts:
  Rotary Encoder KY-040 x1

Circuit notes:
  KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k3-07-encoder-count
