// ---- Circuit (Kit 3) ----
// KY-040 encoder: + 5V, GND, CLK -> D7, DT -> D8, SW -> D9
#define ENC_CLK 7
#define ENC_DT 8
#define ENC_SW 9

int encLast = HIGH;
void encBegin() {
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encLast = digitalRead(ENC_CLK);
}
int encStep() {                            // +1 per clockwise detent, -1 per counter-clockwise detent, 0 when idle
  int c = digitalRead(ENC_CLK), d = 0;
  if (c != encLast && c == LOW) d = (digitalRead(ENC_DT) == HIGH) ? 1 : -1;
  encLast = c;
  return d;
}
int encSwLast = HIGH;
bool encClicked() {                        // true once per push of the encoder shaft
  int now = digitalRead(ENC_SW);
  bool hit = (encSwLast == HIGH && now == LOW);
  encSwLast = now;
  if (hit) delay(20);
  return hit;
}

int position = 0;

void setup() {
  Serial.begin(9600);
  encBegin();
  Serial.println("Turn the encoder - push the shaft to reset");
}

void loop() {
  int s = encStep();
  if (s != 0) {
    position += s;
    Serial.print(s > 0 ? "clockwise      " : "counter-clockwise ");
    Serial.print("position = "); Serial.println(position);
  }
  if (encClicked()) { position = 0; Serial.println("reset to 0"); }
}
