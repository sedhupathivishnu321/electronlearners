// ---- Circuit (Kit 3) ----
// 74HC595: SER -> D12, SRCLK -> D13, RCLK -> A2, /OE -> GND, /SRCLR -> 5V; Q0-Q7 -> 220 ohm -> 8 LEDs -> GND
#define SR_DATA 12
#define SR_CLOCK 13
#define SR_LATCH A2

void srWrite(byte v) {                      // send 8 bits to the 74HC595 and latch them onto Q0-Q7
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, v);
  digitalWrite(SR_LATCH, HIGH);
}
void srBegin() {
  pinMode(SR_DATA, OUTPUT); pinMode(SR_CLOCK, OUTPUT); pinMode(SR_LATCH, OUTPUT);
  srWrite(0);
}

int pos = 0, prev = 0, dir = 1;

void setup() {
  srBegin();
}

void loop() {
  srWrite((1 << pos) | (1 << prev));       // head + one LED of tail
  prev = pos;
  pos += dir;
  if (pos >= 7 || pos <= 0) dir = -dir;
  delay(80);
}
