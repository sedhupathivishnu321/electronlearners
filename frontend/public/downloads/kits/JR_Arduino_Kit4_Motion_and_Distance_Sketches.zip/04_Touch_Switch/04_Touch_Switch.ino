// ---- Circuit (Kit 4) ----
// TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define TOUCH_PIN 4
#define GREEN_LED 5

bool lampOn = false;
int lastTouch = LOW;

void setup() {
  pinMode(TOUCH_PIN, INPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int t = digitalRead(TOUCH_PIN);
  if (t == HIGH && lastTouch == LOW) {                      // new touch
    lampOn = !lampOn;
    digitalWrite(GREEN_LED, lampOn);
    Serial.println(lampOn ? "lamp ON" : "lamp OFF");
  }
  lastTouch = t;
  delay(30);
}
