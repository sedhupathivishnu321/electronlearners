Kit 4 - Motion and Distance
Project 4: Touch Switch (Basic)

Each touch of the TTP223 pad toggles the green LED.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Touch Sensor TTP223 x1

Circuit notes:
  TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-04-touch-switch
