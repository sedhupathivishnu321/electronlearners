Kit 4 - Motion and Distance
Project 24: Motion-Triggered Servo Camera Pan (Intermediate)

While the PIR sees motion the servo pans slowly left and right; when motion stops it holds its position.

Parts:
  PIR Motion HC-SR501 x1
  SG90 Micro Servo x1

Circuit notes:
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-24-pir-pan
