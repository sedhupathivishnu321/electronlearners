// ---- Circuit (Kit 4) ----
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
#define PIR_PIN 7
#define SERVO_PIN 6

#include <Servo.h>
Servo servo;

int angle = 90, dir = 1;
bool wasMoving = false;

void setup() {
  pinMode(PIR_PIN, INPUT);
  servo.attach(SERVO_PIN);
  servo.write(angle);
  Serial.begin(9600);
}

void loop() {
  bool motion = digitalRead(PIR_PIN) == HIGH;
  if (motion) {
    angle += dir;
    if (angle >= 150 || angle <= 30) dir = -dir;             // pan between 30 and 150 degrees
    servo.write(angle);
    delay(25);
  } else {
    delay(50);
  }
  if (motion != wasMoving) {
    wasMoving = motion;
    Serial.print(motion ? "motion - panning from " : "motion stopped - holding at "); Serial.println(angle);
  }
}
