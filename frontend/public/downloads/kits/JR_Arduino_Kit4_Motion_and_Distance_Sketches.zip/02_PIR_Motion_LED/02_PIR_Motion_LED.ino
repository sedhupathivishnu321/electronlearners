// ---- Circuit (Kit 4) ----
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define PIR_PIN 7
#define RED_LED 3

void setup() {
  pinMode(PIR_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool motion = digitalRead(PIR_PIN) == HIGH;
  digitalWrite(RED_LED, motion);
  Serial.println(motion ? "motion!" : "quiet");
  delay(300);
}
