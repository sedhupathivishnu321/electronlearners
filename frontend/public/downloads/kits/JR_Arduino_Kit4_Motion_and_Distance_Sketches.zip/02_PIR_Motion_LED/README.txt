Kit 4 - Motion and Distance
Project 2: PIR Motion LED (Basic)

The red LED lights whenever the PIR sees motion (tick "Motion detected" in the inspector).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  PIR Motion HC-SR501 x1

Circuit notes:
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-02-pir-led
