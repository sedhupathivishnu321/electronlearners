Kit 4 - Motion and Distance
Project 15: Touch-Activated Servo Lock (Intermediate)

Touch toggles the servo bolt between LOCKED (0 degrees, red) and UNLOCKED (90 degrees, green).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Touch Sensor TTP223 x1
  SG90 Micro Servo x1

Circuit notes:
  TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-15-touch-lock
