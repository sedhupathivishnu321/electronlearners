// ---- Circuit (Kit 4) ----
// TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define TOUCH_PIN 4
#define SERVO_PIN 6
#define RED_LED 3
#define GREEN_LED 5

#include <Servo.h>
Servo servo;

bool locked = true;
int lastTouch = LOW;

void show() {
  servo.write(locked ? 0 : 90);
  digitalWrite(RED_LED, locked);
  digitalWrite(GREEN_LED, !locked);
  Serial.println(locked ? "LOCKED" : "UNLOCKED");
}

void setup() {
  pinMode(TOUCH_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  show();
}

void loop() {
  int t = digitalRead(TOUCH_PIN);
  if (t == HIGH && lastTouch == LOW) { locked = !locked; show(); }
  lastTouch = t;
  delay(30);
}
