Kit 4 - Motion and Distance
Project 28: Bike Wheel Revolution Counter (Intermediate)

The Hall sensor counts magnet passes. Every 2 s it prints rpm and speed for a 2.1 m wheel; the button resets the total.

Parts:
  Push Button tactile 6x6 x1
  Hall Effect Sensor A3144 x1

Circuit notes:
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-28-wheel-counter
