// ---- Circuit (Kit 4) ----
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define HALL_PIN 12
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define WHEEL_M 2.1                            // wheel circumference in metres

int lastHall = HIGH;
unsigned long pulses = 0, total = 0, windowStart = 0;

void setup() {
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
}

void loop() {
  int now = digitalRead(HALL_PIN);
  if (lastHall == HIGH && now == LOW) { pulses++; total++; }  // magnet passed the sensor
  lastHall = now;
  if (pressed()) { total = 0; Serial.println("total reset"); }
  if (millis() - windowStart >= 2000) {
    float rpm = pulses * 30.0;                               // pulses in 2 s -> per minute
    Serial.print("rpm "); Serial.print(rpm, 0);
    Serial.print("   speed "); Serial.print(rpm * WHEEL_M * 60.0 / 1000.0, 1);
    Serial.print(" km/h   total revolutions "); Serial.print(total);
    Serial.print("  distance "); Serial.print(total * WHEEL_M, 1); Serial.println(" m");
    pulses = 0;
    windowStart = millis();
  }
}
