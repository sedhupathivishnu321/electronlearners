// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define SERVO_PIN 6
#define TRIG 9
#define ECHO 10
#define RED_LED 3
#define GREEN_LED 5
#define BUZZER 11

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

int ANGLES[5] = {0, 45, 90, 135, 180};
int dist[5];

void setup() {
  usBegin();
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
}

void loop() {
  for (int i = 0; i < 5; i++) {
    servo.write(ANGLES[i]);
    delay(350);                                              // wait for the servo to arrive
    float cm = distCm();
    dist[i] = (cm < 0) ? 400 : (int)cm;
  }
  int best = 0;
  for (int i = 1; i < 5; i++) if (dist[i] > dist[best]) best = i;
  Serial.print("scan: ");
  for (int i = 0; i < 5; i++) { Serial.print(ANGLES[i]); Serial.print("deg="); Serial.print(dist[i]); Serial.print("  "); }
  Serial.println();

  digitalWrite(GREEN_LED, LOW);
  digitalWrite(RED_LED, LOW);
  if (dist[best] < 20) {
    Serial.println("decision: BLOCKED - STOP");
    digitalWrite(RED_LED, HIGH);
    for (int k = 0; k < 3; k++) { tone(BUZZER, 1800, 150); delay(250); }
  } else if (best == 2) {
    Serial.println("decision: FORWARD");
    digitalWrite(GREEN_LED, HIGH);
    delay(1200);
  } else if (best > 2) {
    Serial.println(best == 4 ? "decision: hard LEFT" : "decision: LEFT");
    digitalWrite(RED_LED, HIGH);
    delay(1200);
  } else {
    Serial.println(best == 0 ? "decision: hard RIGHT" : "decision: RIGHT");
    for (int k = 0; k < 4; k++) { digitalWrite(RED_LED, HIGH); delay(150); digitalWrite(RED_LED, LOW); delay(150); }
  }
}
