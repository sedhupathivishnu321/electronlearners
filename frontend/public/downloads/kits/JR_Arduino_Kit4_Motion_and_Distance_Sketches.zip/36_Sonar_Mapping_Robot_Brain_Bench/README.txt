Kit 4 - Motion and Distance
Project 36: Sonar Mapping Robot Brain (Bench) (Advanced)

The servo points the ultrasonic sensor in 5 directions and the robot "decides" to go where it is clearest: green = forward, red = turn (steady = left, blinking = right), red + beeps = blocked, STOP.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-36-sonar-brain
