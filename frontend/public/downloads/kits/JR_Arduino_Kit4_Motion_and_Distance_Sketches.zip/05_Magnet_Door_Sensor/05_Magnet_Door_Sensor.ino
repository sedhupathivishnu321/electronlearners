// ---- Circuit (Kit 4) ----
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define HALL_PIN 12
#define RED_LED 3

void setup() {
  pinMode(HALL_PIN, INPUT_PULLUP);                          // the A3144 is open-collector: it needs a pull-up
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool magnet = digitalRead(HALL_PIN) == LOW;
  digitalWrite(RED_LED, magnet);
  Serial.println(magnet ? "magnet near - door CLOSED" : "no magnet - door OPEN");
  delay(300);
}
