Kit 4 - Motion and Distance
Project 5: Magnet Door Sensor (Basic)

The Hall sensor lights the red LED while a magnet is near (a magnet on the door, the sensor on the frame).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Hall Effect Sensor A3144 x1

Circuit notes:
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-05-hall-door
