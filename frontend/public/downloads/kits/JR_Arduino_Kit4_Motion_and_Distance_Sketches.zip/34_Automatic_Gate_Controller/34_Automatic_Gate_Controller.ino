// ---- Circuit (Kit 4) ----
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define HALL_PIN 12
#define SERVO_PIN 6
#define IR_PIN 8
#define TRIG 9
#define ECHO 10
#define GREEN_LED 5
#define RED_LED 3
#define BUZZER 11

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

int state = 0;                                  // 0 closed, 1 opening, 2 open, 3 closing
int angle = 0;
unsigned long lastClear = 0, lastStep = 0, lastBeep = 0;

void setState(int s, String msg) { state = s; Serial.println(msg); }

void setup() {
  usBegin();
  pinMode(IR_PIN, INPUT);
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(0);
  Serial.begin(9600);
  if (digitalRead(HALL_PIN) != LOW) Serial.println("warning: closed-limit magnet not detected");
  Serial.println("gate CLOSED");
}

void loop() {
  float cm = distCm();
  bool vehicle = cm > 0 && cm < 40;
  bool blocked = digitalRead(IR_PIN) == LOW;                 // something in the gateway
  bool roadBusy = vehicle || blocked || (cm > 0 && cm < 60);

  if (state == 0 && vehicle) setState(1, "vehicle detected - OPENING");
  if (state == 3 && (blocked || vehicle)) { setState(1, "obstacle in the gateway - re-opening!"); tone(BUZZER, 2000, 400); }
  if (state == 2) {
    if (roadBusy) lastClear = millis();
    else if (millis() - lastClear > 4000) setState(3, "road clear - CLOSING");
  }
  if ((state == 1 || state == 3) && millis() - lastStep >= 15) {
    lastStep = millis();
    angle += (state == 1) ? 2 : -2;
    angle = constrain(angle, 0, 90);
    servo.write(angle);
    if (millis() - lastBeep > 500) { lastBeep = millis(); tone(BUZZER, 1200, 80); }   // warning beep while moving
    if (state == 1 && angle >= 90) { setState(2, "gate OPEN"); lastClear = millis(); }
    if (state == 3 && angle <= 0) {
      if (digitalRead(HALL_PIN) == LOW) setState(0, "gate CLOSED (limit magnet confirmed)");
      else setState(0, "gate CLOSED (warning: limit magnet not seen)");
    }
  }
  digitalWrite(GREEN_LED, state == 2);
  digitalWrite(RED_LED, state == 0 ? HIGH : ((millis() / 200) % 2 && state != 2));
  delay(10);
}
