Kit 4 - Motion and Distance
Project 34: Automatic Gate Controller (Advanced)

State machine CLOSED - OPENING - OPEN - CLOSING. A vehicle within 40 cm opens the gate; it closes 4 s after the road is clear. The Hall sensor (magnet on the gate) confirms CLOSED; the IR sensor in the gateway re-opens a closing gate.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  IR Obstacle Sensor x1
  Hall Effect Sensor A3144 x1
  SG90 Micro Servo x1

Circuit notes:
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-34-gate-controller
