// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define TRIG 9
#define ECHO 10
#define IR_PIN 8
#define GREEN_LED 5
#define RED_LED 3

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

unsigned long lastPrint = 0;

void setup() {
  usBegin();
  pinMode(IR_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  float us = distCm();
  int mm = tofMm();
  bool usOk = us > 2 && us < 400;
  bool tofOk = mm >= 0 && mm < 1200;
  bool irNear = digitalRead(IR_PIN) == LOW;                  // the IR module only sees about 30 cm
  float est = -1;
  int conf = 0;                                              // 0 low, 1 medium, 2 high

  if (usOk && tofOk) {
    float t = mm / 10.0;
    float diff = t > us ? t - us : us - t;
    float big = t > us ? t : us;
    if (diff <= 0.1 * big + 1) { est = (t * 2 + us) / 3; conf = 2; }   // agree: favour the laser
    else { est = t; conf = 1; }                                       // disagree: trust the laser
  } else if (tofOk) { est = mm / 10.0; conf = 1; }
  else if (usOk) { est = us; conf = 1; }

  if (irNear && est > 50) conf = 0;                          // IR sees something close but the range says far
  if (!irNear && est >= 0 && est < 10) conf = min(conf, 1);  // very close but IR sees nothing

  digitalWrite(GREEN_LED, conf >= 1);
  digitalWrite(RED_LED, conf <= 1);
  if (millis() - lastPrint > 500) {
    lastPrint = millis();
    Serial.print("US "); Serial.print(usOk ? us : -1, 1); Serial.print(" cm | ToF "); Serial.print(tofOk ? mm / 10.0 : -1, 1);
    Serial.print(" cm | IR "); Serial.print(irNear ? "near" : "clear");
    Serial.print(" -> "); Serial.print(est, 1); Serial.print(" cm, confidence ");
    Serial.println(conf == 2 ? "HIGH" : (conf == 1 ? "MEDIUM" : "LOW"));
  }
  delay(50);
}
