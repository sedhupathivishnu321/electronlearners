Kit 4 - Motion and Distance
Project 49: Multi-Sensor Fusion Distance Estimator (Advanced)

Combines ultrasonic, ToF and the IR proximity sensor. Agreeing ultrasonic + ToF = HIGH confidence (green), one sensor only or disagreement = MEDIUM (both LEDs), the IR sensor contradicting the range = LOW (red).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  HC-SR04 Ultrasonic x1
  IR Obstacle Sensor x1
  VL53L0X ToF Distance x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-49-fusion-ranging
