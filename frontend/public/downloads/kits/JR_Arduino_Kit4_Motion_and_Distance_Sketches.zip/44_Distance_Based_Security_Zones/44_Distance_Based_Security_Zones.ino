// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TRIG 9
#define ECHO 10
#define BUZZER 11
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int Z1[3] = {150, 100, 60};
int Z2[3] = {100, 60, 40};
int Z3[3] = {50, 30, 20};
int preset = 0, level = 0;
unsigned long lastBeep = 0;

void setup() {
  usBegin();
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("preset 1: zones 150 / 100 / 50 cm");
}

void loop() {
  if (pressed()) {
    preset = (preset + 1) % 3;
    Serial.print("preset "); Serial.print(preset + 1); Serial.print(": zones ");
    Serial.print(Z1[preset]); Serial.print(" / "); Serial.print(Z2[preset]); Serial.print(" / "); Serial.print(Z3[preset]); Serial.println(" cm");
  }
  float cm = distCm();
  if (cm < 0) cm = 999;
  int now = 0;
  if (cm < Z1[preset]) now = 1;
  if (cm < Z2[preset]) now = 2;
  if (cm < Z3[preset]) now = 3;
  if (now != level) {
    level = now;
    Serial.print("[t="); Serial.print(millis() / 1000); Serial.print(" s] ");
    Serial.print(cm, 0); Serial.print(" cm -> ");
    Serial.println(level == 0 ? "clear" : (level == 1 ? "zone 1: NOTICE" : (level == 2 ? "zone 2: WARNING" : "zone 3: ALARM")));
  }
  digitalWrite(GREEN_LED, level == 0 ? HIGH : (level == 1 ? (millis() / 400) % 2 : LOW));
  if (level == 0 || level == 1) { digitalWrite(RED_LED, LOW); noTone(BUZZER); }
  if (level == 2) {
    digitalWrite(RED_LED, (millis() / 300) % 2);
    if (millis() - lastBeep > 700) { lastBeep = millis(); tone(BUZZER, 1500, 100); }
  }
  if (level == 3) {
    digitalWrite(RED_LED, HIGH);
    tone(BUZZER, (millis() / 200) % 2 ? 1800 : 1100);
  }
  delay(40);
}
