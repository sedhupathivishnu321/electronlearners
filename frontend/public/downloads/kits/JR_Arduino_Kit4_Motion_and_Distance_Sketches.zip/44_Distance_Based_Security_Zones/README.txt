Kit 4 - Motion and Distance
Project 44: Distance-Based Security Zones (Advanced)

Three nested zones: 1 notice (green blinks), 2 warning (red blinks + slow beeps), 3 alarm (red steady + siren). The button cycles zone presets (150/100/50, 100/60/30, 60/40/20 cm). Every change is logged with a timestamp.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-44-security-zones
