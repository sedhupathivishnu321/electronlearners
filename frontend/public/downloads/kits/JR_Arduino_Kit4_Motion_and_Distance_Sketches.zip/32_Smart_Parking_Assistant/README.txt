Kit 4 - Motion and Distance
Project 32: Smart Parking Assistant (Advanced)

Fuses the ultrasonic and ToF readings, smooths them with integer (fixed-point) filtering, then drives LEDs and beeps. Under 15 cm = STOP (steady tone). The button mutes the buzzer.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  VL53L0X ToF Distance x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-32-smart-parking
