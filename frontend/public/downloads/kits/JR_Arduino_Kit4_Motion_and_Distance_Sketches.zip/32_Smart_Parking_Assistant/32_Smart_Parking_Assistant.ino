// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TRIG 9
#define ECHO 10
#define RED_LED 3
#define GREEN_LED 5
#define BUZZER 11
#define BTN1 2

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

long filt = -1;                                // filtered distance in mm (integer maths only)
bool mute = false;
unsigned long lastBeep = 0, lastPrint = 0;

long fusedMm() {
  int tof = tofMm();
  float us = distCm();
  long usMm = us < 0 ? -1 : (long)(us * 10);
  if (tof >= 0 && tof < 1200) {
    if (usMm >= 0 && abs(tof - usMm) < 100) return (tof * 7L + usMm * 3L) / 10;   // both agree: weight the laser 70 %
    return tof;
  }
  return usMm;                                               // ToF out of range: ultrasonic only
}

void setup() {
  usBegin();
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  long d = fusedMm();
  if (d < 0) d = 4000;
  filt = (filt < 0) ? d : (filt * 3 + d) / 4;                // new = 3/4 old + 1/4 measurement
  if (pressed()) { mute = !mute; Serial.println(mute ? "buzzer muted" : "buzzer on"); }

  bool stopNow = filt < 150;
  digitalWrite(GREEN_LED, filt > 300);
  if (filt > 600) {
    digitalWrite(RED_LED, LOW); noTone(BUZZER);
  } else if (stopNow) {
    digitalWrite(RED_LED, HIGH);
    if (mute) noTone(BUZZER); else tone(BUZZER, 2500);
  } else {
    int gap = map(filt, 150, 600, 80, 600);
    if (millis() - lastBeep >= gap) { lastBeep = millis(); if (!mute) tone(BUZZER, 2000, 50); }
    digitalWrite(RED_LED, millis() - lastBeep < 60);
  }
  if (millis() - lastPrint > 400) {
    lastPrint = millis();
    Serial.print("distance "); Serial.print(filt); Serial.print(" mm");
    Serial.println(stopNow ? "  STOP!" : (filt > 600 ? "  clear" : "  approaching"));
  }
  delay(25);
}
