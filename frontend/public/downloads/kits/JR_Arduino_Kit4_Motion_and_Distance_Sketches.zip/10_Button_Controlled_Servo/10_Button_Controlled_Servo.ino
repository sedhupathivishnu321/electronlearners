// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define SERVO_PIN 6
#define BTN1 2

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int angle = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  servo.attach(SERVO_PIN);
  servo.write(angle);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    angle += 30;
    if (angle > 180) angle = 0;
    servo.write(angle);
    Serial.print("servo at "); Serial.print(angle); Serial.println(" degrees");
  }
}
