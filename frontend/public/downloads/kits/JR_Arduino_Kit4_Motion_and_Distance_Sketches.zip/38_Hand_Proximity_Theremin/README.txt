Kit 4 - Motion and Distance
Project 38: Hand-Proximity Theremin (Advanced)

One hand over the ToF sensor sets the pitch (close = high); the ultrasonic distance sets a "volume": the piezo is driven with longer bursts when the second hand is closer.

Parts:
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  VL53L0X ToF Distance x1

Circuit notes:
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-38-theremin
