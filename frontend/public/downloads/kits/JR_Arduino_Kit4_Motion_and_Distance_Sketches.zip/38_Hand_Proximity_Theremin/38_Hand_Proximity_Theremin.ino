// ---- Circuit (Kit 4) ----
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define TRIG 9
#define ECHO 10
#define BUZZER 11

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

unsigned long lastPrint = 0;

void setup() {
  usBegin();
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  int mm = tofMm();
  if (mm < 0 || mm > 500) { noTone(BUZZER); delay(30); return; }        // no hand over the pitch sensor: silence
  float cm = distCm();
  if (cm < 0 || cm > 50) cm = 50;
  int f = map(mm, 60, 500, 1500, 200);                       // pitch
  int burst = map((int)cm, 5, 50, 18, 2);                    // "volume": burst length inside every 20 ms slot
  burst = constrain(burst, 2, 18);
  tone(BUZZER, f, burst);
  if (millis() - lastPrint > 400) {
    lastPrint = millis();
    Serial.print("pitch "); Serial.print(f); Serial.print(" Hz   volume "); Serial.print(burst * 100 / 18); Serial.println(" %");
  }
  delay(20);
}
