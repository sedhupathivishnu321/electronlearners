// ---- Circuit (Kit 4) ----
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define IR_PIN 8
#define RED_LED 3

void setup() {
  pinMode(IR_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool blocked = digitalRead(IR_PIN) == LOW;               // the module pulls OUT LOW when it sees a reflection
  digitalWrite(RED_LED, blocked);
  Serial.println(blocked ? "obstacle ahead" : "path clear");
  delay(250);
}
