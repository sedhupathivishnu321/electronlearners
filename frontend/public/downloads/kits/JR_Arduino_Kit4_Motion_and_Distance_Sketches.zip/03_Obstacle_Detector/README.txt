Kit 4 - Motion and Distance
Project 3: Obstacle Detector (Basic)

The IR obstacle sensor lights the red LED when an object is in front of it.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  IR Obstacle Sensor x1

Circuit notes:
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-03-obstacle
