// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define TRIG 9
#define ECHO 10
#define RED_LED 3
#define GREEN_LED 5

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

#define SENSOR_TO_BOTTOM 35.0                   // cm from the sensor down to the tank floor (30 cm tank + 5 cm gap)
#define TANK_HEIGHT 30.0

void setup() {
  usBegin();
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float cm = distCm();
  if (cm < 0) { Serial.println("no echo"); delay(300); return; }
  float level = constrain((SENSOR_TO_BOTTOM - cm) * 100.0 / TANK_HEIGHT, 0, 100);
  bool alert = level < 10 || level > 90;
  digitalWrite(RED_LED, alert);
  digitalWrite(GREEN_LED, !alert);
  Serial.print("level "); Serial.print(level, 0); Serial.print(" %  [");
  for (int i = 0; i < 10; i++) Serial.print(i < level / 10 ? "#" : ".");
  Serial.println(alert ? "]  CHECK TANK" : "]");
  delay(400);
}
