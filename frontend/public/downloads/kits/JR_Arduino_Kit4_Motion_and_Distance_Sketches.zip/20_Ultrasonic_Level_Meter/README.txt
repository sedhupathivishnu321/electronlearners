Kit 4 - Motion and Distance
Project 20: Ultrasonic Level Meter (Intermediate)

The sensor sits 5 cm above a 30 cm tank and measures the distance to the surface. Prints the level as a percentage bar; red when the tank is nearly empty (<10 %) or nearly full (>90 %).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-20-level-meter
