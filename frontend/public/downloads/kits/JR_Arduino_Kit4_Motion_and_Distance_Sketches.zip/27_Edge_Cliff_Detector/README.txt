Kit 4 - Motion and Distance
Project 27: Edge/Cliff Detector (Intermediate)

The TCRT5000 looks down at the table. When the table disappears (reflectivity drops) the red LED and a two-tone alarm start.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Piezo Passive Buzzer x1
  TCRT5000 Line Sensor x1

Circuit notes:
  TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-27-cliff-detector
