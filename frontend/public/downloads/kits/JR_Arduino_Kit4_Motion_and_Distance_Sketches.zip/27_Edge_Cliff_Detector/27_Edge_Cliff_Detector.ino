// ---- Circuit (Kit 4) ----
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define LINE_DO 13
#define LINE_AO A0
#define BUZZER 11
#define RED_LED 3

bool edge = false;

void setup() {
  pinMode(LINE_DO, INPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool now = digitalRead(LINE_DO) == HIGH;                  // no reflection = no table below
  if (now != edge) {
    edge = now;
    Serial.println(edge ? "EDGE! stop!" : "surface OK");
  }
  digitalWrite(RED_LED, edge);
  if (edge) tone(BUZZER, (millis() / 200) % 2 ? 1800 : 1200);
  else noTone(BUZZER);
  delay(20);
}
