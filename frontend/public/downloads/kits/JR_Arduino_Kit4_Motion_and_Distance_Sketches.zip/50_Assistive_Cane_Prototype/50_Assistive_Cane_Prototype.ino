// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TRIG 9
#define ECHO 10
#define LINE_DO 13
#define LINE_AO A0
#define BUZZER 11
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool mute = false;
unsigned long lastBeep = 0, lastBeat = 0, lastPrint = 0;

void setup() {
  usBegin();
  pinMode(LINE_DO, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) { mute = !mute; Serial.println(mute ? "obstacle beeps muted" : "obstacle beeps on"); }
  bool drop = digitalRead(LINE_DO) == HIGH;                  // no floor reflection under the cane tip
  float cm = distCm();
  if (cm < 0) cm = 400;

  if (drop) {
    digitalWrite(RED_LED, HIGH);
    tone(BUZZER, (millis() / 150) % 2 ? 700 : 500);          // low warbling alarm: unmistakable
    if (millis() - lastPrint > 700) { lastPrint = millis(); Serial.println("DROP-OFF AHEAD!"); }
    return;
  }
  digitalWrite(RED_LED, cm < 40);
  if (cm < 150 && !mute) {
    int gap = map((int)cm, 10, 150, 100, 900);
    if (millis() - lastBeep >= constrain(gap, 100, 900)) { lastBeep = millis(); tone(BUZZER, 1800, 60); }
  } else noTone(BUZZER);
  if (millis() - lastBeat > 2000) { lastBeat = millis(); digitalWrite(GREEN_LED, HIGH); }   // heartbeat blink
  if (millis() - lastBeat > 100) digitalWrite(GREEN_LED, LOW);
  if (millis() - lastPrint > 700 && cm < 150) { lastPrint = millis(); Serial.print("obstacle at "); Serial.print(cm, 0); Serial.println(" cm"); }
  delay(20);
}
