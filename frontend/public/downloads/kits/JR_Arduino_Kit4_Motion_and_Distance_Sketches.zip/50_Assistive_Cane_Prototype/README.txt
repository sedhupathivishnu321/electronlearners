Kit 4 - Motion and Distance
Project 50: Assistive Cane Prototype (Advanced)

Beeps faster as an obstacle gets closer (within 150 cm). The TCRT5000 pointing at the floor detects a drop-off and sounds a different continuous alarm with the red LED. The button mutes obstacle beeps (never the drop alarm); green blinks as a heartbeat.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  TCRT5000 Line Sensor x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-50-assistive-cane
