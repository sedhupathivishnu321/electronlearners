// ---- Circuit (Kit 4) ----
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define PIR_PIN 7
#define BUZZER 11
#define BTN1 2
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define ARM_DELAY_MS 5000
int state = 0;                              // 0 disarmed, 1 arming, 2 armed, 3 alarm
unsigned long armStart = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(PIR_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("DISARMED - press the button to arm");
}

void loop() {
  if (pressed()) {
    if (state == 0) { state = 1; armStart = millis(); Serial.println("arming... leave the room"); }
    else { state = 0; noTone(BUZZER); digitalWrite(RED_LED, LOW); Serial.println("DISARMED"); }
  }
  if (state == 1) {
    digitalWrite(RED_LED, (millis() / 100) % 2);
    if (millis() - armStart >= ARM_DELAY_MS) { state = 2; Serial.println("ARMED"); }
  } else if (state == 2) {
    digitalWrite(RED_LED, HIGH);
    if (digitalRead(PIR_PIN) == HIGH) { state = 3; Serial.println("INTRUDER DETECTED!"); }
  } else if (state == 3) {
    tone(BUZZER, (millis() / 300) % 2 ? 1400 : 800);         // two-tone siren
    digitalWrite(RED_LED, (millis() / 150) % 2);
  }
}
