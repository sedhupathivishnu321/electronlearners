Kit 4 - Motion and Distance
Project 12: Motion Alarm (Intermediate)

Button arms the alarm after a 5 s exit delay (red blinks fast). Armed = red steady. Motion starts the siren; the button disarms.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  PIR Motion HC-SR501 x1

Circuit notes:
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-12-motion-alarm
