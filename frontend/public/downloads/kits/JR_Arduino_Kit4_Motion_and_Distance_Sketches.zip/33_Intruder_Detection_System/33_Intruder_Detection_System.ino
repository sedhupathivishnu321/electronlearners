// ---- Circuit (Kit 4) ----
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define PIR_PIN 7
#define HALL_PIN 12
#define TRIG 9
#define ECHO 10
#define TOUCH_PIN 4
#define BUZZER 11
#define RED_LED 3
#define GREEN_LED 5

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

#define EXIT_MS 8000
#define ENTRY_MS 8000
#define CODE "SLS"                              // short, long (>= 0.5 s), short

int state = 0;                                  // 0 disarmed, 1 exit delay, 2 armed, 3 entry delay, 4 alarm
unsigned long stateAt = 0, touchStart = 0, lastTap = 0;
bool touching = false;
String entered = "";

void setState(int s, String msg) {
  state = s; stateAt = millis();
  Serial.println(msg);
}

void toggleArm() {
  if (state == 0) setState(1, "arming - leave now (exit delay)");
  else { noTone(BUZZER); setState(0, "DISARMED"); }
}

void readTouchCode() {
  int t = digitalRead(TOUCH_PIN);
  if (t == HIGH && !touching) { touching = true; touchStart = millis(); }
  if (t == LOW && touching) {
    touching = false;
    if (millis() - touchStart >= 500) entered += "L"; else entered += "S";
    lastTap = millis();
    Serial.print("code so far: "); Serial.println(entered);
    if (entered.length() > 3) entered = entered.substring(entered.length() - 3);
    if (entered == CODE) { entered = ""; toggleArm(); }
  }
  if (entered.length() > 0 && millis() - lastTap > 3000) { entered = ""; Serial.println("code timed out"); }
}

void setup() {
  usBegin();
  pinMode(PIR_PIN, INPUT);
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(TOUCH_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("DISARMED - tap the pad short-long-short to arm");
}

void loop() {
  readTouchCode();
  bool doorOpen = digitalRead(HALL_PIN) == HIGH;             // magnet moved away from the sensor
  float cm = distCm();
  bool room = digitalRead(PIR_PIN) == HIGH || (cm > 0 && cm < 80);

  if (state == 1 && millis() - stateAt >= EXIT_MS) setState(2, "ARMED");
  if (state == 2) {
    if (doorOpen) setState(3, "door opened - enter the code within 8 s");
    else if (room) setState(4, "ALARM: movement in the room");
  }
  if (state == 3 && millis() - stateAt >= ENTRY_MS) setState(4, "ALARM: entry delay expired");

  digitalWrite(GREEN_LED, state == 0);
  if (state == 0) { digitalWrite(RED_LED, LOW); noTone(BUZZER); }
  if (state == 1) digitalWrite(RED_LED, (millis() / 250) % 2);
  if (state == 2) digitalWrite(RED_LED, HIGH);
  if (state == 3) {
    digitalWrite(RED_LED, (millis() / 100) % 2);
    if ((millis() / 1000) % 2 == 0) tone(BUZZER, 1000); else noTone(BUZZER);
  }
  if (state == 4) {
    tone(BUZZER, (millis() / 300) % 2 ? 1500 : 900);
    digitalWrite(RED_LED, (millis() / 120) % 2);
  }
  delay(20);
}
