Kit 4 - Motion and Distance
Project 33: Intruder Detection System (Advanced)

Three zones: door (Hall + magnet, with 8 s entry delay), room motion (PIR) and a 80 cm ultrasonic tripwire (instant alarm). Arm / disarm by tapping the touch pad short-long-short. 8 s exit delay.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  PIR Motion HC-SR501 x1
  Touch Sensor TTP223 x1
  Hall Effect Sensor A3144 x1

Circuit notes:
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-33-intruder-system
