Kit 4 - Motion and Distance
Project 45: Servo Plotter Calibration Tool (Advanced)

Press the button: the servo steps through 0-180 degrees in 15 degree steps, the ToF sensor averages 5 readings at each angle, and the table plus a least-squares fit (mm per degree) is printed. Change the target distance while it runs to see the curve.

Parts:
  Push Button tactile 6x6 x1
  VL53L0X ToF Distance x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-45-servo-calibration
