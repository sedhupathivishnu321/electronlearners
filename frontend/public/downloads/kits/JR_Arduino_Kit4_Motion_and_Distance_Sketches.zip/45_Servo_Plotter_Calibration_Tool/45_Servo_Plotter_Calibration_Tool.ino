// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define SERVO_PIN 6
#define BTN1 2

#include <Servo.h>
Servo servo;
#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

void calibrate() {
  float n = 0, sx = 0, sy = 0, sxy = 0, sxx = 0;
  Serial.println("angle,mm");
  for (int a = 0; a <= 180; a += 15) {
    servo.write(a);
    delay(500);                                              // settle
    long sum = 0; int k = 0;
    for (int i = 0; i < 5; i++) { int m = tofMm(); if (m >= 0) { sum += m; k++; } delay(10); }
    if (k == 0) { Serial.print(a); Serial.println(",out of range"); continue; }
    float mm = sum / (float)k;
    Serial.print(a); Serial.print(","); Serial.println(mm, 1);
    n++; sx += a; sy += mm; sxy += a * mm; sxx += (float)a * a;
  }
  if (n < 2) { Serial.println("not enough valid points"); return; }
  float slope = (n * sxy - sx * sy) / (n * sxx - sx * sx);
  float intercept = (sy - slope * sx) / n;
  Serial.print("fit: distance = "); Serial.print(slope, 3); Serial.print(" mm/degree x angle + "); Serial.print(intercept, 1); Serial.println(" mm");
  servo.write(90);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  tofBegin();
  Serial.println("press the button to start the calibration sweep");
}

void loop() {
  if (pressed()) calibrate();
}
