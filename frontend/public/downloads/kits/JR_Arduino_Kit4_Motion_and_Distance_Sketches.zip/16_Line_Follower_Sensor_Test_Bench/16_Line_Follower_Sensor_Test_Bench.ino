// ---- Circuit (Kit 4) ----
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define LINE_DO 13
#define LINE_AO A0
#define BTN1 2
#define GREEN_LED 5
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int threshold = 512, whiteV = -1, blackV = -1;
unsigned long lastPrint = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("Calibrate: put the sensor over WHITE and press, then over BLACK and press");
}

void loop() {
  int v = analogRead(LINE_AO);                              // higher = darker
  bool line = v > threshold;
  digitalWrite(RED_LED, line);
  digitalWrite(GREEN_LED, !line);
  if (pressed()) {
    if (whiteV < 0) { whiteV = v; Serial.print("white = "); Serial.println(v); }
    else if (blackV < 0) {
      blackV = v;
      threshold = (whiteV + blackV) / 2;
      Serial.print("black = "); Serial.print(v); Serial.print("  -> threshold = "); Serial.println(threshold);
    } else { whiteV = -1; blackV = -1; threshold = 512; Serial.println("reset - threshold back to 512"); }
  }
  if (millis() - lastPrint > 300) {
    lastPrint = millis();
    Serial.print("reading "); Serial.print(v); Serial.print(" / threshold "); Serial.print(threshold);
    Serial.println(line ? "  LINE" : "  no line");
  }
}
