Kit 4 - Motion and Distance
Project 16: Line-Follower Sensor Test Bench (Intermediate)

Shows line / no-line live. Calibrate with the button: press over white, press over black, and the threshold is set halfway. A third press resets.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  TCRT5000 Line Sensor x1

Circuit notes:
  TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-16-line-bench
