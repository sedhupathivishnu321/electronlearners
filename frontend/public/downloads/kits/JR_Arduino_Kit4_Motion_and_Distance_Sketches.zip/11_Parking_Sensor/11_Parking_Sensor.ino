// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define TRIG 9
#define ECHO 10
#define RED_LED 3
#define GREEN_LED 5
#define BUZZER 11

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

unsigned long lastBeep = 0;

void setup() {
  usBegin();
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float cm = distCm();
  if (cm < 0) cm = 400;
  digitalWrite(GREEN_LED, cm > 30);                          // green: more than 30 cm free
  if (cm > 60) {
    digitalWrite(RED_LED, LOW);
    noTone(BUZZER);
  } else if (cm < 10) {                                      // practically touching: continuous tone
    digitalWrite(RED_LED, HIGH);
    tone(BUZZER, 2500);
  } else {
    int gap = map((int)cm, 10, 60, 80, 600);                 // beeps get faster as the car gets closer
    if (millis() - lastBeep >= gap) { lastBeep = millis(); tone(BUZZER, 2000, 50); }
    digitalWrite(RED_LED, millis() - lastBeep < 60);         // red flashes with every beep
  }
  Serial.print(cm, 0); Serial.println(" cm");
  delay(30);
}
