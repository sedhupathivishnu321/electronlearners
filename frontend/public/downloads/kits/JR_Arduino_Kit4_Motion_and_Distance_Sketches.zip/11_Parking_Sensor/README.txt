Kit 4 - Motion and Distance
Project 11: Parking Sensor (Intermediate)

Like a car parking aid: green = plenty of room, green + red = getting close, red + faster beeps = very close, steady tone under 10 cm.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-11-parking-sensor
