// ---- Circuit (Kit 4) ----
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define IR_PIN 8
#define GREEN_LED 5

#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

void setup() {
  pinMode(IR_PIN, INPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  int level = 0;
  if (digitalRead(IR_PIN) == LOW) {                          // something is in front: lamp on
    int mm = tofMm();
    if (mm < 0) mm = 400;
    level = map(constrain(mm, 50, 400), 50, 400, 255, 20);   // closer = brighter
  }
  analogWrite(GREEN_LED, level);
  Serial.print("brightness "); Serial.println(level);
  delay(150);
}
