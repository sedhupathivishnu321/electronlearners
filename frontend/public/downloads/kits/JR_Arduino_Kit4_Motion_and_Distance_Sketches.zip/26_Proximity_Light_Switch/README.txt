Kit 4 - Motion and Distance
Project 26: Proximity Light Switch (Intermediate)

The IR obstacle sensor switches the green LED on; the ToF distance dims it - the closer the hand, the brighter.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  IR Obstacle Sensor x1
  VL53L0X ToF Distance x1

Circuit notes:
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-26-proximity-light
