// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define SERVO_PIN 6
#define BTN1 2
#define GREEN_LED 5

#include <Servo.h>
Servo servo;

int poses[5];
int nPoses = 0, angle = 90, dir = 1, idx = 0;
bool replay = false;
unsigned long lastStep = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(angle);
  Serial.begin(9600);
  Serial.println("hold = jog, tap = save pose");
}

void loop() {
  if (replay) {
    if (millis() - lastStep >= 1000) {
      lastStep = millis();
      servo.write(poses[idx]);
      Serial.print("replay pose "); Serial.print(idx + 1); Serial.print(" = "); Serial.println(poses[idx]);
      idx = (idx + 1) % nPoses;
    }
    if (digitalRead(BTN1) == LOW) {                          // any press ends the replay and clears memory
      replay = false; nPoses = 0; digitalWrite(GREEN_LED, LOW);
      Serial.println("memory cleared");
      while (digitalRead(BTN1) == LOW) { }
      delay(40);
    }
    return;
  }
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 400) { }
    if (digitalRead(BTN1) == LOW) {                          // held: jog
      while (digitalRead(BTN1) == LOW) {
        angle += dir;
        if (angle >= 180 || angle <= 0) dir = -dir;
        angle = constrain(angle, 0, 180);
        servo.write(angle);
        delay(15);
      }
      dir = -dir;
      Serial.print("jogged to "); Serial.println(angle);
    } else {                                                 // tapped: save
      poses[nPoses] = angle;
      nPoses++;
      Serial.print("saved pose "); Serial.print(nPoses); Serial.print(" = "); Serial.println(angle);
      if (nPoses == 5) { replay = true; idx = 0; lastStep = 0; digitalWrite(GREEN_LED, HIGH); Serial.println("5 poses stored - replaying"); }
    }
    delay(40);
  }
}
