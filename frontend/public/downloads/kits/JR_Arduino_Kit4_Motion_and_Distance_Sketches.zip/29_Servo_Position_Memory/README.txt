Kit 4 - Motion and Distance
Project 29: Servo Position Memory (Intermediate)

Hold the button to jog the servo (it reverses direction each time), tap it to save the pose (up to 5). After the 5th pose the servo replays them in a loop (green LED); press once to clear and start over.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-29-pose-memory
