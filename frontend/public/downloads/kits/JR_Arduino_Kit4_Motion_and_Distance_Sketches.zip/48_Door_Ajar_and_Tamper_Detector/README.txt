Kit 4 - Motion and Distance
Project 48: Door Ajar and Tamper Detector (Advanced)

Press the button to authorise opening (10 s). Opening the door WITHOUT it, 4+ door changes within 2 s (tampering), or motion beside an unauthorised open door latches the alarm (red + siren) until the button resets it with the door closed. An authorised door left open > 10 s beeps "ajar".

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  PIR Motion HC-SR501 x1
  Hall Effect Sensor A3144 x1

Circuit notes:
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-48-tamper-detector
