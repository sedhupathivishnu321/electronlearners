// ---- Circuit (Kit 4) ----
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define HALL_PIN 12
#define PIR_PIN 7
#define BUZZER 11
#define RED_LED 3
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool doorOpen = false, alarm = false;
unsigned long authUntil = 0, openedAt = 0, lastAjar = 0;
unsigned long flips[4];
int nFlips = 0;

void raise(String why) {
  if (!alarm) { alarm = true; Serial.print("ALARM: "); Serial.println(why); }
}

void setup() {
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(PIR_PIN, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  doorOpen = digitalRead(HALL_PIN) == HIGH;
  Serial.println("door monitor running");
}

void loop() {
  bool open = digitalRead(HALL_PIN) == HIGH;                // magnet away = door open
  bool authorised = millis() < authUntil;
  if (open != doorOpen) {
    doorOpen = open;
    for (int i = 0; i < 3; i++) flips[i] = flips[i + 1];    // remember the last 4 changes
    flips[3] = millis();
    if (nFlips < 4) nFlips++;
    if (open) {
      openedAt = millis();
      if (!authorised) raise("door forced open");
      else Serial.println("door opened (authorised)");
    } else Serial.println("door closed");
    if (nFlips == 4 && millis() - flips[0] < 2000) raise("tamper pattern - door rattled");
  }
  if (doorOpen && !authorised && digitalRead(PIR_PIN) == HIGH) raise("movement at an unauthorised open door");
  if (doorOpen && authorised && millis() - openedAt > 10000 && millis() - lastAjar > 2000) {
    lastAjar = millis();
    tone(BUZZER, 1200, 150);
    digitalWrite(RED_LED, HIGH); delay(150); digitalWrite(RED_LED, LOW);
    Serial.println("door AJAR - please close it");
  }
  if (pressed()) {
    if (alarm) {
      if (doorOpen) Serial.println("close the door first");
      else { alarm = false; nFlips = 0; noTone(BUZZER); digitalWrite(RED_LED, LOW); Serial.println("alarm reset"); }
    } else {
      authUntil = millis() + 10000;
      Serial.println("AUTHORISED: you have 10 s to open the door");
    }
  }
  if (alarm) {
    tone(BUZZER, (millis() / 250) % 2 ? 1700 : 1000);
    digitalWrite(RED_LED, (millis() / 150) % 2);
  }
}
