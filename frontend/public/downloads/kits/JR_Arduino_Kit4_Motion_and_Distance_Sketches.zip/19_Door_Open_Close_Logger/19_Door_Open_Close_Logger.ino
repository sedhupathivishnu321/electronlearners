// ---- Circuit (Kit 4) ----
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define HALL_PIN 12
#define BUZZER 11
#define RED_LED 3
#define GREEN_LED 5

bool closed = true;
unsigned long changedAt = 0, lastBeep = 0;

void setup() {
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  closed = digitalRead(HALL_PIN) == LOW;
  Serial.println(closed ? "log started: door CLOSED" : "log started: door OPEN");
}

void loop() {
  bool c = digitalRead(HALL_PIN) == LOW;                    // magnet near = door closed
  if (c != closed) {
    unsigned long dur = (millis() - changedAt) / 1000;
    closed = c;
    changedAt = millis();
    Serial.print("[t="); Serial.print(millis() / 1000); Serial.print(" s] door ");
    if (closed) { Serial.print("CLOSED (was open "); Serial.print(dur); Serial.println(" s)"); }
    else Serial.println("OPENED");
  }
  digitalWrite(GREEN_LED, closed);
  digitalWrite(RED_LED, !closed);
  if (!closed && millis() - changedAt > 5000 && millis() - lastBeep > 1000) {   // left open too long
    lastBeep = millis();
    tone(BUZZER, 1500, 200);
  }
}
