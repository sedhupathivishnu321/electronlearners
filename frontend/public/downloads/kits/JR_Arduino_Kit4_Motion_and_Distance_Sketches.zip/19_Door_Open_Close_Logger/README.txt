Kit 4 - Motion and Distance
Project 19: Door Open/Close Logger (Intermediate)

The Hall sensor + magnet log door events with timestamps. Green = closed, red = open, and the buzzer beeps if the door stays open for over 5 s.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  Hall Effect Sensor A3144 x1

Circuit notes:
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-19-door-logger
