Kit 4 - Motion and Distance
Project 46: Motion-Aware Night Lamp (Advanced)

The PIR fades the green lamp up quickly and, 8 s after the last motion, fades it out slowly (PWM). A touch toggles an "always on" override, shown by a dim red LED.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  PIR Motion HC-SR501 x1
  Touch Sensor TTP223 x1

Circuit notes:
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-46-night-lamp
