// ---- Circuit (Kit 4) ----
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define PIR_PIN 7
#define TOUCH_PIN 4
#define GREEN_LED 5
#define RED_LED 3

int level = 0, lastTouch = LOW;
bool override = false;
unsigned long lastMotion = 0, lastFade = 0, lastPrint = 0;

void setup() {
  pinMode(PIR_PIN, INPUT);
  pinMode(TOUCH_PIN, INPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (digitalRead(PIR_PIN) == HIGH) lastMotion = millis();
  int t = digitalRead(TOUCH_PIN);
  if (t == HIGH && lastTouch == LOW) {
    override = !override;
    Serial.println(override ? "override ON - lamp held on" : "override OFF - motion control");
  }
  lastTouch = t;
  analogWrite(RED_LED, override ? 40 : 0);

  bool wantOn = override || (lastMotion > 0 && millis() - lastMotion < 8000);
  if (millis() - lastFade >= 10) {
    lastFade = millis();
    if (wantOn && level < 255) level = min(level + 8, 255);   // quick fade up
    if (!wantOn && level > 0) level--;                        // slow fade down (about 2.5 s)
    analogWrite(GREEN_LED, level);
  }
  if (millis() - lastPrint > 1000) { lastPrint = millis(); Serial.print("lamp "); Serial.print(level * 100 / 255); Serial.println(" %"); }
}
