// ---- Circuit (Kit 4) ----
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
#define IR_PIN 8
#define LINE_DO 13
#define LINE_AO A0

#define GATE_CM 10.0                           // distance between the two sensors

int stage = 0;                                 // 0 waiting for gate A (IR), 1 waiting for gate B (line sensor)
unsigned long t1 = 0;

void setup() {
  pinMode(IR_PIN, INPUT);
  pinMode(LINE_DO, INPUT);
  Serial.begin(9600);
  Serial.println("waiting for an object at gate A (IR) ...");
}

void loop() {
  if (stage == 0 && digitalRead(IR_PIN) == LOW) {
    t1 = millis();
    stage = 1;
    Serial.println("gate A passed - timing");
  } else if (stage == 1) {
    if (digitalRead(LINE_DO) == HIGH) {
      unsigned long dt = millis() - t1;
      float cmPerS = GATE_CM * 1000.0 / dt;
      Serial.print("time "); Serial.print(dt); Serial.print(" ms  ->  speed ");
      Serial.print(cmPerS, 1); Serial.print(" cm/s  ("); Serial.print(cmPerS * 0.036, 2); Serial.println(" km/h)");
      while (digitalRead(IR_PIN) == LOW || digitalRead(LINE_DO) == HIGH) { }   // wait until the object has left
      stage = 0;
      Serial.println("ready for the next object");
    } else if (millis() - t1 > 5000) {
      stage = 0;
      Serial.println("timeout - nothing reached gate B");
    }
  }
}
