Kit 4 - Motion and Distance
Project 23: Speed Estimator (Intermediate)

Two sensors 10 cm apart form two gates. Time between the IR sensor and the line sensor triggering gives the speed. Trigger the IR obstacle first, then lower the line sensor reflectivity.

Parts:
  IR Obstacle Sensor x1
  TCRT5000 Line Sensor x1

Circuit notes:
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-23-speed-estimator
