// ---- Circuit (Kit 4) ----
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define PIR_PIN 7
#define GREEN_LED 5

#define HOLD_MS 10000UL                        // 10 s for the demo - use 300000UL for 5 minutes

unsigned long lastMotion = 0, lastPrint = 0;
bool lightOn = false;

void setup() {
  pinMode(PIR_PIN, INPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (digitalRead(PIR_PIN) == HIGH) {
    lastMotion = millis();                                   // retrigger: the countdown starts again
    if (!lightOn) { lightOn = true; Serial.println("occupied - light ON"); }
  }
  if (lightOn && millis() - lastMotion > HOLD_MS) {
    lightOn = false;
    Serial.println("no motion - light OFF");
  }
  digitalWrite(GREEN_LED, lightOn);
  if (lightOn && millis() - lastPrint >= 1000) {
    lastPrint = millis();
    Serial.print("light off in "); Serial.print((HOLD_MS - (millis() - lastMotion)) / 1000); Serial.println(" s");
  }
}
