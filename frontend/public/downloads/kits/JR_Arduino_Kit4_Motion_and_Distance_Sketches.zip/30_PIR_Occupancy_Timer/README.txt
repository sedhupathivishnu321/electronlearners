Kit 4 - Motion and Distance
Project 30: PIR Occupancy Timer (Intermediate)

The light stays on for a hold time after the last motion and the timer restarts on every new motion. (10 s here; set HOLD_MS to 300000 for 5 minutes.)

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  PIR Motion HC-SR501 x1

Circuit notes:
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-30-occupancy-timer
