Kit 4 - Motion and Distance
Project 9: Distance Beeper (Basic)

The piezo beeps faster the closer the object is.

Parts:
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-09-distance-beeper
