// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define TRIG 9
#define ECHO 10
#define BUZZER 11

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

void setup() {
  usBegin();
  Serial.begin(9600);
}

void loop() {
  float cm = distCm();
  if (cm < 0 || cm > 100) { delay(100); return; }            // nothing close: stay silent
  tone(BUZZER, 2000, 60);
  int gap = map((int)cm, 5, 100, 40, 700);                   // closer = shorter pause
  Serial.print(cm, 0); Serial.print(" cm, pause "); Serial.print(gap); Serial.println(" ms");
  delay(constrain(gap, 40, 700));
}
