Kit 4 - Motion and Distance
Project 8: ToF Distance Reader (Basic)

Prints the distance in millimetres from the VL53L0X laser sensor.

Parts:
  VL53L0X ToF Distance x1

Circuit notes:
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-08-tof-reader
