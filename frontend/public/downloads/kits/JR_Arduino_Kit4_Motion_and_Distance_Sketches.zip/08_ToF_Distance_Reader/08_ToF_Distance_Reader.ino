// ---- Circuit (Kit 4) ----
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)


#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

void setup() {
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  int mm = tofMm();
  if (mm < 0) Serial.println("out of range");
  else { Serial.print("Distance: "); Serial.print(mm); Serial.println(" mm"); }
  delay(300);
}
