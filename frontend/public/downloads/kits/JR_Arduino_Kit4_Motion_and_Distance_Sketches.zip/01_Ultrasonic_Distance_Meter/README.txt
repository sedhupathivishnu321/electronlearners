Kit 4 - Motion and Distance
Project 1: Ultrasonic Distance Meter (Basic)

Measures distance in cm with the HC-SR04 and prints it. Move the obstacle slider in the inspector.

Parts:
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-01-ultrasonic-meter
