// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
#define TRIG 9
#define ECHO 10

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

void setup() {
  Serial.begin(9600);
  usBegin();
}

void loop() {
  float cm = distCm();
  if (cm < 0) Serial.println("no echo (out of range)");
  else { Serial.print("Distance: "); Serial.print(cm, 1); Serial.println(" cm"); }
  delay(400);
}
