Kit 4 - Motion and Distance
Project 42: Water-Tank Level Controller Model (Advanced)

Level from the ultrasonic distance (30 cm tank). Pump (green LED) switches ON below 25 % and OFF above 85 % (hysteresis). If the level does not rise 3 % within 8 s of pumping, a dry-run alarm latches (red + siren) until the button resets it.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-42-tank-controller
