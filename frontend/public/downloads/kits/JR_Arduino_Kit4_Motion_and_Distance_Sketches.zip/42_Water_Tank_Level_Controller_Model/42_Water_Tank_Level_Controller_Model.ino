// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define TRIG 9
#define ECHO 10
#define GREEN_LED 5
#define RED_LED 3
#define BUZZER 11
#define BTN1 2

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define SENSOR_TO_BOTTOM 35.0
#define TANK_HEIGHT 30.0

bool pump = false, alarm = false;
unsigned long pumpWindow = 0, lastPrint = 0;
float levelAtWindow = 0;

float levelPct() {
  float cm = distCm();
  if (cm < 0) return -1;
  return constrain((SENSOR_TO_BOTTOM - cm) * 100.0 / TANK_HEIGHT, 0, 100);
}

void setup() {
  usBegin();
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float lvl = levelPct();
  if (lvl < 0) { delay(200); return; }
  if (alarm) {
    tone(BUZZER, (millis() / 250) % 2 ? 1500 : 1000);
    digitalWrite(RED_LED, (millis() / 200) % 2);
    if (pressed()) { alarm = false; noTone(BUZZER); digitalWrite(RED_LED, LOW); Serial.println("alarm reset"); }
    return;
  }
  if (!pump && lvl < 25) { pump = true; pumpWindow = millis(); levelAtWindow = lvl; Serial.println("level low - pump ON"); }
  if (pump && lvl > 85) { pump = false; Serial.println("tank full - pump OFF"); }
  if (pump && millis() - pumpWindow > 8000) {
    if (lvl >= levelAtWindow + 3) { pumpWindow = millis(); levelAtWindow = lvl; }     // level is rising: all fine
    else { alarm = true; pump = false; Serial.println("DRY-RUN ALARM: pump on but the level is not rising"); }
  }
  digitalWrite(GREEN_LED, pump);
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    Serial.print("level "); Serial.print(lvl, 0); Serial.print(" %  pump "); Serial.println(pump ? "ON" : "OFF");
  }
  delay(100);
}
