Kit 4 - Motion and Distance
Project 17: Obstacle-Avoid Servo Steering Demo (Intermediate)

The servo is the car's steering: straight (90) when clear, left (45) when the ultrasonic sees something within 40 cm, hard right (135) when the IR sensor sees something very close.

Parts:
  HC-SR04 Ultrasonic x1
  IR Obstacle Sensor x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-17-avoid-steering
