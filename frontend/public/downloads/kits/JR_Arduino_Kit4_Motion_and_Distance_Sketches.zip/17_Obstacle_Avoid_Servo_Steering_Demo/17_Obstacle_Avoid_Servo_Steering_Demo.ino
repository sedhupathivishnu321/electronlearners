// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
#define SERVO_PIN 6
#define IR_PIN 8
#define TRIG 9
#define ECHO 10

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

int steer = -1;

void setup() {
  usBegin();
  pinMode(IR_PIN, INPUT);
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
}

void loop() {
  bool near = digitalRead(IR_PIN) == LOW;
  float cm = distCm();
  int want = 90;
  if (near) want = 135;
  else if (cm > 0 && cm < 40) want = 45;
  if (want != steer) {
    steer = want;
    servo.write(steer);
    Serial.print("steering "); Serial.print(steer);
    if (near) Serial.println("  (IR: obstacle very close - hard right)");
    else if (want == 45) Serial.println("  (ultrasonic: obstacle ahead - turn left)");
    else Serial.println("  (clear - straight)");
  }
  delay(80);
}
