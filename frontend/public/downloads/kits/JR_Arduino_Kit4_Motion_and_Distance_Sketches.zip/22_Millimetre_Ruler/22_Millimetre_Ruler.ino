// ---- Circuit (Kit 4) ----
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define BTN1 2

#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int zero = 0;

int readAvg() {                             // average of 8 valid readings smooths out the laser noise
  long sum = 0; int n = 0;
  for (int i = 0; i < 8; i++) {
    int m = tofMm();
    if (m >= 0) { sum += m; n++; }
    delay(5);
  }
  return n > 0 ? sum / n : -1;
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  int mm = readAvg();
  if (mm < 0) { Serial.println("out of range"); delay(300); return; }
  if (pressed()) { zero = mm; Serial.print("zeroed at "); Serial.print(zero); Serial.println(" mm"); }
  Serial.print("ruler: "); Serial.print(mm - zero); Serial.print(" mm   (absolute "); Serial.print(mm); Serial.println(" mm)");
  delay(250);
}
