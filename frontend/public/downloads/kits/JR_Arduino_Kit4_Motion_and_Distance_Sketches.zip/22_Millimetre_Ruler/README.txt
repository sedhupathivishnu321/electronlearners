Kit 4 - Motion and Distance
Project 22: Millimetre Ruler (Intermediate)

VL53L0X distance averaged over 8 readings. Press the button to zero the ruler at the current distance.

Parts:
  Push Button tactile 6x6 x1
  VL53L0X ToF Distance x1

Circuit notes:
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-22-mm-ruler
