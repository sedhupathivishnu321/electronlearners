Kit 4 - Motion and Distance
Project 39: RPM Meter with Hall Sensor (Advanced)

Measures the time between magnet passes, averages the last 5 and shows rpm. Over the limit = red + beeps, otherwise green. The button cycles the limit (60 / 120 / 180 rpm).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  Hall Effect Sensor A3144 x1

Circuit notes:
  A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-39-rpm-meter
