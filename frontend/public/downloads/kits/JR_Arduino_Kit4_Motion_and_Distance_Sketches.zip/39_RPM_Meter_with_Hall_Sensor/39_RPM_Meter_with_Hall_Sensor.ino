// ---- Circuit (Kit 4) ----
// A3144 Hall sensor: VCC 5V, GND, OUT -> D12 (INPUT_PULLUP, LOW when a magnet is near)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define HALL_PIN 12
#define BUZZER 11
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

unsigned long periods[5];
int n = 0, slot = 0, lastHall = HIGH, limitIdx = 1;
unsigned long lastEdge = 0, lastPrint = 0;
float rpm = 0;

int limitRpm() { return (limitIdx + 1) * 60; }

void setup() {
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("limit 120 rpm");
}

void loop() {
  int now = digitalRead(HALL_PIN);
  if (lastHall == HIGH && now == LOW) {                      // one revolution
    if (lastEdge > 0) {
      periods[slot] = millis() - lastEdge;
      slot = (slot + 1) % 5;
      if (n < 5) n++;
      unsigned long sum = 0;
      for (int i = 0; i < n; i++) sum += periods[i];
      rpm = 60000.0 / (sum / (float)n);                      // moving average of the last 5 periods
    }
    lastEdge = millis();
  }
  lastHall = now;
  if (millis() - lastEdge > 2500) { rpm = 0; n = 0; slot = 0; lastEdge = 0; }    // stopped
  if (pressed()) { limitIdx = (limitIdx + 1) % 3; Serial.print("limit "); Serial.print(limitRpm()); Serial.println(" rpm"); }

  bool over = rpm > limitRpm();
  digitalWrite(RED_LED, over);
  digitalWrite(GREEN_LED, rpm > 0 && !over);
  if (over) tone(BUZZER, (millis() / 150) % 2 ? 2200 : 1700); else noTone(BUZZER);
  if (millis() - lastPrint > 500) {
    lastPrint = millis();
    Serial.print("rpm "); Serial.print(rpm, 0);
    Serial.println(over ? "  OVERSPEED!" : "");
  }
}
