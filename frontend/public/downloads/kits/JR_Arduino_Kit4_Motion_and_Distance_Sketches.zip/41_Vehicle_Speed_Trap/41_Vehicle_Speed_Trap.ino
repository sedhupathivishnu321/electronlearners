// ---- Circuit (Kit 4) ----
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define IR_PIN 8
#define LINE_DO 13
#define LINE_AO A0
#define BUZZER 11
#define RED_LED 3
#define GREEN_LED 5

#define GATE_CM 20.0
#define LIMIT_CMS 40.0                          // speed limit in cm/s

int stage = 0;
unsigned long t1 = 0;

void setup() {
  pinMode(IR_PIN, INPUT);
  pinMode(LINE_DO, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("speed trap armed");
}

void loop() {
  if (stage == 0 && digitalRead(IR_PIN) == LOW) { t1 = millis(); stage = 1; }
  else if (stage == 1) {
    if (digitalRead(LINE_DO) == HIGH) {
      unsigned long dt = millis() - t1;
      float v = GATE_CM * 1000.0 / dt;
      bool speeding = v > LIMIT_CMS;
      Serial.print("speed "); Serial.print(v, 1); Serial.print(" cm/s  ");
      Serial.println(speeding ? "SPEEDING!" : "within the limit");
      digitalWrite(RED_LED, speeding);
      digitalWrite(GREEN_LED, !speeding);
      if (speeding) { tone(BUZZER, 2000, 600); }
      delay(1500);
      digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, LOW);
      while (digitalRead(IR_PIN) == LOW || digitalRead(LINE_DO) == HIGH) { }
      stage = 0;
    } else if (millis() - t1 > 5000) { stage = 0; Serial.println("timeout"); }
  }
}
