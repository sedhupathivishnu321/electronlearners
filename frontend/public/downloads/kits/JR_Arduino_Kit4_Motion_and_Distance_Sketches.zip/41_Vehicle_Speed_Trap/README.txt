Kit 4 - Motion and Distance
Project 41: Vehicle Speed Trap (Advanced)

Two gates 20 cm apart (IR sensor, then line sensor). The time between them gives the speed of a toy car; over 40 cm/s the buzzer sounds and the red LED lights, otherwise green. Trigger the IR first, then lower the line-sensor reflectivity.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  IR Obstacle Sensor x1
  TCRT5000 Line Sensor x1

Circuit notes:
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-41-speed-trap
