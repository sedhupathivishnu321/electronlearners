Kit 4 - Motion and Distance
Project 14: Automatic Door Opener (Intermediate)

A person seen by the PIR or closer than 30 cm to the ultrasonic sensor opens the 'door' (servo to 90 degrees); it closes 3 s after the last sighting.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  HC-SR04 Ultrasonic x1
  PIR Motion HC-SR501 x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-14-auto-door
