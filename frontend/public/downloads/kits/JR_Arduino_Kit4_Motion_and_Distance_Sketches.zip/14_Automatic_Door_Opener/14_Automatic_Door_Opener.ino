// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define SERVO_PIN 6
#define PIR_PIN 7
#define TRIG 9
#define ECHO 10
#define GREEN_LED 5

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

bool isOpen = false;
int angle = 0;
unsigned long lastSeen = 0;

void moveTo(int target) {                   // smooth 3 degree steps
  while (angle != target) {
    angle += (target > angle) ? 3 : -3;
    if (abs(angle - target) < 3) angle = target;
    servo.write(angle);
    delay(12);
  }
}

void setup() {
  usBegin();
  pinMode(PIR_PIN, INPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(0);
  Serial.begin(9600);
}

void loop() {
  float cm = distCm();
  bool person = digitalRead(PIR_PIN) == HIGH || (cm > 0 && cm < 30);
  if (person) lastSeen = millis();
  if (person && !isOpen) { isOpen = true; moveTo(90); digitalWrite(GREEN_LED, HIGH); Serial.println("door OPEN"); }
  if (isOpen && millis() - lastSeen > 3000) { isOpen = false; moveTo(0); digitalWrite(GREEN_LED, LOW); Serial.println("door closed"); }
  delay(60);
}
