Kit 4 - Motion and Distance
Project 40: Elevator Floor Simulator (Advanced)

The servo is the elevator car (floor 1 = 0, floor 2 = 90, floor 3 = 180 degrees). Tap the button 1-3 times to call that floor; calls are queued. Red = moving, green = doors open (held open while the IR door sensor is blocked), chime on arrival.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  IR Obstacle Sensor x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-40-elevator
