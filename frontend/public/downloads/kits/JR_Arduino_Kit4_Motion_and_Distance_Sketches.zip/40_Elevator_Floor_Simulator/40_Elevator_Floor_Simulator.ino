// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define SERVO_PIN 6
#define IR_PIN 8
#define BTN1 2
#define GREEN_LED 5
#define RED_LED 3
#define BUZZER 11

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int queue[4];
int qLen = 0, floorNow = 0, taps = 0, angle = 0;
unsigned long lastTap = 0;

void enqueue(int f) {
  if (qLen < 4 && f != floorNow) { queue[qLen] = f; qLen++; Serial.print("call queued: floor "); Serial.println(f + 1); }
}

void arrive() {
  floorNow = queue[0];
  for (int i = 1; i < qLen; i++) queue[i - 1] = queue[i];
  qLen--;
  digitalWrite(RED_LED, LOW);
  tone(BUZZER, 1500, 300);
  digitalWrite(GREEN_LED, HIGH);
  Serial.print("arrived at floor "); Serial.println(floorNow + 1);
  unsigned long openAt = millis();
  while (millis() - openAt < 2000 || digitalRead(IR_PIN) == LOW) { delay(20); }   // doors stay open while blocked
  digitalWrite(GREEN_LED, LOW);
  Serial.println("doors closed");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(IR_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(0);
  Serial.begin(9600);
  Serial.println("elevator at floor 1 - tap the button 1, 2 or 3 times to call a floor");
}

void loop() {
  if (pressed()) { taps++; lastTap = millis(); }
  if (taps > 0 && millis() - lastTap > 700) {                // taps counted: that is the requested floor
    enqueue(constrain(taps, 1, 3) - 1);
    taps = 0;
  }
  if (qLen > 0) {
    int target = queue[0] * 90;
    digitalWrite(RED_LED, HIGH);
    if (angle < target) angle += 2;
    else if (angle > target) angle -= 2;
    servo.write(angle);
    delay(12);
    if (abs(angle - target) < 2) { angle = target; servo.write(angle); arrive(); }
  }
}
