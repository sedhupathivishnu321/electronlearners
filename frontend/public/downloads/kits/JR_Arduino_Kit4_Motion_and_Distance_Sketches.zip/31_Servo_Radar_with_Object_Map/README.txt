Kit 4 - Motion and Distance
Project 31: Servo Radar with Object Map (Advanced)

The servo sweeps both rangers through 180 degrees in 5 degree steps and streams angle, ultrasonic cm, ToF cm as CSV for the Serial Plotter, then reports the nearest object of each sweep.

Parts:
  HC-SR04 Ultrasonic x1
  VL53L0X ToF Distance x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-31-radar-map
