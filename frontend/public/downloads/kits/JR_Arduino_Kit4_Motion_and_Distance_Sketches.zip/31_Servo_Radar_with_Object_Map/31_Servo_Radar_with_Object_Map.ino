// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
#define SERVO_PIN 6
#define TRIG 9
#define ECHO 10

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

int sweepNo = 0;
float nearestCm = 999;
int nearestAngle = 0;

void scanAt(int a) {
  servo.write(a);
  delay(80);
  float us = distCm();
  int mm = tofMm();
  float tofCm = mm < 0 ? -1 : mm / 10.0;
  Serial.print(a); Serial.print(","); Serial.print(us, 1); Serial.print(","); Serial.println(tofCm, 1);
  float best = 999;
  if (us > 0) best = us;
  if (tofCm > 0 && tofCm < best) best = tofCm;                // the closer valid reading wins
  if (best < nearestCm) { nearestCm = best; nearestAngle = a; }
}

void setup() {
  usBegin();
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  tofBegin();
  Serial.println("angle,ultrasonic_cm,tof_cm");
}

void loop() {
  nearestCm = 999;
  for (int a = 0; a <= 180; a += 5) scanAt(a);
  sweepNo++;
  Serial.print("sweep "); Serial.print(sweepNo); Serial.print(": nearest object at ");
  Serial.print(nearestAngle); Serial.print(" degrees, "); Serial.print(nearestCm, 1); Serial.println(" cm");
  for (int a = 180; a >= 0; a -= 15) { servo.write(a); delay(30); }   // quick return
}
