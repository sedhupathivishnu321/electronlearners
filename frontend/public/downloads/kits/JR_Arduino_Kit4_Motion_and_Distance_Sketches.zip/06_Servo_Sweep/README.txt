Kit 4 - Motion and Distance
Project 6: Servo Sweep (Basic)

Sweeps the SG90 servo from 0 to 180 degrees and back.

Parts:
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-06-servo-sweep
