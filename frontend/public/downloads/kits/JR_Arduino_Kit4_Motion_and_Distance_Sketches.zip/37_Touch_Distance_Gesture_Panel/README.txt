Kit 4 - Motion and Distance
Project 37: Touch + Distance Gesture Panel (Advanced)

Touch selects the mode (1 = green brightness, 2 = red brightness, 3 = pitch) and the piezo beeps the mode number; your hand distance over the ToF sensor sets the value (close = high).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Piezo Passive Buzzer x1
  VL53L0X ToF Distance x1
  Touch Sensor TTP223 x1

Circuit notes:
  TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-37-gesture-panel
