// ---- Circuit (Kit 4) ----
// TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define TOUCH_PIN 4
#define BUZZER 11
#define GREEN_LED 5
#define RED_LED 3

#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

int mode = 0, lastTouch = LOW;
unsigned long lastPrint = 0, lastTone = 0;

void setup() {
  pinMode(TOUCH_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  tofBegin();
  Serial.println("mode 1: green brightness");
}

void loop() {
  int t = digitalRead(TOUCH_PIN);
  if (t == HIGH && lastTouch == LOW) {
    mode = (mode + 1) % 3;
    analogWrite(GREEN_LED, 0); analogWrite(RED_LED, 0);
    for (int i = 0; i <= mode; i++) { tone(BUZZER, 1800, 80); delay(160); }     // confirm: one beep per mode number
    Serial.print("mode "); Serial.println(mode + 1);
  }
  lastTouch = t;

  int mm = tofMm();
  if (mm < 0) mm = 400;
  int value = map(constrain(mm, 50, 400), 50, 400, 100, 0);   // 0..100 %
  if (mode == 0) analogWrite(GREEN_LED, value * 255 / 100);
  if (mode == 1) analogWrite(RED_LED, value * 255 / 100);
  if (mode == 2 && millis() - lastTone > 250) { lastTone = millis(); tone(BUZZER, 200 + value * 10, 120); }
  if (millis() - lastPrint > 400) {
    lastPrint = millis();
    Serial.print("mode "); Serial.print(mode + 1); Serial.print("  value "); Serial.print(value); Serial.println(" %");
  }
  delay(20);
}
