// ---- Circuit (Kit 4) ----
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define TRIG 9
#define ECHO 10
#define GREEN_LED 5

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

bool lampOn = false, armed = true;

void setup() {
  usBegin();
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float cm = distCm();
  if (cm < 0 || cm > 35) armed = true;                       // hand away: ready for the next wave
  if (armed && cm > 0 && cm < 20) {
    armed = false;
    lampOn = !lampOn;
    digitalWrite(GREEN_LED, lampOn);
    Serial.println(lampOn ? "wave -> lamp ON" : "wave -> lamp OFF");
  }
  delay(50);
}
