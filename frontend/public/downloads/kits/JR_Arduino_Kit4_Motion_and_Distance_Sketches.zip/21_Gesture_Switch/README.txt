Kit 4 - Motion and Distance
Project 21: Gesture Switch (Intermediate)

Wave your hand in to within 20 cm to toggle the green LED. Take the hand away (beyond 35 cm) to re-arm.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  HC-SR04 Ultrasonic x1

Circuit notes:
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-21-gesture-switch
