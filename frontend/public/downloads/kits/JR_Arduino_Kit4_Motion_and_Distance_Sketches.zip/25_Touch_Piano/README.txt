Kit 4 - Motion and Distance
Project 25: Touch Piano (Intermediate)

Each tap on the TTP223 plays the next note of the C major scale; your hand height above the ToF sensor picks the octave (close = high, far = low).

Parts:
  Piezo Passive Buzzer x1
  VL53L0X ToF Distance x1
  Touch Sensor TTP223 x1

Circuit notes:
  TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
  VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-25-touch-piano
