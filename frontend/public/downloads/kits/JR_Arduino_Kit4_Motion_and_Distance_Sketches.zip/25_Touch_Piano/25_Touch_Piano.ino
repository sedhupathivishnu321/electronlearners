// ---- Circuit (Kit 4) ----
// TTP223 touch pad: VCC 5V, GND, I/O -> D4 (HIGH while touched)
// VL53L0X: VIN 5V, GND, SDA -> A4, SCL -> A5 (I2C address 0x29)
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
#define TOUCH_PIN 4
#define BUZZER 11

#include <Wire.h>
#include <Adafruit_VL53L0X.h>
Adafruit_VL53L0X tof;

int tofMm() {                              // distance in mm (-1 = out of range)
  VL53L0X_RangingMeasurementData_t m;
  tof.rangingTest(&m, false);
  if (m.RangeStatus == 4) return -1;
  return m.RangeMilliMeter;
}
void tofBegin() {
  if (!tof.begin()) { Serial.println("VL53L0X not found - check SDA/SCL"); while (true) { } }
}

int NOTES[8] = {262, 294, 330, 349, 392, 440, 494, 523};
String NAMES = "CDEFGABC";
int idx = 0, lastTouch = LOW;

void setup() {
  pinMode(TOUCH_PIN, INPUT);
  Serial.begin(9600);
  tofBegin();
}

void loop() {
  int t = digitalRead(TOUCH_PIN);
  if (t == HIGH && lastTouch == LOW) {
    int mm = tofMm();
    float mult = 1.0; String oct = "middle";
    if (mm >= 0 && mm < 150) { mult = 2.0; oct = "high"; }
    else if (mm < 0 || mm > 300) { mult = 0.5; oct = "low"; }
    int f = NOTES[idx] * mult;
    tone(BUZZER, f, 250);
    Serial.print("note "); Serial.print(NAMES.charAt(idx)); Serial.print("  "); Serial.print(f); Serial.print(" Hz  ("); Serial.print(oct); Serial.println(" octave)");
    idx = (idx + 1) % 8;
  }
  lastTouch = t;
  delay(20);
}
