// ---- Circuit (Kit 4) ----
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define LINE_DO 13
#define LINE_AO A0
#define GREEN_LED 5

void setup() {
  pinMode(LINE_DO, INPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool onLine = digitalRead(LINE_DO) == HIGH;               // dark surface reflects little -> DO goes HIGH
  digitalWrite(GREEN_LED, onLine);
  Serial.print("analog "); Serial.print(analogRead(LINE_AO));
  Serial.println(onLine ? "  -> BLACK line" : "  -> white surface");
  delay(300);
}
