// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
#define SERVO_PIN 6
#define IR_PIN 8
#define TRIG 9
#define ECHO 10
#define PIR_PIN 7
#define RED_LED 3
#define GREEN_LED 5

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

bool lidOpen = false, full = false;
unsigned long openedAt = 0, lastMeasure = 0;

void setup() {
  usBegin();
  pinMode(IR_PIN, INPUT);
  pinMode(PIR_PIN, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(0);
  Serial.begin(9600);
}

void loop() {
  bool hand = digitalRead(IR_PIN) == LOW || digitalRead(PIR_PIN) == HIGH;
  if (hand) {
    openedAt = millis();
    if (!lidOpen) { lidOpen = true; servo.write(90); digitalWrite(GREEN_LED, HIGH); Serial.println("lid OPEN"); }
  }
  if (lidOpen && millis() - openedAt > 3000) {
    lidOpen = false; servo.write(0); digitalWrite(GREEN_LED, LOW); Serial.println("lid closed");
    lastMeasure = 0;                                         // measure the fill level right after closing
  }
  if (!lidOpen && millis() - lastMeasure > 600) {            // the sensor only sees the rubbish with the lid shut
    lastMeasure = millis();
    float cm = distCm();
    bool nowFull = cm > 0 && cm < 8;
    if (nowFull != full) { full = nowFull; Serial.println(full ? "bin FULL - please empty" : "bin has room again"); }
    digitalWrite(RED_LED, full);
  }
  delay(20);
}
