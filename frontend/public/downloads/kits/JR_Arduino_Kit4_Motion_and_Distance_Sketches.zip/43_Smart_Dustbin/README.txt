Kit 4 - Motion and Distance
Project 43: Smart Dustbin (Advanced)

A hand seen by the IR sensor or the PIR opens the lid (servo 90 degrees, green LED) for 3 s. With the lid closed the ultrasonic sensor looks into the bin: closer than 8 cm = FULL (red LED).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  HC-SR04 Ultrasonic x1
  PIR Motion HC-SR501 x1
  IR Obstacle Sensor x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  PIR HC-SR501: VCC 5V, GND, OUT -> D7 (HIGH while it sees motion)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-43-smart-dustbin
