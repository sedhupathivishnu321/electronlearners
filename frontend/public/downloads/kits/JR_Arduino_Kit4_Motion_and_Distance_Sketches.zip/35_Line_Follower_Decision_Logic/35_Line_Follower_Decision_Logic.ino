// ---- Circuit (Kit 4) ----
// TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define LINE_DO 13
#define LINE_AO A0
#define SERVO_PIN 6
#define BTN1 2
#define GREEN_LED 5
#define RED_LED 3

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int whiteV = 205, blackV = 920, calStep = 0;
float prevErr = 0, sumErr = 0;
unsigned long lastPrint = 0;

#define KP 0.45
#define KI 0.01
#define KD 0.25

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  Serial.println("press over WHITE, then over BLACK to calibrate");
}

void loop() {
  int v = analogRead(LINE_AO);
  if (pressed()) {
    if (calStep == 0) { whiteV = v; calStep = 1; Serial.print("white = "); Serial.println(v); }
    else { blackV = v; calStep = 0; Serial.print("black = "); Serial.println(v); }
  }
  float target = (whiteV + blackV) / 2.0;                    // the edge of the line is half way between white and black
  float half = (blackV - whiteV) / 2.0;
  float err = (v - target) * 100.0 / half;                   // -100 (white) .. +100 (black)
  sumErr = constrain(sumErr + err, -500, 500);
  float out = KP * err + KI * sumErr + KD * (err - prevErr);
  prevErr = err;
  int steer = constrain(90 + (int)out, 45, 135);
  servo.write(steer);
  digitalWrite(GREEN_LED, abs(err) < 25);
  digitalWrite(RED_LED, abs(err) > 90);                      // fully white or fully black: line lost
  if (millis() - lastPrint > 250) {
    lastPrint = millis();
    Serial.print("sensor "); Serial.print(v); Serial.print("  error "); Serial.print(err, 0); Serial.print("  steering "); Serial.println(steer);
  }
  delay(20);
}
