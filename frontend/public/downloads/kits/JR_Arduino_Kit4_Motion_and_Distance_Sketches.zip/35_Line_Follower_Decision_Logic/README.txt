Kit 4 - Motion and Distance
Project 35: Line Follower Decision Logic (Advanced)

The analog line sensor follows the edge of a line: a PID controller turns the error into a steering angle on the servo. The button calibrates white then black. Green = on the edge, red = line lost.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  TCRT5000 Line Sensor x1
  SG90 Micro Servo x1

Circuit notes:
  TCRT5000: VCC 5V, GND, DO -> D13 (HIGH over a dark surface / no surface), AO -> A0 (higher = darker)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-35-line-pid
