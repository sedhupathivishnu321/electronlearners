// ---- Circuit (Kit 4) ----
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
// Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define IR_PIN 8
#define TRIG 9
#define ECHO 10
#define BUZZER 11
#define BTN1 2
#define GREEN_LED 5
#define RED_LED 3

float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool playing = false, handNear = false;
int score = 0, best = 0, lastIr = HIGH;
unsigned long startMs = 0;

void point(String what) {
  score++;
  tone(BUZZER, 2200, 40);
  Serial.print("+1 "); Serial.print(what); Serial.print("  score "); Serial.println(score);
}

void setup() {
  usBegin();
  pinMode(IR_PIN, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("press the button to start (15 s)");
}

void loop() {
  if (!playing) {
    if (pressed()) {
      playing = true; score = 0; startMs = millis(); handNear = false; lastIr = digitalRead(IR_PIN);
      digitalWrite(GREEN_LED, HIGH); digitalWrite(RED_LED, LOW);
      Serial.println("GO!");
    }
    return;
  }
  int ir = digitalRead(IR_PIN);
  if (lastIr == HIGH && ir == LOW) point("IR swipe");
  lastIr = ir;
  float cm = distCm();
  bool near = cm > 0 && cm < 25;
  if (near && !handNear) point("ultrasonic hand");
  handNear = near;
  if (millis() - startMs >= 15000) {
    playing = false;
    digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH);
    if (score > best) best = score;
    Serial.print("TIME! score "); Serial.print(score); Serial.print("   best "); Serial.println(best);
    for (int i = 0; i < min(score, 10); i++) { tone(BUZZER, 1500, 100); delay(220); }
    digitalWrite(RED_LED, LOW);
    Serial.println("press the button to play again");
  }
  delay(10);
}
