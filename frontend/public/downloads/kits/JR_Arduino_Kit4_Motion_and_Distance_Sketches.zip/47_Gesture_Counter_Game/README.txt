Kit 4 - Motion and Distance
Project 47: Gesture Counter Game (Advanced)

Press the button for a 15 s challenge. Every swipe past the IR sensor and every hand-in/hand-out within 25 cm of the ultrasonic sensor scores a point with a tick. At the end the buzzer plays one beep per point (up to 10).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Piezo Passive Buzzer x1
  HC-SR04 Ultrasonic x1
  IR Obstacle Sensor x1

Circuit notes:
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
  Passive piezo buzzer + -> D11, - -> GND (drive it with tone())
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5 (PWM), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-47-gesture-game
