Kit 4 - Motion and Distance
Project 18: People Counter (Intermediate)

Counts objects passing the IR sensor; the button resets the count.

Parts:
  Push Button tactile 6x6 x1
  IR Obstacle Sensor x1

Circuit notes:
  IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-18-people-counter
