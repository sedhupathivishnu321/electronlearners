// ---- Circuit (Kit 4) ----
// IR obstacle sensor: VCC 5V, GND, OUT -> D8 (LOW when something is in front)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define IR_PIN 8
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int count = 0, lastIr = HIGH;
unsigned long lastCount = 0;

void setup() {
  pinMode(IR_PIN, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  Serial.println("People counter: 0");
}

void loop() {
  int now = digitalRead(IR_PIN);
  if (lastIr == HIGH && now == LOW && millis() - lastCount > 150) {   // beam broken (ignore flutter)
    count++;
    lastCount = millis();
    Serial.print("People counter: "); Serial.println(count);
  }
  lastIr = now;
  if (pressed()) { count = 0; Serial.println("reset - People counter: 0"); }
}
