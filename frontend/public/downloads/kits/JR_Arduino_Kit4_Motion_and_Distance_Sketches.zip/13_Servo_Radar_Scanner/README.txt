Kit 4 - Motion and Distance
Project 13: Servo Radar Scanner (Intermediate)

The servo turns the ultrasonic sensor in 10 degree steps and prints angle,distance pairs for each sweep.

Parts:
  HC-SR04 Ultrasonic x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k4-13-servo-radar
