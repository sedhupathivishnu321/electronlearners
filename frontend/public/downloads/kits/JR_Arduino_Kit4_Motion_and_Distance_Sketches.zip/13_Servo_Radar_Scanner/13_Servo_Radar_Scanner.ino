// ---- Circuit (Kit 4) ----
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// HC-SR04: VCC 5V, GND, TRIG -> D9, ECHO -> D10
#define SERVO_PIN 6
#define TRIG 9
#define ECHO 10

#include <Servo.h>
Servo servo;
float distCm() {                           // HC-SR04: 10 us trigger pulse, echo time / 58 = cm (-1 = no echo)
  digitalWrite(TRIG, LOW); delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long us = pulseIn(ECHO, HIGH, 30000);
  if (us == 0) return -1;
  return us / 58.2;
}
void usBegin() { pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); }

void scanAt(int a) {
  servo.write(a);
  delay(150);                               // let the servo arrive
  Serial.print(a); Serial.print(","); Serial.println(distCm(), 1);
}

void setup() {
  usBegin();
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  Serial.println("angle,distance_cm");
}

void loop() {
  for (int a = 0; a <= 180; a += 10) scanAt(a);
  for (int a = 170; a > 0; a -= 10) scanAt(a);
}
