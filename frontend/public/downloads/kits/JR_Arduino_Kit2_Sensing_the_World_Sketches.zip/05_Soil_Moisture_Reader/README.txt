Kit 2 - Sensing the World
Project 5: Soil Moisture Reader (Basic)

Classifies the soil as dry, moist or wet.

Parts:
  Soil Moisture Sensor x1

Circuit notes:
  Soil moisture probe: VCC 5V, GND, AO -> A0 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-05-soil-reader
