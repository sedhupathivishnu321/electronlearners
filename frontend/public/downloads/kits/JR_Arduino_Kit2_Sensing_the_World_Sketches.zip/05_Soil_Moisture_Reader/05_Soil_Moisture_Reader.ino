// ---- Circuit (Kit 2) ----
// Soil moisture probe: VCC 5V, GND, AO -> A0 (dry = high reading)
#define SOIL_PIN A0

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }

void setup() {
  Serial.begin(9600);
}

void loop() {
  int pct = soilPct();
  Serial.print("moisture "); Serial.print(pct); Serial.print(" %  ");
  if (pct < 30) Serial.println("DRY");
  else if (pct < 65) Serial.println("MOIST");
  else Serial.println("WET");
  delay(500);
}
