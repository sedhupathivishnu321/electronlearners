// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define DHT_PIN 8
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float tHist[5], hHist[5];
int n = 0;
bool followTemp = true;
unsigned long last = 0;

String arrow(float d) { return d > 0.4 ? "^" : (d < -0.4 ? "v" : "="); }

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  Serial.println("Button: switch LEDs between temperature and humidity trend");
}

void loop() {
  if (pressed()) { followTemp = !followTemp; Serial.println(followTemp ? "following TEMPERATURE" : "following HUMIDITY"); }
  if (millis() - last >= 2000) {
    last = millis();
    for (int i = 4; i > 0; i--) { tHist[i] = tHist[i - 1]; hHist[i] = hHist[i - 1]; }
    tHist[0] = dht.readTemperature(); hHist[0] = dht.readHumidity();
    if (n < 5) n++;
    float dt = (n >= 5) ? tHist[0] - tHist[4] : 0;
    float dh = (n >= 5) ? hHist[0] - hHist[4] : 0;
    Serial.print("T "); Serial.print(tHist[0], 1); Serial.print(arrow(dt));
    Serial.print("   RH "); Serial.print(hHist[0], 0); Serial.println(arrow(dh));
    float d = followTemp ? dt : dh;
    digitalWrite(RED_LED, d > 0.4);        // rising
    digitalWrite(GREEN_LED, d < -0.4);     // falling
  }
}
