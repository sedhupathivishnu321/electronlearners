// ---- Circuit (Kit 2) ----
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
#define LDR_PIN A0

void setup() {
  Serial.begin(9600);
}

void loop() {
  int v = analogRead(LDR_PIN);
  Serial.print("darkness = "); Serial.print(v);
  if (v < 300) Serial.println("  -> BRIGHT");
  else if (v < 650) Serial.println("  -> DIM");
  else Serial.println("  -> DARK");
  delay(400);
}
