Kit 2 - Sensing the World
Project 4: Light Level Reader (Basic)

Prints the LDR reading and a Bright / Dim / Dark label.

Parts:
  LDR Light Sensor Module x1

Circuit notes:
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-04-ldr-level
