Kit 2 - Sensing the World
Project 23: Moving-Average Filter Demo (Intermediate)

Raw vs 10-sample moving average, ready for the Serial Plotter.

Parts:
  LM35 Temperature Sensor x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-23-moving-average
