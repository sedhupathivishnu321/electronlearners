// ---- Circuit (Kit 2) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
#define LM35_PIN A0

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

float window[10];
int idx = 0;
bool filled = false;

void setup() {
  Serial.begin(9600);
}

void loop() {
  float raw = lm35C() + (random(-10, 11) / 10.0);        // add +/-1 C of noise so the filter has work to do
  window[idx] = raw;
  idx = (idx + 1) % 10;
  if (idx == 0) filled = true;
  int n = filled ? 10 : idx;
  float sum = 0;
  for (int i = 0; i < n; i++) sum += window[i];
  Serial.print("raw:"); Serial.print(raw, 2);
  Serial.print(" filtered:"); Serial.println(sum / n, 2);
  delay(150);
}
