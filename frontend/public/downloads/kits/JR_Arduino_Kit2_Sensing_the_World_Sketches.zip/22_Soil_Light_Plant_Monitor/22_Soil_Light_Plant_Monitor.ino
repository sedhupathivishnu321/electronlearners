// ---- Circuit (Kit 2) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)
#define RED_LED 3
#define GREEN_LED 5
#define YELLOW_LED 6
#define LDR_PIN A0
#define SOIL_PIN A1

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int water = soilPct();
  int dark = analogRead(LDR_PIN);
  bool dry = water < 30, dim = dark > 700;
  digitalWrite(RED_LED, dry);
  digitalWrite(YELLOW_LED, dim);
  digitalWrite(GREEN_LED, !dry && !dim);
  Serial.print("water "); Serial.print(water); Serial.print(" %, darkness "); Serial.print(dark);
  Serial.println(dry ? "  -> needs WATER" : (dim ? "  -> needs LIGHT" : "  -> happy plant"));
  delay(500);
}
