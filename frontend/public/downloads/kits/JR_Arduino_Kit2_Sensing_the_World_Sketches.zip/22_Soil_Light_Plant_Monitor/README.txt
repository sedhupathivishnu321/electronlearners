Kit 2 - Sensing the World
Project 22: Soil + Light Plant Monitor (Intermediate)

Green = happy plant, red = needs water, yellow = needs light.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  LDR Light Sensor Module x1
  Soil Moisture Sensor x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-22-plant-monitor
