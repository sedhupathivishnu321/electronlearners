// ---- Circuit (Kit 2) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)
#define BTN1 2
#define LM35_PIN A0
#define NTC_PIN A1

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
float ntcC() {                        // NTC on the 5V side, 10k resistor to GND
  int adc = analogRead(NTC_PIN);
  if (adc < 1) adc = 1;
  float r = 10000.0 * (1023.0 / adc - 1.0);
  float k = 1.0 / (1.0 / 298.15 + log(r / 10000.0) / 3950.0);   // beta equation, B = 3950
  return k - 273.15;
}
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float offset = 0;
int samples = 0;
unsigned long last = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  Serial.println("Press the button to calibrate the NTC against the LM35");
  Serial.println("LM35 | NTC raw | NTC corrected | error");
}

void loop() {
  if (pressed()) {
    float ref = lm35C();
    offset = ref - ntcC();
    Serial.print("calibrated, offset = "); Serial.print(offset, 2); Serial.println(" C");
  }
  if (millis() - last >= 1000) {
    last = millis();
    float ref = lm35C(), raw = ntcC(), fixed = raw + offset;
    Serial.print(ref, 1); Serial.print(" | "); Serial.print(raw, 1); Serial.print(" | ");
    Serial.print(fixed, 1); Serial.print(" | "); Serial.println(fixed - ref, 2);
  }
}
