Kit 2 - Sensing the World
Project 38: Thermistor Linearisation and Self-Test (Advanced)

Button stores the LM35 as a reference; the NTC is corrected with the offset and an error table is printed.

Parts:
  Push Button tactile 6x6 x1
  Thermistor NTC 10k x1
  Resistor 10k ohm 1/4W x1
  LM35 Temperature Sensor x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-38-ntc-selftest
