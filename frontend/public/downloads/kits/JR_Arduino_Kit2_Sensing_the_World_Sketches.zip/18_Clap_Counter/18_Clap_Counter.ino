// ---- Circuit (Kit 2) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Sound sensor: VCC 5V, GND, AO -> A0
#define RED_LED 3
#define GREEN_LED 5
#define SND_PIN A0

int claps = 0;
unsigned long first = 0, lastClap = 0;

void act(int n) {
  Serial.print(n); Serial.println(n == 1 ? " clap: green" : (n == 2 ? " claps: red" : " claps: both"));
  digitalWrite(GREEN_LED, n == 1 || n >= 3);
  digitalWrite(RED_LED, n == 2 || n >= 3);
}

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int v = analogRead(SND_PIN);
  if (v > 600 && millis() - lastClap > 250) {
    lastClap = millis();
    if (claps == 0) first = millis();
    claps++;
  }
  if (claps > 0 && millis() - first > 1500) { act(claps); claps = 0; }
}
