Kit 2 - Sensing the World
Project 18: Clap Counter (Intermediate)

One clap = green, two = red, three = both, within a 1.5 s window.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Sound Sensor Module x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Sound sensor: VCC 5V, GND, AO -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-18-clap-counter
