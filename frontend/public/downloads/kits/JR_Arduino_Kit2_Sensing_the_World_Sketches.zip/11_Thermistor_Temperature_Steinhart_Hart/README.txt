Kit 2 - Sensing the World
Project 11: Thermistor Temperature (Steinhart-Hart) (Intermediate)

Real temperature from the NTC using the beta / Steinhart-Hart equation.

Parts:
  Thermistor NTC 10k x1
  Resistor 10k ohm 1/4W x1

Circuit notes:
  NTC 10k thermistor + 10k resistor divider (5V - NTC - A0 - 10k - GND)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-11-steinhart
