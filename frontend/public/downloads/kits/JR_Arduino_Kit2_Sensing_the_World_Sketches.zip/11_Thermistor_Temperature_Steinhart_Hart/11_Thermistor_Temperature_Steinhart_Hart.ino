// ---- Circuit (Kit 2) ----
// NTC 10k thermistor + 10k resistor divider (5V - NTC - A0 - 10k - GND)
#define NTC_PIN A0

float ntcC() {                        // NTC on the 5V side, 10k resistor to GND
  int adc = analogRead(NTC_PIN);
  if (adc < 1) adc = 1;
  float r = 10000.0 * (1023.0 / adc - 1.0);
  float k = 1.0 / (1.0 / 298.15 + log(r / 10000.0) / 3950.0);   // beta equation, B = 3950
  return k - 273.15;
}

void setup() {
  Serial.begin(9600);
}

void loop() {
  Serial.print("Thermistor temperature: ");
  Serial.print(ntcC(), 1);
  Serial.println(" C");
  delay(500);
}
