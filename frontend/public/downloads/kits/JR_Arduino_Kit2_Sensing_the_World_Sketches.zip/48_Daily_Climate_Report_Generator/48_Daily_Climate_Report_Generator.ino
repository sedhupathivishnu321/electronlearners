// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
#define DHT_PIN 8
#define LDR_PIN A0
#define LM35_PIN A1

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

float temp[24], hum[24];
int dark[24];
int hour = 0;
unsigned long last = 0;

void report() {
  float tMin = 999, tMax = -999, tSum = 0, hSum = 0;
  int dMax = 0;
  Serial.println();
  Serial.println("=========== DAILY CLIMATE REPORT ===========");
  Serial.println("hour | temp C | RH % | darkness");
  for (int i = 0; i < 24; i++) {
    Serial.print(i); Serial.print("    | "); Serial.print(temp[i], 1); Serial.print("   | "); Serial.print(hum[i], 0); Serial.print("   | "); Serial.println(dark[i]);
    if (temp[i] < tMin) tMin = temp[i];
    if (temp[i] > tMax) tMax = temp[i];
    tSum += temp[i]; hSum += hum[i];
    if (dark[i] > dMax) dMax = dark[i];
  }
  Serial.print("Temperature: min "); Serial.print(tMin, 1); Serial.print("  max "); Serial.print(tMax, 1); Serial.print("  avg "); Serial.println(tSum / 24, 1);
  Serial.print("Humidity avg "); Serial.print(hSum / 24, 0); Serial.print(" %   darkest reading "); Serial.println(dMax);
  Serial.println("============================================");
}

void setup() {
  Serial.begin(9600);
  dht.begin();
  Serial.println("Collecting 24 hourly samples (1 s = 1 hour)...");
}

void loop() {
  if (millis() - last >= 1000) {
    last = millis();
    temp[hour] = (dht.readTemperature() + lm35C()) / 2.0;
    hum[hour] = dht.readHumidity();
    dark[hour] = analogRead(LDR_PIN);
    hour++;
    if (hour == 24) { report(); hour = 0; }
  }
}
