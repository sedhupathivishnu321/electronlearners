Kit 2 - Sensing the World
Project 48: Daily Climate Report Generator (Advanced)

Accelerated day: 1 "hour" = 1 s. After 24 samples prints a formatted table with min / max / average.

Parts:
  LDR Light Sensor Module x1
  LM35 Temperature Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-48-daily-report
