// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// LDR module: VCC 5V, GND, AO -> A1 (bright = low reading)
// Soil moisture probe: VCC 5V, GND, AO -> A2 (dry = high reading)
#define DHT_PIN 8
#define RED_LED 3
#define GREEN_LED 5
#define YELLOW_LED 6
#define POT A0
#define LDR_PIN A1
#define SOIL_PIN A2

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }

unsigned long lastPrint = 0;

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float limit = 22.0 + analogRead(POT) * 13.0 / 1023.0;     // 22 .. 35 C
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  int water = soilPct();
  int dark = analogRead(LDR_PIN);
  bool needWater = water < 35;
  bool needVent = t > limit || h > 80;
  bool needLight = dark > 700;
  digitalWrite(YELLOW_LED, needWater);
  digitalWrite(RED_LED, needVent);
  digitalWrite(GREEN_LED, needLight);
  if (millis() - lastPrint > 1500) {
    lastPrint = millis();
    Serial.print("T "); Serial.print(t, 1); Serial.print("/"); Serial.print(limit, 1);
    Serial.print(" RH "); Serial.print(h, 0); Serial.print(" soil "); Serial.print(water); Serial.print(" dark "); Serial.print(dark);
    Serial.print("  ->");
    if (needWater) Serial.print(" WATER");
    if (needVent) Serial.print(" VENT");
    if (needLight) Serial.print(" LIGHT");
    if (!needWater && !needVent && !needLight) Serial.print(" all good");
    Serial.println();
  }
}
