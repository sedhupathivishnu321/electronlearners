Kit 2 - Sensing the World
Project 35: Auto Greenhouse Logic (Advanced)

Rule engine: yellow = watering, red = vent / cooling, green = grow light. Pot sets the temperature limit.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  Potentiometer 10k (rotary) x1
  LDR Light Sensor Module x1
  Soil Moisture Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  LDR module: VCC 5V, GND, AO -> A1 (bright = low reading)
  Soil moisture probe: VCC 5V, GND, AO -> A2 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-35-greenhouse
