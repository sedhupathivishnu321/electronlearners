// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
#define GREEN_LED 5
#define RED_LED 3
#define LDR_PIN A0
#define SOIL_PIN A1
#define RAIN_PIN A2

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

bool watering = false;
unsigned long since = 0;
unsigned long lastPrint = 0;

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool dark = analogRead(LDR_PIN) > 650;
  bool dry = soilPct() < 35;
  bool rain = wetPct() > 20;
  bool allowed = dark && dry && !rain;
  if (allowed && !watering) { watering = true; since = millis(); Serial.println("Watering started"); }
  if (watering && (!allowed || millis() - since > 8000)) {
    watering = false;
    Serial.println(allowed ? "Watering finished (8 s cycle)" : "Watering stopped: conditions changed");
  }
  digitalWrite(GREEN_LED, watering);
  digitalWrite(RED_LED, dry && !allowed);                 // wants water but is blocked
  if (millis() - lastPrint > 2000) {
    lastPrint = millis();
    Serial.print("dark "); Serial.print(dark); Serial.print(" dry "); Serial.print(dry); Serial.print(" rain "); Serial.println(rain);
  }
}
