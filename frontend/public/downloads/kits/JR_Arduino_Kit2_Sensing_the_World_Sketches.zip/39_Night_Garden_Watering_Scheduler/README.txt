Kit 2 - Sensing the World
Project 39: Night Garden Watering Scheduler (Advanced)

Green = watering. It waters only when it is dark, the soil is dry and it is not raining; red shows it is blocked.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  LDR Light Sensor Module x1
  Soil Moisture Sensor x1
  Rain Sensor Module x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-39-night-garden
