// ---- Circuit (Kit 2) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// Soil moisture probe: VCC 5V, GND, AO -> A0 (dry = high reading)
#define BTN1 2
#define GREEN_LED 5
#define RED_LED 3
#define YELLOW_LED 6
#define SOIL_PIN A0

#include <EEPROM.h>
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int dryVal = 1023, wetVal = 0;
int step = 0;             // 0 = measuring with saved values, 1 = waiting for dry, 2 = waiting for wet

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  int d = EEPROM.read(0) * 256 + EEPROM.read(1);
  int w = EEPROM.read(2) * 256 + EEPROM.read(3);
  if (d > w && d <= 1023) { dryVal = d; wetVal = w; Serial.println("Loaded saved calibration"); }
  Serial.println("Button: start calibration (dry reading, then wet reading)");
}

void loop() {
  if (pressed()) {
    int v = analogRead(SOIL_PIN);
    if (step == 0) { step = 1; Serial.println("Hold the probe DRY and press the button"); }
    else if (step == 1) { dryVal = v; step = 2; Serial.print("dry = "); Serial.println(dryVal); Serial.println("Now WET and press the button"); }
    else { wetVal = v; step = 0;
      EEPROM.write(0, dryVal / 256); EEPROM.write(1, dryVal % 256); EEPROM.write(2, wetVal / 256); EEPROM.write(3, wetVal % 256);
      Serial.print("wet = "); Serial.println(wetVal); Serial.println("Calibration saved"); }
  }
  digitalWrite(RED_LED, step == 1);
  digitalWrite(YELLOW_LED, step == 2);
  digitalWrite(GREEN_LED, step == 0);
  if (step == 0 && millis() % 1000 < 20) {
    int pct = constrain(map(analogRead(SOIL_PIN), dryVal, wetVal, 0, 100), 0, 100);
    Serial.print("calibrated moisture "); Serial.print(pct); Serial.println(" %");
    delay(25);
  }
}
