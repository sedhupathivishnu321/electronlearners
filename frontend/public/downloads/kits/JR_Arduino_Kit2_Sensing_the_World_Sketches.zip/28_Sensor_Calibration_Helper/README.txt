Kit 2 - Sensing the World
Project 28: Sensor Calibration Helper (Intermediate)

Button records the dry then the wet reading, stores both in EEPROM and shows a calibrated percentage.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  Push Button tactile 6x6 x1
  Soil Moisture Sensor x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  Soil moisture probe: VCC 5V, GND, AO -> A0 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-28-soil-calibrate
