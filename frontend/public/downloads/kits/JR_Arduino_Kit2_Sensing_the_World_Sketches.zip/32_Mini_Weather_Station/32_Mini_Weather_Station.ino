// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
#define DHT_PIN 8
#define RED_LED 3
#define GREEN_LED 5
#define LDR_PIN A0
#define LM35_PIN A1
#define RAIN_PIN A2

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float t = (dht.readTemperature() + lm35C()) / 2.0;   // average of both sensors
  float h = dht.readHumidity();
  int wet = wetPct();
  int dark = analogRead(LDR_PIN);
  String forecast;
  if (wet > 25) forecast = "Rainy";
  else if (h > 80 && dark > 500) forecast = "Overcast, rain likely";
  else if (dark < 300 && t > 30) forecast = "Hot and sunny";
  else if (dark < 300) forecast = "Sunny";
  else if (dark > 800) forecast = "Night / very dark";
  else forecast = "Fair";
  digitalWrite(RED_LED, wet > 25 || h > 80);
  digitalWrite(GREEN_LED, wet <= 25 && h <= 80);
  Serial.print("T "); Serial.print(t, 1); Serial.print(" C  RH "); Serial.print(h, 0);
  Serial.print(" %  rain "); Serial.print(wet); Serial.print(" %  -> "); Serial.println(forecast);
  delay(2000);
}
