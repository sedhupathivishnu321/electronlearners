Kit 2 - Sensing the World
Project 32: Mini Weather Station (Advanced)

Temperature, humidity, rain and light summarised into a forecast string.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  LDR Light Sensor Module x1
  Rain Sensor Module x1
  LM35 Temperature Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-32-weather-station
