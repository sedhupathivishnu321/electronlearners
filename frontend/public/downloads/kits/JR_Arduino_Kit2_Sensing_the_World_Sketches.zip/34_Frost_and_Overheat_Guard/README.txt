Kit 2 - Sensing the World
Project 34: Frost and Overheat Guard (Advanced)

Two independent sensors, dual thresholds, a latched fault and an acknowledge button.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  Thermistor NTC 10k x1
  Resistor 10k ohm 1/4W x1
  LM35 Temperature Sensor x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-34-frost-guard
