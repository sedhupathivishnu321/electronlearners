// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)
#define BUZZER 12
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2
#define LM35_PIN A0
#define NTC_PIN A1

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
float ntcC() {                        // NTC on the 5V side, 10k resistor to GND
  int adc = analogRead(NTC_PIN);
  if (adc < 1) adc = 1;
  float r = 10000.0 * (1023.0 / adc - 1.0);
  float k = 1.0 / (1.0 / 298.15 + log(r / 10000.0) / 3950.0);   // beta equation, B = 3950
  return k - 273.15;
}
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int fault = 0;           // 0 ok, 1 frost, 2 overheat, 3 sensor disagreement (latched until acknowledged)
unsigned long lastPrint = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float a = lm35C(), b = ntcC();
  float t = (a + b) / 2.0;
  if (fault == 0) {
    if (t < 3.0) fault = 1;
    else if (t > 40.0) fault = 2;
    else if (abs(a - b) > 6.0) fault = 3;
    if (fault) { Serial.print("FAULT "); Serial.println(fault == 1 ? "frost" : (fault == 2 ? "overheat" : "sensor mismatch")); }
  }
  if (pressed()) {
    if (t >= 5.0 && t <= 38.0 && abs(a - b) <= 6.0) { fault = 0; Serial.println("fault acknowledged"); }
    else Serial.println("cannot acknowledge: still out of range");
  }
  digitalWrite(GREEN_LED, fault == 0);
  digitalWrite(RED_LED, fault != 0);
  digitalWrite(BUZZER, fault != 0 && (millis() / 300) % 2);
  if (millis() - lastPrint > 1000) { lastPrint = millis(); Serial.print("LM35 "); Serial.print(a, 1); Serial.print("  NTC "); Serial.println(b, 1); }
}
