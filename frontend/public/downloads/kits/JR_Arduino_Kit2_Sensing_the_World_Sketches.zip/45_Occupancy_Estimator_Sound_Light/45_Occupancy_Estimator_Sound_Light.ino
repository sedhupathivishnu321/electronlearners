// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// Sound sensor: VCC 5V, GND, AO -> A1
#define GREEN_LED 5
#define RED_LED 3
#define LDR_PIN A0
#define SND_PIN A1

float score = 0;
int lastLight = 0;
unsigned long lastTick = 0, lastPrint = 0;
bool occupied = false;

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  lastLight = analogRead(LDR_PIN);
}

void loop() {
  if (millis() - lastTick >= 200) {
    lastTick = millis();
    score *= 0.97;                                         // activity fades away
    if (analogRead(SND_PIN) > 450) score += 4;             // noise
    int l = analogRead(LDR_PIN);
    if (abs(l - lastLight) > 120) score += 8;              // lights switched or shadows moving
    lastLight = l;
    if (!occupied && score > 15) occupied = true;
    if (occupied && score < 4) occupied = false;
  }
  digitalWrite(GREEN_LED, occupied);
  digitalWrite(RED_LED, !occupied);
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    Serial.print("activity score "); Serial.print(score, 1); Serial.println(occupied ? "  OCCUPIED" : "  vacant");
  }
}
