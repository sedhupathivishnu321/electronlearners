Kit 2 - Sensing the World
Project 45: Occupancy Estimator (Sound + Light) (Advanced)

Scores noise events and light changes over time; green = room occupied, red = vacant.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  LDR Light Sensor Module x1
  Sound Sensor Module x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  Sound sensor: VCC 5V, GND, AO -> A1

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-45-occupancy
