Kit 2 - Sensing the World
Project 31: Smart Plant Care Station (Advanced)

Scores water, light and temperature; green / yellow / red status, buzzer when critical. Pot sets the moisture target.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  Buzzer Active 5V x1
  Potentiometer 10k (rotary) x1
  LDR Light Sensor Module x1
  Soil Moisture Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  LDR module: VCC 5V, GND, AO -> A1 (bright = low reading)
  Soil moisture probe: VCC 5V, GND, AO -> A2 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-31-plant-station
