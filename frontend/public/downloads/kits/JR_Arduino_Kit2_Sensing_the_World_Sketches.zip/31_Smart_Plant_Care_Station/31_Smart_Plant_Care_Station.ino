// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// LDR module: VCC 5V, GND, AO -> A1 (bright = low reading)
// Soil moisture probe: VCC 5V, GND, AO -> A2 (dry = high reading)
#define DHT_PIN 8
#define BUZZER 12
#define RED_LED 3
#define GREEN_LED 5
#define YELLOW_LED 6
#define POT A0
#define LDR_PIN A1
#define SOIL_PIN A2

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }

unsigned long lastBuzz = 0, lastPrint = 0;

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  int target = map(analogRead(POT), 0, 1023, 20, 70);
  int water = soilPct();
  int dark = analogRead(LDR_PIN);
  float t = dht.readTemperature();
  int score = 0;                                       // 0 = perfect, higher = worse
  if (water < target) score += (water < target - 15) ? 2 : 1;
  if (dark > 700) score += 1;
  if (t < 12 || t > 32) score += 2;
  digitalWrite(GREEN_LED, score == 0);
  digitalWrite(YELLOW_LED, score == 1 || score == 2);
  digitalWrite(RED_LED, score >= 3);
  if (score >= 3 && millis() - lastBuzz > 3000) { lastBuzz = millis(); digitalWrite(BUZZER, HIGH); delay(200); digitalWrite(BUZZER, LOW); }
  if (millis() - lastPrint > 2000) {
    lastPrint = millis();
    Serial.print("water "); Serial.print(water); Serial.print("/"); Serial.print(target);
    Serial.print(" %  dark "); Serial.print(dark); Serial.print("  temp "); Serial.print(t, 1);
    Serial.print(" C  -> "); Serial.println(score == 0 ? "HEALTHY" : (score < 3 ? "needs attention" : "CRITICAL"));
  }
}
