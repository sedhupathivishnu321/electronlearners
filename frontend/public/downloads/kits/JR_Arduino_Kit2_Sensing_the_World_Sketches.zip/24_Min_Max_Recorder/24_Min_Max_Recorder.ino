// ---- Circuit (Kit 2) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
#define BTN1 2
#define LM35_PIN A0

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float lo = 999, hi = -999;
unsigned long lastPrint = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
}

void loop() {
  float t = lm35C();
  if (t < lo) lo = t;
  if (t > hi) hi = t;
  if (pressed()) { lo = t; hi = t; Serial.println("min/max reset"); }
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    Serial.print("now "); Serial.print(t, 1); Serial.print("  min "); Serial.print(lo, 1); Serial.print("  max "); Serial.println(hi, 1);
  }
}
