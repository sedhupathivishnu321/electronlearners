Kit 2 - Sensing the World
Project 24: Min/Max Recorder (Intermediate)

Tracks the lowest and highest temperature since power-up; the button resets them.

Parts:
  Push Button tactile 6x6 x1
  LM35 Temperature Sensor x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-24-minmax
