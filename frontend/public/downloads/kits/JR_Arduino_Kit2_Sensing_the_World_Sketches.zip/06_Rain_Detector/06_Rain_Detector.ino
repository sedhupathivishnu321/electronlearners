// ---- Circuit (Kit 2) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)
#define RED_LED 3
#define RAIN_PIN A0

int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool raining = wetPct() > 25;
  digitalWrite(RED_LED, raining);
  Serial.println(raining ? "RAIN detected" : "dry");
  delay(500);
}
