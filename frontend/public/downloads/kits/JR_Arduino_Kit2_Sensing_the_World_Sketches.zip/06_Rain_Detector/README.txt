Kit 2 - Sensing the World
Project 6: Rain Detector (Basic)

Lights the red LED and prints RAIN when the sensor board gets wet.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Rain Sensor Module x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-06-rain-detector
