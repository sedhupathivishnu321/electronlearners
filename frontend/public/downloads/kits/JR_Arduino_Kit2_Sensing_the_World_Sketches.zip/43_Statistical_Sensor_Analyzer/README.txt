Kit 2 - Sensing the World
Project 43: Statistical Sensor Analyzer (Advanced)

Collects 100 LM35 samples and reports mean, variance, standard deviation and drift; the button re-runs it.

Parts:
  Push Button tactile 6x6 x1
  LM35 Temperature Sensor x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-43-stats
