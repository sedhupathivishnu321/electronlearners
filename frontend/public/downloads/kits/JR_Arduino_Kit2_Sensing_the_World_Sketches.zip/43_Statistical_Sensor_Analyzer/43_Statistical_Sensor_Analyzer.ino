// ---- Circuit (Kit 2) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
#define BTN1 2
#define LM35_PIN A0

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float data[100];

void report() {
  float sum = 0;
  for (int i = 0; i < 100; i++) sum += data[i];
  float mean = sum / 100.0;
  float variance = 0;
  for (int i = 0; i < 100; i++) variance += (data[i] - mean) * (data[i] - mean);
  variance /= 100.0;
  float a = 0, b = 0;
  for (int i = 0; i < 10; i++) { a += data[i]; b += data[90 + i]; }
  Serial.println("---- LM35 report (100 samples) ----");
  Serial.print("mean      "); Serial.print(mean, 2); Serial.println(" C");
  Serial.print("variance  "); Serial.println(variance, 4);
  Serial.print("std dev   "); Serial.print(sqrt(variance), 3); Serial.println(" C");
  Serial.print("drift     "); Serial.print((b - a) / 10.0, 3); Serial.println(" C (last 10 minus first 10)");
}

void collect() {
  Serial.println("collecting 100 samples...");
  for (int i = 0; i < 100; i++) { data[i] = lm35C(); delay(20); }
  report();
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  collect();
  Serial.println("Press the button to run again");
}

void loop() {
  if (pressed()) collect();
}
