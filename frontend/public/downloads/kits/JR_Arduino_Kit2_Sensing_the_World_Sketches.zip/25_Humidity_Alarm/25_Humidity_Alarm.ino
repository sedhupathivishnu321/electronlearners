// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
#define DHT_PIN 8
#define BUZZER 12
#define RED_LED 3
#define POT A0

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  int limit = map(analogRead(POT), 0, 1023, 30, 90);
  float h = dht.readHumidity();
  bool alarm = h > limit;
  digitalWrite(RED_LED, alarm);
  digitalWrite(BUZZER, alarm && (millis() / 500) % 2);
  Serial.print("humidity "); Serial.print(h, 0); Serial.print(" % / limit "); Serial.print(limit);
  Serial.println(alarm ? " %  ALARM" : " %  ok");
  delay(500);
}
