Kit 2 - Sensing the World
Project 25: Humidity Alarm (Intermediate)

Alarm when the humidity goes above the pot-set limit (30-90 %).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Potentiometer 10k (rotary) x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-25-humidity-alarm
