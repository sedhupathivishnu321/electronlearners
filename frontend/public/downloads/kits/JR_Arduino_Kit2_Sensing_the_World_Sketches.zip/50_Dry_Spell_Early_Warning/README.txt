Kit 2 - Sensing the World
Project 50: Dry-Spell Early Warning (Advanced)

Measures how fast the soil is drying and predicts the time until the critical level; warns early.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  Potentiometer 10k (rotary) x1
  Soil Moisture Sensor x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  10k pot: ends to 5V and GND, wiper -> A0
  Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-50-dry-spell
