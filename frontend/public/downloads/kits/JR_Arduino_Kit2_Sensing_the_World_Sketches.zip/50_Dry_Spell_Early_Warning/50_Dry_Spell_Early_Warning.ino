// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 10k pot: ends to 5V and GND, wiper -> A0
// Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)
#define BUZZER 12
#define RED_LED 3
#define GREEN_LED 5
#define BTN1 2
#define POT A0
#define SOIL_PIN A1

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float lastPct = -1;
float rate = 0;                    // percent lost per second (smoothed)
unsigned long last = 0, lastBeep = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Pot = critical level (10-50 %). Button = pretend I watered the plant.");
}

void loop() {
  int critical = map(analogRead(POT), 0, 1023, 10, 50);
  if (pressed()) { rate = 0; Serial.println("watered - drying history cleared"); }
  if (millis() - last >= 1000) {
    last = millis();
    float pct = soilPct();
    if (lastPct >= 0) rate = rate * 0.7 + (lastPct - pct) * 0.3;   // positive = drying
    lastPct = pct;
    float eta = -1;
    if (rate > 0.05 && pct > critical) eta = (pct - critical) / rate;
    bool early = (eta >= 0 && eta < 30) || pct <= critical;
    digitalWrite(GREEN_LED, !early);
    digitalWrite(RED_LED, early);
    if (early && millis() - lastBeep > 4000) { lastBeep = millis(); digitalWrite(BUZZER, HIGH); delay(150); digitalWrite(BUZZER, LOW); }
    Serial.print("moisture "); Serial.print(pct, 0); Serial.print(" %  drying "); Serial.print(rate, 2); Serial.print(" %/s  critical "); Serial.print(critical);
    if (pct <= critical) Serial.println(" %  CRITICAL NOW");
    else if (eta >= 0) { Serial.print(" %  critical in ~"); Serial.print(eta, 0); Serial.println(" s"); }
    else Serial.println(" %  stable");
  }
}
