// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)
#define DHT_PIN 8
#define BUZZER 12
#define RED_LED 3
#define RAIN_PIN A0

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

float hist[6];
int count = 0;
bool warned = false;
unsigned long last = 0;

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  if (millis() - last >= 2000) {
    last = millis();
    for (int i = 5; i > 0; i--) hist[i] = hist[i - 1];
    hist[0] = dht.readHumidity();
    if (count < 6) count++;
    float trend = (count >= 6) ? hist[0] - hist[5] : 0;     // change over the last 10 s
    bool rising = trend >= 5.0;
    bool wet = wetPct() > 20;
    Serial.print("RH "); Serial.print(hist[0], 0); Serial.print(" %  trend "); Serial.print(trend, 1);
    Serial.print(rising ? " (rising)" : " (steady)"); Serial.println(wet ? "  rain: yes" : "  rain: no");
    warned = (rising && wet) || (hist[0] > 85 && wet);
    if (warned) Serial.println("*** STORM WARNING ***");
  }
  digitalWrite(RED_LED, warned);
  digitalWrite(BUZZER, warned && (millis() / 250) % 4 == 0);
}
