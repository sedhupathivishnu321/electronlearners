Kit 2 - Sensing the World
Project 37: Rain and Humidity Storm Predictor (Advanced)

Rising humidity plus rain onset triggers a storm warning with trend analysis.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Rain Sensor Module x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-37-storm-predictor
