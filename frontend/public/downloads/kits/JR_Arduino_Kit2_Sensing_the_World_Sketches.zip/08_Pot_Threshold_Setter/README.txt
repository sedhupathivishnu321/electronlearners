Kit 2 - Sensing the World
Project 8: Pot Threshold Setter (Basic)

Prints the pot as a 0-100 % setting whenever it changes.

Parts:
  Potentiometer 10k (rotary) x1

Circuit notes:
  10k pot: ends to 5V and GND, wiper -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-08-pot-setting
