// ---- Circuit (Kit 2) ----
// 10k pot: ends to 5V and GND, wiper -> A0
#define POT A0

int last = -1;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int pct = map(analogRead(POT), 0, 1023, 0, 100);
  if (pct != last) {
    last = pct;
    Serial.print("threshold = "); Serial.print(pct); Serial.println(" %");
  }
  delay(50);
}
