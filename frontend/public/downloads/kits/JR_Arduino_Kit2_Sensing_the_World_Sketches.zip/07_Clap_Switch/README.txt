Kit 2 - Sensing the World
Project 7: Clap Switch (Basic)

A loud clap toggles the green LED (raise the sound level in the inspector).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Sound Sensor Module x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Sound sensor: VCC 5V, GND, AO -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-07-clap-switch
