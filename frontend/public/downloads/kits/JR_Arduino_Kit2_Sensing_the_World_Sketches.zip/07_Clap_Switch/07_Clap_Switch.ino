// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Sound sensor: VCC 5V, GND, AO -> A0
#define GREEN_LED 5
#define SND_PIN A0

bool lampOn = false;
unsigned long lastClap = 0;

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int v = analogRead(SND_PIN);
  if (v > 600 && millis() - lastClap > 400) {      // loud and not a bounce of the previous clap
    lastClap = millis();
    lampOn = !lampOn;
    digitalWrite(GREEN_LED, lampOn);
    Serial.println(lampOn ? "clap -> lamp ON" : "clap -> lamp OFF");
  }
}
