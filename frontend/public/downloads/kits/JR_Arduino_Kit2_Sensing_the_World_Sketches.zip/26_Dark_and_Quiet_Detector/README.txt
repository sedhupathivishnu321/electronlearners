Kit 2 - Sensing the World
Project 26: Dark and Quiet Detector (Intermediate)

Green when the room is both dark and quiet (bedtime detector).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  LDR Light Sensor Module x1
  Sound Sensor Module x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  Sound sensor: VCC 5V, GND, AO -> A1

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-26-dark-quiet
