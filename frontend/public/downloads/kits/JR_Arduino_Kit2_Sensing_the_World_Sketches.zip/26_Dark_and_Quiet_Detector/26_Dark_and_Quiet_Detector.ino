// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// Sound sensor: VCC 5V, GND, AO -> A1
#define GREEN_LED 5
#define LDR_PIN A0
#define SND_PIN A1

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool dark = analogRead(LDR_PIN) > 650;
  bool quiet = analogRead(SND_PIN) < 400;
  digitalWrite(GREEN_LED, dark && quiet);
  Serial.print(dark ? "dark" : "bright"); Serial.print(" + "); Serial.print(quiet ? "quiet" : "noisy");
  Serial.println(dark && quiet ? "  -> BEDTIME" : "");
  delay(400);
}
