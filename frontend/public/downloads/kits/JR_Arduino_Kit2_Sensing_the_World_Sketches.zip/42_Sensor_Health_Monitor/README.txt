Kit 2 - Sensing the World
Project 42: Sensor Health Monitor (Advanced)

Detects missing or stuck sensors; the red LED blinks a fault code (1 = DHT, 2 = LM35, 3 = soil), green when all is well.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Soil Moisture Sensor x1
  LM35 Temperature Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-42-health-monitor
