// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)
#define DHT_PIN 8
#define RED_LED 3
#define GREEN_LED 5
#define LM35_PIN A0
#define SOIL_PIN A1

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

float lastT = -99;
unsigned long lastChange = 0;
int code = 0;
unsigned long lastCheck = 0;

void blinkCode(int n) {
  for (int i = 0; i < n; i++) { digitalWrite(RED_LED, HIGH); delay(200); digitalWrite(RED_LED, LOW); delay(250); }
  delay(700);
}

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  lastChange = millis();
}

void loop() {
  if (millis() - lastCheck >= 1000) {
    lastCheck = millis();
    code = 0;
    if (isnan(dht.readTemperature()) || isnan(dht.readHumidity())) code = 1;
    float t = lm35C();
    if (t < -5 || t > 140) code = 2;
    if (t != lastT) { lastT = t; lastChange = millis(); }
    int soil = analogRead(SOIL_PIN);
    if (soil > 1018 || soil < 3) code = 3;                 // reading pinned at a rail: probe unplugged or shorted
    Serial.print("health code "); Serial.println(code);
  }
  digitalWrite(GREEN_LED, code == 0);
  if (code != 0) blinkCode(code);
}
