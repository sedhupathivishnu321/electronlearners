Kit 2 - Sensing the World
Project 33: Environmental Data Logger (Advanced)

Time-stamped CSV lines for all sensors; the button marks an event in the log.

Parts:
  Push Button tactile 6x6 x1
  LDR Light Sensor Module x1
  Sound Sensor Module x1
  Soil Moisture Sensor x1
  LM35 Temperature Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
  Soil moisture probe: VCC 5V, GND, AO -> A2 (dry = high reading)
  Sound sensor: VCC 5V, GND, AO -> A3

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-33-data-logger
