// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
// Soil moisture probe: VCC 5V, GND, AO -> A2 (dry = high reading)
// Sound sensor: VCC 5V, GND, AO -> A3
#define DHT_PIN 8
#define BTN1 2
#define LDR_PIN A0
#define LM35_PIN A1
#define SOIL_PIN A2
#define SND_PIN A3

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

unsigned long last = 0;
int events = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  dht.begin();
  Serial.println("ms,dht_c,rh,lm35_c,dark,sound,soil_pct,event");
}

void loop() {
  bool mark = pressed();
  if (mark) events++;
  if (millis() - last >= 1000 || mark) {
    last = millis();
    Serial.print(millis()); Serial.print(",");
    Serial.print(dht.readTemperature(), 1); Serial.print(",");
    Serial.print(dht.readHumidity(), 0); Serial.print(",");
    Serial.print(lm35C(), 1); Serial.print(",");
    Serial.print(analogRead(LDR_PIN)); Serial.print(",");
    Serial.print(analogRead(SND_PIN)); Serial.print(",");
    Serial.print(soilPct()); Serial.print(",");
    Serial.println(mark ? events : 0);
  }
}
