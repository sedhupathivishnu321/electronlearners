Kit 2 - Sensing the World
Project 16: Rain Warning with Intensity (Intermediate)

Light / moderate / heavy rain give 1, 2 or 3 beeps.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  Rain Sensor Module x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-16-rain-intensity
