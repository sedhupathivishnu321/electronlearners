// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)
#define BUZZER 12
#define RED_LED 3
#define GREEN_LED 5
#define RAIN_PIN A0

int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

void beeps(int n) {
  for (int i = 0; i < n; i++) { digitalWrite(BUZZER, HIGH); delay(100); digitalWrite(BUZZER, LOW); delay(150); }
}

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int w = wetPct();
  int level = 0;
  if (w > 70) level = 3; else if (w > 40) level = 2; else if (w > 15) level = 1;
  digitalWrite(GREEN_LED, level == 0);
  digitalWrite(RED_LED, level > 0);
  Serial.print("wetness "); Serial.print(w); Serial.print(" %  ");
  Serial.println(level == 0 ? "no rain" : (level == 1 ? "light rain" : (level == 2 ? "moderate rain" : "HEAVY rain")));
  if (level > 0) beeps(level);
  delay(2000);
}
