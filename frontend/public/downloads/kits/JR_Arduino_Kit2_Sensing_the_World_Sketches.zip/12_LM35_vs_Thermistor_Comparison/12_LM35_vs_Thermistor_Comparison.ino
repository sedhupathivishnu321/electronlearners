// ---- Circuit (Kit 2) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)
#define LM35_PIN A0
#define NTC_PIN A1

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}
float ntcC() {                        // NTC on the 5V side, 10k resistor to GND
  int adc = analogRead(NTC_PIN);
  if (adc < 1) adc = 1;
  float r = 10000.0 * (1023.0 / adc - 1.0);
  float k = 1.0 / (1.0 / 298.15 + log(r / 10000.0) / 3950.0);   // beta equation, B = 3950
  return k - 273.15;
}

void setup() {
  Serial.begin(9600);
}

void loop() {
  float a = lm35C(), b = ntcC();
  Serial.print("LM35 "); Serial.print(a, 1);
  Serial.print(" C | NTC "); Serial.print(b, 1);
  Serial.print(" C | difference "); Serial.print(b - a, 1); Serial.println(" C");
  delay(700);
}
