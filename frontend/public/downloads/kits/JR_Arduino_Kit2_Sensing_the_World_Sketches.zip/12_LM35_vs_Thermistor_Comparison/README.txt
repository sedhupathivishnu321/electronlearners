Kit 2 - Sensing the World
Project 12: LM35 vs Thermistor Comparison (Intermediate)

Both sensors side by side with their difference.

Parts:
  Thermistor NTC 10k x1
  Resistor 10k ohm 1/4W x1
  LM35 Temperature Sensor x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-12-lm35-vs-ntc
