// ---- Circuit (Kit 2) ----
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Soil moisture probe: VCC 5V, GND, AO -> A0 (dry = high reading)
// Rain sensor: VCC 5V, GND, AO -> A1 (dry = high reading)
#define BTN1 2
#define GREEN_LED 5
#define RED_LED 3
#define SOIL_PIN A0
#define RAIN_PIN A1

#include <EEPROM.h>
int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int stepNo = 0;
int vals[4];                      // soil dry, soil wet, rain dry, rain wet

void save(int idx, int v) { EEPROM.write(idx * 2, v / 256); EEPROM.write(idx * 2 + 1, v % 256); }

void prompt() {
  if (stepNo == 0) Serial.println("Step 1/4: keep the SOIL probe DRY, press the button");
  else if (stepNo == 1) Serial.println("Step 2/4: put the SOIL probe in WET soil, press the button");
  else if (stepNo == 2) Serial.println("Step 3/4: keep the RAIN board DRY, press the button");
  else if (stepNo == 3) Serial.println("Step 4/4: make the RAIN board WET, press the button");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("=== Sensor calibration wizard ===");
  prompt();
}

void loop() {
  digitalWrite(RED_LED, stepNo < 4);
  digitalWrite(GREEN_LED, stepNo >= 4);
  if (stepNo < 4 && pressed()) {
    int v = (stepNo < 2) ? analogRead(SOIL_PIN) : analogRead(RAIN_PIN);
    vals[stepNo] = v;
    save(stepNo, v);
    Serial.print("  recorded "); Serial.println(v);
    stepNo++;
    if (stepNo < 4) prompt();
    else {
      Serial.println("=== Calibration saved to EEPROM ===");
      Serial.print("soil: dry "); Serial.print(vals[0]); Serial.print(", wet "); Serial.println(vals[1]);
      Serial.print("rain: dry "); Serial.print(vals[2]); Serial.print(", wet "); Serial.println(vals[3]);
    }
  }
}
