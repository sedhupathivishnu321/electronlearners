Kit 2 - Sensing the World
Project 44: Wet-Dry Calibration Wizard (Advanced)

Guided wizard calibrates soil and rain sensors (dry then wet), saves them in EEPROM and prints a summary.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Soil Moisture Sensor x1
  Rain Sensor Module x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Soil moisture probe: VCC 5V, GND, AO -> A0 (dry = high reading)
  Rain sensor: VCC 5V, GND, AO -> A1 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-44-wizard
