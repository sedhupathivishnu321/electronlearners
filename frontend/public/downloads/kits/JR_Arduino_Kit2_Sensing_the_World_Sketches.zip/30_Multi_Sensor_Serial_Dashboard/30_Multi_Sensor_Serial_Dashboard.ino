// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
// Sound sensor: VCC 5V, GND, AO -> A2
#define DHT_PIN 8
#define LDR_PIN A0
#define LM35_PIN A1
#define SND_PIN A2

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

void setup() {
  Serial.begin(9600);
  dht.begin();
  Serial.println("time_s | dhtT | RH | lm35 | dark | sound");
}

void loop() {
  Serial.print(millis() / 1000); Serial.print(" | ");
  Serial.print(dht.readTemperature(), 1); Serial.print(" | ");
  Serial.print(dht.readHumidity(), 0); Serial.print(" | ");
  Serial.print(lm35C(), 1); Serial.print(" | ");
  Serial.print(analogRead(LDR_PIN)); Serial.print(" | ");
  Serial.println(analogRead(SND_PIN));
  delay(1000);
}
