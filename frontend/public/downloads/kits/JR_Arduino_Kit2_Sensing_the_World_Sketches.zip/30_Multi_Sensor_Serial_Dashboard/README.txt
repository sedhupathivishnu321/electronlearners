Kit 2 - Sensing the World
Project 30: Multi-Sensor Serial Dashboard (Intermediate)

One tidy line with temperature, humidity, light and sound for logging.

Parts:
  LDR Light Sensor Module x1
  Sound Sensor Module x1
  LM35 Temperature Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
  Sound sensor: VCC 5V, GND, AO -> A2

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-30-dashboard
