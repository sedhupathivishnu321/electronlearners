// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define DHT_PIN 8
#define BTN1 2

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  dht.begin();
  Serial.println("Press the button for a reading");
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    Serial.print("T = "); Serial.print(dht.readTemperature(), 1);
    Serial.print(" C, RH = "); Serial.print(dht.readHumidity(), 0); Serial.println(" %");
    while (digitalRead(BTN1) == LOW) { }
    delay(50);
  }
}
