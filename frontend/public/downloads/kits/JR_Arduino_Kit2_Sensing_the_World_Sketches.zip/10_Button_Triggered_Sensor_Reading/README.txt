Kit 2 - Sensing the World
Project 10: Button-Triggered Sensor Reading (Basic)

Press the button to take a one-shot DHT11 reading.

Parts:
  Push Button tactile 6x6 x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-10-button-dht
