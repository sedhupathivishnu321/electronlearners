Kit 2 - Sensing the World
Project 13: Heat Index Calculator (Intermediate)

Combines temperature and humidity into a "feels like" heat index.

Parts:
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-13-heat-index
