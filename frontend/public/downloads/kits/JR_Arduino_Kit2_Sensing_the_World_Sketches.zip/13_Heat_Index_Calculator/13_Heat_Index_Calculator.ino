// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
#define DHT_PIN 8

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  float hi = dht.computeHeatIndex(t, h, false);
  Serial.print("Temp "); Serial.print(t, 1); Serial.print(" C, RH "); Serial.print(h, 0);
  Serial.print(" %, feels like "); Serial.print(hi, 1); Serial.println(" C");
  delay(2000);
}
