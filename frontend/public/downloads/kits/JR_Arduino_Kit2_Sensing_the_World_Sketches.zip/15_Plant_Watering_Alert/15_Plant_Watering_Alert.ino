// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)
#define BUZZER 12
#define RED_LED 3
#define POT A0
#define SOIL_PIN A1

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }

unsigned long lastBeep = 0;

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int limit = map(analogRead(POT), 0, 1023, 10, 80);
  int m = soilPct();
  bool thirsty = m < limit;
  digitalWrite(RED_LED, thirsty);
  if (thirsty && millis() - lastBeep > 2000) {
    lastBeep = millis();
    digitalWrite(BUZZER, HIGH); delay(120); digitalWrite(BUZZER, LOW);
  }
  Serial.print("moisture "); Serial.print(m); Serial.print(" % / limit "); Serial.print(limit); Serial.println(thirsty ? " %  WATER ME" : " %  ok");
  delay(300);
}
