Kit 2 - Sensing the World
Project 15: Plant Watering Alert (Intermediate)

Red LED and beeps when moisture falls below the pot-set threshold.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Potentiometer 10k (rotary) x1
  Soil Moisture Sensor x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  Soil moisture probe: VCC 5V, GND, AO -> A1 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-15-plant-alert
