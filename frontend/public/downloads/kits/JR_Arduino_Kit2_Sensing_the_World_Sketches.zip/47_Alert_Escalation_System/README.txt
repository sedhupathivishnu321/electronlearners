Kit 2 - Sensing the World
Project 47: Alert Escalation System (Advanced)

Warning (yellow) -> alarm (red) -> critical (red + fast buzzer) from temperature, noise and light.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  Buzzer Active 5V x1
  LDR Light Sensor Module x1
  Sound Sensor Module x1
  LM35 Temperature Sensor x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
  LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
  Sound sensor: VCC 5V, GND, AO -> A2

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-47-escalation
