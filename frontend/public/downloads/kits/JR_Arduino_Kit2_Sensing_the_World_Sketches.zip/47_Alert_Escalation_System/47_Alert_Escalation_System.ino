// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// LDR module: VCC 5V, GND, AO -> A0 (bright = low reading)
// LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
// Sound sensor: VCC 5V, GND, AO -> A2
#define BUZZER 12
#define GREEN_LED 5
#define YELLOW_LED 6
#define RED_LED 3
#define LDR_PIN A0
#define LM35_PIN A1
#define SND_PIN A2

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

int level = 0;
unsigned long lastPrint = 0;

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float t = lm35C();
  int noise = analogRead(SND_PIN);
  int dark = analogRead(LDR_PIN);
  int points = 0;
  if (t > 30) points++;
  if (t > 40) points += 2;
  if (noise > 500) points++;
  if (noise > 800) points += 2;
  if (dark < 150) points++;                                // blinding light
  level = (points >= 4) ? 3 : (points >= 2 ? 2 : (points >= 1 ? 1 : 0));
  digitalWrite(GREEN_LED, level == 0);
  digitalWrite(YELLOW_LED, level == 1);
  digitalWrite(RED_LED, level >= 2);
  if (level == 2) digitalWrite(BUZZER, (millis() / 800) % 2);
  else if (level == 3) digitalWrite(BUZZER, (millis() / 150) % 2);
  else digitalWrite(BUZZER, LOW);
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    Serial.print("T "); Serial.print(t, 1); Serial.print(" C  noise "); Serial.print(noise); Serial.print("  dark "); Serial.print(dark);
    Serial.print("  -> "); Serial.println(level == 0 ? "NORMAL" : (level == 1 ? "WARNING" : (level == 2 ? "ALARM" : "CRITICAL")));
  }
}
