Kit 2 - Sensing the World
Project 46: Dual-Sensor Fusion Thermometer (Advanced)

Weighted fusion of DHT11 and LM35 with outlier rejection.

Parts:
  LM35 Temperature Sensor x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-46-fusion
