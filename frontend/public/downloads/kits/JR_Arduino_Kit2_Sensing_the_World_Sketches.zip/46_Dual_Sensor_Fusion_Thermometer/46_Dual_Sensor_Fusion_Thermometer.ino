// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
#define DHT_PIN 8
#define LM35_PIN A0

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

float fused = 0;
bool first = true;

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float a = dht.readTemperature();       // +/-2 C, whole degrees
  float b = lm35C();                     // +/-0.5 C
  float t;
  if (isnan(a)) t = b;                   // DHT failed: use the LM35 alone
  else if (abs(a - b) > 3.0) t = b;      // disagree a lot: trust the more accurate LM35
  else t = 0.3 * a + 0.7 * b;            // otherwise weight by accuracy
  if (first) { fused = t; first = false; }
  fused = fused * 0.8 + t * 0.2;         // smooth
  Serial.print("DHT "); Serial.print(a, 1); Serial.print("  LM35 "); Serial.print(b, 1);
  Serial.print("  fused "); Serial.println(fused, 2);
  delay(1000);
}
