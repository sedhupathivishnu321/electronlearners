// ---- Circuit (Kit 2) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// LDR module: VCC 5V, GND, AO -> A1 (bright = low reading)
#define RED_LED 3
#define POT A0
#define LDR_PIN A1

bool lampOn = false;

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int dark = analogRead(LDR_PIN);
  int level = analogRead(POT);
  if (!lampOn && dark > level + 30) lampOn = true;
  if (lampOn && dark < level - 30) lampOn = false;
  digitalWrite(RED_LED, lampOn);
  Serial.print("dark "); Serial.print(dark); Serial.print(" / level "); Serial.print(level);
  Serial.println(lampOn ? "  LAMP ON" : "  lamp off");
  delay(250);
}
