Kit 2 - Sensing the World
Project 17: Auto Street Light (Intermediate)

The street lamp (red LED) switches on in the dark; the pot sets the level, hysteresis stops flicker.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Potentiometer 10k (rotary) x1
  LDR Light Sensor Module x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  LDR module: VCC 5V, GND, AO -> A1 (bright = low reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-17-street-light
