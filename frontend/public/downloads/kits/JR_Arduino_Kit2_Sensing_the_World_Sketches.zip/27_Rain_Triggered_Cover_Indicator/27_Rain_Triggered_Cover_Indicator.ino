// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)
#define GREEN_LED 5
#define RED_LED 3
#define RAIN_PIN A0

int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

bool closed = false;
unsigned long since = 0;

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  digitalWrite(RED_LED, HIGH);
  since = millis();
}

void loop() {
  bool wet = wetPct() > 25;
  if (wet != closed) {                                  // the sensor disagrees with the cover state
    unsigned long need = wet ? 3000 : 10000;
    if (millis() - since > need) {
      closed = wet;
      digitalWrite(GREEN_LED, closed);
      digitalWrite(RED_LED, !closed);
      Serial.println(closed ? "Rain persisted: COVER CLOSED" : "Dry again: COVER OPEN");
    }
  } else {
    since = millis();
  }
}
