Kit 2 - Sensing the World
Project 27: Rain-Triggered Cover Indicator (Intermediate)

Cover closes (green) after 3 s of rain and reopens (red) after 10 s dry.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Rain Sensor Module x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Rain sensor: VCC 5V, GND, AO -> A0 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-27-rain-cover
