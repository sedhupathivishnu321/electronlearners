// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)
#define BUZZER 12
#define RED_LED 3
#define POT A0
#define LM35_PIN A1

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float sum = 0;
  for (int i = 0; i < 10; i++) { sum += lm35C(); delay(10); }
  float t = sum / 10.0;
  float limit = 35.0 + analogRead(POT) * 7.0 / 1023.0;
  bool fever = t > limit;
  digitalWrite(RED_LED, fever);
  digitalWrite(BUZZER, fever && (millis() / 400) % 2);
  Serial.print("body "); Serial.print(t, 1); Serial.print(" C  limit "); Serial.print(limit, 1);
  Serial.println(fever ? "  FEVER" : "  normal");
  delay(200);
}
