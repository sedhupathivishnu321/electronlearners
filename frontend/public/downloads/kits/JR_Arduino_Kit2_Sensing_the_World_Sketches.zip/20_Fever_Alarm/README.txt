Kit 2 - Sensing the World
Project 20: Fever Alarm (Intermediate)

Average of 10 LM35 samples against a pot-set limit (35-42 C).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Potentiometer 10k (rotary) x1
  LM35 Temperature Sensor x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  LM35: VCC 5V, GND, OUT -> A1 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-20-fever-alarm
