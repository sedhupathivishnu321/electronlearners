// ---- Circuit (Kit 2) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// Blue LED anode -> 220 ohm -> D4, cathode -> GND
// Active buzzer + -> D12, - -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// Sound sensor: VCC 5V, GND, AO -> A1
#define RED_LED 3
#define GREEN_LED 5
#define YELLOW_LED 6
#define BLUE_LED 4
#define BUZZER 12
#define POT A0
#define SND_PIN A1

unsigned long lastBeat = 0;

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT); pinMode(BLUE_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int sens = map(analogRead(POT), 0, 1023, 300, 800);      // lower = more sensitive
  int v = analogRead(SND_PIN);
  int level = 0;
  if (v > sens * 0.5) level = 1;
  if (v > sens * 0.7) level = 2;
  if (v > sens * 0.9) level = 3;
  if (v > sens * 1.1) level = 4;
  digitalWrite(BLUE_LED, level >= 1);
  digitalWrite(GREEN_LED, level >= 2);
  digitalWrite(YELLOW_LED, level >= 3);
  digitalWrite(RED_LED, level >= 4);
  if (level == 4 && millis() - lastBeat > 300) { lastBeat = millis(); digitalWrite(BUZZER, HIGH); delay(40); digitalWrite(BUZZER, LOW); }
  Serial.print("sound "); Serial.print(v); Serial.print("  sensitivity "); Serial.print(sens); Serial.print("  level "); Serial.println(level);
  delay(60);
}
