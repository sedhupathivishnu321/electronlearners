Kit 2 - Sensing the World
Project 40: Sound-Reactive Light Show (Advanced)

Four LEDs climb with the sound level; pot = sensitivity; the buzzer beats on very loud peaks.

Parts:
  Resistor 220 ohm 1/4W x4
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  LED 5mm Blue x1
  Buzzer Active 5V x1
  Potentiometer 10k (rotary) x1
  Sound Sensor Module x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  Blue LED anode -> 220 ohm -> D4, cathode -> GND
  Active buzzer + -> D12, - -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  Sound sensor: VCC 5V, GND, AO -> A1

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-40-sound-show
