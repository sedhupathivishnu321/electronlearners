Kit 2 - Sensing the World
Project 49: Smart Humidity-Rain Dehumidifier Logic (Advanced)

State machine with minimum on/off times; green = dehumidifier on. Pot sets the target humidity; rain raises the demand.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Potentiometer 10k (rotary) x1
  Rain Sensor Module x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  Rain sensor: VCC 5V, GND, AO -> A1 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-49-dehumidifier
