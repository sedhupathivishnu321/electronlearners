// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// Rain sensor: VCC 5V, GND, AO -> A1 (dry = high reading)
#define DHT_PIN 8
#define RED_LED 3
#define GREEN_LED 5
#define POT A0
#define RAIN_PIN A1

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }

bool on = false;
unsigned long changedAt = 0;
unsigned long lastPrint = 0;

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  changedAt = millis() - 6000;
}

void loop() {
  float target = 40.0 + analogRead(POT) * 30.0 / 1023.0;      // 40 .. 70 %
  if (wetPct() > 20) target -= 8.0;                            // rain: aim lower, the air will be damp
  float h = dht.readHumidity();
  bool wantOn = on ? (h > target - 3.0) : (h > target + 3.0);  // 3 % hysteresis band
  bool canSwitch = millis() - changedAt > 5000;                // protect the compressor: 5 s minimum
  if (wantOn != on && canSwitch) {
    on = wantOn; changedAt = millis();
    Serial.println(on ? "dehumidifier ON" : "dehumidifier OFF");
  }
  digitalWrite(GREEN_LED, on);
  digitalWrite(RED_LED, wantOn != on);                        // waiting for the minimum time
  if (millis() - lastPrint > 1500) {
    lastPrint = millis();
    Serial.print("RH "); Serial.print(h, 0); Serial.print(" %  target "); Serial.print(target, 0); Serial.println(on ? " %  [ON]" : " %  [off]");
  }
}
