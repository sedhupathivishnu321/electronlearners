Kit 2 - Sensing the World
Project 9: Over-Temperature Buzzer (Basic)

The buzzer sounds when the LM35 reads more than 35 C.

Parts:
  Buzzer Active 5V x1
  LM35 Temperature Sensor x1

Circuit notes:
  Active buzzer + -> D12, - -> GND
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-09-overtemp
