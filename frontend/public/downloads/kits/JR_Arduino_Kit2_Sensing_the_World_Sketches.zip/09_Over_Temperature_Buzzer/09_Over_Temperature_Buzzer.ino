// ---- Circuit (Kit 2) ----
// Active buzzer + -> D12, - -> GND
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
#define BUZZER 12
#define LM35_PIN A0

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

void setup() {
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float t = lm35C();
  digitalWrite(BUZZER, t > 35.0);
  Serial.print(t, 1);
  Serial.println(t > 35.0 ? " C  TOO HOT!" : " C");
  delay(300);
}
