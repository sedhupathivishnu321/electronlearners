Kit 2 - Sensing the World
Project 3: Thermistor Raw Reading (Basic)

Reads the NTC in a voltage divider and prints the ADC value and resistance.

Parts:
  Thermistor NTC 10k x1
  Resistor 10k ohm 1/4W x1

Circuit notes:
  NTC 10k thermistor + 10k resistor divider (5V - NTC - A0 - 10k - GND)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-03-ntc-raw
