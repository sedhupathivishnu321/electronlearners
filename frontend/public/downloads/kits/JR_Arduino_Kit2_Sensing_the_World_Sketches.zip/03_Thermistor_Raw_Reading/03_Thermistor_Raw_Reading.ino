// ---- Circuit (Kit 2) ----
// NTC 10k thermistor + 10k resistor divider (5V - NTC - A0 - 10k - GND)
#define NTC_PIN A0

void setup() {
  Serial.begin(9600);
}

void loop() {
  int adc = analogRead(NTC_PIN);
  if (adc < 1) adc = 1;
  float r = 10000.0 * (1023.0 / adc - 1.0);
  Serial.print("ADC = "); Serial.print(adc);
  Serial.print("   NTC resistance = "); Serial.print(r, 0); Serial.println(" ohm");
  delay(500);
}
