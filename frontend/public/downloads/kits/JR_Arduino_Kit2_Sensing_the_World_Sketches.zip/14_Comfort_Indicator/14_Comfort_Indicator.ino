// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Yellow LED anode -> 220 ohm -> D6, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define DHT_PIN 8
#define GREEN_LED 5
#define YELLOW_LED 6
#define RED_LED 3

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(YELLOW_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  int level;                                              // 0 good, 1 borderline, 2 bad
  if (t >= 20 && t <= 26 && h >= 30 && h <= 60) level = 0;
  else if (t >= 17 && t <= 30 && h >= 20 && h <= 75) level = 1;
  else level = 2;
  digitalWrite(GREEN_LED, level == 0);
  digitalWrite(YELLOW_LED, level == 1);
  digitalWrite(RED_LED, level == 2);
  Serial.print(t, 1); Serial.print(" C  "); Serial.print(h, 0); Serial.print(" %  -> ");
  Serial.println(level == 0 ? "comfortable" : (level == 1 ? "borderline" : "uncomfortable"));
  delay(1000);
}
