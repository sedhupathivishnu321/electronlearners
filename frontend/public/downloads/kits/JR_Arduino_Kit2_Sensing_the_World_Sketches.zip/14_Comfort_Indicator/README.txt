Kit 2 - Sensing the World
Project 14: Comfort Indicator (Intermediate)

Green = comfortable, yellow = borderline, red = uncomfortable (temperature and humidity).

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  LED 5mm Yellow x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Yellow LED anode -> 220 ohm -> D6, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-14-comfort
