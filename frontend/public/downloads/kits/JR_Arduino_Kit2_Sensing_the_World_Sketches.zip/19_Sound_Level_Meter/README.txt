Kit 2 - Sensing the World
Project 19: Sound Level Meter (Intermediate)

Peak level over a 50 ms window as 0-100, with a text bar and LEDs.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Sound Sensor Module x1

Circuit notes:
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Sound sensor: VCC 5V, GND, AO -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-19-sound-meter
