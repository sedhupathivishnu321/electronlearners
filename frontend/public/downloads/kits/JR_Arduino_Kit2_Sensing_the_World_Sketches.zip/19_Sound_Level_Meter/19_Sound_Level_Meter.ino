// ---- Circuit (Kit 2) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Sound sensor: VCC 5V, GND, AO -> A0
#define RED_LED 3
#define GREEN_LED 5
#define SND_PIN A0

void setup() {
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int lo = 1023, hi = 0;
  unsigned long t0 = millis();
  while (millis() - t0 < 50) {
    int v = analogRead(SND_PIN);
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  int level = constrain(map(hi, 100, 920, 0, 100), 0, 100);
  digitalWrite(GREEN_LED, level > 30);
  digitalWrite(RED_LED, level > 70);
  Serial.print("[");
  for (int i = 0; i < 10; i++) Serial.print(i < level / 10 ? "#" : ".");
  Serial.print("] "); Serial.println(level);
  delay(200);
}
