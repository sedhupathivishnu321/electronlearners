// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 10k pot: ends to 5V and GND, wiper -> A0
// NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)
#define GREEN_LED 5
#define RED_LED 3
#define POT A0
#define NTC_PIN A1

float ntcC() {                        // NTC on the 5V side, 10k resistor to GND
  int adc = analogRead(NTC_PIN);
  if (adc < 1) adc = 1;
  float r = 10000.0 * (1023.0 / adc - 1.0);
  float k = 1.0 / (1.0 / 298.15 + log(r / 10000.0) / 3950.0);   // beta equation, B = 3950
  return k - 273.15;
}

bool fanOn = false;

void setup() {
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float limit = 20.0 + analogRead(POT) * 20.0 / 1023.0;
  float t = ntcC();
  if (!fanOn && t > limit + 1.0) fanOn = true;
  if (fanOn && t < limit - 1.0) fanOn = false;
  digitalWrite(GREEN_LED, fanOn);
  digitalWrite(RED_LED, !fanOn);
  Serial.print("temp "); Serial.print(t, 1); Serial.print(" C  target "); Serial.print(limit, 1);
  Serial.println(fanOn ? " C  FAN ON" : " C  fan off");
  delay(500);
}
