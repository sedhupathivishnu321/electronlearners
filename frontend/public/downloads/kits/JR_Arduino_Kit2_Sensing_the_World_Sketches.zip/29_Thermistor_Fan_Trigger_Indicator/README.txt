Kit 2 - Sensing the World
Project 29: Thermistor Fan-Trigger Indicator (Intermediate)

Pot sets the target (20-40 C); green = fan on, red = fan off, with 1 C hysteresis.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Potentiometer 10k (rotary) x1
  Thermistor NTC 10k x1
  Resistor 10k ohm 1/4W x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  10k pot: ends to 5V and GND, wiper -> A0
  NTC 10k thermistor + 10k resistor divider (5V - NTC - A1 - 10k - GND)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-29-ntc-fan
