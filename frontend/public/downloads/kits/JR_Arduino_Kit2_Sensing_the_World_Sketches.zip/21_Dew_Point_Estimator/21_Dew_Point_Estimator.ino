// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define DHT_PIN 8
#define RED_LED 3

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

float dewPoint(float t, float rh) {
  float a = 17.62, b = 243.12;
  float g = log(rh / 100.0) + (a * t) / (b + t);
  return (b * g) / (a - g);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  float dp = dewPoint(t, h);
  bool risk = (t - dp) < 2.5;
  digitalWrite(RED_LED, risk);
  Serial.print("T "); Serial.print(t, 1); Serial.print(" C  RH "); Serial.print(h, 0);
  Serial.print(" %  dew point "); Serial.print(dp, 1); Serial.println(risk ? " C  CONDENSATION RISK" : " C");
  delay(2000);
}
