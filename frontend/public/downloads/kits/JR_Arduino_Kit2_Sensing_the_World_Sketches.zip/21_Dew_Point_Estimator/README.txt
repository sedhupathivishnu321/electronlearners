Kit 2 - Sensing the World
Project 21: Dew Point Estimator (Intermediate)

Dew point with the Magnus formula; red LED when condensation is likely.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-21-dew-point
