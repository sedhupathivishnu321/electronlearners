Kit 2 - Sensing the World
Project 36: Clap-Pattern Door Knock Code (Advanced)

Secret knock: clap, short pause, clap, long pause, clap. Right pattern lights green, wrong sounds the buzzer.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  Sound Sensor Module x1

Circuit notes:
  Green LED anode -> 220 ohm -> D5, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Active buzzer + -> D12, - -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Sound sensor: VCC 5V, GND, AO -> A0

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-36-clap-code
