// ---- Circuit (Kit 2) ----
// Green LED anode -> 220 ohm -> D5, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Active buzzer + -> D12, - -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Sound sensor: VCC 5V, GND, AO -> A0
#define GREEN_LED 5
#define RED_LED 3
#define BUZZER 12
#define BTN1 2
#define SND_PIN A0

int lastBtn = HIGH;
bool pressed() {
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

unsigned long times[3];
int n = 0;
unsigned long lastClap = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  Serial.println("Secret knock: clap - short gap - clap - LONG gap - clap");
}

void verdict() {
  unsigned long g1 = times[1] - times[0], g2 = times[2] - times[1];
  Serial.print("gaps "); Serial.print(g1); Serial.print(" ms, "); Serial.print(g2); Serial.println(" ms");
  if (g1 < 700 && g2 >= 900) {
    Serial.println("CORRECT - door open");
    digitalWrite(GREEN_LED, HIGH); delay(2500); digitalWrite(GREEN_LED, LOW);
  } else {
    Serial.println("WRONG knock");
    digitalWrite(RED_LED, HIGH); digitalWrite(BUZZER, HIGH); delay(700);
    digitalWrite(RED_LED, LOW); digitalWrite(BUZZER, LOW);
  }
  n = 0;
}

void loop() {
  int v = analogRead(SND_PIN);
  if (v > 600 && millis() - lastClap > 200) {
    lastClap = millis();
    times[n++] = millis();
    Serial.println("clap");
    if (n == 3) verdict();
  }
  if (n > 0 && millis() - lastClap > 3000) { n = 0; Serial.println("timeout - start again"); }
  if (pressed()) { n = 0; Serial.println("cleared"); }
}
