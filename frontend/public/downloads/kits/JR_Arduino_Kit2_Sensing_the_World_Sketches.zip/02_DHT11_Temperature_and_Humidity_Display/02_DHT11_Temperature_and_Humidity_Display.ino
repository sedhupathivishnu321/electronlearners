// ---- Circuit (Kit 2) ----
// DHT11: VCC 5V, GND, DATA -> D8
#define DHT_PIN 8

#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (isnan(t) || isnan(h)) {
    Serial.println("DHT read failed - check wiring");
  } else {
    Serial.print("Temperature: "); Serial.print(t, 1); Serial.print(" C   Humidity: "); Serial.print(h, 0); Serial.println(" %");
  }
  delay(2000);
}
