Kit 2 - Sensing the World
Project 2: DHT11 Temperature and Humidity Display (Basic)

Reads temperature and humidity with the DHT library every 2 s.

Parts:
  DHT11 Temp & Humidity x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-02-dht11
