Kit 2 - Sensing the World
Project 1: Room Temperature Reader (LM35) (Basic)

Converts the LM35 voltage to degrees Celsius. Change the temperature in the inspector.

Parts:
  LM35 Temperature Sensor x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k2-01-lm35
