// ---- Circuit (Kit 2) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
#define LM35_PIN A0

float lm35C() {                       // 10 mV per degree C, 5 V reference, 10-bit ADC
  return analogRead(LM35_PIN) * 500.0 / 1023.0;
}

void setup() {
  Serial.begin(9600);
}

void loop() {
  float volts = analogRead(LM35_PIN) * 5.0 / 1023.0;
  Serial.print("LM35 = ");
  Serial.print(volts, 3);
  Serial.print(" V  ->  ");
  Serial.print(lm35C(), 1);
  Serial.println(" C");
  delay(500);
}
