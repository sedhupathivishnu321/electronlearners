Kit 8 - Smart Systems Capstone
Project 18: Step/Motion Counter (Intermediate)

Counts a step every time the total acceleration jumps above 1.3 g (a peak). Raise AZ to 1.6 g and back to simulate a step.

Parts:
  MPU6050 IMU x1
  16x2 LCD I2C x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-18-step-counter
