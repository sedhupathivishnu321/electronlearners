// ---- Circuit (Kit 8) ----
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

void setup() {
  oledBegin();
  oled.drawRect(0, 0, 128, 64, SSD1306_WHITE);
  oled.setTextSize(2);
  oled.setCursor(10, 8);
  oled.println("Hello!");
  oled.setTextSize(1);
  oled.setCursor(10, 32);
  oled.println("JR Learners Kit 8");
  oled.setCursor(10, 44);
  oled.println("Smart Systems");
  oled.display();
}

void loop() {
}
