Kit 8 - Smart Systems Capstone
Project 10: OLED Hello (Basic)

Shows a greeting in two text sizes and draws a frame on the 128x64 OLED.

Parts:
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-10-oled-hello
