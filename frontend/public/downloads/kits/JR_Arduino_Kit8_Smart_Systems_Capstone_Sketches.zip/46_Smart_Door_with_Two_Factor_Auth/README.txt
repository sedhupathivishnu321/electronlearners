Kit 8 - Smart Systems Capstone
Project 46: Smart Door with Two-Factor Auth (Advanced)

Factor 1: the owner card. Factor 2: a 3-press PIN on the button - short, LONG, short. Both correct opens the servo and relay; every attempt is logged with the RTC time.

Parts:
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  RTC DS3231 x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-46-two-factor-door
