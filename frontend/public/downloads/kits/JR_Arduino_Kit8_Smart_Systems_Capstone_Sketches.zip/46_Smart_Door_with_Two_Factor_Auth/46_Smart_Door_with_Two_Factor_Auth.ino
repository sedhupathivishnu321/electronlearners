// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
#define RFID_SS 10
#define RFID_RST 9
#define BTN1 4
#define SERVO_PIN 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 7

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int btnEvent() {                           // 0 = nothing, 1 = short press, 2 = long press (held for 0.8 s)
  if (digitalRead(BTN1) == HIGH) return 0;
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == LOW) {
    delay(5);
    if (millis() - t0 > 800) { while (digitalRead(BTN1) == LOW) delay(5); return 2; }
  }
  return 1;
}
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String OWNER = "DE AD BE EF";
String PIN = "SLS";                        // S = short press, L = long press (hold 1 s)
#define PIN_TIMEOUT_MS 10000
bool waitingPin = false;
String entered = "";
unsigned long pinStart = 0;

void logLine(String what) {
  Serial.println(clockText(rtc.now()) + "  " + cardUid + "  " + what);
}
void deny(String why) {
  waitingPin = false;
  lcdRow(0, "ACCESS DENIED");
  lcdRow(1, why);
  logLine("DENIED " + why);
  beeps(3);
  delay(1000);
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  rtc.begin();
  lcdBegin();
  rfidBegin();
}

void loop() {
  if (!waitingPin) {
    lcdRow(0, "Door locked");
    lcdRow(1, "1) show card");
    if (readCard()) {
      if (cardUid == OWNER) { waitingPin = true; entered = ""; pinStart = millis(); beep(60); }
      else deny("unknown card");
    }
  } else {
    lcdRow(0, "2) enter PIN");
    lcdRow(1, "presses: " + String(entered.length()) + "/" + String(PIN.length()));
    int e = btnEvent();
    if (e == 1) { entered += "S"; beep(30); }
    if (e == 2) { entered += "L"; beep(30); }
    if (entered.length() >= PIN.length()) {
      if (entered == PIN) {
        waitingPin = false;
        lcdRow(0, "WELCOME");
        lcdRow(1, clockText(rtc.now()));
        logLine("OPEN");
        servo.write(OPEN_ANGLE);
        digitalWrite(RELAY_PIN, RELAY_ON);
        beep(200);
        delay(3000);
        servo.write(LOCKED_ANGLE);
        digitalWrite(RELAY_PIN, RELAY_OFF);
      } else deny("wrong PIN");
    } else if (millis() - pinStart > PIN_TIMEOUT_MS) deny("PIN timeout");
  }
  delay(20);
}
