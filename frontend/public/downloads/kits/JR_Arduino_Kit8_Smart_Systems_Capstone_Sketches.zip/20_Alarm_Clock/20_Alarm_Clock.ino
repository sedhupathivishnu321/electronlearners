// ---- Circuit (Kit 8) ----
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define BUZZER 7
#define BTN1 4

#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define ALARM_AFTER_S 20      // demo: alarm 20 s after start-up. On real hardware use rtc.adjust() and a fixed time.
#define SNOOZE_S 15
unsigned long alarmAt = 0;
bool ringing = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  rtc.begin();
  lcdBegin();
  alarmAt = rtc.now().unixtime() + ALARM_AFTER_S;
}

void loop() {
  DateTime now = rtc.now();
  if (!ringing && now.unixtime() >= alarmAt) ringing = true;
  if (ringing) {
    digitalWrite(BUZZER, (millis() / 250) % 2 == 0 ? HIGH : LOW);     // beep-beep
    if (pressed()) {
      ringing = false;
      digitalWrite(BUZZER, LOW);
      alarmAt = now.unixtime() + SNOOZE_S;
    }
  }
  lcdRow(0, "Time  " + clockText(now));
  lcdRow(1, ringing ? "WAKE UP! snooze?" : "Alarm " + clockText(DateTime(alarmAt)));
  delay(50);
}
