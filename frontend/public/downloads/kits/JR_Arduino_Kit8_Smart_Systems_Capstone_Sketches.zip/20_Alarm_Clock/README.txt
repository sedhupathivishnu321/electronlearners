Kit 8 - Smart Systems Capstone
Project 20: Alarm Clock (Intermediate)

The alarm is armed for 20 s after power-up so you can see it ring. Press the button to snooze it for 15 s.

Parts:
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  RTC DS3231 x1
  16x2 LCD I2C x1

Circuit notes:
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-20-alarm-clock
