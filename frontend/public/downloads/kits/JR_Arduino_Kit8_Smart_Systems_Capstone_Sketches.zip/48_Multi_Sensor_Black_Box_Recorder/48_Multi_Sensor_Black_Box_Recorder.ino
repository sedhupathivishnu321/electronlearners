// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define LOAD_PIN 8
#define BTN1 4

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <MAX30105.h>
#include <heartRate.h>
MAX30105 pulse;
void pulseBegin() {
  if (!pulse.begin(Wire, I2C_SPEED_FAST)) Serial.println("MAX30102 not found - check the wiring");
  pulse.setup();
  pulse.setPulseAmplitudeRed(0x1F);
  pulse.setPulseAmplitudeGreen(0);
}
long irNow() { return pulse.getIR(); }
long redNow() { return pulse.getRed(); }
bool fingerOn() { return pulse.getIR() > 50000; }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define N 20
#define POST 10                            // samples recorded after the trigger
#define IMPACT_DEV 0.6
int bufG[N];                               // acceleration deviation from 1 g, in milli-g
int bufI[N];                               // current in 0.1 mA
int bufH[N];                               // heart rate
int head = 0, filled = 0;
int state = 0;                             // 0 recording, 1 post-trigger, 2 frozen
int postLeft = 0;
String why = "";
String stamp = "";
int bpm = 0;
long lastBeat = 0;
unsigned long lastSample = 0;

void trigger(String reason) {
  if (state != 0) return;
  state = 1; postLeft = POST; why = reason;
  stamp = dateText(rtc.now()) + " " + clockText(rtc.now());
}
void dump() {
  Serial.println("==== BLACK BOX " + stamp + " trigger: " + why + " ====");
  Serial.println("t(s),dev_mg,mA x10,bpm");
  int start = (head - N + N) % N;                               // oldest sample
  for (int i = 0; i < N; i++) {
    int k = (start + i) % N;
    Serial.print((i - (N - POST)) * 0.2, 1); Serial.print(",");
    Serial.print(bufG[k]); Serial.print(","); Serial.print(bufI[k]); Serial.print(","); Serial.println(bufH[k]);
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  mpuBegin();
  ina.begin();
  pulseBegin();
  rtc.begin();
  lcdBegin();
}

void loop() {
  long ir = irNow();                                            // keep the beat detector running at full speed
  if (ir < 50000) bpm = 0;
  else if (checkForBeat(ir)) {
    long delta = millis() - lastBeat;
    bool firstBeat = (lastBeat == 0);        // the first beat has no previous beat to measure from
    lastBeat = millis();
    float b = 60000.0 / delta;
    if (!firstBeat && b > 40 && b < 200) bpm = (int)b;
  }
  readAccel();
  float dev = abs(totalG() - 1.0);
  bool btn = pressed();
  if (state == 0 && dev > IMPACT_DEV) trigger("IMPACT");
  if (state == 0 && btn) trigger("BUTTON");
  else if (state == 2 && btn) { state = 0; filled = 0; head = 0; }       // re-arm
  if (state != 2 && millis() - lastSample >= 200) {
    lastSample = millis();
    readPower();
    bufG[head] = (int)(dev * 1000); bufI[head] = (int)(mA * 10); bufH[head] = bpm;
    head = (head + 1) % N;
    if (filled < N) filled++;
    if (state == 1) {
      postLeft--;
      if (postLeft <= 0) { state = 2; dump(); }
    }
  }
  lcdRow(0, state == 0 ? "REC " + String(filled) + "/" + String(N) : state == 1 ? "TRIGGER " + why : "FROZEN " + why);
  lcdRow(1, state == 2 ? "button = re-arm" : String(dev * 1000, 0) + "mg " + String(mA, 0) + "mA " + String(bpm));
  delay(10);
}
