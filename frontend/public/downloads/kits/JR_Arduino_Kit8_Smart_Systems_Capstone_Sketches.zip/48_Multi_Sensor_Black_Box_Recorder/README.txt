Kit 8 - Smart Systems Capstone
Project 48: Multi-Sensor Black Box Recorder (Advanced)

Records acceleration, current and heart rate in a rolling buffer (20 samples, 5 per second). An impact above 0.6 g or the button freezes the buffer after 10 more samples and dumps it on the Serial Monitor with the RTC time stamp.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  RTC DS3231 x1
  MPU6050 IMU x1
  MAX30102 Pulse Oximeter x1
  16x2 LCD I2C x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-48-black-box
