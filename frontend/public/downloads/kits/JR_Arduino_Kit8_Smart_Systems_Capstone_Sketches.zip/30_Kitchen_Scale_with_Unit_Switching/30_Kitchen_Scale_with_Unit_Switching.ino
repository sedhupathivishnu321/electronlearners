// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define HX_DT 2
#define HX_SCK 3
#define BTN1 4

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int btnEvent() {                           // 0 = nothing, 1 = short press, 2 = long press (held for 0.8 s)
  if (digitalRead(BTN1) == HIGH) return 0;
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == LOW) {
    delay(5);
    if (millis() - t0 > 800) { while (digitalRead(BTN1) == LOW) delay(5); return 2; }
  }
  return 1;
}

bool ounces = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  lcdBegin();
  scaleBegin();
}

void loop() {
  int e = btnEvent();
  if (e == 1) ounces = !ounces;
  if (e == 2) { scale.tare(); lcdRow(0, "Tared"); delay(300); }
  float g = grams();
  lcdRow(0, "Kitchen scale");
  if (ounces) lcdRow(1, String(g / 28.3495, 2) + " oz");
  else lcdRow(1, String(g, 0) + " g");
  delay(30);
}
