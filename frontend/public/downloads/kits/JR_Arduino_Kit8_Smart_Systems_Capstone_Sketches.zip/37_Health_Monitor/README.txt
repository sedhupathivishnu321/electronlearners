Kit 8 - Smart Systems Capstone
Project 37: Health Monitor (Advanced)

BPM and SpO2 from the MAX30102 with motion rejection: while the MPU6050 sees movement the readings are discarded. The OLED draws a BPM trend and the buzzer warns about low SpO2 or an abnormal pulse.

Parts:
  Buzzer Active 5V x1
  MPU6050 IMU x1
  MAX30102 Pulse Oximeter x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-37-health-monitor
