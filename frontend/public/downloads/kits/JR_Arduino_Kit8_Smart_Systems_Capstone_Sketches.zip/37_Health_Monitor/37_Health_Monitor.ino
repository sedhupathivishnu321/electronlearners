// ---- Circuit (Kit 8) ----
// MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
#define BUZZER 7

#include <MAX30105.h>
#include <heartRate.h>
MAX30105 pulse;
void pulseBegin() {
  if (!pulse.begin(Wire, I2C_SPEED_FAST)) Serial.println("MAX30102 not found - check the wiring");
  pulse.setup();
  pulse.setPulseAmplitudeRed(0x1F);
  pulse.setPulseAmplitudeGreen(0);
}
long irNow() { return pulse.getIR(); }
long redNow() { return pulse.getRed(); }
bool fingerOn() { return pulse.getIR() > 50000; }
#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

long lastBeat = 0;
int bpm = 0, spo2 = 0;
float sumIr = 0, sumRed = 0;
int samples = 0;
int hist[16];
int histN = 0;
bool motion = false;
unsigned long lastDraw = 0;

void pushTrend(int v) {
  if (histN < 16) { hist[histN] = v; histN++; return; }
  for (int i = 0; i < 15; i++) hist[i] = hist[i + 1];
  hist[15] = v;
}
void draw() {
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  if (motion) oled.print("MOTION - hold still");
  else oled.print("BPM ");
  if (!motion) { oled.print(bpm); oled.print("  SpO2 "); oled.print(spo2); oled.print("%"); }
  for (int i = 0; i < histN; i++) {                                    // trend bars, 8 px wide
    int h = constrain(map(hist[i], 40, 160, 2, 40), 2, 40);
    oled.fillRect(i * 8, 63 - h, 6, h, SSD1306_WHITE);
  }
  oled.display();
}

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT);
  mpuBegin();
  oledBegin();
  pulseBegin();
}

void loop() {
  readAccel();
  motion = (abs(totalG() - 1.0) > 0.25);
  long ir = irNow(), red = redNow();
  if (motion || ir < 50000) {                                          // artefact or no finger: throw the data away
    sumIr = 0; sumRed = 0; samples = 0;
    if (ir < 50000) { bpm = 0; spo2 = 0; }
    digitalWrite(BUZZER, LOW);
  } else {
    sumIr += ir; sumRed += red; samples++;
    if (checkForBeat(ir)) {
      long delta = millis() - lastBeat;
      bool firstBeat = (lastBeat == 0);        // the first beat has no previous beat to measure from
      lastBeat = millis();
      float b = 60000.0 / delta;
      if (!firstBeat && b > 40 && b < 200) { bpm = (int)b; pushTrend(bpm); }
    }
    if (samples >= 50) {
      spo2 = constrain((int)(90 + (sumRed / sumIr - 0.90) * 200), 70, 100);
      sumIr = 0; sumRed = 0; samples = 0;
      bool bad = (spo2 < 92) || (bpm > 0 && (bpm < 50 || bpm > 120));
      digitalWrite(BUZZER, bad ? HIGH : LOW);
      Serial.print("BPM "); Serial.print(bpm); Serial.print("  SpO2 "); Serial.println(spo2);
    }
  }
  if (millis() - lastDraw > 200) { lastDraw = millis(); draw(); }
  delay(10);
}
