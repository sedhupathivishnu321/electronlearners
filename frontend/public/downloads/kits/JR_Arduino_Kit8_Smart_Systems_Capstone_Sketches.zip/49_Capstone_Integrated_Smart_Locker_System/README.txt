Kit 8 - Smart Systems Capstone
Project 49: Capstone: Integrated Smart-Locker System (Advanced)

Everything together: RFID opens the locker (servo + relay strike), the load cell checks the contents, the MPU6050 raises a tamper alarm while it is locked, the INA219 monitors the electronics, the RTC time-stamps the events, the LCD shows the status and the OLED the power, tilt and event log.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  LED 5mm Blue x1
  MFRC522 RFID Kit x1
  Load Cell + HX711 x1
  INA219 Current Sensor x1
  RTC DS3231 x1
  MPU6050 IMU x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  0.96in OLED I2C SSD1306 x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-49-capstone-locker
