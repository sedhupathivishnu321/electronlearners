// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define RFID_SS 10
#define RFID_RST 9
#define HX_DT 2
#define HX_SCK 3
#define SERVO_PIN 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define LOAD_PIN 8
#define BUZZER 7
#define GREEN_LED A1
#define RED_LED A0

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String OWNER = "DE AD BE EF";
#define TAMPER_G 0.35
bool open = false, alarm = false;
float weightOpen = 0;
String ev1 = "system ready", ev2 = "";
unsigned long lastUi = 0;

void event(String s) {
  ev2 = ev1; ev1 = clockText(rtc.now()) + " " + s;
  Serial.println(ev1 + "  [" + cardUid + "]");
}

void ui() {
  float w = grams();
  lcdRow(0, alarm ? "!! TAMPER ALARM" : open ? "OPEN  " + clockText(rtc.now()) : "LOCKED " + clockText(rtc.now()));
  lcdRow(1, "Items " + String(w, 0) + " g");
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);  oled.print(busV, 2); oled.print("V "); oled.print(mA, 0); oled.print("mA ");
  oled.print(tiltDeg(), 0); oled.print("deg");
  oled.drawLine(0, 11, 127, 11, SSD1306_WHITE);
  oled.setCursor(0, 16); oled.print(ev1);
  oled.setCursor(0, 28); oled.print(ev2);
  oled.setCursor(0, 44); oled.print(alarm ? "ALARM" : open ? "OPEN" : "LOCKED");
  oled.display();
}

void setup() {
  Serial.begin(9600);
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  rtc.begin();
  mpuBegin();
  ina.begin();
  lcdBegin();
  oledBegin();
  scaleBegin();
  rfidBegin();
  digitalWrite(RED_LED, HIGH);
}

void loop() {
  readAccel();
  readPower();
  if (!open && !alarm && abs(totalG() - 1.0) > TAMPER_G) { alarm = true; event("TAMPER"); }
  if (readCard()) {
    if (cardUid == OWNER) {
      alarm = false;
      if (!open) {
        open = true;
        weightOpen = grams();
        servo.write(OPEN_ANGLE);
        digitalWrite(RELAY_PIN, RELAY_ON); delay(400); digitalWrite(RELAY_PIN, RELAY_OFF);
        digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH);
        beep(100);
        event("opened");
      } else {
        open = false;
        servo.write(LOCKED_ANGLE);
        digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH);
        float diff = grams() - weightOpen;
        beep(100);
        event(diff > 5 ? "in +" + String(diff, 0) + "g" : diff < -5 ? "out " + String(diff, 0) + "g" : "closed");
      }
    } else { event("DENIED"); beeps(3); }
  }
  digitalWrite(BUZZER, (alarm && (millis() / 250) % 2 == 0) ? HIGH : LOW);
  if (millis() - lastUi > 250) { lastUi = millis(); ui(); }
  delay(10);
}
