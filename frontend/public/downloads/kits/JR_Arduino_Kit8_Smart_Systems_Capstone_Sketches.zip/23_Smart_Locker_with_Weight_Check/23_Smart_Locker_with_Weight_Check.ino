// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define RFID_SS 10
#define RFID_RST 9
#define SERVO_PIN 5
#define HX_DT 2
#define HX_SCK 3

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

String OWNER = "DE AD BE EF";
bool open = false;

void setup() {
  Serial.begin(9600);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  lcdBegin();
  scaleBegin();                            // the locker is empty at start-up
  rfidBegin();
}

void loop() {
  if (readCard()) {
    if (cardUid == OWNER) {
      open = !open;
      servo.write(open ? OPEN_ANGLE : LOCKED_ANGLE);
      Serial.println(open ? "locker OPEN" : "locker LOCKED");
    } else {
      lcdRow(0, "Wrong card");
      Serial.println("wrong card " + cardUid);
      delay(1000);
    }
  }
  lcdRow(0, open ? "Locker OPEN" : "Locker LOCKED");
  lcdRow(1, "Contents " + String(grams(), 0) + " g");
  delay(100);
}
