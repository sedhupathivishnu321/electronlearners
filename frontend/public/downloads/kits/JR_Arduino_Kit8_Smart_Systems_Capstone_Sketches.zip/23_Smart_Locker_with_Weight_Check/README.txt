Kit 8 - Smart Systems Capstone
Project 23: Smart Locker with Weight Check (Intermediate)

An authorised card opens and closes the locker door (servo). The LCD always reports the weight of the contents measured by the load cell.

Parts:
  MFRC522 RFID Kit x1
  Load Cell + HX711 x1
  SG90 Micro Servo x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-23-smart-locker
