Kit 8 - Smart Systems Capstone
Project 41: Secure Vault Alarm (Advanced)

The owner card arms and disarms the vault. While armed, shaking the MPU6050, changing the weight on the load cell or presenting a wrong card latches the alarm (relay + buzzer) until the owner card is swiped.

Parts:
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  Load Cell + HX711 x1
  MPU6050 IMU x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  Active buzzer: + -> D7, - -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-41-vault-alarm
