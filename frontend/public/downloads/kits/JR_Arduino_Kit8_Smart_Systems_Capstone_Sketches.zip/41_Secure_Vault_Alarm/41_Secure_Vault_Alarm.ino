// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// Active buzzer: + -> D7, - -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define HX_DT 2
#define HX_SCK 3
#define RFID_SS 10
#define RFID_RST 9
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 7

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String OWNER = "DE AD BE EF";
#define TAMPER_G 0.3
#define WEIGHT_TOL 10.0
int state = 0;                             // 0 disarmed, 1 armed, 2 ALARM (latched)
float baseline = 0;
String reason = "";

void trigger(String why) {
  state = 2;
  reason = why;
  digitalWrite(RELAY_PIN, RELAY_ON);
  Serial.println("ALARM: " + why);
}

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  mpuBegin();
  lcdBegin();
  scaleBegin();
  rfidBegin();
}

void loop() {
  readAccel();
  float w = grams();
  if (state == 1) {
    if (abs(totalG() - 1.0) > TAMPER_G) trigger("TAMPER");
    else if (abs(w - baseline) > WEIGHT_TOL) trigger("WEIGHT");
  }
  if (readCard()) {
    if (cardUid == OWNER) {
      if (state == 0) { baseline = grams(); state = 1; beep(150); Serial.println("armed"); }
      else { state = 0; digitalWrite(RELAY_PIN, RELAY_OFF); Serial.println("disarmed"); beep(150); }
    } else if (state == 1) trigger("BAD CARD");
    else beeps(2);
  }
  digitalWrite(BUZZER, (state == 2 && (millis() / 200) % 2 == 0) ? HIGH : LOW);
  if (state == 0) { lcdRow(0, "Vault DISARMED"); lcdRow(1, "swipe to arm"); }
  else if (state == 1) { lcdRow(0, "Vault ARMED"); lcdRow(1, String(w, 0) + " g"); }
  else { lcdRow(0, "ALARM! " + reason); lcdRow(1, "owner card=reset"); }
  delay(20);
}
