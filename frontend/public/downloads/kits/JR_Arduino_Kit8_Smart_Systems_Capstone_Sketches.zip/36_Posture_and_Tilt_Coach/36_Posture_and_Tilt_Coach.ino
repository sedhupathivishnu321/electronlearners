// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
// Red LED anode -> 220 ohm -> A0, cathode -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
#define BUZZER 7
#define RED_LED A0
#define GREEN_LED A1

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

#define SLOUCH_DEG 20.0
#define SLOUCH_MS 3000
bool slouching = false, alerted = false;
unsigned long since = 0, totalMs = 0;
int events = 0;
String startStamp = "";

void setup() {
  Serial.begin(9600);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  mpuBegin();
  rtc.begin();
  oledBegin();
  Serial.println("start,seconds");
}

void loop() {
  readAccel();
  float tilt = tiltDeg();
  bool bad = (tilt > SLOUCH_DEG);
  if (bad && !slouching) { slouching = true; since = millis(); alerted = false; }
  if (!bad && slouching) {
    if (alerted) {
      unsigned long ms = millis() - since;
      totalMs += ms;
      events++;
      Serial.print(startStamp); Serial.print(","); Serial.println(ms / 1000.0, 1);
    }
    slouching = false; alerted = false;
  }
  if (slouching && !alerted && millis() - since > SLOUCH_MS) {
    alerted = true;
    startStamp = clockText(rtc.now());
    beeps(2);
  }
  digitalWrite(RED_LED, alerted ? HIGH : LOW);
  digitalWrite(GREEN_LED, bad ? LOW : HIGH);
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);  oled.print("POSTURE  "); oled.print(clockText(rtc.now()));
  oled.setTextSize(2);
  oled.setCursor(0, 14); oled.print(tilt, 0); oled.print(" deg");
  oled.setTextSize(1);
  oled.setCursor(0, 36); oled.print(alerted ? "SIT UP!" : bad ? "careful..." : "good posture");
  oled.setCursor(0, 48); oled.print("slouches "); oled.print(events); oled.print("  "); oled.print(totalMs / 1000); oled.print("s");
  oled.display();
  delay(100);
}
