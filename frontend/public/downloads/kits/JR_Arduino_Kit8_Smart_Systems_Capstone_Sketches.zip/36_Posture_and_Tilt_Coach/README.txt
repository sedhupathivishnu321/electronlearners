Kit 8 - Smart Systems Capstone
Project 36: Posture and Tilt Coach (Advanced)

Tilting past 20 degrees for 3 s counts as a slouch: red LED and beeps. When you sit up again the slouch is logged with its start time and duration.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  RTC DS3231 x1
  MPU6050 IMU x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
  Red LED anode -> 220 ohm -> A0, cathode -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-36-posture-coach
