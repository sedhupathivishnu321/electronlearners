// ---- Circuit (Kit 8) ----
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }

void setup() {
  Serial.begin(9600);
  if (!rtc.begin()) Serial.println("DS3231 not found - check SDA / SCL");
  Serial.println("DS3231 clock running");
}

void loop() {
  DateTime now = rtc.now();
  Serial.print(dateText(now));
  Serial.print("  ");
  Serial.println(clockText(now));
  delay(1000);
}
