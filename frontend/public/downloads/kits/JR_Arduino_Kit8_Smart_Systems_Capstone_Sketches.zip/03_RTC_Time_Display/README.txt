Kit 8 - Smart Systems Capstone
Project 3: RTC Time Display (Basic)

Prints the date and time from the DS3231 every second (the simulated RTC follows the PC clock).

Parts:
  RTC DS3231 x1

Circuit notes:
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-03-rtc-time
