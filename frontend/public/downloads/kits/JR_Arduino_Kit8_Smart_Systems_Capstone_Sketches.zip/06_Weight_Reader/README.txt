Kit 8 - Smart Systems Capstone
Project 6: Weight Reader (Basic)

Tares the empty platform at start-up, then prints the weight in grams (move the "Weight on cell" slider in the HX711 inspector).

Parts:
  Load Cell + HX711 x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-06-weight-reader
