// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
#define HX_DT 2
#define HX_SCK 3

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }

void setup() {
  Serial.begin(9600);
  scaleBegin();
  Serial.println("Scale tared - put something on the platform");
}

void loop() {
  Serial.print("Weight: ");
  Serial.print(grams(), 1);
  Serial.println(" g");
  delay(500);
}
