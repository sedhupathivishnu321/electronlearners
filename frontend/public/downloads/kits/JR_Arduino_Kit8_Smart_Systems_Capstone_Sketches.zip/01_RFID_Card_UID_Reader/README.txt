Kit 8 - Smart Systems Capstone
Project 1: RFID Card UID Reader (Basic)

Select the RC522 and tick "Card on reader": the UID of the card (editable in the inspector) is printed on the Serial Monitor.

Parts:
  MFRC522 RFID Kit x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-01-rfid-uid
