Kit 8 - Smart Systems Capstone
Project 26: Access Denied Lockout (Intermediate)

Three wrong cards in a row start a 30 s lockout: the buzzer pulses, the red LED lights and every card is ignored while the LCD counts down.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  Active buzzer: + -> D7, - -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-26-lockout
