// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// Active buzzer: + -> D7, - -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define RFID_SS 10
#define RFID_RST 9
#define BUZZER 7
#define RED_LED A0

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

String AUTHORISED = "DE AD BE EF";
#define MAX_TRIES 3
#define LOCK_MS 30000
int wrong = 0;
unsigned long lockUntil = 0;
bool wasLocked = false;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT); pinMode(RED_LED, OUTPUT);
  lcdBegin();
  rfidBegin();
  lcdRow(0, "Present card");
}

void loop() {
  if (millis() < lockUntil) {                                  // locked out: ignore the reader
    wasLocked = true;
    readCard();
    digitalWrite(RED_LED, HIGH);
    digitalWrite(BUZZER, (millis() / 300) % 2 == 0 ? HIGH : LOW);
    lcdRow(0, "LOCKED OUT");
    lcdRow(1, "wait " + String((lockUntil - millis()) / 1000 + 1) + " s");
    delay(50);
    return;
  }
  digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW);
  if (wasLocked) { wasLocked = false; lcdRow(0, "Present card"); lcdRow(1, ""); }
  if (readCard()) {
    if (cardUid == AUTHORISED) {
      wrong = 0;
      lcdRow(0, "Welcome!");
      lcdRow(1, cardUid);
      Serial.println("granted");
    } else {
      wrong++;
      Serial.print("denied, wrong tries: "); Serial.println(wrong);
      lcdRow(0, "Denied " + String(wrong) + "/" + String(MAX_TRIES));
      lcdRow(1, cardUid);
      if (wrong >= MAX_TRIES) { lockUntil = millis() + LOCK_MS; wrong = 0; Serial.println("LOCKOUT"); }
    }
  }
  delay(50);
}
