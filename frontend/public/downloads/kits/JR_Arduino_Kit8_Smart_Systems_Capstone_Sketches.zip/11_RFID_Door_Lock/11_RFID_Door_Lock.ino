// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// Active buzzer: + -> D7, - -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define RFID_SS 10
#define RFID_RST 9
#define SERVO_PIN 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 7
#define GREEN_LED A1
#define RED_LED A0

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String AUTHORISED = "DE AD BE EF";

void setup() {
  Serial.begin(9600);
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  rfidBegin();
  digitalWrite(RED_LED, HIGH);              // red = locked
  Serial.println("Door locked - present a card");
}

void loop() {
  if (!readCard()) return;
  Serial.print("Card "); Serial.print(cardUid);
  if (cardUid == AUTHORISED) {
    Serial.println(" -> OPEN");
    digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH);
    servo.write(OPEN_ANGLE);
    digitalWrite(RELAY_PIN, RELAY_ON);
    beep(150);
    delay(3000);
    servo.write(LOCKED_ANGLE);
    digitalWrite(RELAY_PIN, RELAY_OFF);
    digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH);
    Serial.println("Door locked again");
  } else {
    Serial.println(" -> DENIED");
    beeps(3);
  }
}
