Kit 8 - Smart Systems Capstone
Project 11: RFID Door Lock (Intermediate)

The authorised card (DE AD BE EF) opens the servo latch and the relay strike for 3 s with one beep; any other card gets three beeps.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  Active buzzer: + -> D7, - -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-11-rfid-door-lock
