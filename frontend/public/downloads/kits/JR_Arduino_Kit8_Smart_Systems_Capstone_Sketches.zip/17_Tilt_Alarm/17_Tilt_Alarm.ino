// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// Active buzzer: + -> D7, - -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define BUZZER 7
#define RED_LED A0

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }

#define TILT_LIMIT 30.0

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT); pinMode(RED_LED, OUTPUT);
  mpuBegin();
}

void loop() {
  readAccel();
  float tilt = tiltDeg();
  bool bad = (tilt > TILT_LIMIT);
  digitalWrite(RED_LED, bad ? HIGH : LOW);
  digitalWrite(BUZZER, bad ? HIGH : LOW);
  Serial.print("tilt "); Serial.print(tilt, 1); Serial.println(bad ? " deg  ALARM" : " deg  ok");
  delay(200);
}
