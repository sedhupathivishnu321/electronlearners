Kit 8 - Smart Systems Capstone
Project 17: Tilt Alarm (Intermediate)

When the board is tilted more than 30 degrees (raise AX or lower AZ in the MPU6050 inspector) the red LED lights and the buzzer sounds.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  MPU6050 IMU x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  Active buzzer: + -> D7, - -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-17-tilt-alarm
