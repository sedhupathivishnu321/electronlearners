// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define RFID_SS 10
#define RFID_RST 9

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

int count = 0;

void setup() {
  Serial.begin(9600);
  rtc.begin();
  lcdBegin();
  rfidBegin();
  Serial.println("date,time,uid");
  lcdRow(0, "Attendance");
  lcdRow(1, "Present a card");
}

void loop() {
  if (!readCard()) return;
  DateTime now = rtc.now();
  count++;
  Serial.print(dateText(now)); Serial.print(","); Serial.print(clockText(now)); Serial.print(","); Serial.println(cardUid);
  lcdRow(0, cardUid);
  lcdRow(1, clockText(now) + " #" + String(count));
}
