Kit 8 - Smart Systems Capstone
Project 12: RFID Attendance with Time-Stamp (Intermediate)

Every card swipe is logged on the Serial Monitor with the RTC date and time, and the last swipe is shown on the LCD.

Parts:
  MFRC522 RFID Kit x1
  RTC DS3231 x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-12-rfid-attendance
