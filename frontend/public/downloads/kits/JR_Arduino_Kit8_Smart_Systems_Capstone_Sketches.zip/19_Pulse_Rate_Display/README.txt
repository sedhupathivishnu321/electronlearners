Kit 8 - Smart Systems Capstone
Project 19: Pulse Rate Display (Intermediate)

Detects heartbeats in the MAX30102 IR signal and shows the averaged BPM on the OLED (set a different "Heart rate" in the inspector).

Parts:
  MAX30102 Pulse Oximeter x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-19-pulse-rate
