// ---- Circuit (Kit 8) ----
// MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <MAX30105.h>
#include <heartRate.h>
MAX30105 pulse;
void pulseBegin() {
  if (!pulse.begin(Wire, I2C_SPEED_FAST)) Serial.println("MAX30102 not found - check the wiring");
  pulse.setup();
  pulse.setPulseAmplitudeRed(0x1F);
  pulse.setPulseAmplitudeGreen(0);
}
long irNow() { return pulse.getIR(); }
long redNow() { return pulse.getRed(); }
bool fingerOn() { return pulse.getIR() > 50000; }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

long lastBeat = 0;
float rates[4];
int rateIdx = 0;
int bpm = 0;

void draw(String msg) {
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0); oled.println("PULSE RATE");
  oled.setTextSize(3);
  oled.setCursor(0, 24);
  oled.print(bpm);
  oled.setTextSize(1);
  oled.setCursor(0, 56); oled.println(msg);
  oled.display();
}

void setup() {
  Serial.begin(9600);
  oledBegin();
  pulseBegin();
  draw("place finger");
}

void loop() {
  long ir = irNow();
  if (ir < 50000) { bpm = 0; draw("place finger"); delay(100); return; }
  if (checkForBeat(ir)) {
    long delta = millis() - lastBeat;
    bool firstBeat = (lastBeat == 0);        // the first beat has no previous beat to measure from
    lastBeat = millis();
    float b = 60000.0 / delta;
    if (!firstBeat && b > 40 && b < 200) {
      rates[rateIdx] = b;
      rateIdx = (rateIdx + 1) % 4;
      float sum = 0; int n = 0;
      for (int i = 0; i < 4; i++) if (rates[i] > 0) { sum += rates[i]; n++; }
      bpm = (int)(sum / n);
      Serial.print("BPM "); Serial.println(bpm);
      draw("beat detected");
    }
  }
  delay(10);
}
