Kit 8 - Smart Systems Capstone
Project 28: SpO2 Estimate Display (Intermediate)

Averages red and IR light over about a second and turns their ratio into an approximate SpO2 (teaching calibration), next to the BPM. Change "SpO2" and "Heart rate" in the inspector.

Parts:
  MAX30102 Pulse Oximeter x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-28-spo2-estimate
