// ---- Circuit (Kit 8) ----
// MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <MAX30105.h>
#include <heartRate.h>
MAX30105 pulse;
void pulseBegin() {
  if (!pulse.begin(Wire, I2C_SPEED_FAST)) Serial.println("MAX30102 not found - check the wiring");
  pulse.setup();
  pulse.setPulseAmplitudeRed(0x1F);
  pulse.setPulseAmplitudeGreen(0);
}
long irNow() { return pulse.getIR(); }
long redNow() { return pulse.getRed(); }
bool fingerOn() { return pulse.getIR() > 50000; }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

long lastBeat = 0;
int bpm = 0;
float sumIr = 0, sumRed = 0;
int samples = 0;
int spo2 = 0;

void draw() {
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0); oled.println("SpO2 / BPM");
  oled.setTextSize(2);
  oled.setCursor(0, 18); oled.print("SpO2 "); oled.print(spo2); oled.println("%");
  oled.setCursor(0, 42); oled.print("BPM  "); oled.println(bpm);
  oled.display();
}

void setup() {
  Serial.begin(9600);
  oledBegin();
  pulseBegin();
  draw();
}

void loop() {
  long ir = irNow();
  long red = redNow();
  if (ir < 50000) { spo2 = 0; bpm = 0; sumIr = 0; sumRed = 0; samples = 0; draw(); delay(100); return; }
  sumIr += ir; sumRed += red; samples++;
  if (checkForBeat(ir)) {
    long delta = millis() - lastBeat;
    bool firstBeat = (lastBeat == 0);        // the first beat has no previous beat to measure from
    lastBeat = millis();
    float b = 60000.0 / delta;
    if (!firstBeat && b > 40 && b < 200) bpm = (int)b;
  }
  if (samples >= 50) {                                           // about one second of data
    float ratio = sumRed / sumIr;                                // red / IR light: lower with less oxygen
    spo2 = constrain((int)(90 + (ratio - 0.90) * 200), 70, 100);   // simplified linear calibration, not medical grade
    Serial.print("SpO2 "); Serial.print(spo2); Serial.print("  BPM "); Serial.println(bpm);
    sumIr = 0; sumRed = 0; samples = 0;
    draw();
  }
  delay(20);
}
