Kit 8 - Smart Systems Capstone
Project 32: Attendance System with Reports (Advanced)

Three registered cards swipe IN and OUT. Visits and time present are kept per user in EEPROM (reset each new day); press the button to print the daily report on the Serial Monitor.

Parts:
  Push Button tactile 6x6 x1
  MFRC522 RFID Kit x1
  RTC DS3231 x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  EEPROM: byte 0 = day of the month; user u uses 8 bytes at 1 + 8u:
    +0 state (1 = in)   +1,+2 seconds present (low, high)   +3..+6 time of the last IN (unix time)   +7 visits

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-32-attendance-reports
