// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define RFID_SS 10
#define RFID_RST 9
#define BTN1 4

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
#include <EEPROM.h>

String U0 = "DE AD BE EF";
String U1 = "01 02 03 04";
String U2 = "AA BB CC DD";
#define NUSERS 3
// EEPROM: byte 0 = day of the month; user u uses 8 bytes at 1 + 8u:
//   +0 state (1 = in)   +1,+2 seconds present (low, high)   +3..+6 time of the last IN (unix time)   +7 visits

int slotOf(String uid) {
  if (uid == U0) return 0;
  if (uid == U1) return 1;
  if (uid == U2) return 2;
  return -1;
}
int base(int u) { return 1 + 8 * u; }
long readLong(int a) { return ((long)EEPROM.read(a) << 24) | ((long)EEPROM.read(a + 1) << 16) | ((long)EEPROM.read(a + 2) << 8) | EEPROM.read(a + 3); }
void writeLong(int a, long v) { EEPROM.write(a, (v >> 24) & 255); EEPROM.write(a + 1, (v >> 16) & 255); EEPROM.write(a + 2, (v >> 8) & 255); EEPROM.write(a + 3, v & 255); }
int secondsPresent(int u) { return EEPROM.read(base(u) + 1) + 256 * EEPROM.read(base(u) + 2); }

void newDay(int day) {
  for (int i = 1; i < 1 + 8 * NUSERS; i++) EEPROM.write(i, 0);
  EEPROM.write(0, day);
}
void report() {
  Serial.println("---- daily report ----");
  for (int u = 0; u < NUSERS; u++) {
    Serial.print("user "); Serial.print(u + 1);
    Serial.print("  visits "); Serial.print(EEPROM.read(base(u) + 7));
    Serial.print("  present "); Serial.print(secondsPresent(u)); Serial.print(" s");
    Serial.println(EEPROM.read(base(u)) == 1 ? "  (still IN)" : "  (out)");
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  rtc.begin();
  lcdBegin();
  rfidBegin();
  if (EEPROM.read(0) != rtc.now().day()) newDay(rtc.now().day());
  lcdRow(0, "Attendance");
  lcdRow(1, "swipe IN / OUT");
}

void loop() {
  if (pressed()) report();
  if (!readCard()) return;
  int u = slotOf(cardUid);
  if (u < 0) { lcdRow(0, "Unknown card"); lcdRow(1, cardUid); return; }
  long now = rtc.now().unixtime();
  int a = base(u);
  if (EEPROM.read(a) == 0) {                                   // IN
    EEPROM.write(a, 1);
    writeLong(a + 3, now);
    EEPROM.write(a + 7, EEPROM.read(a + 7) + 1);
    lcdRow(0, "User " + String(u + 1) + " IN");
    lcdRow(1, clockText(rtc.now()));
  } else {                                                     // OUT: add the time spent inside
    int total = secondsPresent(u) + (now - readLong(a + 3));
    EEPROM.write(a, 0);
    EEPROM.write(a + 1, total & 255);
    EEPROM.write(a + 2, (total >> 8) & 255);
    lcdRow(0, "User " + String(u + 1) + " OUT");
    lcdRow(1, "total " + String(total) + " s");
  }
}
