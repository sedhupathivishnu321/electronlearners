// ---- Circuit (Kit 8) ----
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define LOAD_PIN 8
#define BTN1 4

#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define LOG_EVERY_S 10
float energy_mWh = 0;
unsigned long lastMs = 0, lastLog = 0, lastDraw = 0;

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  ina.begin();
  rtc.begin();
  oledBegin();
  lastMs = millis(); lastLog = millis();
  Serial.println("date,time,mW,mWh");
}

void loop() {
  readPower();
  unsigned long ms = millis();
  energy_mWh += mW * (ms - lastMs) / 3600000.0;
  lastMs = ms;
  if (pressed()) { energy_mWh = 0; Serial.println("energy counter reset"); }
  if (ms - lastLog >= LOG_EVERY_S * 1000UL) {
    lastLog = ms;
    DateTime now = rtc.now();
    Serial.print(dateText(now)); Serial.print(","); Serial.print(clockText(now)); Serial.print(",");
    Serial.print(mW, 1); Serial.print(","); Serial.println(energy_mWh, 4);
  }
  if (ms - lastDraw >= 250) {
    lastDraw = ms;
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setCursor(0, 0);  oled.print("ENERGY  "); oled.print(clockText(rtc.now()));
    oled.setCursor(0, 16); oled.print(busV, 2); oled.print(" V  "); oled.print(mA, 1); oled.print(" mA");
    oled.setTextSize(2);
    oled.setCursor(0, 32); oled.print(mW, 1); oled.print("mW");
    oled.setTextSize(1);
    oled.setCursor(0, 54); oled.print(energy_mWh, 4); oled.print(" mWh");
    oled.display();
  }
  delay(20);
}
