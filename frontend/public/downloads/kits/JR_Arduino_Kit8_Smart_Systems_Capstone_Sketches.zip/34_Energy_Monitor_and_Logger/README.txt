Kit 8 - Smart Systems Capstone
Project 34: Energy Monitor and Logger (Advanced)

Integrates the INA219 power into energy (mWh), shows it on the OLED and logs a time-stamped line every 10 s (use 3600 for an hourly log). The button resets the energy counter.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  RTC DS3231 x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-34-energy-logger
