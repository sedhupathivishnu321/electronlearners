// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// Active buzzer: + -> D7, - -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define HX_DT 2
#define HX_SCK 3
#define BUZZER 7
#define RED_LED A0

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

#define LIMIT_G 500.0

void setup() {
  pinMode(BUZZER, OUTPUT); pinMode(RED_LED, OUTPUT);
  lcdBegin();
  scaleBegin();
}

void loop() {
  float w = grams();
  bool over = (w > LIMIT_G);
  digitalWrite(RED_LED, over ? HIGH : LOW);
  digitalWrite(BUZZER, over ? HIGH : LOW);
  lcdRow(0, String(w, 0) + " g");
  lcdRow(1, over ? "OVERLOAD!" : "limit " + String(LIMIT_G, 0) + " g");
  delay(150);
}
