Kit 8 - Smart Systems Capstone
Project 15: Overload Alarm Scale (Intermediate)

Weighs on the LCD; above the 500 g limit the red LED lights and the buzzer sounds until the load is removed.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Load Cell + HX711 x1
  16x2 LCD I2C x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  Active buzzer: + -> D7, - -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-15-overload-scale
