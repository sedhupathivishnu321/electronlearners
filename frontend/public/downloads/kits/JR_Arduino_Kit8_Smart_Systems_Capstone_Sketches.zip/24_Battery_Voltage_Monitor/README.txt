Kit 8 - Smart Systems Capstone
Project 24: Battery Voltage Monitor (Intermediate)

The INA219 measures the supply voltage while a small load runs. Above LOW_V the green LED is on; below it the red LED and buzzer warn (raise LOW_V to 5.0 in the code to see the warning).

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-24-battery-monitor
