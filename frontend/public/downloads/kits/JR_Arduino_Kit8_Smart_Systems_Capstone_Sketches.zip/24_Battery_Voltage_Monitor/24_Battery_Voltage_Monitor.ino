// ---- Circuit (Kit 8) ----
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
#define LOAD_PIN 8
#define BUZZER 7
#define RED_LED A0
#define GREEN_LED A1

#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

#define LOW_V 4.50              // warning threshold; use 3.3 for a lithium cell, 5.0 to trigger the demo here
#define FULL_V 4.90
#define EMPTY_V 4.00

void setup() {
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  pinMode(BUZZER, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  ina.begin();
  lcdBegin();
}

void loop() {
  readPower();
  int pct = constrain(map((int)(busV * 100), (int)(EMPTY_V * 100), (int)(FULL_V * 100), 0, 100), 0, 100);
  bool low = (busV < LOW_V);
  digitalWrite(GREEN_LED, low ? LOW : HIGH);
  digitalWrite(RED_LED, low ? HIGH : LOW);
  digitalWrite(BUZZER, (low && (millis() / 500) % 2 == 0) ? HIGH : LOW);
  lcdRow(0, String(busV, 2) + "V " + String(mA, 0) + "mA");
  lcdRow(1, low ? "LOW BATTERY!" : "Battery " + String(pct) + "%");
  delay(200);
}
