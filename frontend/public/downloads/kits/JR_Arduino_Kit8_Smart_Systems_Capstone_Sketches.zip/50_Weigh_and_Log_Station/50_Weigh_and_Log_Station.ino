// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// Active buzzer: + -> D7, - -> GND
#define HX_DT 2
#define HX_SCK 3
#define BTN1 4
#define BUZZER 7

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int btnEvent() {                           // 0 = nothing, 1 = short press, 2 = long press (held for 0.8 s)
  if (digitalRead(BTN1) == HIGH) return 0;
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == LOW) {
    delay(5);
    if (millis() - t0 > 800) { while (digitalRead(BTN1) == LOW) delay(5); return 2; }
  }
  return 1;
}
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

#define MIN_G 2.0                          // lighter than this is "nothing on the pan"
int n = 0;
float total = 0;
bool needClear = false;                    // must remove the logged item before logging the next

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  rtc.begin();
  lcdBegin();
  scaleBegin();
  Serial.println("time,item,grams,total_g");
}

void loop() {
  float w = grams();
  if (needClear && w < MIN_G) needClear = false;
  int e = btnEvent();
  if (e == 1) {
    if (w >= MIN_G && !needClear) {
      n++; total += w; needClear = true;
      Serial.print(clockText(rtc.now())); Serial.print(","); Serial.print(n); Serial.print(",");
      Serial.print(w, 1); Serial.print(","); Serial.println(total, 1);
      beep(80);
    } else beeps(2);                                            // nothing to log, or the last item is still on the pan
  }
  if (e == 2) {
    scale.tare(); n = 0; total = 0; needClear = false;
    Serial.println(clockText(rtc.now()) + ",NEW BATCH");
    beep(300);
  }
  lcdRow(0, "Pan " + String(w, 1) + " g");
  lcdRow(1, "n" + String(n) + " sum " + String(total, 1) + "g");
  delay(30);
}
