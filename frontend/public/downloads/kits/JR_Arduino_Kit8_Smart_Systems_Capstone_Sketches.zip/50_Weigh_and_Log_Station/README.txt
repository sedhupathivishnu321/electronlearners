Kit 8 - Smart Systems Capstone
Project 50: Weigh-and-Log Station (Advanced)

Put an item on the pan and press the button: its weight is logged with the RTC time stamp and added to the running total on the LCD. Remove the item before the next one. A long press starts a new batch (and tares).

Parts:
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  Load Cell + HX711 x1
  RTC DS3231 x1
  16x2 LCD I2C x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  Active buzzer: + -> D7, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-50-weigh-and-log
