// ---- Circuit (Kit 8) ----
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define LOAD_PIN 8
#define BTN1 4

#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <MAX30105.h>
#include <heartRate.h>
MAX30105 pulse;
void pulseBegin() {
  if (!pulse.begin(Wire, I2C_SPEED_FAST)) Serial.println("MAX30102 not found - check the wiring");
  pulse.setup();
  pulse.setPulseAmplitudeRed(0x1F);
  pulse.setPulseAmplitudeGreen(0);
}
long irNow() { return pulse.getIR(); }
long redNow() { return pulse.getRed(); }
bool fingerOn() { return pulse.getIR() > 50000; }
#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define PEAK_G 1.3
int page = 0;
int bpm = 0, steps = 0;
long lastBeat = 0;
bool above = false;
unsigned long lastStep = 0, lastDraw = 0;

void title(String s) { oled.setTextSize(1); oled.setCursor(0, 0); oled.print(s); }

void draw() {
  oled.clearDisplay();
  if (page == 0) {
    DateTime now = rtc.now();
    title("TIME");
    oled.setTextSize(2); oled.setCursor(0, 20); oled.print(clockText(now));
    oled.setTextSize(1); oled.setCursor(0, 48); oled.print(dateText(now));
  } else if (page == 1) {
    title("HEART RATE");
    oled.setTextSize(3); oled.setCursor(0, 22); oled.print(bpm);
    oled.setTextSize(1); oled.setCursor(80, 40); oled.print("bpm");
  } else if (page == 2) {
    title("STEPS");
    oled.setTextSize(3); oled.setCursor(0, 22); oled.print(steps);
  } else {
    title("BATTERY");
    int pct = constrain(map((int)(busV * 100), 400, 490, 0, 100), 0, 100);
    oled.setTextSize(2); oled.setCursor(0, 16); oled.print(busV, 2); oled.print(" V");
    oled.drawRect(0, 40, 100, 14, SSD1306_WHITE);
    oled.fillRect(2, 42, pct, 10, SSD1306_WHITE);
    oled.setTextSize(1); oled.setCursor(0, 56); oled.print(pct); oled.print("%  "); oled.print(mA, 1); oled.print(" mA");
  }
  oled.display();
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  rtc.begin();
  mpuBegin();
  ina.begin();
  oledBegin();
  pulseBegin();
}

void loop() {
  if (pressed()) { page = (page + 1) % 4; Serial.print("page "); Serial.println(page); }
  readAccel();                                                  // steps: rising edge through 1.3 g
  float g = totalG();
  if (g > PEAK_G && !above && millis() - lastStep > 250) { steps++; lastStep = millis(); }
  above = (g > PEAK_G);
  long ir = irNow();                                            // heart rate
  if (ir < 50000) bpm = 0;
  else if (checkForBeat(ir)) {
    long delta = millis() - lastBeat;
    bool firstBeat = (lastBeat == 0);        // the first beat has no previous beat to measure from
    lastBeat = millis();
    float b = 60000.0 / delta;
    if (!firstBeat && b > 40 && b < 200) bpm = (int)b;
  }
  if (millis() - lastDraw > 250) { lastDraw = millis(); readPower(); draw(); }
  delay(10);
}
