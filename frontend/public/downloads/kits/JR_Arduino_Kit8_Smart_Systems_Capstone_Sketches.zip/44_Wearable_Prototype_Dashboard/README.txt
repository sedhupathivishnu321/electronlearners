Kit 8 - Smart Systems Capstone
Project 44: Wearable Prototype Dashboard (Advanced)

A four-page OLED dashboard (time, heart rate, steps, battery) paged with the button. The pulse sensor and step counter keep running in the background whichever page is shown.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  RTC DS3231 x1
  MPU6050 IMU x1
  MAX30102 Pulse Oximeter x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-44-wearable-dashboard
