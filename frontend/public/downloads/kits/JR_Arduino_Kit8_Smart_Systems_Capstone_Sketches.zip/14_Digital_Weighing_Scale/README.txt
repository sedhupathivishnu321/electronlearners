Kit 8 - Smart Systems Capstone
Project 14: Digital Weighing Scale (Intermediate)

The weight in grams on the LCD. Press the button to tare (zero) the scale with the pan empty or with a container on it.

Parts:
  Push Button tactile 6x6 x1
  Load Cell + HX711 x1
  16x2 LCD I2C x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-14-digital-scale
