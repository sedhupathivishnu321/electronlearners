// ---- Circuit (Kit 8) ----
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define LOAD_PIN 8
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 4

#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define LIMIT_S 20                         // maximum continuous use
bool on = false;
unsigned long onSince = 0, lastMs = 0;
float sessionMwh = 0;
String onStamp = "";

void switchOn() {
  on = true; onSince = millis(); lastMs = millis(); sessionMwh = 0;
  digitalWrite(RELAY_PIN, RELAY_ON);
  onStamp = clockText(rtc.now());
  Serial.println("ON  " + onStamp);
}
void switchOff(String why) {
  on = false;
  digitalWrite(RELAY_PIN, RELAY_OFF);
  Serial.print("OFF " + clockText(rtc.now()) + "  used "); Serial.print((millis() - onSince) / 1000); Serial.print(" s, ");
  Serial.print(sessionMwh, 4); Serial.println(" mWh  (" + why + ")");
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  ina.begin();
  rtc.begin();
  lcdBegin();
}

void loop() {
  readPower();
  if (pressed()) { if (on) switchOff("button"); else switchOn(); }
  if (on) {
    unsigned long ms = millis();
    sessionMwh += mW * (ms - lastMs) / 3600000.0;
    lastMs = ms;
    if (ms - onSince > LIMIT_S * 1000UL) switchOff("time limit");
  }
  if (on) {
    lcdRow(0, "ON " + String((millis() - onSince) / 1000) + "s " + String(mA, 1) + "mA");
    lcdRow(1, String(sessionMwh, 4) + " mWh");
  } else {
    lcdRow(0, "OFF  " + String(mA, 1) + " mA");
    lcdRow(1, "press to start");
  }
  delay(30);
}
