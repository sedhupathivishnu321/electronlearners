// ---- Circuit (Kit 8) ----
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
#define SERVO_PIN 5
#define HX_DT 2
#define HX_SCK 3
#define BUZZER 7
#define RFID_SS 10
#define RFID_RST 9

#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String CARER = "DE AD BE EF";
#define FIRST_DOSE_S 25
#define DOSE_EVERY_S 90
#define DOSE_MIN_G 3
#define DOSE_MAX_G 20
int state = 0;                             // 0 waiting, 1 dose due (locked), 2 lid open
unsigned long nextDose = 0;
float before = 0;
int doses = 0;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  rtc.begin();
  lcdBegin();
  scaleBegin();
  rfidBegin();
  nextDose = rtc.now().unixtime() + FIRST_DOSE_S;
}

void loop() {
  DateTime now = rtc.now();
  bool card = readCard();
  if (state == 0) {
    if (now.unixtime() >= nextDose) { state = 1; Serial.println(clockText(now) + "  DOSE DUE"); }
    lcdRow(0, "Time " + clockText(now));
    lcdRow(1, "next dose " + String((long)(nextDose - now.unixtime())) + "s");
  } else if (state == 1) {
    digitalWrite(BUZZER, (millis() / 400) % 3 == 0 ? HIGH : LOW);
    lcdRow(0, "TAKE MEDICINE");
    lcdRow(1, "swipe card");
    if (card && cardUid == CARER) {
      digitalWrite(BUZZER, LOW);
      before = grams();
      servo.write(OPEN_ANGLE);
      state = 2;
      Serial.println(clockText(now) + "  lid open, weight " + String(before, 0) + " g");
    }
  } else {
    lcdRow(0, "Lid open " + String(grams(), 0) + "g");
    lcdRow(1, "take pills,swipe");
    if (card && cardUid == CARER) {
      servo.write(LOCKED_ANGLE);
      float taken = before - grams();
      if (taken >= DOSE_MIN_G && taken <= DOSE_MAX_G) {
        doses++;
        lcdRow(0, "Dose OK " + String(taken, 0) + " g");
        lcdRow(1, "doses today " + String(doses));
        Serial.println(clockText(now) + "  dose taken, " + String(taken, 0) + " g");
        nextDose = now.unixtime() + DOSE_EVERY_S;
        state = 0;
        beep(200);
      } else {
        lcdRow(0, taken < DOSE_MIN_G ? "Too little!" : "Too much!");
        lcdRow(1, "check the box");
        Serial.println(clockText(now) + "  WRONG DOSE " + String(taken, 0) + " g");
        beeps(3);
        nextDose = now.unixtime() + 20;                 // remind again soon
        state = 0;
      }
      delay(1500);
    }
  }
  delay(50);
}
