Kit 8 - Smart Systems Capstone
Project 38: Smart Medication Box (Advanced)

A dose falls due 25 s after start-up. The box beeps and stays locked until the carer card opens the lid; the load cell then checks that 3-20 g of pills were taken before the card closes it again.

Parts:
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  Load Cell + HX711 x1
  RTC DS3231 x1
  SG90 Micro Servo x1
  16x2 LCD I2C x1

Circuit notes:
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-38-medication-box
