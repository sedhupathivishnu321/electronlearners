Kit 8 - Smart Systems Capstone
Project 31: Complete Smart Locker (Advanced)

RFID opens the locker (servo latch + relay strike), the load cell reports what was put in or taken out, every event is logged with the RTC time and the OLED shows the status.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  Load Cell + HX711 x1
  RTC DS3231 x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-31-complete-locker
