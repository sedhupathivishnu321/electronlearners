// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
#define RFID_SS 10
#define RFID_RST 9
#define SERVO_PIN 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define HX_DT 2
#define HX_SCK 3
#define BUZZER 7
#define GREEN_LED A1

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String OWNER = "DE AD BE EF";
bool open = false;
float weightOpen = 0;
String lastEvent = "ready";

void ui() {
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);  oled.print("SMART LOCKER  "); oled.print(clockText(rtc.now()));
  oled.setTextSize(2);
  oled.setCursor(0, 14); oled.print(open ? "OPEN" : "LOCKED");
  oled.setTextSize(1);
  oled.setCursor(0, 36); oled.print("Contents "); oled.print(grams(), 0); oled.print(" g");
  oled.setCursor(0, 50); oled.print(lastEvent);
  oled.display();
}

void setup() {
  Serial.begin(9600);
  pinMode(GREEN_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  rtc.begin();
  oledBegin();
  scaleBegin();
  rfidBegin();
  Serial.println("time,uid,event,grams");
}

void loop() {
  if (readCard()) {
    DateTime now = rtc.now();
    if (cardUid == OWNER) {
      if (!open) {
        open = true;
        weightOpen = grams();
        servo.write(OPEN_ANGLE);
        digitalWrite(RELAY_PIN, RELAY_ON); delay(500); digitalWrite(RELAY_PIN, RELAY_OFF);   // strike pulse
        digitalWrite(GREEN_LED, HIGH);
        beep(100);
        lastEvent = "opened";
      } else {
        open = false;
        servo.write(LOCKED_ANGLE);
        digitalWrite(GREEN_LED, LOW);
        float diff = grams() - weightOpen;
        lastEvent = diff > 5 ? "put in " + String(diff, 0) + " g" : diff < -5 ? "took " + String(-diff, 0) + " g" : "no change";
        beep(100);
      }
    } else {
      lastEvent = "DENIED";
      beeps(3);
    }
    Serial.print(clockText(now)); Serial.print(","); Serial.print(cardUid); Serial.print(","); Serial.print(lastEvent); Serial.print(","); Serial.println(grams(), 0);
  }
  ui();
  delay(100);
}
