Kit 8 - Smart Systems Capstone
Project 4: LCD Clock (Basic)

The date on the first LCD row and the running time on the second.

Parts:
  RTC DS3231 x1
  16x2 LCD I2C x1

Circuit notes:
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-04-lcd-clock
