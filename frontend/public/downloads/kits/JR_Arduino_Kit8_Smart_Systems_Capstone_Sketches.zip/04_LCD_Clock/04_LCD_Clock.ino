// ---- Circuit (Kit 8) ----
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

void setup() {
  rtc.begin();
  lcdBegin();
}

void loop() {
  DateTime now = rtc.now();
  lcdRow(0, "Date " + dateText(now));
  lcdRow(1, "Time " + clockText(now));
  delay(250);
}
