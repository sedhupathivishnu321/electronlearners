Kit 8 - Smart Systems Capstone
Project 39: Industrial Weighing Station (Advanced)

Short press = next mode: WEIGH (long press tares), COUNT (long press adds the item to the batch), CAL (long press calibrates against a 200 g mass) and REPORT (long press prints and clears the batch). Above 800 g the relay trips and latches.

Parts:
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  Load Cell + HX711 x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  Active buzzer: + -> D7, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-39-weighing-station
