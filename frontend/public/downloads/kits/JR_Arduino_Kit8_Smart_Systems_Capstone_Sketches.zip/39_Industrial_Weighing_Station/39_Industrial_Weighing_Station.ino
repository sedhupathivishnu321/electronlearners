// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// Active buzzer: + -> D7, - -> GND
#define HX_DT 2
#define HX_SCK 3
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 4
#define BUZZER 7

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int btnEvent() {                           // 0 = nothing, 1 = short press, 2 = long press (held for 0.8 s)
  if (digitalRead(BTN1) == HIGH) return 0;
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == LOW) {
    delay(5);
    if (millis() - t0 > 800) { while (digitalRead(BTN1) == LOW) delay(5); return 2; }
  }
  return 1;
}

#define TRIP_G 800.0
#define KNOWN_G 200.0
int mode = 0;                              // 0 weigh, 1 count, 2 calibrate, 3 report
int items = 0;
float batchTotal = 0;
bool tripped = false;
float factor = CAL_FACTOR;

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  lcdBegin();
  scaleBegin();
}

void calibrate() {
  scale.set_scale(1);                                          // raw counts above the tare offset
  float counts = scale.get_units();
  if (counts > 1000) { factor = counts / KNOWN_G; Serial.print("new factor "); Serial.println(factor, 2); }
  scale.set_scale(factor);
}

void loop() {
  float w = grams();
  if (w > TRIP_G && !tripped) { tripped = true; digitalWrite(RELAY_PIN, RELAY_ON); Serial.println("OVERLOAD - relay tripped"); }
  if (tripped && w < TRIP_G - 50) { tripped = false; digitalWrite(RELAY_PIN, RELAY_OFF); }
  digitalWrite(BUZZER, tripped ? HIGH : LOW);

  int e = btnEvent();
  if (e == 1) mode = (mode + 1) % 4;
  if (e == 2) {
    if (mode == 0) scale.tare();
    if (mode == 1 && w > 1) { items++; batchTotal += w; Serial.print("item "); Serial.print(items); Serial.print(": "); Serial.print(w, 1); Serial.println(" g"); }
    if (mode == 2) calibrate();
    if (mode == 3) { Serial.print("REPORT: "); Serial.print(items); Serial.print(" items, total "); Serial.print(batchTotal, 1); Serial.println(" g"); items = 0; batchTotal = 0; }
  }
  if (tripped) { lcdRow(0, "OVERLOAD TRIP"); lcdRow(1, String(w, 0) + " g"); }
  else if (mode == 0) { lcdRow(0, "WEIGH (hold=tare)"); lcdRow(1, String(w, 1) + " g"); }
  else if (mode == 1) { lcdRow(0, "COUNT " + String(items) + " items"); lcdRow(1, String(w, 1) + "g T" + String(batchTotal, 0)); }
  else if (mode == 2) { lcdRow(0, "CAL put " + String(KNOWN_G, 0) + " g"); lcdRow(1, "factor " + String(factor, 1)); }
  else { lcdRow(0, "REPORT hold=print"); lcdRow(1, String(items) + " items " + String(batchTotal, 0) + "g"); }
  delay(30);
}
