Kit 8 - Smart Systems Capstone
Project 25: IMU Level Bubble on OLED (Intermediate)

A digital spirit level: the bubble moves on the OLED as you change AX / AY in the MPU6050 inspector and sits in the centre ring when the board is level.

Parts:
  MPU6050 IMU x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-25-level-bubble
