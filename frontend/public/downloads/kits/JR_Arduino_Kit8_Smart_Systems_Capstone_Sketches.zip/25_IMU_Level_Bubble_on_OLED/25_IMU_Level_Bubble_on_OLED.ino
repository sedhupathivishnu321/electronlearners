// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5


#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

void setup() {
  mpuBegin();
  oledBegin();
}

void loop() {
  readAccel();
  int bx = 64 + constrain((int)(axg * 90), -50, 50);          // 1 g of tilt moves the bubble off the screen
  int by = 36 - constrain((int)(ayg * 90), -22, 22);
  bool level = (abs(axg) < 0.03 && abs(ayg) < 0.03);          // about 2 degrees
  oled.clearDisplay();
  oled.drawCircle(64, 36, 12, SSD1306_WHITE);                 // target ring
  oled.drawLine(64, 18, 64, 54, SSD1306_WHITE);
  oled.drawLine(46, 36, 82, 36, SSD1306_WHITE);
  oled.fillCircle(bx, by, 6, SSD1306_WHITE);                  // the bubble
  oled.setTextSize(1);
  oled.setCursor(0, 0);  oled.print("tilt "); oled.print(tiltDeg(), 1); oled.print(" deg");
  oled.setCursor(0, 56); oled.print(level ? "LEVEL" : "not level");
  oled.display();
  delay(50);
}
