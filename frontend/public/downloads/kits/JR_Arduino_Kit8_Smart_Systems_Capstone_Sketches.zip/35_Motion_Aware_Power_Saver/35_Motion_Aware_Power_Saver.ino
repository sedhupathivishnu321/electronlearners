// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
#define LOAD_PIN 8

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

#define IDLE_MS 5000
#define MOTION_G 0.15
unsigned long lastMotion = 0, sleepStart = 0, lastShow = 0;
bool awake = true;
float awakeMw = 0, savedMwh = 0;

void setup() {
  Serial.begin(9600);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  mpuBegin();
  ina.begin();
  oledBegin();
  lastMotion = millis();
}

void loop() {
  readAccel();
  if (abs(totalG() - 1.0) > MOTION_G) {
    lastMotion = millis();
    if (!awake) {
      awake = true;
      savedMwh += awakeMw * (millis() - sleepStart) / 3600000.0;
      digitalWrite(LOAD_PIN, HIGH);
      Serial.println("motion: WAKE");
    }
  }
  if (awake && millis() - lastMotion > IDLE_MS) {
    awake = false;
    sleepStart = millis();
    awakeMw = mW;
    digitalWrite(LOAD_PIN, LOW);
    oled.clearDisplay();
    oled.display();                        // blank screen
    Serial.println("idle: SLEEP");
  }
  if (millis() - lastShow > 300) {
    lastShow = millis();
    readPower();
    if (awake) {
      oled.clearDisplay();
      oled.setTextSize(1);
      oled.setCursor(0, 0);  oled.println("ACTIVE");
      oled.setCursor(0, 16); oled.print(mA, 1); oled.println(" mA");
      oled.setCursor(0, 32); oled.print("idle in "); oled.print((IDLE_MS - (millis() - lastMotion)) / 1000 + 1); oled.println(" s");
      oled.setCursor(0, 48); oled.print("saved "); oled.print(savedMwh, 3); oled.println(" mWh");
      oled.display();
    } else {
      Serial.print("sleeping, load current "); Serial.print(mA, 1); Serial.println(" mA");
    }
  }
  delay(10);
}
