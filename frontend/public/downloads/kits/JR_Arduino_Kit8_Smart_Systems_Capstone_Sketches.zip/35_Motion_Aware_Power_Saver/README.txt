Kit 8 - Smart Systems Capstone
Project 35: Motion-Aware Power Saver (Advanced)

While the board moves the OLED and the load stay on. After 5 s without motion both switch off, and the INA219 proves the saving (current falls to about 0). Shake the board with the AX slider to wake it.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  MPU6050 IMU x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-35-motion-power-saver
