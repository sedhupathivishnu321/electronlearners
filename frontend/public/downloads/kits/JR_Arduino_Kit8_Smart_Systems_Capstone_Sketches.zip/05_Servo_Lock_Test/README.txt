Kit 8 - Smart Systems Capstone
Project 5: Servo Lock Test (Basic)

Each press of the button moves the servo between the locked (0 deg) and unlocked (90 deg) positions.

Parts:
  Push Button tactile 6x6 x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-05-servo-lock-test
