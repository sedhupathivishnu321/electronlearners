// ---- Circuit (Kit 8) ----
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define SERVO_PIN 5
#define BTN1 4

#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool locked = true;

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  Serial.println("LOCKED");
}

void loop() {
  if (pressed()) {
    locked = !locked;
    servo.write(locked ? LOCKED_ANGLE : OPEN_ANGLE);
    Serial.println(locked ? "LOCKED" : "UNLOCKED");
  }
}
