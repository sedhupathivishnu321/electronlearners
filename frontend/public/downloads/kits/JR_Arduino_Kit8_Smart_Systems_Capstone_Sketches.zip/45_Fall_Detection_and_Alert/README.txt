Kit 8 - Smart Systems Capstone
Project 45: Fall Detection and Alert (Advanced)

A hard impact followed by a lying-down orientation starts an 8 s pre-alarm (beeps). Press the button to cancel; otherwise the alarm escalates: relay (external siren / dialer), continuous buzzer and red LED.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MPU6050 IMU x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  Active buzzer: + -> D7, - -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> A0, cathode -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-45-fall-alert
