// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// Active buzzer: + -> D7, - -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> A0, cathode -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
#define BUZZER 7
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 4
#define RED_LED A0
#define GREEN_LED A1

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define IMPACT_G 2.0
#define LYING_DEG 60.0
#define CANCEL_MS 8000
int state = 0;                             // 0 monitoring, 1 checking orientation, 2 pre-alarm, 3 ALARM
unsigned long since = 0;

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  mpuBegin();
  digitalWrite(GREEN_LED, HIGH);
  Serial.println("monitoring");
}

void allOff() {
  digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW); digitalWrite(RELAY_PIN, RELAY_OFF); digitalWrite(GREEN_LED, HIGH);
}

void loop() {
  readAccel();
  bool btn = pressed();
  if (state == 0) {
    if (totalG() > IMPACT_G) { state = 1; since = millis(); Serial.println("impact!"); }
  } else if (state == 1) {
    if (millis() - since > 1500) {                              // wait for the movement to settle, then look at the orientation
      if (tiltDeg() > LYING_DEG) { state = 2; since = millis(); digitalWrite(GREEN_LED, LOW); Serial.println("lying down: pre-alarm, press the button to cancel"); }
      else { state = 0; Serial.println("up again: false alarm"); }
    }
  } else if (state == 2) {
    digitalWrite(BUZZER, (millis() / 500) % 2 == 0 ? HIGH : LOW);
    digitalWrite(RED_LED, (millis() / 500) % 2 == 0 ? HIGH : LOW);
    if (btn) { state = 0; allOff(); Serial.println("cancelled"); }
    else if (millis() - since > CANCEL_MS) { state = 3; Serial.println("ALERT sent"); }
  } else {
    digitalWrite(BUZZER, HIGH); digitalWrite(RED_LED, HIGH); digitalWrite(RELAY_PIN, RELAY_ON);
    if (btn) { state = 0; allOff(); Serial.println("alert cleared"); }
  }
  delay(10);
}
