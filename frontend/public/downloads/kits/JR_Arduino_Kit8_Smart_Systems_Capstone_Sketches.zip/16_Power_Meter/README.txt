Kit 8 - Smart Systems Capstone
Project 16: Power Meter (Intermediate)

The OLED shows the INA219 voltage, current and power, plus the energy used so far (mWh) integrated over time.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  0.96in OLED I2C SSD1306 x1

Circuit notes:
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-16-power-meter
