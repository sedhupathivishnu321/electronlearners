// ---- Circuit (Kit 8) ----
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// SSD1306 OLED (I2C 0x3C): VCC 5V, GND, SDA -> A4, SCL -> A5
#define LOAD_PIN 8

#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
void oledBegin() {
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.setTextColor(SSD1306_WHITE);
  oled.clearDisplay();
  oled.display();
}

float energy_mWh = 0;
unsigned long lastMs = 0;

void setup() {
  pinMode(LOAD_PIN, OUTPUT);
  digitalWrite(LOAD_PIN, HIGH);
  ina.begin();
  oledBegin();
  lastMs = millis();
}

void loop() {
  readPower();
  unsigned long now = millis();
  energy_mWh += mW * (now - lastMs) / 3600000.0;     // mW x hours
  lastMs = now;
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);  oled.println("POWER METER");
  oled.setCursor(0, 14); oled.print("V:"); oled.print(busV, 2); oled.println(" V");
  oled.setCursor(0, 26); oled.print("I:"); oled.print(mA, 1); oled.println(" mA");
  oled.setCursor(0, 38); oled.print("P:"); oled.print(mW, 1); oled.println(" mW");
  oled.setCursor(0, 50); oled.print("E:"); oled.print(energy_mWh, 4); oled.println(" mWh");
  oled.display();
  delay(250);
}
