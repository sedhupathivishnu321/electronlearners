Kit 8 - Smart Systems Capstone
Project 47: Sample-Weight Dispensing Controller (Advanced)

Short press picks the target (25 / 50 / 100 / 200 g), long press tares and starts: the gate (servo) and feeder (relay) run until the target minus the learned in-flight amount is reached. After settling, the controller corrects its own anticipation.

Parts:
  Push Button tactile 6x6 x1
  Load Cell + HX711 x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-47-dispenser
