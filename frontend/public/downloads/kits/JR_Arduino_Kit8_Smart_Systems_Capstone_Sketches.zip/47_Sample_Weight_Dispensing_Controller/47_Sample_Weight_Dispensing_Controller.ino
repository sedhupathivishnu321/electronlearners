// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
#define HX_DT 2
#define HX_SCK 3
#define SERVO_PIN 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 4

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int btnEvent() {                           // 0 = nothing, 1 = short press, 2 = long press (held for 0.8 s)
  if (digitalRead(BTN1) == HIGH) return 0;
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == LOW) {
    delay(5);
    if (millis() - t0 > 800) { while (digitalRead(BTN1) == LOW) delay(5); return 2; }
  }
  return 1;
}

float anticipate = 3.0;                    // grams still falling when the gate closes - adjusted after every run
int ti = 1;
bool running = false;
float target = 50;
unsigned long startMs = 0;
String result = "";

float targetFor(int i) { if (i == 0) return 25; if (i == 1) return 50; if (i == 2) return 100; return 200; }

void finish(String msg) {
  servo.write(LOCKED_ANGLE);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  running = false;
  delay(1500);                                                  // let the falling material settle
  float final = grams();
  result = msg + " " + String(final, 1) + "g";
  if (msg == "Done") {
    anticipate = constrain(anticipate + (final - target) * 0.5, 0, 20);   // overshoot -> stop earlier next time
    Serial.print("dispensed "); Serial.print(final, 1); Serial.print(" g, anticipation now "); Serial.println(anticipate, 1);
  } else Serial.println(msg);
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  lcdBegin();
  scaleBegin();
  target = targetFor(ti);
}

void loop() {
  float w = grams();
  if (!running) {
    int e = btnEvent();
    if (e == 1) { ti = (ti + 1) % 4; target = targetFor(ti); result = ""; }
    if (e == 2) {
      scale.tare();                                             // zero with the empty container in place
      servo.write(OPEN_ANGLE);
      digitalWrite(RELAY_PIN, RELAY_ON);
      running = true;
      startMs = millis();
      Serial.print("dispensing "); Serial.print(target, 0); Serial.println(" g");
    }
    lcdRow(0, "Target " + String(target, 0) + " g");
    lcdRow(1, result.length() > 0 ? result : "hold to start");
  } else {
    lcdRow(0, "Dispensing...");
    lcdRow(1, String(w, 1) + " / " + String(target, 0) + " g");
    if (w >= target - anticipate) finish("Done");
    else if (millis() - startMs > 30000) finish("No flow!");
  }
  delay(50);
}
