// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)


#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }

void setup() {
  Serial.begin(9600);
  mpuBegin();
  if (!mpu.testConnection()) Serial.println("MPU6050 not found - AD0 must be tied to 5 V (address 0x69)");
}

void loop() {
  readAccel();
  int gx, gy, gz;
  mpu.getRotation(&gx, &gy, &gz);
  Serial.print("accel g: "); Serial.print(axg, 2); Serial.print(" "); Serial.print(ayg, 2); Serial.print(" "); Serial.print(azg, 2);
  Serial.print("   gyro deg/s: "); Serial.print(gx / 131); Serial.print(" "); Serial.print(gy / 131); Serial.print(" "); Serial.print(gz / 131);
  Serial.print("   tilt "); Serial.print(tiltDeg(), 0); Serial.println(" deg");
  delay(500);
}
