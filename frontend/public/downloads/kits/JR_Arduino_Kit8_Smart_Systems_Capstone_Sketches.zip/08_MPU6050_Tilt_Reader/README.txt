Kit 8 - Smart Systems Capstone
Project 8: MPU6050 Tilt Reader (Basic)

Prints the acceleration (g), the rotation rate and the tilt angle. Drag the AX / AY / AZ sliders in the MPU6050 inspector.

Parts:
  MPU6050 IMU x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-08-mpu-tilt
