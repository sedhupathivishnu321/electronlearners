// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define BUZZER 7

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

#define N 40
#define ALARM_MG 200
float samp[N];
unsigned long lastLog = 0;
String lastAlarm = "none";

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT);
  mpuBegin();
  rtc.begin();
  lcdBegin();
  Serial.println("time,rms_mg");
}

void loop() {
  float mean = 0;
  for (int i = 0; i < N; i++) {                                // about 0.4 s of samples
    readAccel();
    samp[i] = totalG();
    mean += samp[i];
    delay(10);
  }
  mean /= N;
  float sq = 0;
  for (int i = 0; i < N; i++) sq += (samp[i] - mean) * (samp[i] - mean);
  float rmsMg = sqrt(sq / N) * 1000.0;
  bool alarm = (rmsMg > ALARM_MG);
  digitalWrite(BUZZER, alarm ? HIGH : LOW);
  if (alarm && millis() - lastLog > 2000) {
    lastLog = millis();
    lastAlarm = clockText(rtc.now());
    Serial.print(lastAlarm); Serial.print(","); Serial.println(rmsMg, 0);
  }
  lcdRow(0, "RMS " + String(rmsMg, 0) + " mg " + (alarm ? "!!" : "ok"));
  lcdRow(1, "last " + lastAlarm);
}
