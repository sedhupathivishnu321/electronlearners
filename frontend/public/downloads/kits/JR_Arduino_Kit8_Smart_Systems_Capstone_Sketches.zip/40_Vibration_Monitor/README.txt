Kit 8 - Smart Systems Capstone
Project 40: Vibration Monitor (Advanced)

Measures the RMS of the acceleration ripple over 40 samples and shows it in milli-g. Above 200 mg the buzzer sounds and the event is logged with the RTC time.

Parts:
  Buzzer Active 5V x1
  RTC DS3231 x1
  MPU6050 IMU x1
  16x2 LCD I2C x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-40-vibration-monitor
