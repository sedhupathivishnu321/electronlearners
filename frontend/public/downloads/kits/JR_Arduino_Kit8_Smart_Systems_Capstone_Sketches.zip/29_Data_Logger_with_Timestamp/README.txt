Kit 8 - Smart Systems Capstone
Project 29: Data Logger with Timestamp (Intermediate)

Logs one CSV line every 2 s: the RTC date and time, the INA219 voltage and the load current. Copy the Serial Monitor text into a spreadsheet.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1
  RTC DS3231 x1

Circuit notes:
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-29-data-logger
