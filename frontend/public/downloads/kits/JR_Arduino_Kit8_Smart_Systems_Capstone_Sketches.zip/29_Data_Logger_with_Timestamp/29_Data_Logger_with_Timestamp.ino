// ---- Circuit (Kit 8) ----
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
#define LOAD_PIN 8

#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }

void setup() {
  Serial.begin(9600);
  pinMode(LOAD_PIN, OUTPUT);
  digitalWrite(LOAD_PIN, HIGH);
  ina.begin();
  rtc.begin();
  Serial.println("date,time,volts,mA");
}

void loop() {
  readPower();
  DateTime now = rtc.now();
  Serial.print(dateText(now)); Serial.print(",");
  Serial.print(clockText(now)); Serial.print(",");
  Serial.print(busV, 2); Serial.print(",");
  Serial.println(mA, 1);
  delay(2000);
}
