// ---- Circuit (Kit 8) ----
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Green LED anode -> 220 ohm -> A1, cathode -> GND
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define GREEN_LED A1

#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

#define ON_FROM_S 10
#define ON_UNTIL_S 40

void setup() {
  Serial.begin(9600);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  rtc.begin();
  lcdBegin();
}

bool lastOn = false;
void loop() {
  DateTime now = rtc.now();
  int s = now.second();
  bool on = (s >= ON_FROM_S && s < ON_UNTIL_S);
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
  digitalWrite(GREEN_LED, on ? HIGH : LOW);
  if (on != lastOn) { Serial.print(clockText(now)); Serial.println(on ? "  relay ON" : "  relay OFF"); lastOn = on; }
  lcdRow(0, clockText(now));
  lcdRow(1, on ? "Relay ON" : "Relay OFF");
  delay(200);
}
