Kit 8 - Smart Systems Capstone
Project 21: Timed Relay Schedule (Intermediate)

The relay is ON from second 10 to second 40 of every minute (a fast demo schedule - swap second() for hour() / minute() for a daily timetable). The LCD shows the clock and the relay state.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  RTC DS3231 x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Green LED anode -> 220 ohm -> A1, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-21-timed-relay
