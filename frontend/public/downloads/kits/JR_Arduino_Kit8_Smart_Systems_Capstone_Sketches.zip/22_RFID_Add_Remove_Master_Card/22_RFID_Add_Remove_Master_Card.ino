// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Green LED anode -> 220 ohm -> A1, cathode -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define RFID_SS 10
#define RFID_RST 9
#define GREEN_LED A1
#define RED_LED A0

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <EEPROM.h>

String MASTER = "AA BB CC DD";
#define MAX_CARDS 8                        // EEPROM: byte 0 = number of cards, then 4 bytes per card
int mode = 0;                              // 0 normal, 1 add, 2 remove

int findCard() {                           // slot number of the card in uidB[], or -1
  int n = EEPROM.read(0);
  for (int c = 0; c < n; c++) {
    bool same = true;
    for (int i = 0; i < 4; i++) if (EEPROM.read(1 + c * 4 + i) != uidB[i]) same = false;
    if (same) return c;
  }
  return -1;
}
bool addCard() {
  int n = EEPROM.read(0);
  if (n >= MAX_CARDS || findCard() >= 0) return false;
  for (int i = 0; i < 4; i++) EEPROM.write(1 + n * 4 + i, uidB[i]);
  EEPROM.write(0, n + 1);
  return true;
}
bool removeCard() {
  int slot = findCard();
  if (slot < 0) return false;
  int n = EEPROM.read(0);
  for (int i = 0; i < 4; i++) EEPROM.write(1 + slot * 4 + i, EEPROM.read(1 + (n - 1) * 4 + i));   // move the last card into the gap
  EEPROM.write(0, n - 1);
  return true;
}
void show(String a, String b) { lcdRow(0, a); lcdRow(1, b); }
void flash(int pin) { digitalWrite(pin, HIGH); delay(700); digitalWrite(pin, LOW); }

void setup() {
  Serial.begin(9600);
  pinMode(GREEN_LED, OUTPUT); pinMode(RED_LED, OUTPUT);
  if (EEPROM.read(0) > MAX_CARDS) EEPROM.write(0, 0);      // blank EEPROM
  lcdBegin();
  rfidBegin();
  show("Card manager", String(EEPROM.read(0)) + " cards stored");
}

void loop() {
  if (!readCard()) return;
  if (cardUid == MASTER) {
    mode = (mode + 1) % 3;
    show(mode == 0 ? "NORMAL mode" : mode == 1 ? "ADD mode" : "REMOVE mode", mode == 0 ? "swipe a card" : "swipe the card");
    flash(mode == 2 ? RED_LED : GREEN_LED);
    return;
  }
  if (mode == 1) {
    bool ok = addCard();
    show(ok ? "Card added" : "Not added", cardUid);
    flash(ok ? GREEN_LED : RED_LED);
    mode = 0;
  } else if (mode == 2) {
    bool ok = removeCard();
    show(ok ? "Card removed" : "Unknown card", cardUid);
    flash(ok ? GREEN_LED : RED_LED);
    mode = 0;
  } else {
    bool ok = (findCard() >= 0);
    show(ok ? "ACCESS OK" : "ACCESS DENIED", cardUid);
    flash(ok ? GREEN_LED : RED_LED);
  }
  Serial.print("cards stored: "); Serial.println(EEPROM.read(0));
}
