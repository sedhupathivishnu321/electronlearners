Kit 8 - Smart Systems Capstone
Project 22: RFID Add/Remove Master Card (Intermediate)

The master card (AA BB CC DD) cycles NORMAL -> ADD -> REMOVE. In ADD mode the next card is stored in EEPROM, in REMOVE mode it is deleted. Stored cards open the door (green), others do not (red).

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  MFRC522 RFID Kit x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Green LED anode -> 220 ohm -> A1, cathode -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-22-master-card
