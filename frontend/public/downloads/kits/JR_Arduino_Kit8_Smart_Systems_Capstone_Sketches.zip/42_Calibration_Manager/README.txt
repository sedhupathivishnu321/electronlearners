Kit 8 - Smart Systems Capstone
Project 42: Calibration Manager (Advanced)

A short press selects TARE / SPAN 200 g / CURRENT ZERO / IMU ZERO, a long press performs and saves it in EEPROM. The stored values are loaded again at every start-up.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  Load Cell + HX711 x1
  INA219 Current Sensor x1
  MPU6050 IMU x1
  16x2 LCD I2C x1

Circuit notes:
  HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  EEPROM map: 0 magic(0xCA)  1-3 load-cell offset  4-5 span factor x10  6-7 current offset (0.1 mA, +32768)  8-9 IMU x, 10-11 IMU y, 12-13 IMU z (mg, +32768)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-42-calibration-manager
