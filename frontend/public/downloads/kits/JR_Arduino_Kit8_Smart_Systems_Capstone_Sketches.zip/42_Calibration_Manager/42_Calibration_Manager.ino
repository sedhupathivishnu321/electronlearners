// ---- Circuit (Kit 8) ----
// HX711 board: VCC 5V, GND, DT -> D2, SCK -> D3 (load cell wires E+ E- A- A+ on the left header)
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// Push button between D4 and GND (INPUT_PULLUP, pressed = LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define HX_DT 2
#define HX_SCK 3
#define LOAD_PIN 8
#define BTN1 4

#include <HX711.h>
HX711 scale;
#define CAL_FACTOR 441.5                   // raw counts per gram, found by calibrating with a known weight
void scaleBegin() {
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(CAL_FACTOR);
  scale.tare();                            // empty platform = 0 g
}
float grams() { return scale.get_units(); }
#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}
#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int btnEvent() {                           // 0 = nothing, 1 = short press, 2 = long press (held for 0.8 s)
  if (digitalRead(BTN1) == HIGH) return 0;
  unsigned long t0 = millis();
  while (digitalRead(BTN1) == LOW) {
    delay(5);
    if (millis() - t0 > 800) { while (digitalRead(BTN1) == LOW) delay(5); return 2; }
  }
  return 1;
}
#include <EEPROM.h>

// EEPROM map: 0 magic(0xCA)  1-3 load-cell offset  4-5 span factor x10  6-7 current offset (0.1 mA, +32768)  8-9 IMU x, 10-11 IMU y, 12-13 IMU z (mg, +32768)
#define MAGIC 0xCA
#define KNOWN_G 200.0
int item = 0;
float factor = CAL_FACTOR;
float mAoffset = 0;
int imuX = 0, imuY = 0, imuZ = 0;           // milli-g to subtract

void put16(int a, int v) { EEPROM.write(a, v & 255); EEPROM.write(a + 1, (v >> 8) & 255); }
int get16(int a) { return EEPROM.read(a) + 256 * EEPROM.read(a + 1); }
void saveOffset(long off) { EEPROM.write(1, (off >> 16) & 255); EEPROM.write(2, (off >> 8) & 255); EEPROM.write(3, off & 255); }
long loadOffset() { return ((long)EEPROM.read(1) << 16) | ((long)EEPROM.read(2) << 8) | EEPROM.read(3); }

void loadAll() {
  if (EEPROM.read(0) != MAGIC) return;                          // nothing stored yet: keep the defaults
  scale.set_offset(loadOffset());
  factor = get16(4) / 10.0;
  scale.set_scale(factor);
  mAoffset = (get16(6) - 32768) / 10.0;
  imuX = get16(8) - 32768; imuY = get16(10) - 32768; imuZ = get16(12) - 32768;
}
float avgMa() {
  float s = 0;
  for (int i = 0; i < 10; i++) { s += ina.getCurrent_mA(); delay(10); }
  return s / 10;
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(LOAD_PIN, OUTPUT); digitalWrite(LOAD_PIN, HIGH);
  scale.begin(HX_DT, HX_SCK);
  scale.set_scale(factor);
  ina.begin();
  mpuBegin();
  lcdBegin();
  loadAll();
  if (EEPROM.read(0) != MAGIC) scale.tare();                    // nothing stored yet: assume the platform is empty now
  Serial.println(EEPROM.read(0) == MAGIC ? "calibration loaded from EEPROM" : "no calibration stored - using defaults");
}

void doCalibrate() {
  if (item == 0) {                                              // empty platform = zero
    scale.tare();
    saveOffset(scale.get_offset());
    EEPROM.write(0, MAGIC);
    put16(4, (int)(factor * 10));
  } else if (item == 1) {                                       // known mass on the platform = span
    scale.set_scale(1);
    float counts = scale.get_units();
    if (counts > 1000) factor = counts / KNOWN_G;
    scale.set_scale(factor);
    put16(4, (int)(factor * 10));
    EEPROM.write(0, MAGIC);
  } else if (item == 2) {                                       // load switched off = zero current
    digitalWrite(LOAD_PIN, LOW);
    delay(100);
    mAoffset = avgMa();
    digitalWrite(LOAD_PIN, HIGH);
    put16(6, (int)(mAoffset * 10) + 32768);
  } else {                                                      // board lying flat and still
    readAccel();
    imuX = (int)(axg * 1000); imuY = (int)(ayg * 1000); imuZ = (int)(azg * 1000) - 1000;
    put16(8, imuX + 32768); put16(10, imuY + 32768); put16(12, imuZ + 32768);
  }
  Serial.print("saved item "); Serial.println(item);
  lcdRow(0, "Saved!");
  lcdRow(1, "");
  delay(700);
}

void loop() {
  int e = btnEvent();
  if (e == 1) item = (item + 1) % 4;
  if (e == 2) doCalibrate();
  if (item == 0) { lcdRow(0, "1 TARE (hold)"); lcdRow(1, String(grams(), 1) + " g"); }
  else if (item == 1) { lcdRow(0, "2 SPAN 200g(hold)"); lcdRow(1, String(grams(), 1) + " g f" + String(factor, 0)); }
  else if (item == 2) { lcdRow(0, "3 CURRENT ZERO"); lcdRow(1, String(ina.getCurrent_mA() - mAoffset, 1) + " mA"); }
  else {
    readAccel();
    lcdRow(0, "4 IMU ZERO (hold)");
    lcdRow(1, "x" + String((int)(axg * 1000) - imuX) + " y" + String((int)(ayg * 1000) - imuY) + " z" + String((int)(azg * 1000) - 1000 - imuZ));
  }
  delay(30);
}
