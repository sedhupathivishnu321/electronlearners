// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
// SG90 servo: signal -> D5, red -> 5V, brown -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Active buzzer: + -> D7, - -> GND
#define RFID_SS 10
#define RFID_RST 9
#define SERVO_PIN 5
#define BUZZER 7

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }
#include <RTClib.h>
RTC_DS3231 rtc;
String two(int v) { if (v < 10) return "0" + String(v); return String(v); }
String clockText(DateTime t) { return two(t.hour()) + ":" + two(t.minute()) + ":" + two(t.second()); }
String dateText(DateTime t) { return String(t.year()) + "-" + two(t.month()) + "-" + two(t.day()); }
#include <Servo.h>
Servo servo;
#define LOCKED_ANGLE 0
#define OPEN_ANGLE 90
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
void beep(int ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }
void beeps(int n) { for (int i = 0; i < n; i++) { beep(80); delay(80); } }

String STAFF = "DE AD BE EF";
String VISITOR = "01 02 03 04";
#define STAFF_FROM 0
#define STAFF_TO 40
#define VISITOR_FROM 20
#define VISITOR_TO 50

int clockUnit(DateTime t) { return t.second(); }               // demo: seconds. Use t.hour() for a real timetable.
bool allowed(String uid, int t) {
  if (uid == STAFF) return t >= STAFF_FROM && t < STAFF_TO;
  if (uid == VISITOR) return t >= VISITOR_FROM && t < VISITOR_TO;
  return false;
}

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(LOCKED_ANGLE);
  rtc.begin();
  lcdBegin();
  rfidBegin();
}

void loop() {
  DateTime now = rtc.now();
  lcdRow(0, "Time " + clockText(now));
  if (readCard()) {
    bool known = (cardUid == STAFF || cardUid == VISITOR);
    bool ok = allowed(cardUid, clockUnit(now));
    Serial.print(clockText(now)); Serial.print("  "); Serial.print(cardUid); Serial.println(ok ? "  OPEN" : known ? "  OUTSIDE HOURS" : "  UNKNOWN");
    if (ok) {
      lcdRow(1, "Welcome");
      servo.write(OPEN_ANGLE);
      beep(120);
      delay(2500);
      servo.write(LOCKED_ANGLE);
    } else {
      lcdRow(1, known ? "Not allowed now" : "Unknown card");
      beeps(3);
      delay(800);
    }
  }
  lcdRow(1, "Present a card");
  delay(100);
}
