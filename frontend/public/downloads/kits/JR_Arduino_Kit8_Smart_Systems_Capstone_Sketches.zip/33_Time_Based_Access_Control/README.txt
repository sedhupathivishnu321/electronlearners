Kit 8 - Smart Systems Capstone
Project 33: Time-Based Access Control (Advanced)

Staff may enter during seconds 0-39 of every minute, the visitor card during seconds 20-49 (a fast demo: change second() to hour() for real opening hours). Outside its window a card is refused.

Parts:
  Buzzer Active 5V x1
  MFRC522 RFID Kit x1
  RTC DS3231 x1
  SG90 Micro Servo x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  SG90 servo: signal -> D5, red -> 5V, brown -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Active buzzer: + -> D7, - -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-33-timed-access
