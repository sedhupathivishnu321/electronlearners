Kit 8 - Smart Systems Capstone
Project 13: Access Log on LCD (Intermediate)

Shows the last card, whether it was GRANTED or DENIED and the time of the swipe on the LCD.

Parts:
  MFRC522 RFID Kit x1
  RTC DS3231 x1
  16x2 LCD I2C x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  DS3231 RTC (I2C 0x68): VCC 5V, GND, SDA -> A4, SCL -> A5
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-13-access-log-lcd
