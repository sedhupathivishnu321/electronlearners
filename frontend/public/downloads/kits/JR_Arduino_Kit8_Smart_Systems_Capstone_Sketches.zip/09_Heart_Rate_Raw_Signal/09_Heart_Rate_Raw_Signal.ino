// ---- Circuit (Kit 8) ----
// MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5


#include <MAX30105.h>
#include <heartRate.h>
MAX30105 pulse;
void pulseBegin() {
  if (!pulse.begin(Wire, I2C_SPEED_FAST)) Serial.println("MAX30102 not found - check the wiring");
  pulse.setup();
  pulse.setPulseAmplitudeRed(0x1F);
  pulse.setPulseAmplitudeGreen(0);
}
long irNow() { return pulse.getIR(); }
long redNow() { return pulse.getRed(); }
bool fingerOn() { return pulse.getIR() > 50000; }

void setup() {
  Serial.begin(115200);
  pulseBegin();
  Serial.println("IR,RED");
}

void loop() {
  Serial.print(irNow());
  Serial.print(",");
  Serial.println(redNow());
  delay(50);
}
