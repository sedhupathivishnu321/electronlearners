Kit 8 - Smart Systems Capstone
Project 9: Heart-Rate Raw Signal (Basic)

Streams the raw IR and red photodiode counts. With a finger on the sensor the IR value pulses with each heartbeat.

Parts:
  MAX30102 Pulse Oximeter x1

Circuit notes:
  MAX30102 (I2C 0x57): VIN 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-09-pulse-raw
