Kit 8 - Smart Systems Capstone
Project 27: Fall Detector Demo (Intermediate)

A fall is free-fall (total acceleration below 0.4 g) followed by an impact (above 2 g) within half a second. Try AZ = 0.1 then AZ = 2.5 in the inspector.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MPU6050 IMU x1

Circuit notes:
  MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
  Active buzzer: + -> D7, - -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND
  Green LED anode -> 220 ohm -> A1, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-27-fall-detector
