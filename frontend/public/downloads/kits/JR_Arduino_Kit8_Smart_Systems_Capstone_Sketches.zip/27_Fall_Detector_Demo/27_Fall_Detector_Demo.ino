// ---- Circuit (Kit 8) ----
// MPU6050 (I2C): VCC 5V, GND, SDA -> A4, SCL -> A5, AD0 -> 5V so it answers on 0x69 (the DS3231 owns 0x68)
// Active buzzer: + -> D7, - -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
// Green LED anode -> 220 ohm -> A1, cathode -> GND
#define BUZZER 7
#define RED_LED A0
#define GREEN_LED A1

#include <MPU6050.h>
MPU6050 mpu(0x69);                         // AD0 is tied to 5 V, so the IMU answers on 0x69
int rawX, rawY, rawZ;
float axg, ayg, azg;                       // acceleration in g
void readAccel() {
  mpu.getAcceleration(&rawX, &rawY, &rawZ);
  axg = rawX / 16384.0; ayg = rawY / 16384.0; azg = rawZ / 16384.0;
}
float totalG() { return sqrt(axg * axg + ayg * ayg + azg * azg); }
float tiltDeg() {                          // angle between the board's Z axis and straight up
  float flat = sqrt(axg * axg + ayg * ayg);
  return atan2(flat, azg) * 180.0 / PI;
}
void mpuBegin() { Wire.begin(); mpu.initialize(); }

#define FREEFALL_G 0.4
#define IMPACT_G 2.0
bool freefall = false;
unsigned long freefallAt = 0;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT); pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  mpuBegin();
  digitalWrite(GREEN_LED, HIGH);           // green = monitoring
  Serial.println("fall detector armed");
}

void loop() {
  readAccel();
  float g = totalG();
  if (g < FREEFALL_G && !freefall) { freefall = true; freefallAt = millis(); }
  if (freefall && g > IMPACT_G && millis() - freefallAt < 500) {
    Serial.println("FALL DETECTED");
    digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH); digitalWrite(BUZZER, HIGH);
    delay(3000);
    digitalWrite(RED_LED, LOW); digitalWrite(BUZZER, LOW); digitalWrite(GREEN_LED, HIGH);
    freefall = false;
  }
  if (freefall && millis() - freefallAt > 500) freefall = false;     // no impact followed: it was just a drop of the hand
  delay(5);
}
