// ---- Circuit (Kit 8) ----
// MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
// Green LED anode -> 220 ohm -> A1, cathode -> GND
// Red LED anode -> 220 ohm -> A0, cathode -> GND
#define RFID_SS 10
#define RFID_RST 9
#define GREEN_LED A1
#define RED_LED A0

#include <SPI.h>
#include <MFRC522.h>
MFRC522 rfid(RFID_SS, RFID_RST);
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}

String cardUid = "";                       // UID of the last card read, e.g. "DE AD BE EF"
int uidB[10];                              // the same UID as raw bytes
bool readCard() {                          // true when a new card has been read into cardUid
  if (!rfid.PICC_IsNewCardPresent()) return false;
  if (!rfid.PICC_ReadCardSerial()) return false;
  cardUid = "";
  for (int i = 0; i < rfid.uid.size; i++) {
    if (i > 0) cardUid += " ";
    cardUid += hex2(rfid.uid.uidByte[i]);
    uidB[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return true;
}
void rfidBegin() { SPI.begin(); rfid.PCD_Init(); }

String AUTHORISED = "DE AD BE EF";         // the UID that is allowed in

void setup() {
  Serial.begin(9600);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  rfidBegin();
  Serial.println("Hold a card on the reader");
}

void loop() {
  if (readCard()) {
    bool ok = (cardUid == AUTHORISED);
    digitalWrite(GREEN_LED, ok ? HIGH : LOW);
    digitalWrite(RED_LED, ok ? LOW : HIGH);
    Serial.print(cardUid); Serial.println(ok ? "  -> ACCESS GRANTED" : "  -> ACCESS DENIED");
    delay(1500);
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(RED_LED, LOW);
  }
}
