Kit 8 - Smart Systems Capstone
Project 2: RFID Access LED (Basic)

The green LED lights for the authorised UID (DE AD BE EF), the red LED for any other card.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  MFRC522 RFID Kit x1

Circuit notes:
  MFRC522: 3.3V (never 5 V!), GND, SDA(SS) -> D10, RST -> D9, SCK -> D13, MOSI -> D11, MISO -> D12
  Green LED anode -> 220 ohm -> A1, cathode -> GND
  Red LED anode -> 220 ohm -> A0, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-02-rfid-access-led
