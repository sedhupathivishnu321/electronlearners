Kit 8 - Smart Systems Capstone
Project 7: Voltage and Current Reader (Basic)

Switches the blue LED load on and prints the INA219 bus voltage, current and power. The load current flows through the INA219 shunt.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Blue x1
  INA219 Current Sensor x1

Circuit notes:
  INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k8-07-power-reader
