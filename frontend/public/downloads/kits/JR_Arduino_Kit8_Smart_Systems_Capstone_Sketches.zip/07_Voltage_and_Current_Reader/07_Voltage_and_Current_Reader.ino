// ---- Circuit (Kit 8) ----
// INA219: VCC 5V, GND, SDA -> A4, SCL -> A5; the load (D8 -> VIN+ -> VIN- -> 220 ohm -> blue LED -> GND) runs THROUGH the shunt. With the relay (project 43) D8 -> relay COM, relay NO -> VIN+
#define LOAD_PIN 8

#include <Adafruit_INA219.h>
Adafruit_INA219 ina;
float busV, mA, mW;
void readPower() {
  busV = ina.getBusVoltage_V();
  mA = ina.getCurrent_mA();
  mW = busV * mA;
}

void setup() {
  Serial.begin(9600);
  pinMode(LOAD_PIN, OUTPUT);
  digitalWrite(LOAD_PIN, HIGH);            // switch the load on
  if (!ina.begin()) Serial.println("INA219 not found - check SDA / SCL");
}

void loop() {
  readPower();
  Serial.print("Bus "); Serial.print(busV, 2); Serial.print(" V   ");
  Serial.print(mA, 1); Serial.print(" mA   ");
  Serial.print(mW, 1); Serial.println(" mW");
  delay(1000);
}
