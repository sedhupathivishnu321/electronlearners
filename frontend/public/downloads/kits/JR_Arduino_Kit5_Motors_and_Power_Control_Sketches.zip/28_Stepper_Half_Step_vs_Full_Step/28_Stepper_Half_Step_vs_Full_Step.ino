// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int FULL[4][4] = {{1,1,0,0}, {0,1,1,0}, {0,0,1,1}, {1,0,0,1}};
int HALF[8][4] = {{1,0,0,0}, {1,1,0,0}, {0,1,0,0}, {0,1,1,0}, {0,0,1,0}, {0,0,1,1}, {0,0,0,1}, {1,0,0,1}};
int pins[4];

void coils(int a, int b, int c, int d) {
  digitalWrite(pins[0], a); digitalWrite(pins[1], b); digitalWrite(pins[2], c); digitalWrite(pins[3], d);
}

void run(bool half, int steps, int wait) {
  unsigned long t0 = millis();
  for (int i = 0; i < steps; i++) {
    if (half) { int k = i % 8; coils(HALF[k][0], HALF[k][1], HALF[k][2], HALF[k][3]); }
    else { int k = i % 4; coils(FULL[k][0], FULL[k][1], FULL[k][2], FULL[k][3]); }
    delay(wait);
  }
  coils(0, 0, 0, 0);
  Serial.print(half ? "HALF-step: " : "FULL-step: "); Serial.print(steps); Serial.print(" steps in "); Serial.print(millis() - t0); Serial.println(" ms");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pins[0] = STEP_IN1; pins[1] = STEP_IN2; pins[2] = STEP_IN3; pins[3] = STEP_IN4;
  for (int i = 0; i < 4; i++) pinMode(pins[i], OUTPUT);
  Serial.begin(9600);
  Serial.println("press the button for a quarter-turn comparison");
}

void loop() {
  if (pressed()) {
    run(false, 512, 3);                        // a quarter turn = 512 full steps
    delay(500);
    run(true, 1024, 2);                        // = 1024 half steps
  }
}
