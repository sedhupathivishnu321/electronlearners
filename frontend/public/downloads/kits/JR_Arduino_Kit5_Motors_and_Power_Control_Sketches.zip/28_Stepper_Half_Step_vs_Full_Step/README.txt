Kit 5 - Motors and Power Control
Project 28: Stepper Half-Step vs Full-Step (Intermediate)

Press the button: the stepper turns a quarter revolution in FULL-step mode (512 steps) and again in HALF-step mode (1024 steps at the same coil rate) and prints how long each took. Half-stepping is smoother and twice as fine.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-28-half-vs-full
