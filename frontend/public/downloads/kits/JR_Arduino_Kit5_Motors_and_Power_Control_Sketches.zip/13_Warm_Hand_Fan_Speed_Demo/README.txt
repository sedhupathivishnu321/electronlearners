Kit 5 - Motors and Power Control
Project 13: Warm-Hand Fan Speed Demo (Intermediate)

Warm the LM35 with your hand (raise the temperature slider): the fan speeds up in five PWM steps, one per two degrees above 27 C.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  LM35 Temperature Sensor x1
  DC Motor 6V x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-13-warm-hand-fan
