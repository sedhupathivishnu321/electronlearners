// ---- Circuit (Kit 5) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define LM35_PIN A0
#define TIP_PIN 9

int level = 0;

float readTemp() {                             // average of 8 readings
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

void setup() {
  pinMode(TIP_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float t = readTemp();
  int step = constrain((int)((t - 27.0) / 2.0) + 1, 0, 5);   // 0 = off, 1..5 = five speeds
  int duty = step == 0 ? 0 : 60 + step * 39;
  analogWrite(TIP_PIN, duty);
  if (step != level) {
    level = step;
    Serial.print(t, 1); Serial.print(" C -> step "); Serial.print(step); Serial.print(" of 5, PWM "); Serial.println(duty);
  }
  delay(200);
}
