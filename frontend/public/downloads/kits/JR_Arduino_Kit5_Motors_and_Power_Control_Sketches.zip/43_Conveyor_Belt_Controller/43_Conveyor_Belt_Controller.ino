// ---- Circuit (Kit 5) ----
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define ENA 5
#define IN1 4
#define IN2 7
#define SERVO_PIN 11
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Servo.h>
Servo servo;
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}

bool running = false;
int items = 0, diverted = 0;
unsigned long lastItem = 0, divertUntil = 0;

void stopped() { motorA(0); digitalWrite(RED_LED, HIGH); digitalWrite(GREEN_LED, LOW); }

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  driverBegin();
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  stopped();
  Serial.println("belt stopped - tap = start/stop, hold = jog");
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 700) { }
    if (digitalRead(BTN1) == LOW) {                          // held: jog slowly
      Serial.println("jog");
      motorA(110); digitalWrite(GREEN_LED, HIGH);
      while (digitalRead(BTN1) == LOW) { }
      if (running) motorA(190); else stopped();
    } else {                                                 // tapped: start / stop
      running = !running;
      if (running) { motorA(190); digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH); lastItem = millis(); Serial.println("belt RUNNING"); }
      else { stopped(); Serial.print("belt STOPPED - items "); Serial.print(items); Serial.print(", diverted "); Serial.println(diverted); }
    }
    delay(40);
  }
  if (running && millis() - lastItem >= 2500) {
    lastItem = millis();
    items++;
    Serial.print("item "); Serial.println(items);
    if (items % 3 == 0) { servo.write(30); divertUntil = millis() + 1000; diverted++; Serial.println("diverter: push item off the belt"); }
  }
  if (divertUntil > 0 && millis() > divertUntil) { servo.write(90); divertUntil = 0; }
}
