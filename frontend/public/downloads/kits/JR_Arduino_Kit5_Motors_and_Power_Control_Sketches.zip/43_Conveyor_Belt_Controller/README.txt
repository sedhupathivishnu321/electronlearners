Kit 5 - Motors and Power Control
Project 43: Conveyor Belt Controller (Advanced)

A tap starts / stops the BO-motor belt (green running, red stopped); holding the button jogs the belt slowly. While running an "item" arrives every 2.5 s and is counted; every third item the servo diverter swings across for a second.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  SG90 Micro Servo x1
  Motor Driver Module L298N x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-43-conveyor
