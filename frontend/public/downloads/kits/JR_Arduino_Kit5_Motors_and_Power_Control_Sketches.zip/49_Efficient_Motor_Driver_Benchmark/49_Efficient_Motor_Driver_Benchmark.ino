// ---- Circuit (Kit 5) ----
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
// L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// Motor-node monitor: 10k + 10k divider from the switched (low-side) motor terminal to A0 (A0 reads half of that voltage)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define TIP_PIN 9
#define MOS_PIN 10
#define L293_EN 6
#define L293_1A A1
#define L293_2A A2
#define ENA 5
#define IN1 4
#define IN2 7
#define VSENSE_PIN A0

float supplyVolts() {                       // the 10k + 10k divider halves the voltage
  return analogRead(VSENSE_PIN) * 5.0 / 1023.0 * 2.0;
}

#define PACK_V 6.0

void drive(int id, bool on) {
  if (id == 0) digitalWrite(TIP_PIN, on);
  if (id == 1) digitalWrite(MOS_PIN, on);
  if (id == 2) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); digitalWrite(L293_EN, on); }   // output 1Y pulls the motor low
  if (id == 3) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); digitalWrite(ENA, on); }               // OUT1 pulls the motor low
}

String name(int id) { if (id == 0) return "TIP122 "; if (id == 1) return "IRFZ44N"; if (id == 2) return "L293D  "; return "L298N  "; }

void setup() {
  pinMode(TIP_PIN, OUTPUT); pinMode(MOS_PIN, OUTPUT);
  pinMode(L293_EN, OUTPUT); pinMode(L293_1A, OUTPUT); pinMode(L293_2A, OUTPUT);
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  for (int i = 0; i < 4; i++) drive(i, false);
  Serial.begin(9600);
  Serial.println("driver benchmark: voltage lost across each switch with the same motor");
}

void loop() {
  float loss[4];
  for (int id = 0; id < 4; id++) {
    drive(id, true);
    delay(1100);
    float sum = 0;
    for (int i = 0; i < 20; i++) { sum += supplyVolts(); delay(10); }
    drive(id, false);
    loss[id] = sum / 20;
    Serial.print(name(id)); Serial.print(": "); Serial.print(loss[id], 2); Serial.print(" V lost, motor gets about "); Serial.print(PACK_V - loss[id], 2); Serial.println(" V");
    delay(700);
  }
  int best = 0;
  for (int i = 1; i < 4; i++) if (loss[i] < loss[best]) best = i;
  Serial.print("most efficient: "); Serial.println(name(best));
  Serial.println("----");
  delay(2500);
}
