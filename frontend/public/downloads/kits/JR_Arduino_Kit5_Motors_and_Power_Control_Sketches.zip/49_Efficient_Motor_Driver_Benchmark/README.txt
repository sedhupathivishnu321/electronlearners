Kit 5 - Motors and Power Control
Project 49: Efficient Motor Driver Benchmark (Advanced)

Four drivers share one motor, each used as a low-side switch. One after the other they switch it fully on while the divider measures the voltage lost across the switch: the lower the loss, the more of the 6 V reaches the motor. A ranking is printed. (The kit has no tachometer, so delivered voltage replaces measured speed.)

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x2
  TIP122 Darlington x1
  Diode 1N4007 x1
  MOSFET IRFZ44N x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x2
  Motor Driver L293D x1
  Motor Driver Module L298N x1
  DC Motor 6V x1

Circuit notes:
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
  L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  Motor-node monitor: 10k + 10k divider from the switched (low-side) motor terminal to A0 (A0 reads half of that voltage)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-49-driver-benchmark
