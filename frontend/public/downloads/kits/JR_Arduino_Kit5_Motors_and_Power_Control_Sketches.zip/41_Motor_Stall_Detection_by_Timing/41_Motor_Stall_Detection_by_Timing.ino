// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define TIP_PIN 9
#define BTN1 2
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define STARTUP_MS 2500UL
#define STALL_MS 1500UL
int state = 0;                                 // 0 idle, 1 running, 2 stalled
unsigned long lastPulse = 0;
int pulses = 0;

void powerOff() {
  digitalWrite(TIP_PIN, LOW);
  delay(100);
  digitalWrite(RELAY_PIN, RELAY_OFF);          // open the supply only after the transistor is off
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(TIP_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  Serial.println("press to start, then tap once per revolution");
}

void loop() {
  if (pressed()) {
    if (state == 0) {
      digitalWrite(RELAY_PIN, RELAY_ON); delay(150);
      digitalWrite(TIP_PIN, HIGH);
      state = 1; pulses = 0; lastPulse = millis();
      Serial.println("motor started");
    } else if (state == 1) {
      pulses++; lastPulse = millis();
      Serial.print("revolution "); Serial.println(pulses);
    } else {
      state = 0; digitalWrite(RED_LED, LOW);
      Serial.println("fault cleared - idle");
    }
  }
  if (state == 1) {
    unsigned long limit = (pulses == 0) ? STARTUP_MS : STALL_MS;
    if (millis() - lastPulse > limit) {
      powerOff();
      state = 2;
      digitalWrite(RED_LED, HIGH);
      Serial.println("STALL detected - power cut");
    }
  }
}
