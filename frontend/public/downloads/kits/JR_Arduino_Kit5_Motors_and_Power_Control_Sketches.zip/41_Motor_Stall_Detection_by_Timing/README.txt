Kit 5 - Motors and Power Control
Project 41: Motor Stall Detection by Timing (Advanced)

The kit has no speed sensor, so the button stands in for a rotation switch: press it to start the motor, then keep tapping it once per "revolution". If no tap arrives within 1.5 s (2.5 s at start-up) the motor is judged stalled and power is cut through the TIP122 and the relay (red). A press clears the fault.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Relay Module 1 Channel 5V x1
  DC Motor 6V x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-41-stall-detection
