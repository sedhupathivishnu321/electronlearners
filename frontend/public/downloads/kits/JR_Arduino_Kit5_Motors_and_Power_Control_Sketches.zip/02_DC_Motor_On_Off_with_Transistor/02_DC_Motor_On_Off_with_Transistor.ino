// ---- Circuit (Kit 5) ----
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define TIP_PIN 9
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool motorOn = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(TIP_PIN, OUTPUT);
  digitalWrite(TIP_PIN, LOW);
  Serial.begin(9600);
  Serial.println("press the button to switch the motor");
}

void loop() {
  if (pressed()) {
    motorOn = !motorOn;
    digitalWrite(TIP_PIN, motorOn);
    Serial.println(motorOn ? "motor ON" : "motor OFF");
  }
}
