Kit 5 - Motors and Power Control
Project 2: DC Motor On/Off with Transistor (Basic)

The button toggles the 6 V motor through a TIP122. The Uno pin only supplies a few mA of base current; the 1N4007 absorbs the spike when the motor is switched off.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  DC Motor 6V x1

Circuit notes:
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-02-tip122-switch
