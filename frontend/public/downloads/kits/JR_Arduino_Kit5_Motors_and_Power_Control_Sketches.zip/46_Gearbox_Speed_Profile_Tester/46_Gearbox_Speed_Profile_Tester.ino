// ---- Circuit (Kit 5) ----
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define ENA 5
#define IN1 4
#define IN2 7
#define ENB 6
#define IN3 12
#define IN4 13
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}
void motorB(int speed) {                    // same for channel B
  if (speed > 0) { digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW); }
  else if (speed < 0) { digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH); }
  else { digitalWrite(IN3, LOW); digitalWrite(IN4, LOW); }
  analogWrite(ENB, abs(speed));
}
void driverBBegin() {
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  motorB(0);
}

int profile = 0;

int shape(int p, float t) {                      // t = 0..1 through the run -> PWM 0..255
  if (p == 0) return (int)(255 * t);                                       // linear ramp
  if (p == 1) return (int)(255 * t * t * (3.0 - 2.0 * t));                  // S-curve (smoothstep)
  if (p == 2) return t < 0.33 ? 85 : (t < 0.66 ? 170 : 255);                // three steps
  if (t < 0.25) return (int)(255 * t / 0.25);                              // trapezoid: up, hold, down
  if (t < 0.75) return 255;
  return (int)(255 * (1.0 - t) / 0.25);
}

String name(int p) { if (p == 0) return "LINEAR"; if (p == 1) return "S-CURVE"; if (p == 2) return "STEPS"; return "TRAPEZOID"; }

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  driverBegin(); driverBBegin();
  Serial.begin(9600);
  Serial.println("press the button to run the next profile");
}

void loop() {
  if (pressed()) {
    Serial.print("profile "); Serial.println(name(profile));
    unsigned long t0 = millis();
    unsigned long lastPrint = 0;
    while (millis() - t0 < 4000) {
      float t = (millis() - t0) / 4000.0;
      int pwm = shape(profile, t);
      motorA(pwm); motorB(pwm);
      if (millis() - lastPrint >= 400) { lastPrint = millis(); Serial.print("  t "); Serial.print((millis() - t0) / 100 / 10.0, 1); Serial.print(" s  PWM "); Serial.println(pwm); }
      delay(20);
    }
    motorA(0); motorB(0);
    Serial.println("done");
    profile = (profile + 1) % 4;
  }
}
