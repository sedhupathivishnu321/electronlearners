Kit 5 - Motors and Power Control
Project 46: Gearbox Speed Profile Tester (Advanced)

Each press runs both motors (DC on channel A, BO gear motor on B) through the next 4 s speed profile: LINEAR ramp, S-CURVE, STEPS or TRAPEZOID. The PWM values are printed so you can compare how gently each profile loads the gearbox.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Motor Driver Module L298N x1
  DC Motor 6V x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-46-speed-profiles
