// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define LM35_PIN A0

#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)

long posSteps = 0;
unsigned long lastPrint = 0;

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

void setup() {
  stepper.setSpeed(12);
  Serial.begin(9600);
}

void loop() {
  float t = readTemp();
  float deg = constrain((t - 20.0) * 270.0 / 20.0, 0, 270);
  long target = (long)(deg * 2048.0 / 360.0);
  if (abs(target - posSteps) > 12) {                         // ignore tiny changes: no jitter
    stepper.step(target - posSteps);
    posSteps = target;
    Serial.print(t, 1); Serial.print(" C -> pointer at "); Serial.print(deg, 0); Serial.println(" degrees");
  }
  delay(200);
}
