Kit 5 - Motors and Power Control
Project 22: Stepper Dial Pointer (Intermediate)

The stepper turns a dial pointer to show the LM35 temperature: 20 C = 0 degrees, 40 C = 270 degrees.

Parts:
  AA 4-cell Battery Holder x1
  28BYJ-48 Stepper + ULN2003 x1
  LM35 Temperature Sensor x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-22-stepper-dial
