Kit 5 - Motors and Power Control
Project 23: PWM Brake and Coast Comparison (Intermediate)

The motor runs for 2 s, then stops either by COASTING (enable low, outputs off) or by BRAKING (enable high, both outputs low, the motor shorts itself). A press chooses the mode. A real motor coasts for a while but stops almost at once when braked.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Motor Driver L293D x1
  DC Motor 6V x1

Circuit notes:
  L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-23-brake-coast
