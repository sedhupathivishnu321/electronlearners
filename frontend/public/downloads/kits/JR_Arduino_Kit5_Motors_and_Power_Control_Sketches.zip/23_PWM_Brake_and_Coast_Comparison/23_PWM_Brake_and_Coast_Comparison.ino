// ---- Circuit (Kit 5) ----
// L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define L293_EN 6
#define L293_1A A1
#define L293_2A A2
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motor293(int speed) {                  // -255 .. 255 ; EN1,2 carries the PWM
  if (speed > 0) { digitalWrite(L293_1A, HIGH); digitalWrite(L293_2A, LOW); }
  else if (speed < 0) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, HIGH); }
  else { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); }
  analogWrite(L293_EN, abs(speed));
}
void l293Begin() {
  pinMode(L293_EN, OUTPUT); pinMode(L293_1A, OUTPUT); pinMode(L293_2A, OUTPUT);
  motor293(0);
}

bool brake = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  l293Begin();
  Serial.begin(9600);
  Serial.println("stop mode: COAST (press the button to change)");
}

void loop() {
  if (pressed()) { brake = !brake; Serial.println(brake ? "stop mode: BRAKE" : "stop mode: COAST"); }
  Serial.println("run");
  motor293(255);
  unsigned long t0 = millis();
  while (millis() - t0 < 2000) { if (pressed()) { brake = !brake; Serial.println(brake ? "stop mode: BRAKE" : "stop mode: COAST"); } }
  if (brake) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); digitalWrite(L293_EN, HIGH); Serial.println("braking"); }
  else { motor293(0); Serial.println("coasting"); }
  t0 = millis();
  while (millis() - t0 < 2500) { if (pressed()) { brake = !brake; Serial.println(brake ? "stop mode: BRAKE" : "stop mode: COAST"); } }
}
