// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define SERVO_PIN 11
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int WAYPOINTS[5] = {20, 150, 60, 120, 90};
#define MOVE_MS 1200

bool running = false;
int target = 0;
float fromAngle = 90;
unsigned long moveStart = 0;
float current = 90;

float sCurve(float t) {                          // smoothstep: zero speed at both ends
  return t * t * (3.0 - 2.0 * t);
}

void startMove() {
  fromAngle = current;
  moveStart = millis();
  Serial.print("-> waypoint "); Serial.print(target + 1); Serial.print(": "); Serial.print(WAYPOINTS[target]); Serial.println(" degrees");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  Serial.println("press the button to start / pause");
}

void loop() {
  if (pressed()) {
    running = !running;
    if (running) startMove();
    Serial.println(running ? "running" : "paused");
  }
  digitalWrite(GREEN_LED, running);
  digitalWrite(RED_LED, !running);
  if (running) {
    float t = (millis() - moveStart) / (float)MOVE_MS;
    if (t >= 1) {
      current = WAYPOINTS[target];
      servo.write((int)current);
      target = (target + 1) % 5;
      startMove();
    } else {
      current = fromAngle + (WAYPOINTS[target] - fromAngle) * sCurve(t);
      servo.write((int)current);
    }
    delay(15);
  }
}
