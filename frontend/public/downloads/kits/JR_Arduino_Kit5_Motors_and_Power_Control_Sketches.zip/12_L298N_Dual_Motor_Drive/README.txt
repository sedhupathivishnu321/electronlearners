Kit 5 - Motors and Power Control
Project 12: L298N Dual Motor Drive (Intermediate)

Channel A (DC motor) ramps up while channel B (BO motor) ramps down, then they swap directions - speed and direction are independent.

Parts:
  AA 4-cell Battery Holder x1
  Motor Driver Module L298N x1
  DC Motor 6V x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-12-l298n-dual
