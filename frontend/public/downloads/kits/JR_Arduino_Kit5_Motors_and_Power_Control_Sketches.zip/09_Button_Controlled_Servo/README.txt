Kit 5 - Motors and Power Control
Project 9: Button-Controlled Servo (Basic)

Each button press steps the servo by 30 degrees; after 180 it returns to 0.

Parts:
  Push Button tactile 6x6 x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-09-button-servo
