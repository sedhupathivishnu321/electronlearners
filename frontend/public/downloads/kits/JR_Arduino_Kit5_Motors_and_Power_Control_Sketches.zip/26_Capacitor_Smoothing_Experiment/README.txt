Kit 5 - Motors and Power Control
Project 26: Capacitor Smoothing Experiment (Intermediate)

Starts and stops the motor five times and prints the lowest pack voltage seen in each start-up. Delete the purple capacitor jumpers and run again to compare how much the supply dips without the 100 uF capacitor.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x2
  DC Motor 6V x1

Circuit notes:
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Supply monitor: 10k + 10k divider from the +6V rail to A0 (A0 reads half of the supply voltage)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-26-cap-smoothing
