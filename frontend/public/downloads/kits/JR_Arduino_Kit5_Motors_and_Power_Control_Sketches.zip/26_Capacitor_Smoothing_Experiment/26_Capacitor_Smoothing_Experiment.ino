// ---- Circuit (Kit 5) ----
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Supply monitor: 10k + 10k divider from the +6V rail to A0 (A0 reads half of the supply voltage)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define TIP_PIN 9
#define VSENSE_PIN A0

float supplyVolts() {                       // the 10k + 10k divider halves the voltage
  return analogRead(VSENSE_PIN) * 5.0 / 1023.0 * 2.0;
}

void setup() {
  pinMode(TIP_PIN, OUTPUT);
  Serial.begin(9600);
  Serial.print("idle supply "); Serial.print(supplyVolts(), 2); Serial.println(" V");
}

void loop() {
  for (int run = 1; run <= 5; run++) {
    digitalWrite(TIP_PIN, HIGH);                                           // hard start: full voltage at once
    float lowest = 99, sum = 0;
    int n = 0;
    unsigned long t0 = millis();
    while (millis() - t0 < 700) {
      float v = supplyVolts();
      if (v < lowest) lowest = v;
      sum += v; n++;
    }
    Serial.print("start "); Serial.print(run); Serial.print(": lowest "); Serial.print(lowest, 2);
    Serial.print(" V, average "); Serial.print(sum / n, 2); Serial.println(" V");
    digitalWrite(TIP_PIN, LOW);
    delay(1200);
  }
  Serial.println("--- series finished, repeating ---");
  delay(2000);
}
