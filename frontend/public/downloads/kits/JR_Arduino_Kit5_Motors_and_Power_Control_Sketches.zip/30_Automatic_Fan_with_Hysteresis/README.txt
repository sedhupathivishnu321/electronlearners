Kit 5 - Motors and Power Control
Project 30: Automatic Fan with Hysteresis (Intermediate)

The relay switches the fan on above 30 C and off below 27 C. The 3 degree dead band stops the relay chattering around a single threshold. Green = temperature OK, red = fan running.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Relay Module 1 Channel 5V x1
  LM35 Temperature Sensor x1
  DC Motor 6V x1
  Diode 1N4007 x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-30-hysteresis-fan
