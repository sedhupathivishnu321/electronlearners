// ---- Circuit (Kit 5) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define LM35_PIN A0
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define GREEN_LED A5
#define RED_LED 3

bool fanOn = false;
unsigned long lastPrint = 0;

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

void setFan(bool on) {
  fanOn = on;
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, on);
  digitalWrite(GREEN_LED, !on);
  Serial.println(on ? "FAN ON  (above 30 C)" : "FAN OFF (below 27 C)");
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  setFan(false);
}

void loop() {
  float t = readTemp();
  if (!fanOn && t > 30.0) setFan(true);
  if (fanOn && t < 27.0) setFan(false);
  if (millis() - lastPrint > 1000) { lastPrint = millis(); Serial.print("temperature "); Serial.print(t, 1); Serial.println(" C"); }
  delay(100);
}
