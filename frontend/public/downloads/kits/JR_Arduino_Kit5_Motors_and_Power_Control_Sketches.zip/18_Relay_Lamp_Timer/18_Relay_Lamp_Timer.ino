// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define ON_MS 6000UL
bool lampOn = false;
unsigned long startedAt = 0, lastPrint = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    startedAt = millis();
    if (!lampOn) { lampOn = true; digitalWrite(RELAY_PIN, RELAY_ON); Serial.println("lamp ON"); }
    else Serial.println("timer restarted");
  }
  if (lampOn) {
    unsigned long left = ON_MS - (millis() - startedAt);
    if (millis() - startedAt >= ON_MS) { lampOn = false; digitalWrite(RELAY_PIN, RELAY_OFF); Serial.println("lamp OFF"); }
    else if (millis() - lastPrint >= 1000) { lastPrint = millis(); Serial.print("off in "); Serial.print(left / 1000 + 1); Serial.println(" s"); }
  }
}
