// ---- Circuit (Kit 5) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define LM35_PIN A0
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define TIP_PIN 9
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define SETPOINT 25.0
#define BAND 1.0
int mode = 0;                                   // 0 AUTO, 1 HEAT only, 2 COOL only, 3 OFF
bool heater = false, fan = false;
unsigned long lastPrint = 0;

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

String modeName() { if (mode == 0) return "AUTO"; if (mode == 1) return "HEAT only"; if (mode == 2) return "COOL only"; return "OFF"; }

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(TIP_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("mode AUTO");
}

void loop() {
  if (pressed()) { mode = (mode + 1) % 4; Serial.print("mode "); Serial.println(modeName()); }
  float t = readTemp();
  bool heatOk = (mode == 0 || mode == 1), coolOk = (mode == 0 || mode == 2);
  if (heatOk) { if (!heater && t < SETPOINT - BAND) { heater = true; Serial.println("heater ON"); } if (heater && t >= SETPOINT) { heater = false; Serial.println("heater OFF"); } }
  else heater = false;
  if (coolOk) { if (!fan && t > SETPOINT + BAND) { fan = true; Serial.println("fan ON"); } if (fan && t <= SETPOINT) { fan = false; Serial.println("fan OFF"); } }
  else fan = false;
  digitalWrite(RELAY_PIN, heater ? RELAY_ON : RELAY_OFF);
  analogWrite(TIP_PIN, fan ? constrain(100 + (int)((t - SETPOINT) * 40), 100, 255) : 0);
  digitalWrite(GREEN_LED, !heater && !fan);
  digitalWrite(RED_LED, heater || fan);
  if (millis() - lastPrint > 1500) { lastPrint = millis(); Serial.print(t, 1); Serial.print(" C  "); Serial.print(modeName()); Serial.print("  heater "); Serial.print(heater ? "on" : "off"); Serial.print("  fan "); Serial.println(fan ? "on" : "off"); }
}
