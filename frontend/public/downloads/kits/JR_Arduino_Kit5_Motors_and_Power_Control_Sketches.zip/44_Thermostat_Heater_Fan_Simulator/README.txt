Kit 5 - Motors and Power Control
Project 44: Thermostat Heater/Fan Simulator (Advanced)

Setpoint 25 C with a +/-1 C dead band. The relay (red lamp) is the heater, the motor on the TIP122 is the fan, speed rising with the excess temperature. The button cycles the mode AUTO / HEAT only / COOL only / OFF. Green = in band and idle, red = something is running.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x4
  LED 5mm Red x2
  LED 5mm Green x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Relay Module 1 Channel 5V x1
  LM35 Temperature Sensor x1
  DC Motor 6V x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-44-thermostat
