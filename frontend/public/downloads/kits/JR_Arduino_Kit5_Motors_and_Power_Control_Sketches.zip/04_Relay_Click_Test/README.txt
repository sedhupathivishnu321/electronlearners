Kit 5 - Motors and Power Control
Project 4: Relay Click Test (Basic)

The button toggles the relay (listen for the click, watch the board LED). The red LED on the relay contacts shows the switched circuit.

Parts:
  Push Button tactile 6x6 x1
  Relay Module 1 Channel 5V x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-04-relay-click
