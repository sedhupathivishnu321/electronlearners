// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool relayOn = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);                        // set the level first so the relay does not click at start-up
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    relayOn = !relayOn;
    digitalWrite(RELAY_PIN, relayOn ? RELAY_ON : RELAY_OFF);
    Serial.println(relayOn ? "relay ON  - contacts closed" : "relay OFF - contacts open");
  }
}
