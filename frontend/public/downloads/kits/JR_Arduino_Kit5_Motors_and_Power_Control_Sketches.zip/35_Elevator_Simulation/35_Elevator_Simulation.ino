// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define SERVO_PIN 11
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Servo.h>
Servo servo;
#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define FLOOR_STEPS 600
int queue[4];
int qLen = 0, floorNow = 0, taps = 0;
long carPos = 0;
unsigned long lastTap = 0;

void enqueue(int f) {
  if (qLen < 4 && f != floorNow) { queue[qLen] = f; qLen++; Serial.print("call: floor "); Serial.println(f + 1); }
}

void door(bool open) {
  servo.write(open ? 90 : 0);
  digitalWrite(GREEN_LED, open);
  delay(900);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(0);
  stepper.setSpeed(14);
  Serial.begin(9600);
  Serial.println("car at floor 1 - tap the button 1, 2 or 3 times to call a floor");
}

void loop() {
  if (pressed()) { taps++; lastTap = millis(); }
  if (taps > 0 && millis() - lastTap > 700) { enqueue(constrain(taps, 1, 3) - 1); taps = 0; }
  if (qLen > 0) {
    int target = queue[0];
    digitalWrite(RED_LED, HIGH);                                             // moving: interlock holds the door shut
    long goal = (long)target * FLOOR_STEPS;
    while (carPos != goal) {
      long chunk = goal > carPos ? 30 : -30;
      if (abs(goal - carPos) < 30) chunk = goal - carPos;
      stepper.step(chunk);
      carPos += chunk;
      if (pressed()) { taps++; lastTap = millis(); }                          // calls can be added while moving
    }
    digitalWrite(RED_LED, LOW);
    floorNow = target;
    for (int i = 1; i < qLen; i++) queue[i - 1] = queue[i];
    qLen--;
    Serial.print("arrived at floor "); Serial.println(floorNow + 1);
    door(true);
    delay(1500);
    door(false);
    Serial.println("door closed");
  }
}
