// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define BTN1 2
#define GREEN_LED A5

#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
#include <EEPROM.h>

// EEPROM map: 0 = 0xA5 marker, 1..4 = position in steps (32-bit)
long posSteps = 0;

void savePos() {
  EEPROM.write(0, 0xA5);
  for (int i = 0; i < 4; i++) EEPROM.write(1 + i, (posSteps >> (8 * i)) & 255);
}

void loadPos() {
  if (EEPROM.read(0) != 0xA5) { Serial.println("first start - position unknown, assuming home"); posSteps = 0; return; }
  posSteps = 0;
  for (int i = 3; i >= 0; i--) posSteps = (posSteps << 8) | EEPROM.read(1 + i);
  Serial.print("restored position from EEPROM: "); Serial.print(posSteps); Serial.print(" steps ("); Serial.print(posSteps * 360 / 2048); Serial.println(" degrees)");
}

void report() {
  digitalWrite(GREEN_LED, posSteps == 0);
  Serial.print("position "); Serial.print(posSteps); Serial.print(" steps ("); Serial.print(posSteps * 360 / 2048); Serial.println(" degrees)");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  stepper.setSpeed(14);
  Serial.begin(9600);
  loadPos();
  digitalWrite(GREEN_LED, posSteps == 0);
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 1000) { }
    if (digitalRead(BTN1) == LOW) {                          // held: set home
      posSteps = 0; savePos(); report(); Serial.println("home set and saved");
      while (digitalRead(BTN1) == LOW) { }
    } else {                                                 // tapped: move and remember
      stepper.step(256);
      posSteps += 256;
      savePos();
      report();
    }
    delay(40);
  }
}
