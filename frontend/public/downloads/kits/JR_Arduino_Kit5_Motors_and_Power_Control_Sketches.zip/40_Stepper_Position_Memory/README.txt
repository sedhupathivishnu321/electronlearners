Kit 5 - Motors and Power Control
Project 40: Stepper Position Memory (Advanced)

A tap moves the stepper 256 steps; holding the button for 1 s sets "home" (position 0, green LED). The position is stored in EEPROM after every move and restored at the next start-up, so power cuts do not lose it.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
  EEPROM map: 0 = 0xA5 marker, 1..4 = position in steps (32-bit)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-40-stepper-memory
