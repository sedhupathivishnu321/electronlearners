// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)

#define TRAVEL 4096L
long pos = 0;
int preset = 0, dir = 1;

int percent() { return pos * 100 / TRAVEL; }

void report() {
  Serial.print("blind at "); Serial.print(percent()); Serial.println(" %");
}

void moveTo(long target) {
  digitalWrite(RED_LED, HIGH); digitalWrite(GREEN_LED, LOW);
  while (pos != target) {
    long chunk = target - pos;
    if (chunk > 64) chunk = 64;
    if (chunk < -64) chunk = -64;
    stepper.step(chunk);
    pos += chunk;
  }
  digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH);
  report();
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  stepper.setSpeed(15);
  Serial.begin(9600);
  digitalWrite(GREEN_LED, HIGH);
  Serial.println("blind at 0 % (open) - tap = next preset, hold = manual");
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 600) { }
    if (digitalRead(BTN1) == LOW) {                          // held: manual override
      Serial.println(dir > 0 ? "manual: closing" : "manual: opening");
      digitalWrite(RED_LED, HIGH); digitalWrite(GREEN_LED, LOW);
      while (digitalRead(BTN1) == LOW) {
        if ((dir > 0 && pos < TRAVEL) || (dir < 0 && pos > 0)) { stepper.step(dir * 32); pos += dir * 32; }
      }
      pos = constrain(pos, 0, TRAVEL);
      dir = -dir;
      preset = (pos * 4 + TRAVEL / 2) / TRAVEL;
      digitalWrite(RED_LED, LOW); report();
    } else {                                                 // tapped: next preset
      preset = (preset + 1) % 5;
      moveTo(preset * (TRAVEL / 4));
    }
    delay(40);
  }
}
