Kit 5 - Motors and Power Control
Project 45: Window Blind Controller (Advanced)

The stepper winds the blind between 0 % (open) and 100 % (closed), 4096 steps in all. A tap goes to the next preset (0, 25, 50, 75, 100 %, then back to 0); holding the button is the manual override and runs the blind continuously, reversing direction on every hold. Red = moving, green = at a preset.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-45-window-blind
