Kit 5 - Motors and Power Control
Project 15: Servo Gate (Intermediate)

A press opens the gate (90 degrees, green); it closes by itself 4 s later (red).

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-15-servo-gate
