// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define SERVO_PIN 11
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool open = false;
unsigned long openedAt = 0;

void setGate(bool o) {
  open = o;
  servo.write(o ? 90 : 0);
  digitalWrite(GREEN_LED, o);
  digitalWrite(RED_LED, !o);
  Serial.println(o ? "gate OPEN" : "gate CLOSED");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  setGate(false);
}

void loop() {
  if (pressed()) { if (!open) setGate(true); openedAt = millis(); }     // a press while open restarts the timer
  if (open && millis() - openedAt >= 4000) setGate(false);
}
