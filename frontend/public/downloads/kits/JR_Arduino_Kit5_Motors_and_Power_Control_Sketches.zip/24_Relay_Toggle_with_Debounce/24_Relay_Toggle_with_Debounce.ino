// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

bool relayOn = false;
int stable = HIGH, lastRead = HIGH;
unsigned long changedAt = 0;

void show() {
  digitalWrite(RELAY_PIN, relayOn ? RELAY_ON : RELAY_OFF);
  digitalWrite(GREEN_LED, relayOn);
  digitalWrite(RED_LED, !relayOn);
  Serial.println(relayOn ? "relay ON" : "relay OFF");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  show();
}

void loop() {
  int r = digitalRead(BTN1);
  if (r != lastRead) { lastRead = r; changedAt = millis(); }               // any change restarts the settle timer
  if (millis() - changedAt > 30 && r != stable) {                          // steady for 30 ms: accept it
    stable = r;
    if (stable == LOW) { relayOn = !relayOn; show(); }
  }
}
