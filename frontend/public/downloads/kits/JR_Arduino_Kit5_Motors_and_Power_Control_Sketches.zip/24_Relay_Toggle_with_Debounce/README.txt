Kit 5 - Motors and Power Control
Project 24: Relay Toggle with Debounce (Intermediate)

One button latches the relay on and off. Contact bounce is filtered; green = relay on, red = relay off.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-24-relay-latch
