// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH

bool on = false;

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  Serial.println("Without a flyback diode the motor coil would spike to many times the supply voltage when the relay opens.");
}

void loop() {
  on = !on;
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
  Serial.println(on ? "relay closes: motor runs" : "relay opens: the 1N4007 carries the coil current (spike clamped to about 0.7 V)");
  delay(2000);
}
