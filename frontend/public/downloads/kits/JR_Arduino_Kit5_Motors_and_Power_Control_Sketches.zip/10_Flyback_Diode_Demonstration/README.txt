Kit 5 - Motors and Power Control
Project 10: Flyback Diode Demonstration (Basic)

The relay switches the motor supply on and off every 2 s. The 1N4007 across the motor gives the coil current a path when the contacts open; unplug its jumper to see why it matters on real hardware (the simulator does not model the voltage spike).

Parts:
  AA 4-cell Battery Holder x1
  Relay Module 1 Channel 5V x1
  DC Motor 6V x1
  Diode 1N4007 x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-10-flyback-demo
