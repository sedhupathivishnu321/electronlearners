// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define SERVO_PIN 11
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2

#include <Servo.h>
Servo servo;
#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define PICK_STEPS 512                         // quarter turn
#define PLACE_STEPS 1024                       // half turn
#define GRIP_OPEN 110
#define GRIP_CLOSED 40
int armPos = 0;

void armTo(long steps, String name) {
  Serial.print("arm -> "); Serial.println(name);
  stepper.step(steps - armPos);
  armPos = steps;
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(GRIP_OPEN);
  stepper.setSpeed(14);
  Serial.begin(9600);
  Serial.println("press the button to run a pick-and-place cycle");
}

void loop() {
  if (pressed()) {
    armTo(PICK_STEPS, "pick point");
    Serial.println("gripper closes"); servo.write(GRIP_CLOSED); delay(700);
    Serial.println("magnet ON"); digitalWrite(RELAY_PIN, RELAY_ON); delay(300);
    armTo(PLACE_STEPS, "place point");
    Serial.println("gripper opens"); servo.write(GRIP_OPEN); delay(700);
    Serial.println("magnet OFF"); digitalWrite(RELAY_PIN, RELAY_OFF); delay(300);
    armTo(0, "home");
    Serial.println("cycle complete");
  }
}
