Kit 5 - Motors and Power Control
Project 34: Stepper Pick-and-Place Model (Advanced)

A press runs the whole cycle: stepper swings the arm to the pick point, the servo gripper closes, the relay switches the "electromagnet" lamp on, the arm swings to the place point, the gripper opens, the magnet goes off and the arm returns home.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  SG90 Micro Servo x1
  28BYJ-48 Stepper + ULN2003 x1
  Relay Module 1 Channel 5V x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Yellow x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-34-pick-and-place
