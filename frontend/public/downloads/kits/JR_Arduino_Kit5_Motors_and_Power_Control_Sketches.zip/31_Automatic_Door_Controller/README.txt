Kit 5 - Motors and Power Control
Project 31: Automatic Door Controller (Advanced)

State machine: the button starts a cycle - stepper bolt retracts, servo door opens, holds 3 s (a press extends the hold), closes, bolt locks. If the door has been open for 15 s in total, a safety timeout forces it shut and latches a fault (red blinks; press to clear).

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  SG90 Micro Servo x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-31-door-controller
