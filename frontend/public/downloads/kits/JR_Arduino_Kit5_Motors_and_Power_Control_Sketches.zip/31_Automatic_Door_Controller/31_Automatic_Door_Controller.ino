// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define SERVO_PIN 11
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Servo.h>
Servo servo;
#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define HOLD_MS 3000UL
#define SAFETY_MS 15000UL
int state = 0;                                 // 0 locked, 1 unbolting, 2 opening, 3 open, 4 closing, 5 bolting, 6 fault
int angle = 0;
unsigned long openSince = 0, holdUntil = 0;

void setState(int s, String msg) { state = s; Serial.println(msg); }

void moveDoor(int target) {
  while (angle != target) {
    angle += (target > angle) ? 3 : -3;
    if (abs(angle - target) < 3) angle = target;
    servo.write(angle);
    delay(20);
  }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(0);
  stepper.setSpeed(14);
  Serial.begin(9600);
  Serial.println("door locked - press the button");
}

void loop() {
  digitalWrite(RED_LED, state == 0 || state == 5 ? HIGH : (state == 6 ? (millis() / 200) % 2 : LOW));
  digitalWrite(GREEN_LED, state == 3);
  if (state == 0 && pressed()) setState(1, "bolt retracting");
  else if (state == 1) { stepper.step(-512); setState(2, "door opening"); }
  else if (state == 2) { moveDoor(90); openSince = millis(); holdUntil = millis() + HOLD_MS; setState(3, "door open"); }
  else if (state == 3) {
    if (pressed()) { holdUntil = millis() + HOLD_MS; Serial.println("hold extended"); }
    if (millis() - openSince > SAFETY_MS) { setState(4, "SAFETY TIMEOUT - forcing the door shut"); openSince = 1; }
    else if (millis() > holdUntil) setState(4, "door closing");
  }
  else if (state == 4) { moveDoor(0); setState(openSince == 1 ? 6 : 5, openSince == 1 ? "FAULT latched - press to clear" : "bolt locking"); }
  else if (state == 5) { stepper.step(512); setState(0, "door locked"); }
  else if (state == 6 && pressed()) { openSince = 0; setState(5, "fault cleared - bolting"); }
}
