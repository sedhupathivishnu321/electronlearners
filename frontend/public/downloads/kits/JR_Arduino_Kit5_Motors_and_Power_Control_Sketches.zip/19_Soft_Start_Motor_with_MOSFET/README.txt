Kit 5 - Motors and Power Control
Project 19: Soft-Start Motor with MOSFET (Intermediate)

The IRFZ44N ramps the motor up over 3 s, runs it, then ramps down. The 10k+10k divider reports the pack voltage; the 100 uF capacitor and the flyback diode protect the supply.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x1
  MOSFET IRFZ44N x1
  Diode 1N4007 x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x2
  DC Motor 6V x1

Circuit notes:
  IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Supply monitor: 10k + 10k divider from the +6V rail to A0 (A0 reads half of the supply voltage)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-19-soft-start-mosfet
