// ---- Circuit (Kit 5) ----
// IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Supply monitor: 10k + 10k divider from the +6V rail to A0 (A0 reads half of the supply voltage)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define MOS_PIN 10
#define VSENSE_PIN A0

float supplyVolts() {                       // the 10k + 10k divider halves the voltage
  return analogRead(VSENSE_PIN) * 5.0 / 1023.0 * 2.0;
}

void setup() {
  pinMode(MOS_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  Serial.println("soft start");
  for (int duty = 0; duty <= 255; duty += 5) {
    analogWrite(MOS_PIN, duty);
    if (duty % 50 == 0) { Serial.print("PWM "); Serial.print(duty); Serial.print("   supply "); Serial.print(supplyVolts(), 2); Serial.println(" V"); }
    delay(60);
  }
  Serial.println("full speed");
  delay(2000);
  Serial.println("soft stop");
  for (int duty = 255; duty >= 0; duty -= 5) { analogWrite(MOS_PIN, duty); delay(40); }
  delay(1500);
}
