// ---- Circuit (Kit 5) ----
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define ENA 5
#define IN1 4
#define IN2 7
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}

int LEVELS[5] = {80, 120, 160, 200, 255};
int idx = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  driverBegin();
  Serial.begin(9600);
  Serial.println("press the button to run the next PWM level");
}

void loop() {
  if (pressed()) {
    int pwm = LEVELS[idx];
    Serial.print("PWM "); Serial.print(pwm); Serial.print(" ("); Serial.print(pwm * 100 / 255); Serial.println(" %)");
    Serial.println("  forward"); motorA(pwm); delay(2000);
    Serial.println("  pause");   motorA(0);   delay(600);
    Serial.println("  reverse"); motorA(-pwm); delay(2000);
    motorA(0);
    Serial.println("  stopped");
    idx = (idx + 1) % 5;
  }
}
