Kit 5 - Motors and Power Control
Project 29: BO Motor Wheel Test Rig (Intermediate)

Each press runs the BO wheel forward 2 s, pauses, runs it in reverse 2 s and stops - at the next PWM level (80, 120, 160, 200, 255). Note how the speed rises with the duty cycle.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Motor Driver Module L298N x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-29-bo-rig
