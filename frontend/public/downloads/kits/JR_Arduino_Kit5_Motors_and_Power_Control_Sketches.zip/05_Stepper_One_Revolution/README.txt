Kit 5 - Motors and Power Control
Project 5: Stepper One Revolution (Basic)

The 28BYJ-48 turns exactly one revolution (2048 steps), pauses, then turns back.

Parts:
  AA 4-cell Battery Holder x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-05-stepper-rev
