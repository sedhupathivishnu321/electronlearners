// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4

#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)

void setup() {
  stepper.setSpeed(10);                      // rpm
  Serial.begin(9600);
}

void loop() {
  Serial.println("one revolution forward");
  stepper.step(2048);
  delay(1000);
  Serial.println("one revolution back");
  stepper.step(-2048);
  delay(1000);
}
