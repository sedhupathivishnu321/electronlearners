Kit 5 - Motors and Power Control
Project 42: PWM Frequency Explorer (Advanced)

The motor gets 50 % duty at four different PWM frequencies: the hardware 490 Hz, then software PWM at 100, 10 and 2 Hz. Press the button to change. At 2 Hz the motor visibly pulses; at high frequency its inertia smooths the pulses into a steady speed.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  MOSFET IRFZ44N x1
  Diode 1N4007 x1
  Electrolytic Capacitor 100uF 25V x1
  DC Motor 6V x1

Circuit notes:
  IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-42-pwm-frequency
