// ---- Circuit (Kit 5) ----
// IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define MOS_PIN 10
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int mode = 0;
bool level = false;

void announce() {
  if (mode == 0) { analogWrite(MOS_PIN, 128); Serial.println("490 Hz hardware PWM, 50 % duty: smooth running"); }
  if (mode == 1) { analogWrite(MOS_PIN, 0); Serial.println("100 Hz software PWM, 50 %: still smooth, slight hum"); }
  if (mode == 2) { Serial.println("10 Hz software PWM, 50 %: the speed ripples"); }
  if (mode == 3) { Serial.println("2 Hz software PWM, 50 %: the motor starts and stops visibly"); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(MOS_PIN, OUTPUT);
  Serial.begin(9600);
  announce();
}

void loop() {
  if (pressed()) {
    mode = (mode + 1) % 4;
    digitalWrite(MOS_PIN, LOW);
    announce();
  }
  if (mode > 0) {
    int halfPeriod = (mode == 1) ? 5 : (mode == 2 ? 50 : 250);        // ms for each half of one PWM period
    level = !level;
    digitalWrite(MOS_PIN, level);
    delay(halfPeriod);
  }
}
