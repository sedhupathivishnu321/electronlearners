// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define SERVO_PIN 11
#define BTN1 2
#define RED_LED 3
#define GREEN_LED A5

#include <Servo.h>
Servo servo;

#define CYCLE_MS 4000UL
#define GUARD_OPEN 90
#define GUARD_CLOSED 0
int state = 0;                                  // 0 ready, 1 armed, 2 running, 3 e-stop
unsigned long armedAt = 0, cycleStart = 0;

void show() {
  digitalWrite(GREEN_LED, state == 0);
  digitalWrite(RED_LED, state == 3 ? HIGH : (state == 1 ? (millis() / 200) % 2 : LOW));
}

void estop() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  state = 3;
  Serial.println("E-STOP: relay off, guard stays closed - hold 2 s to reset");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(GUARD_OPEN);
  Serial.begin(9600);
  Serial.println("READY - hold the button 1 s, release, then tap within 2 s to start");
}

void loop() {
  if (digitalRead(BTN1) == LOW) {
    if (state == 2) { estop(); while (digitalRead(BTN1) == LOW) { } delay(40); return; }       // any press while running
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 2000) { }
    unsigned long held = millis() - t0;
    if (held >= 2000) {
      if (state == 3) { state = 0; servo.write(GUARD_OPEN); Serial.println("reset - READY"); }
    } else if (held >= 1000) {
      if (state == 0) { state = 1; armedAt = millis(); Serial.println("ARMED - tap within 2 s"); }
    } else if (state == 1 && millis() - armedAt < 2000) {
      Serial.println("guard closing"); servo.write(GUARD_CLOSED); delay(900);
      digitalWrite(RELAY_PIN, RELAY_ON);
      state = 2; cycleStart = millis();
      Serial.println("CYCLE RUNNING - machine on");
    } else if (state == 0) {
      Serial.println("not armed - hold the button for 1 s first");
    }
    while (digitalRead(BTN1) == LOW) { }
    delay(40);
  }
  if (state == 1 && millis() - armedAt >= 2000) { state = 0; Serial.println("arm timed out"); }
  if (state == 2 && millis() - cycleStart >= CYCLE_MS) {
    digitalWrite(RELAY_PIN, RELAY_OFF);
    delay(300);
    servo.write(GUARD_OPEN);
    state = 0;
    Serial.println("cycle complete - guard open, READY");
  }
  show();
}
