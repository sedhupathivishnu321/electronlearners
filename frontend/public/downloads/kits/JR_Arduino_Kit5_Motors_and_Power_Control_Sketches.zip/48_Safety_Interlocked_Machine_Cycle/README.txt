Kit 5 - Motors and Power Control
Project 48: Safety-Interlocked Machine Cycle (Advanced)

With one button the "two-hand" start becomes a two-step start: HOLD for 1 s (arms for 2 s), then TAP. The servo guard closes before the relay (the machine lamp) switches on for 4 s. Any press during the cycle is an e-stop: relay off at once, guard stays shut, red latched; a 2 s hold resets.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  LED 5mm Yellow x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-48-safety-cycle
