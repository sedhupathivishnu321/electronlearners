Kit 5 - Motors and Power Control
Project 47: Motor Control Command Language (Advanced)

A serial interpreter for every actuator: S90 (servo angle), M1 128 (DC motor speed -255..255), M2 -100 (BO motor), T512 (stepper steps), R1 on / R1 off (relay lamp), STATUS, STOP, HELP.

Parts:
  AA 4-cell Battery Holder x1
  SG90 Micro Servo x1
  28BYJ-48 Stepper + ULN2003 x1
  Relay Module 1 Channel 5V x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Yellow x1
  Motor Driver Module L298N x1
  DC Motor 6V x1
  BO Motor + wheel x1

Circuit notes:
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-47-command-language
