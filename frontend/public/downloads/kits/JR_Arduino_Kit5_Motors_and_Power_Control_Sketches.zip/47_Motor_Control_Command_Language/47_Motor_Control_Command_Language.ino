// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define SERVO_PIN 11
#define ENA 5
#define IN1 4
#define IN2 7
#define ENB 6
#define IN3 12
#define IN4 13
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH

#include <Servo.h>
Servo servo;
#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}
void motorB(int speed) {                    // same for channel B
  if (speed > 0) { digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW); }
  else if (speed < 0) { digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH); }
  else { digitalWrite(IN3, LOW); digitalWrite(IN4, LOW); }
  analogWrite(ENB, abs(speed));
}
void driverBBegin() {
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  motorB(0);
}

String line = "";
int servoAngle = 90, m1 = 0, m2 = 0;
long stepperPos = 0;
bool relayOn = false;

void help() {
  Serial.println("S<0-180>        servo angle        e.g. S90");
  Serial.println("M1 <-255..255>  DC motor           e.g. M1 128");
  Serial.println("M2 <-255..255>  BO motor           e.g. M2 -100");
  Serial.println("T<steps>        stepper steps      e.g. T512");
  Serial.println("R1 on | R1 off  relay lamp");
  Serial.println("STATUS  STOP  HELP");
}

void status() {
  Serial.print("servo "); Serial.print(servoAngle); Serial.print("  M1 "); Serial.print(m1); Serial.print("  M2 "); Serial.print(m2);
  Serial.print("  stepper "); Serial.print(stepperPos); Serial.print(" steps  relay "); Serial.println(relayOn ? "on" : "off");
}

void handle(String c) {
  c.toUpperCase();
  char k = c.charAt(0);
  if (c.startsWith("HELP")) help();
  else if (c.startsWith("STATUS")) status();
  else if (c.startsWith("STOP")) { m1 = 0; m2 = 0; motorA(0); motorB(0); relayOn = false; digitalWrite(RELAY_PIN, RELAY_OFF); Serial.println("all stopped"); }
  else if (c.startsWith("M1")) { m1 = constrain(c.substring(2).toInt(), -255, 255); motorA(m1); Serial.print("M1 = "); Serial.println(m1); }
  else if (c.startsWith("M2")) { m2 = constrain(c.substring(2).toInt(), -255, 255); motorB(m2); Serial.print("M2 = "); Serial.println(m2); }
  else if (c.startsWith("R1")) {
    relayOn = c.indexOf("ON") >= 0;
    digitalWrite(RELAY_PIN, relayOn ? RELAY_ON : RELAY_OFF);
    Serial.println(relayOn ? "relay ON" : "relay OFF");
  }
  else if (k == 'S') { servoAngle = constrain(c.substring(1).toInt(), 0, 180); servo.write(servoAngle); Serial.print("servo = "); Serial.println(servoAngle); }
  else if (k == 'T') { long n = c.substring(1).toInt(); stepper.step(n); stepperPos += n; Serial.print("stepper moved "); Serial.print(n); Serial.println(" steps"); }
  else { Serial.print("unknown command: "); Serial.println(c); }
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  driverBegin(); driverBBegin();
  servo.attach(SERVO_PIN);
  servo.write(servoAngle);
  stepper.setSpeed(14);
  Serial.begin(9600);
  Serial.println("motor console ready - type HELP");
}

void loop() {
  while (Serial.available() > 0) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') { if (line.length() > 0) handle(line); line = ""; }
    else line += ch;
  }
}
