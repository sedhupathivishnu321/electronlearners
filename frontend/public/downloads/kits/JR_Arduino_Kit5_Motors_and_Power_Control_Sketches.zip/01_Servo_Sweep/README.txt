Kit 5 - Motors and Power Control
Project 1: Servo Sweep (Basic)

Sweeps the SG90 servo through its full range, 0 to 180 degrees and back.

Parts:
  SG90 Micro Servo x1

Circuit notes:
  SG90 servo: signal -> D11, red -> 5V, brown -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-01-servo-sweep
