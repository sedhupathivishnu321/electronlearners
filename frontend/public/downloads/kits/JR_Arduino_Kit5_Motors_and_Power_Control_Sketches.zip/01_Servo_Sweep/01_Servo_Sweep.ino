// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
#define SERVO_PIN 11

#include <Servo.h>
Servo servo;

void setup() {
  servo.attach(SERVO_PIN);
}

void loop() {
  for (int a = 0; a <= 180; a += 2) { servo.write(a); delay(15); }
  for (int a = 180; a >= 0; a -= 2) { servo.write(a); delay(15); }
}
