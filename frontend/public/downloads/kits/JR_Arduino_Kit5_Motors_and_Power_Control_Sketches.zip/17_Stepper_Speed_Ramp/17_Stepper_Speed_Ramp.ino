// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define BTN1 2

#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int dir = 1;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
}

void chunk(int rpm) {
  stepper.setSpeed(rpm);
  stepper.step(dir * 40);                    // a short burst of steps at this speed
  if (pressed()) { dir = -dir; Serial.println(dir > 0 ? "direction: clockwise" : "direction: counter-clockwise"); }
}

void loop() {
  Serial.println("accelerating");
  for (int rpm = 2; rpm <= 14; rpm++) { Serial.print("rpm "); Serial.println(rpm); chunk(rpm); chunk(rpm); }
  Serial.println("decelerating");
  for (int rpm = 14; rpm >= 2; rpm--) { chunk(rpm); chunk(rpm); }
}
