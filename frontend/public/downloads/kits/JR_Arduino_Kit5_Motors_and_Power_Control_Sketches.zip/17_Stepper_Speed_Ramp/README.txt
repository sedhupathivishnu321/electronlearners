Kit 5 - Motors and Power Control
Project 17: Stepper Speed Ramp (Intermediate)

The stepper accelerates from 2 to 14 rpm and back down in small chunks of steps. A button press reverses the direction.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-17-stepper-ramp
