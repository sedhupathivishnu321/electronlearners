Kit 5 - Motors and Power Control
Project 25: Motor Direction Safety Interlock (Intermediate)

The button asks for the opposite direction, but the motor must first stop and stay stopped for 1.5 s (red LED blinks) - no instant reversal.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Motor Driver L293D x1
  DC Motor 6V x1

Circuit notes:
  L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-25-direction-interlock
