// ---- Circuit (Kit 5) ----
// L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define L293_EN 6
#define L293_1A A1
#define L293_2A A2
#define BTN1 2
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motor293(int speed) {                  // -255 .. 255 ; EN1,2 carries the PWM
  if (speed > 0) { digitalWrite(L293_1A, HIGH); digitalWrite(L293_2A, LOW); }
  else if (speed < 0) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, HIGH); }
  else { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); }
  analogWrite(L293_EN, abs(speed));
}
void l293Begin() {
  pinMode(L293_EN, OUTPUT); pinMode(L293_1A, OUTPUT); pinMode(L293_2A, OUTPUT);
  motor293(0);
}

#define STOP_WAIT_MS 1500UL
int dir = 1;                                  // current direction
bool waiting = false;
unsigned long stopAt = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  l293Begin();
  Serial.begin(9600);
  motor293(255 * dir);
  Serial.println("running forward");
}

void loop() {
  if (!waiting && pressed()) {
    Serial.println("reverse requested: stopping first");
    motor293(0);
    waiting = true;
    stopAt = millis();
  }
  if (waiting) {
    digitalWrite(RED_LED, (millis() / 150) % 2);                            // red blinks while the interlock is active
    if (pressed()) Serial.println("interlock active - wait for the motor to stop");
    if (millis() - stopAt >= STOP_WAIT_MS) {
      waiting = false;
      digitalWrite(RED_LED, LOW);
      dir = -dir;
      motor293(255 * dir);
      Serial.println(dir > 0 ? "running forward" : "running reverse");
    }
  }
}
