Kit 5 - Motors and Power Control
Project 8: Motor Speed with PWM (Basic)

analogWrite() ramps the motor speed up and down through the TIP122.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  DC Motor 6V x1

Circuit notes:
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-08-pwm-tip122
