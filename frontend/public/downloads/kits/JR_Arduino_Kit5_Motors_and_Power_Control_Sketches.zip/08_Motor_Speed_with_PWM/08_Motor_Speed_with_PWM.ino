// ---- Circuit (Kit 5) ----
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define TIP_PIN 9

void setup() {
  pinMode(TIP_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  for (int duty = 0; duty <= 255; duty += 5) {
    analogWrite(TIP_PIN, duty);
    Serial.print("PWM "); Serial.print(duty * 100 / 255); Serial.println(" %");
    delay(120);
  }
  for (int duty = 255; duty >= 0; duty -= 5) {
    analogWrite(TIP_PIN, duty);
    delay(120);
  }
}
