Kit 5 - Motors and Power Control
Project 27: MOSFET vs TIP122 Comparison (Intermediate)

The same motor is switched fully on by the TIP122 and then by the IRFZ44N. The divider measures the voltage left across the switch: the smaller it is, the more of the 6 V reaches the motor.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x2
  TIP122 Darlington x1
  Diode 1N4007 x1
  MOSFET IRFZ44N x1
  Resistor 10k ohm 1/4W x2
  DC Motor 6V x1

Circuit notes:
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Motor-node monitor: 10k + 10k divider from the switched (low-side) motor terminal to A0 (A0 reads half of that voltage)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-27-mosfet-vs-tip
