// ---- Circuit (Kit 5) ----
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Motor-node monitor: 10k + 10k divider from the switched (low-side) motor terminal to A0 (A0 reads half of that voltage)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define TIP_PIN 9
#define MOS_PIN 10
#define VSENSE_PIN A0

float supplyVolts() {                       // the 10k + 10k divider halves the voltage
  return analogRead(VSENSE_PIN) * 5.0 / 1023.0 * 2.0;
}

#define PACK_V 6.0

float measureNode(int pin) {
  digitalWrite(pin, HIGH);
  delay(900);                                 // let the motor settle
  float sum = 0;
  for (int i = 0; i < 20; i++) { sum += supplyVolts(); delay(10); }
  digitalWrite(pin, LOW);
  return sum / 20;
}

void setup() {
  pinMode(TIP_PIN, OUTPUT);
  pinMode(MOS_PIN, OUTPUT);
  digitalWrite(TIP_PIN, LOW); digitalWrite(MOS_PIN, LOW);
  Serial.begin(9600);
}

void loop() {
  float vt = measureNode(TIP_PIN);
  Serial.print("TIP122 : "); Serial.print(vt, 2); Serial.print(" V across the switch, motor gets about "); Serial.print(PACK_V - vt, 2); Serial.println(" V");
  delay(1200);
  float vm = measureNode(MOS_PIN);
  Serial.print("IRFZ44N: "); Serial.print(vm, 2); Serial.print(" V across the switch, motor gets about "); Serial.print(PACK_V - vm, 2); Serial.println(" V");
  Serial.println(vm < vt ? "the MOSFET wastes less voltage and heat" : "the TIP122 wastes less voltage here");
  delay(2500);
}
