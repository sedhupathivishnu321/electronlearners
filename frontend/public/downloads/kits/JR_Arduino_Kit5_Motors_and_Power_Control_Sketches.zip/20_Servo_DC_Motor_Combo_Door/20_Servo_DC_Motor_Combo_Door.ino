// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define SERVO_PIN 11
#define L293_EN 6
#define L293_1A A1
#define L293_2A A2
#define BTN1 2

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motor293(int speed) {                  // -255 .. 255 ; EN1,2 carries the PWM
  if (speed > 0) { digitalWrite(L293_1A, HIGH); digitalWrite(L293_2A, LOW); }
  else if (speed < 0) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, HIGH); }
  else { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); }
  analogWrite(L293_EN, abs(speed));
}
void l293Begin() {
  pinMode(L293_EN, OUTPUT); pinMode(L293_1A, OUTPUT); pinMode(L293_2A, OUTPUT);
  motor293(0);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  l293Begin();
  servo.attach(SERVO_PIN);
  servo.write(90);                           // 90 = latch locked
  Serial.begin(9600);
  Serial.println("door locked - press the button");
}

void loop() {
  if (pressed()) {
    Serial.println("latch: unlock"); servo.write(0); delay(600);
    Serial.println("door opening"); motor293(255); delay(1500); motor293(0);
    Serial.println("door open - waiting"); delay(2500);
    Serial.println("door closing"); motor293(-255); delay(1500); motor293(0);
    Serial.println("latch: lock"); servo.write(90); delay(600);
    Serial.println("door locked");
  }
}
