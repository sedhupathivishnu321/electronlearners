Kit 5 - Motors and Power Control
Project 6: BO Motor Spin (Basic)

The L298N channel A spins the BO gear motor forward, stops, then spins it backwards.

Parts:
  AA 4-cell Battery Holder x1
  Motor Driver Module L298N x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-06-bo-spin
