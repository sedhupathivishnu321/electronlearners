// ---- Circuit (Kit 5) ----
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define ENA 5
#define IN1 4
#define IN2 7
#define ENB 6
#define IN3 12
#define IN4 13
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}
void motorB(int speed) {                    // same for channel B
  if (speed > 0) { digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW); }
  else if (speed < 0) { digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH); }
  else { digitalWrite(IN3, LOW); digitalWrite(IN4, LOW); }
  analogWrite(ENB, abs(speed));
}
void driverBBegin() {
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  motorB(0);
}

int maneuver = 4;                            // 4 = stopped

void drive(int left, int right, String name) {
  motorA(left); motorB(right);
  Serial.print(name); Serial.print("  left "); Serial.print(left); Serial.print("  right "); Serial.println(right);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  driverBegin(); driverBBegin();
  Serial.begin(9600);
}

unsigned long started = 0;

void loop() {
  if (pressed()) {
    maneuver = (maneuver + 1) % 5;
    started = millis();
    if (maneuver == 0) drive(200, 200, "STRAIGHT");
    if (maneuver == 1) drive(70, 200, "LEFT turn (left wheel slower)");
    if (maneuver == 2) drive(200, 70, "RIGHT turn (right wheel slower)");
    if (maneuver == 3) drive(200, -200, "SPIN on the spot");
    if (maneuver == 4) drive(0, 0, "STOP");
  }
  if (maneuver != 4 && millis() - started >= 2500) {          // every manoeuvre lasts 2.5 s
    drive(0, 0, "time up - stopped");
    maneuver = 4;
  }
}
