Kit 5 - Motors and Power Control
Project 14: Temperature Fan Controller (Intermediate)

The LM35 temperature picks the motor speed: below 28 C off, 28-31 C slow, 31-34 C medium, above 34 C full speed.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  LM35 Temperature Sensor x1
  DC Motor 6V x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-14-temp-fan
