// ---- Circuit (Kit 5) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define LM35_PIN A0
#define TIP_PIN 9

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

unsigned long lastPrint = 0;

void setup() {
  pinMode(TIP_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  float t = readTemp();
  int duty = 0;
  if (t >= 34) duty = 255;
  else if (t >= 31) duty = 180;
  else if (t >= 28) duty = 110;
  analogWrite(TIP_PIN, duty);
  if (millis() - lastPrint > 700) {
    lastPrint = millis();
    Serial.print("temperature "); Serial.print(t, 1); Serial.print(" C   fan PWM "); Serial.println(duty);
  }
  delay(100);
}
