Kit 5 - Motors and Power Control
Project 36: Heat-Seeking Servo Pointer (Advanced)

Press the button: the servo scans 0-180 degrees, averages the LM35 at each angle, then parks at the warmest direction (green). Move the temperature slider during the scan to place a "heat source".

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  SG90 Micro Servo x1
  LM35 Temperature Sensor x1

Circuit notes:
  SG90 servo: signal -> D11, red -> 5V, brown -> GND
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-36-heat-seeker
