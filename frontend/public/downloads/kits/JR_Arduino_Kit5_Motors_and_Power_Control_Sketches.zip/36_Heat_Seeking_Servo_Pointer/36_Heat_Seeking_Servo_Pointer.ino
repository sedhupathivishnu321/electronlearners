// ---- Circuit (Kit 5) ----
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
#define SERVO_PIN 11
#define LM35_PIN A0
#define BTN1 2
#define GREEN_LED A5

#include <Servo.h>
Servo servo;
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  Serial.println("press the button to scan for heat");
}

void loop() {
  if (pressed()) {
    digitalWrite(GREEN_LED, LOW);
    float best = -100; int bestAngle = 0;
    Serial.println("scanning...");
    for (int a = 0; a <= 180; a += 10) {
      servo.write(a);
      delay(450);                                            // wait for the servo and the sensor
      float t = readTemp();
      Serial.print(a); Serial.print(" deg: "); Serial.print(t, 1); Serial.println(" C");
      if (t > best) { best = t; bestAngle = a; }
    }
    servo.write(bestAngle);
    digitalWrite(GREEN_LED, HIGH);
    Serial.print("warmest direction: "); Serial.print(bestAngle); Serial.print(" degrees ("); Serial.print(best, 1); Serial.println(" C)");
  }
}
