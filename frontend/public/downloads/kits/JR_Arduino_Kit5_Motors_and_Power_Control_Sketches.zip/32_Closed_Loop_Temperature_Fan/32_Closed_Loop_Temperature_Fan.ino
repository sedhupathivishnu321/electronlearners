// ---- Circuit (Kit 5) ----
// LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
// IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define LM35_PIN A0
#define MOS_PIN 10

#define SETPOINT 30.0
#define KP 30.0
#define KI 3.0

float integral = 0;
unsigned long lastRun = 0, lastPrint = 0;

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(LM35_PIN); delay(2); }
  return sum / 8.0 * 500.0 / 1023.0;
}

void setup() {
  pinMode(MOS_PIN, OUTPUT);
  Serial.begin(9600);
  Serial.println("setpoint 30 C - PI control of the fan");
}

void loop() {
  if (millis() - lastRun < 200) return;
  float dt = (millis() - lastRun) / 1000.0;
  lastRun = millis();
  float t = readTemp();
  float err = t - SETPOINT;                                  // positive = too warm = more cooling
  float pTerm = KP * err;
  float out = pTerm + KI * integral;
  if (out > 0 && out < 255) integral += err * dt;            // anti-windup: only integrate while not saturated
  if (out <= 0 && err > 0) integral += err * dt;
  integral = constrain(integral, -20, 85);
  out = constrain(pTerm + KI * integral, 0, 255);
  analogWrite(MOS_PIN, (int)out);
  if (millis() - lastPrint > 800) {
    lastPrint = millis();
    Serial.print("T "); Serial.print(t, 1); Serial.print("  err "); Serial.print(err, 1);
    Serial.print("  P "); Serial.print(pTerm, 0); Serial.print("  I "); Serial.print(KI * integral, 0);
    Serial.print("  PWM "); Serial.println((int)out);
  }
}
