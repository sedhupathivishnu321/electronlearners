Kit 5 - Motors and Power Control
Project 32: Closed-Loop Temperature Fan (Advanced)

A PI controller turns the LM35 error (temperature minus the 30 C setpoint) into PWM for the IRFZ44N-driven fan: proportional term for quick reaction, integral term to remove the remaining error. Anti-windup keeps the integral sane.

Parts:
  AA 4-cell Battery Holder x1
  Resistor 220 ohm 1/4W x1
  MOSFET IRFZ44N x1
  Diode 1N4007 x1
  Electrolytic Capacitor 100uF 25V x1
  LM35 Temperature Sensor x1
  DC Motor 6V x1

Circuit notes:
  LM35: VCC 5V, GND, OUT -> A0 (10 mV per degree C)
  IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-32-pi-fan
