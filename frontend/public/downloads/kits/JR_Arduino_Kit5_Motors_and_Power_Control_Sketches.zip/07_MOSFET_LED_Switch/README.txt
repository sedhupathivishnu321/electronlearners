Kit 5 - Motors and Power Control
Project 7: MOSFET LED Switch (Basic)

The IRFZ44N switches an LED branch from a digital pin: the gate takes almost no current, the load runs through the drain.

Parts:
  Resistor 220 ohm 1/4W x2
  MOSFET IRFZ44N x1
  LED 5mm Red x1

Circuit notes:
  IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-07-mosfet-led
