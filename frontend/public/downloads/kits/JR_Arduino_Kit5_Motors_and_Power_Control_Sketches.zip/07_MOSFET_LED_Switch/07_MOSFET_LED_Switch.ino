// ---- Circuit (Kit 5) ----
// IRFZ44N: gate <- D10 via 220 ohm, source -> GND, drain -> motor (low-side switch, 1N4007 flyback diode across the motor)
#define MOS_PIN 10

void setup() {
  pinMode(MOS_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  digitalWrite(MOS_PIN, HIGH);
  Serial.println("gate HIGH - LED on");
  delay(1000);
  digitalWrite(MOS_PIN, LOW);
  Serial.println("gate LOW - LED off");
  delay(1000);
}
