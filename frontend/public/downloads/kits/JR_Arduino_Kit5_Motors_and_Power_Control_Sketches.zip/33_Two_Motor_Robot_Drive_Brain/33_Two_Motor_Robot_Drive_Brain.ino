// ---- Circuit (Kit 5) ----
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define ENA 5
#define IN1 4
#define IN2 7
#define ENB 6
#define IN3 12
#define IN4 13
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}
void motorB(int speed) {                    // same for channel B
  if (speed > 0) { digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW); }
  else if (speed < 0) { digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH); }
  else { digitalWrite(IN3, LOW); digitalWrite(IN4, LOW); }
  analogWrite(ENB, abs(speed));
}
void driverBBegin() {
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  motorB(0);
}

int targetL = 0, targetR = 0, curL = 0, curR = 0;
bool estop = false;
unsigned long lastRamp = 0;
String line = "";

void command(String c) {
  c.toUpperCase();
  int sp = c.length() > 1 ? constrain(c.substring(1).toInt(), 1, 9) * 28 : 200;      // 1..9 -> about 28..252
  char k = c.charAt(0);
  if (estop) { Serial.println("E-STOP active - press the button to release"); return; }
  if (k == 'F') { targetL = sp; targetR = sp; Serial.println("forward"); }
  else if (k == 'B') { targetL = -sp; targetR = -sp; Serial.println("backward"); }
  else if (k == 'L') { targetL = sp / 3; targetR = sp; Serial.println("turn left"); }
  else if (k == 'R') { targetL = sp; targetR = sp / 3; Serial.println("turn right"); }
  else if (k == 'X') { targetL = sp; targetR = -sp; Serial.println("spin"); }
  else if (k == 'S') { targetL = 0; targetR = 0; Serial.println("stop"); }
  else Serial.println("commands: F B L R X S + speed 1-9");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  driverBegin(); driverBBegin();
  Serial.begin(9600);
  Serial.println("robot ready: F B L R X S (+ speed 1-9)");
}

void loop() {
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') { if (line.length() > 0) command(line); line = ""; } else line += c;
  }
  if (pressed()) {
    estop = !estop;
    if (estop) { targetL = 0; targetR = 0; curL = 0; curR = 0; motorA(0); motorB(0); Serial.println("EMERGENCY STOP"); }
    else Serial.println("e-stop released");
  }
  if (millis() - lastRamp >= 20) {
    lastRamp = millis();
    if (curL < targetL) curL = min(curL + 12, targetL); else if (curL > targetL) curL = max(curL - 12, targetL);
    if (curR < targetR) curR = min(curR + 12, targetR); else if (curR > targetR) curR = max(curR - 12, targetR);
    if (!estop) { motorA(curL); motorB(curR); }
  }
  digitalWrite(RED_LED, estop);
  digitalWrite(GREEN_LED, !estop && (curL != 0 || curR != 0) && (millis() / 250) % 2);
}
