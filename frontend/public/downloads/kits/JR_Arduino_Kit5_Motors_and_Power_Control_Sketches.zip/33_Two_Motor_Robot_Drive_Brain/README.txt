Kit 5 - Motors and Power Control
Project 33: Two-Motor Robot Drive Brain (Advanced)

Type F, B, L, R, X (spin) or S (stop) in the Serial Monitor - optionally followed by a speed 1-9, e.g. F7. Wheel speeds ramp smoothly towards their targets. The button is an emergency stop (red, latched; press again to release). Green blinks while moving.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Motor Driver Module L298N x1
  DC Motor 6V x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  L298N channel B: ENB <- D6 (PWM), IN3 <- D12, IN4 <- D13
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-33-robot-brain
