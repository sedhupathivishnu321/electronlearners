// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// SG90 servo: signal -> D11, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4
#define SERVO_PIN 11
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

#include <Servo.h>
Servo servo;
#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

long basePos = 0;
int armAngle = 90, axis = 0, jogDir = 1, taps = 0, n = 0;
long wpBase[6];
int wpArm[6];
bool replay = false;
unsigned long lastTap = 0;

void saveWaypoint() {
  if (n >= 6) { Serial.println("memory full (6 waypoints)"); return; }
  wpBase[n] = basePos; wpArm[n] = armAngle; n++;
  Serial.print("saved waypoint "); Serial.print(n); Serial.print(": base "); Serial.print(basePos); Serial.print(" steps, arm "); Serial.println(armAngle);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(armAngle);
  stepper.setSpeed(14);
  Serial.begin(9600);
  digitalWrite(RED_LED, HIGH);
  Serial.println("recording - hold = jog, tap x1 save, x2 switch axis, x3 replay");
}

void jog() {
  Serial.print("jogging "); Serial.println(axis == 0 ? "base" : "arm");
  while (digitalRead(BTN1) == LOW) {
    if (axis == 0) { stepper.step(jogDir * 24); basePos += jogDir * 24; }
    else { armAngle = constrain(armAngle + jogDir, 0, 180); servo.write(armAngle); delay(12); }
  }
  jogDir = -jogDir;
}

void loop() {
  if (!replay) {
    if (digitalRead(BTN1) == LOW) {
      unsigned long t0 = millis();
      while (digitalRead(BTN1) == LOW && millis() - t0 < 400) { }
      if (digitalRead(BTN1) == LOW) jog();
      else { taps++; lastTap = millis(); }
      delay(40);
    }
    if (taps > 0 && millis() - lastTap > 600) {
      if (taps == 1) saveWaypoint();
      else if (taps == 2) { axis = 1 - axis; Serial.print("axis: "); Serial.println(axis == 0 ? "base (stepper)" : "arm (servo)"); }
      else if (n > 0) { replay = true; digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, HIGH); Serial.println("REPLAY"); }
      taps = 0;
    }
  } else {
    for (int i = 0; i < n && replay; i++) {
      Serial.print("-> waypoint "); Serial.println(i + 1);
      stepper.step(wpBase[i] - basePos); basePos = wpBase[i];
      servo.write(wpArm[i]); armAngle = wpArm[i];
      unsigned long t0 = millis();
      while (millis() - t0 < 700) { if (digitalRead(BTN1) == LOW) { replay = false; break; } }
      if (digitalRead(BTN1) == LOW) replay = false;
    }
    if (!replay) {
      digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, HIGH);
      Serial.println("replay stopped - recording");
      while (digitalRead(BTN1) == LOW) { }
      delay(60);
    }
  }
}
