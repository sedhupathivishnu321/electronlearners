Kit 5 - Motors and Power Control
Project 39: Relay-Based Alternating Pump Logic Demo (Advanced)

Pump A is the motor on the TIP122, pump B is the yellow lamp on the relay. Every button press is a water demand: the pump with the LOWER total run time takes it (3 s), so both wear equally. Green = A running, red = B running.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x4
  LED 5mm Red x1
  LED 5mm Green x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Relay Module 1 Channel 5V x1
  LED 5mm Yellow x1
  DC Motor 6V x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
  TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-39-alternating-pumps
