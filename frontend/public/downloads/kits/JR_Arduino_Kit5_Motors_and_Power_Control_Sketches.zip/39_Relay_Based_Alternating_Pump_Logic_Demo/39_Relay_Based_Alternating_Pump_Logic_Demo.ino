// ---- Circuit (Kit 5) ----
// Relay module: DC+ 5V, DC- GND, IN <- D8 (active LOW: LOW = relay on)
// TIP122: base <- D9 via 1k, emitter -> GND, collector -> motor (low-side switch, 1N4007 flyback diode across the motor)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> A5 (used as a digital pin), cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define RELAY_PIN 8
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define TIP_PIN 9
#define BTN1 2
#define GREEN_LED A5
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define RUN_MS 3000UL
unsigned long runtimeA = 0, runtimeB = 0;

void runPump(bool a) {
  Serial.print("demand -> pump "); Serial.println(a ? "A (motor)" : "B (relay lamp)");
  if (a) { digitalWrite(TIP_PIN, HIGH); digitalWrite(GREEN_LED, HIGH); }
  else { digitalWrite(RELAY_PIN, RELAY_ON); digitalWrite(RED_LED, HIGH); }
  delay(RUN_MS);
  digitalWrite(TIP_PIN, LOW); digitalWrite(RELAY_PIN, RELAY_OFF);
  digitalWrite(GREEN_LED, LOW); digitalWrite(RED_LED, LOW);
  if (a) runtimeA += RUN_MS / 1000; else runtimeB += RUN_MS / 1000;
  Serial.print("total run time: A "); Serial.print(runtimeA); Serial.print(" s, B "); Serial.print(runtimeB); Serial.println(" s");
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(TIP_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  Serial.println("press the button to create a water demand");
}

void loop() {
  if (pressed()) runPump(runtimeA <= runtimeB);              // the less-used pump goes first
}
