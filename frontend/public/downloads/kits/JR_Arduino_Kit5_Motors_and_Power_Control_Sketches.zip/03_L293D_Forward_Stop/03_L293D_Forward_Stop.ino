// ---- Circuit (Kit 5) ----
// L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define L293_EN 6
#define L293_1A A1
#define L293_2A A2

void motor293(int speed) {                  // -255 .. 255 ; EN1,2 carries the PWM
  if (speed > 0) { digitalWrite(L293_1A, HIGH); digitalWrite(L293_2A, LOW); }
  else if (speed < 0) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, HIGH); }
  else { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); }
  analogWrite(L293_EN, abs(speed));
}
void l293Begin() {
  pinMode(L293_EN, OUTPUT); pinMode(L293_1A, OUTPUT); pinMode(L293_2A, OUTPUT);
  motor293(0);
}

void setup() {
  l293Begin();
  Serial.begin(9600);
}

void loop() {
  Serial.println("forward");
  motor293(255);
  delay(3000);
  Serial.println("stop");
  motor293(0);
  delay(2000);
}
