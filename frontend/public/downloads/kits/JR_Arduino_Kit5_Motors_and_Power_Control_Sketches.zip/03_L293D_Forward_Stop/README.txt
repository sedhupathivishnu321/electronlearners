Kit 5 - Motors and Power Control
Project 3: L293D Forward/Stop (Basic)

Runs the DC motor forward for 3 s and stops for 2 s using one channel of the L293D.

Parts:
  AA 4-cell Battery Holder x1
  Motor Driver L293D x1
  DC Motor 6V x1

Circuit notes:
  L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-03-l293d-forward
