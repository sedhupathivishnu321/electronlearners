Kit 5 - Motors and Power Control
Project 16: Stepper Angle Positioning (Intermediate)

Type an angle such as A90 or A-45 in the Serial Monitor (H sets home): the stepper moves to that absolute angle by the shortest number of steps.

Parts:
  AA 4-cell Battery Holder x1
  28BYJ-48 Stepper + ULN2003 x1

Circuit notes:
  ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-16-stepper-angle
