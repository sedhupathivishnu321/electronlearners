// ---- Circuit (Kit 5) ----
// ULN2003 stepper board: + -> +6V pack, - -> GND, IN1-IN4 <- A1-A4
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define STEP_IN1 A1
#define STEP_IN2 A2
#define STEP_IN3 A3
#define STEP_IN4 A4

#include <Stepper.h>
Stepper stepper(2048, STEP_IN1, STEP_IN3, STEP_IN2, STEP_IN4);     // 2048 steps per output-shaft revolution (pin order for the 28BYJ-48)

long posSteps = 0;                             // current position in steps (0 = home)
String line = "";

void goToAngle(int deg) {
  long target = deg * 2048L / 360;
  long delta = target - posSteps;
  Serial.print("moving "); Serial.print(delta); Serial.println(" steps");
  stepper.step(delta);
  posSteps = target;
  Serial.print("now at "); Serial.print(deg); Serial.println(" degrees");
}

void setup() {
  stepper.setSpeed(12);
  Serial.begin(9600);
  Serial.println("commands: A<degrees> (absolute angle), H (set home)");
}

void loop() {
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (line.length() > 0) {
        if (line.charAt(0) == 'A' || line.charAt(0) == 'a') goToAngle(line.substring(1).toInt());
        else if (line.charAt(0) == 'H' || line.charAt(0) == 'h') { posSteps = 0; Serial.println("home set"); }
        else Serial.println("unknown command");
      }
      line = "";
    } else line += c;
  }
}
