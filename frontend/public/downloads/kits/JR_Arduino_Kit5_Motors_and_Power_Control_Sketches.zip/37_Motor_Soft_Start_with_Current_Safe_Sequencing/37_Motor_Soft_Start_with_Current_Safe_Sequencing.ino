// ---- Circuit (Kit 5) ----
// L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
// L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
// Supply monitor: 10k + 10k divider from the +6V rail to A0 (A0 reads half of the supply voltage)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND
#define ENA 5
#define IN1 4
#define IN2 7
#define L293_EN 6
#define L293_1A A1
#define L293_2A A2
#define VSENSE_PIN A0
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}
void motorA(int speed) {                    // -255 .. 255 : sign = direction, 0 = coast
  if (speed > 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else if (speed < 0) { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  analogWrite(ENA, abs(speed));
}
void driverBegin() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  motorA(0);
}
void motor293(int speed) {                  // -255 .. 255 ; EN1,2 carries the PWM
  if (speed > 0) { digitalWrite(L293_1A, HIGH); digitalWrite(L293_2A, LOW); }
  else if (speed < 0) { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, HIGH); }
  else { digitalWrite(L293_1A, LOW); digitalWrite(L293_2A, LOW); }
  analogWrite(L293_EN, abs(speed));
}
void l293Begin() {
  pinMode(L293_EN, OUTPUT); pinMode(L293_1A, OUTPUT); pinMode(L293_2A, OUTPUT);
  motor293(0);
}
float supplyVolts() {                       // the 10k + 10k divider halves the voltage
  return analogRead(VSENSE_PIN) * 5.0 / 1023.0 * 2.0;
}

bool running = false;

void rampBO() { for (int s = 0; s <= 200; s += 10) { motorA(s); delay(50); } }
void rampDC() { for (int s = 0; s <= 255; s += 15) { motor293(s); delay(50); } }

void waitForSupply() {                          // wait until the supply is steady again (max 2.5 s)
  float last = supplyVolts();
  unsigned long steadySince = millis(), t0 = millis();
  while (millis() - t0 < 2500) {
    delay(60);
    float v = supplyVolts();
    if (abs(v - last) > 0.08) steadySince = millis();
    last = v;
    if (millis() - steadySince > 300) break;
  }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  driverBegin();
  l293Begin();
  Serial.begin(9600);
  Serial.print("idle supply "); Serial.print(supplyVolts(), 2); Serial.println(" V - press the button");
}

void loop() {
  if (pressed()) {
    if (!running) {
      running = true;
      Serial.println("starting BO motor...");
      rampBO();
      Serial.print("supply after BO start "); Serial.print(supplyVolts(), 2); Serial.println(" V");
      waitForSupply();
      Serial.print("supply steady at "); Serial.print(supplyVolts(), 2); Serial.println(" V - starting DC motor");
      rampDC();
      Serial.print("both running, supply "); Serial.print(supplyVolts(), 2); Serial.println(" V");
    } else {
      running = false;
      motor293(0); delay(300); motorA(0);
      Serial.println("both motors stopped");
    }
  }
}
