Kit 5 - Motors and Power Control
Project 37: Motor Soft-Start with Current-Safe Sequencing (Advanced)

A press soft-starts the BO motor (L298N), waits until the pack voltage has recovered from the start-up dip, and only then soft-starts the DC motor (L293D) - so the two inrush currents never overlap. The next press stops both.

Parts:
  AA 4-cell Battery Holder x1
  Push Button tactile 6x6 x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x2
  Motor Driver L293D x1
  Motor Driver Module L298N x1
  DC Motor 6V x1
  BO Motor + wheel x1

Circuit notes:
  L298N channel A: ENA <- D5 (PWM), IN1 <- D4, IN2 <- D7; 12V terminal <- +6V pack, GND <- GND, 5V pin <- Uno 5V (logic)
  L293D: pin 16 + EN -> logic 5V, pin 8 -> +6V pack, GND pins -> GND; EN1,2 <- D6 (PWM), 1A <- A1, 2A <- A2
  Supply monitor: 10k + 10k divider from the +6V rail to A0 (A0 reads half of the supply voltage)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  4xAA pack (6 V): + -> bottom red rail (+6V), - -> bottom blue rail (GND), joined to the Uno GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k5-37-staggered-start
