Kit 7 - Wireless and Remote Control
Project 44: Multi-Protocol Gateway (Advanced)

IR keys 1-3, phone commands "ACT n" and radio packets "ACT n" (typed in the NodeMCU monitor) all go into one action queue; the main loop executes the queue in arrival order and logs the source of each action.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  NRF24L01 Radio x2
  IR Remote + Receiver x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-44-protocol-gateway
