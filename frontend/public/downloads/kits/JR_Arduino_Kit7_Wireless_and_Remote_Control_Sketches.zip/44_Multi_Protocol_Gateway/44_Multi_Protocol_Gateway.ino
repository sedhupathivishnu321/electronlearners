// ---- Circuit (Kit 7, Uno) ----
// IR receiver: OUT -> D7, VCC 5V, GND
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
#define IR_PIN 7
#define BT_RX A0
#define BT_TX A1
#define NRF_CE 9
#define NRF_CSN 10

#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}

#define QMAX 8
int qAct[QMAX];
int qSrc[QMAX];                                      // 0 = IR, 1 = Bluetooth, 2 = radio
int qLen = 0;

String srcName(int s) { if (s == 0) return "IR"; if (s == 1) return "Bluetooth"; return "radio"; }

void enqueue(int act, int src) {
  if (qLen >= QMAX) { Serial.println("queue full - dropped"); return; }
  qAct[qLen] = act; qSrc[qLen] = src; qLen++;
}

String actionName(int a) { if (a == 1) return "LIGHT ON"; if (a == 2) return "LIGHT OFF"; if (a == 3) return "LIGHT BLINK"; return "UNKNOWN"; }

void setup() {
  Serial.begin(9600);
  bt.begin(9600);
  irrecv.enableIRIn();
  radioBegin();
  Serial.println("gateway ready: IR 1-3, phone ACT n, radio ACT n");
}

void loop() {
  if (irrecv.decode(&ir)) { int d = keyDigit(ir.value); if (d >= 1 && d <= 3) enqueue(d, 0); irrecv.resume(); }
  if (btPoll()) { btCmd.toUpperCase(); if (btCmd.startsWith("ACT ")) enqueue(btCmd.substring(4).toInt(), 1); }
  if (recvText() && rxText.startsWith("ACT ")) enqueue(rxText.substring(4).toInt(), 2);
  if (qLen > 0) {
    Serial.println("[" + srcName(qSrc[0]) + "] " + actionName(qAct[0]));
    bt.println("did " + actionName(qAct[0]));
    for (int i = 1; i < qLen; i++) { qAct[i - 1] = qAct[i]; qSrc[i - 1] = qSrc[i]; }
    qLen--;
    delay(300);
  }
}
