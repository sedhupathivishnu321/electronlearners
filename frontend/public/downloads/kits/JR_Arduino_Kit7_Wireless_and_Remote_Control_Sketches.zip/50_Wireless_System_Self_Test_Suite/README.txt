Kit 7 - Wireless and Remote Control
Project 50: Wireless System Self-Test Suite (Advanced)

Tests run in turn and are reported on the LCD and Serial Monitor: HC-05 (AT -> OK), nRF24 radio round trip to the NodeMCU, the level-shifted NodeMCU link, the IR receiver (press any remote key within 8 s), the relay click and the LCD. Ends with a PASS / FAIL summary.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  NRF24L01 Radio x2
  IR Remote + Receiver x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1
  Logic Level Converter 4ch x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  IR receiver: OUT -> D7, VCC 5V, GND
  Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-50-self-test
