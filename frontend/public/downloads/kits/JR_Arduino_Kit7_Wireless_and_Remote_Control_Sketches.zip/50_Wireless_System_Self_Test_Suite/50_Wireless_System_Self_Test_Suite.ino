// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
// IR receiver: OUT -> D7, VCC 5V, GND
// Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
#define BT_RX A0
#define BT_TX A1
#define NRF_CE 9
#define NRF_CSN 10
#define IR_PIN 7
#define RELAY_PIN 5
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define LINK_RX A2
#define LINK_TX A3

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}
#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <SoftwareSerial.h>
SoftwareSerial link(LINK_RX, LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

int passed = 0, total = 0;
String failed = "";

void report(String name, bool ok) {
  total++;
  if (ok) passed++; else failed += name + " ";
  lcdRow(0, "Test " + String(total) + ": " + name);
  lcdRow(1, ok ? "PASS" : "FAIL");
  Serial.println(name + (ok ? ": PASS" : ": FAIL"));
  delay(700);
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  bt.begin(9600);
  link.begin(9600);
  irrecv.enableIRIn();
  lcdBegin();
  radioBegin();
  Serial.println("=== wireless self-test ===");
  lcdRow(0, "Self-test"); lcdRow(1, "starting..."); delay(800);

  bt.println("AT");                                               // 1: HC-05 answers OK to AT
  bool btOk = false;
  unsigned long t0 = millis();
  while (millis() - t0 < 1200 && !btOk) { delay(20); if (btPoll() && btCmd == "OK") btOk = true; }
  report("HC-05", btOk);

  bool radioOk = false;                                           // 2: radio round trip: TEST -> ECHO TEST
  for (int tries = 0; tries < 3 && !radioOk; tries++) {
    if (sendText("TEST")) {
      t0 = millis();
      while (millis() - t0 < 600 && !radioOk) { if (recvText() && rxText == "ECHO TEST") radioOk = true; }
    }
  }
  report("nRF24", radioOk);

  link.println("LINK?");                                          // 3: serial link through the level converter
  bool linkOk = false;
  t0 = millis();
  while (millis() - t0 < 1200 && !linkOk) { delay(20); if (linkPoll() && linkLine == "LINK OK") linkOk = true; }
  report("NodeMCU link", linkOk);

  lcdRow(0, "Test 4: IR"); lcdRow(1, "press a key...");        // 4: IR receiver needs a key press
  bool irOk = false;
  t0 = millis();
  while (millis() - t0 < 8000 && !irOk) { delay(20); if (irrecv.decode(&ir)) { irOk = true; irrecv.resume(); } }
  report("IR", irOk);

  digitalWrite(RELAY_PIN, RELAY_ON); delay(400); digitalWrite(RELAY_PIN, RELAY_OFF);       // 5: relay click (listen for it)
  report("relay click", true);
  Serial.println("RESULT: " + String(passed) + "/" + String(total) + (passed == total ? " PASS" : " FAIL"));
  if (passed != total) Serial.println("failed: " + failed);
}

void loop() {
  lcdRow(0, passed == total ? "SELF-TEST PASS" : "SELF-TEST FAIL");
  lcdRow(1, String(passed) + "/" + String(total) + (passed == total ? " ok" : " " + failed));
  delay(1000);
}
