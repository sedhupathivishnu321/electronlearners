Kit 7 - Wireless and Remote Control
Project 46: Encrypted Message Link (Advanced)

The button on the Uno cycles through three messages; each is XOR-encrypted with a shared key (0x5A), sent as hex over the radio, and shown on the LCD (plain / cipher). The NodeMCU prints the intercepted cipher text and the decrypted message.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  Push Button tactile 6x6 x1
  NRF24L01 Radio x2
  16x2 LCD I2C x1

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-46-encrypted-link
