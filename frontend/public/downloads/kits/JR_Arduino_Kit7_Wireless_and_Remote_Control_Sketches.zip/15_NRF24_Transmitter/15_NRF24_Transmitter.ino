// ---- Circuit (Kit 7, Uno) ----
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
// second nRF24L01 on the same SPI bus: CE -> A0, CSN -> A1 (3.3 V from the AMS1117)
// DHT11: VCC 5V, GND, DATA -> D8
#define NRF_CE 9
#define NRF_CSN 10
#define NRF2_CE A0
#define NRF2_CSN A1
#define DHT_PIN 8

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
RF24 radioA(NRF_CE, NRF_CSN);
RF24 radioB(NRF2_CE, NRF2_CSN);
const uint64_t PIPE = 0xE8E8F0F0E1LL;
byte buf[32];
int sent = 0, acked = 0;

void setup() {
  Serial.begin(9600);
  dht.begin();
  if (!radioA.begin() || !radioB.begin()) Serial.println("a radio did not start - check wiring and the 3.3 V supply");
  radioA.openWritingPipe(PIPE);
  radioA.stopListening();
  radioB.openReadingPipe(1, PIPE);
  radioB.startListening();
}

void loop() {
  String msg = "T=" + String(dht.readTemperature(), 0) + ";H=" + String(dht.readHumidity(), 0);
  bool ok = radioA.write(msg.c_str(), msg.length() + 1);
  sent++; if (ok) acked++;
  Serial.print("TX '"); Serial.print(msg); Serial.print("' "); Serial.print(ok ? "acknowledged" : "NO ACK"); Serial.print("  ("); Serial.print(acked); Serial.print("/"); Serial.print(sent); Serial.println(")");
  delay(100);
  if (radioB.available()) {
    radioB.read(buf, 32);
    String s = "";
    for (int i = 0; i < 32 && buf[i] != 0; i++) s += (char)buf[i];
    Serial.print("RX '"); Serial.print(s); Serial.println("'");
  }
  delay(1900);
}
