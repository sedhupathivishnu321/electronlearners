Kit 7 - Wireless and Remote Control
Project 15: NRF24 Transmitter (Intermediate)

Radio A transmits the DHT11 reading every 2 s as a text packet; radio B (a second node on the same Uno) receives it and prints it. Raise "Packet loss" on a radio to see failed transmissions.

Parts:
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2
  DHT11 Temp & Humidity x1

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  second nRF24L01 on the same SPI bus: CE -> A0, CSN -> A1 (3.3 V from the AMS1117)
  DHT11: VCC 5V, GND, DATA -> D8

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-15-nrf-tx
