Kit 7 - Wireless and Remote Control
Project 29: NodeMCU Wi-Fi Status LCD (Intermediate)

The LCD shows the connection state, then the IP address and signal strength once connected.

Parts:
  ESP8266 NodeMCU V3 x1
  16x2 LCD I2C x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-29-wifi-status
