// ---- Circuit (Kit 7, NodeMCU) ----
// 16x2 LCD (I2C 0x27) powered from VIN: SDA -> D2, SCL -> D1


#include <ESP8266WiFi.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

void setup() {
  Serial.begin(115200);
  lcdBegin();
  lcdRow(0, "Connecting...");
  WiFi.mode(WIFI_STA);
  WiFi.begin("JR_Learners", "jr12345");
  while (WiFi.status() != WL_CONNECTED) { delay(250); }
  Serial.print("IP "); Serial.println(WiFi.localIP());
}

void loop() {
  lcdRow(0, "IP " + WiFi.localIP().toString());
  lcdRow(1, "Signal " + String(WiFi.RSSI()) + " dBm");
  delay(1000);
}
