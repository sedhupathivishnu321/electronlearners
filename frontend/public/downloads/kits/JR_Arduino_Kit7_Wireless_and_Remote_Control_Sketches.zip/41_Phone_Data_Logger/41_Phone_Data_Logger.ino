// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// DHT11: VCC 5V, GND, DATA -> D8
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define BT_RX A0
#define BT_TX A1
#define DHT_PIN 8
#define BTN1 2

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define KEEP 10
int logT[KEEP], logH[KEEP];
unsigned long logTime[KEEP];
int n = 0;
unsigned long last = 0;

void sendLine(int i) {
  bt.println("LOG," + String(logTime[i]) + "," + String(logT[i]) + "," + String(logH[i]));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  bt.begin(9600);
  dht.begin();
  bt.println("logger ready: DUMP, CLEAR");
}

void loop() {
  if (millis() - last >= 5000) {
    last = millis();
    if (n == KEEP) { for (int i = 1; i < KEEP; i++) { logT[i - 1] = logT[i]; logH[i - 1] = logH[i]; logTime[i - 1] = logTime[i]; } n = KEEP - 1; }
    logT[n] = dht.readTemperature(); logH[n] = dht.readHumidity(); logTime[n] = millis() / 1000;
    sendLine(n);
    n++;
    Serial.println("logged sample " + String(n));
  }
  if (pressed()) { bt.println("EVENT," + String(millis() / 1000)); Serial.println("event marker sent"); }
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd == "DUMP") { bt.println("BEGIN," + String(n)); for (int i = 0; i < n; i++) sendLine(i); bt.println("END"); }
    else if (btCmd == "CLEAR") { n = 0; bt.println("log cleared"); }
  }
}
