Kit 7 - Wireless and Remote Control
Project 41: Phone Data Logger (Advanced)

Every 5 s a protocol line "LOG,<seconds>,<temp>,<hum>" is sent to the phone. The button inserts an "EVENT" marker line. The last 10 samples are kept: DUMP replays them, CLEAR empties the log.

Parts:
  Push Button tactile 6x6 x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  DHT11 Temp & Humidity x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  DHT11: VCC 5V, GND, DATA -> D8
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-41-phone-logger
