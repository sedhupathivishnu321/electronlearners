// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
#define BT_RX A0
#define BT_TX A1

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}

void setup() {
  Serial.begin(9600);
  bt.begin(9600);
  Serial.println("Bluetooth echo ready");
  bt.println("Hello from the Uno!");
}

void loop() {
  if (btPoll()) {
    Serial.print("phone says: "); Serial.println(btCmd);
    bt.print("Echo: "); bt.println(btCmd);
  }
}
