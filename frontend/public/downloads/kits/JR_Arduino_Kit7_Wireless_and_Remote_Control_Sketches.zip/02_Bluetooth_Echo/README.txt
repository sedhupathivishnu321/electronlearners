Kit 7 - Wireless and Remote Control
Project 2: Bluetooth Echo (Basic)

Text typed on the phone is printed on the Serial Monitor and echoed back to the phone.

Parts:
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-02-bt-echo
