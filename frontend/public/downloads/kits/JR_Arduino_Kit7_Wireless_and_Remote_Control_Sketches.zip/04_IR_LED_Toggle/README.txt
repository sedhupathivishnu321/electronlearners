Kit 7 - Wireless and Remote Control
Project 4: IR LED Toggle (Basic)

The "1" key of the remote toggles the green LED.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  IR Remote + Receiver x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-04-ir-toggle
