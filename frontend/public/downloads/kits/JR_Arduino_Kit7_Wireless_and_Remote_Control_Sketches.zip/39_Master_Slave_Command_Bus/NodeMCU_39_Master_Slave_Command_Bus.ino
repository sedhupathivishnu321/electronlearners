// ---- Circuit (Kit 7, NodeMCU) ----
// nRF24L01: VCC 3V3, GND, CE -> D0, CSN -> D8, SCK -> D5, MISO -> D6, MOSI -> D7
#define NRF_CE D0
#define NRF_CSN D8

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_UNO);
  radio.openReadingPipe(1, PIPE_NODE);
  radio.startListening();
}

int chk(String s) { int sum = 0; for (int i = 0; i < s.length(); i++) sum += s.charAt(i); return sum % 100; }

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH);
  Serial.begin(115200);
  radioBegin();
  Serial.println("slave ready");
}

void loop() {
  if (recvText() && rxText.startsWith("#")) {
    int lastComma = rxText.lastIndexOf(',');
    String body = rxText.substring(1, lastComma);
    int sum = rxText.substring(lastComma + 1).toInt();
    if (sum != chk(body)) { Serial.println("bad checksum - frame ignored"); return; }
    int c1 = body.indexOf(',');
    int c2 = body.lastIndexOf(',');
    String seqText = body.substring(0, c1);
    String cmd = body.substring(c1 + 1, c2);
    int arg = body.substring(c2 + 1).toInt();
    if (cmd == "LED") digitalWrite(LED_BUILTIN, arg ? LOW : HIGH);
    Serial.println("executed " + cmd + " " + String(arg) + " (seq " + seqText + ")");
    sendText("ACK," + seqText);
  }
}
