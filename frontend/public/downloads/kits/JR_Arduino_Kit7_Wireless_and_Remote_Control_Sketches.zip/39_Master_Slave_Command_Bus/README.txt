Kit 7 - Wireless and Remote Control
Project 39: Master-Slave Command Bus (Advanced)

The Uno master sends framed commands "#seq,cmd,arg,checksum" over the radio and waits for an ACK frame from the NodeMCU slave, retrying up to 3 times. The slave verifies the checksum, executes (toggles its on-board LED) and acknowledges. Raise "Packet loss" on a radio to see retries.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-39-master-slave
