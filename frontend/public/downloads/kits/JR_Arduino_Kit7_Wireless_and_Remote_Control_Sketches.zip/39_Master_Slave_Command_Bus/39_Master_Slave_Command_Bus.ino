// ---- Circuit (Kit 7, Uno) ----
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
#define NRF_CE 9
#define NRF_CSN 10

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}

int seq = 0;

int chk(String s) { int sum = 0; for (int i = 0; i < s.length(); i++) sum += s.charAt(i); return sum % 100; }

bool sendCommand(String cmd, int arg) {
  seq++;
  String body = String(seq) + "," + cmd + "," + String(arg);
  String frame = "#" + body + "," + String(chk(body));
  for (int attempt = 1; attempt <= 3; attempt++) {
    sendText(frame);
    unsigned long t0 = millis();
    while (millis() - t0 < 400) {
      if (recvText() && rxText.startsWith("ACK," + String(seq))) { Serial.println("cmd " + String(seq) + " " + cmd + " acknowledged (attempt " + String(attempt) + ")"); return true; }
    }
    Serial.println("cmd " + String(seq) + " attempt " + String(attempt) + " timed out");
  }
  Serial.println("cmd " + String(seq) + " FAILED after 3 attempts");
  return false;
}

void setup() {
  Serial.begin(9600);
  radioBegin();
}

void loop() {
  sendCommand("LED", 1);
  delay(2500);
  sendCommand("LED", 0);
  delay(2500);
}
