Kit 7 - Wireless and Remote Control
Project 12: Bluetooth Sensor Data to Phone (Intermediate)

The DHT11 temperature and humidity are sent to the phone every 3 s; typing READ asks for an immediate reading.

Parts:
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  DHT11 Temp & Humidity x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  DHT11: VCC 5V, GND, DATA -> D8

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-12-bt-sensor
