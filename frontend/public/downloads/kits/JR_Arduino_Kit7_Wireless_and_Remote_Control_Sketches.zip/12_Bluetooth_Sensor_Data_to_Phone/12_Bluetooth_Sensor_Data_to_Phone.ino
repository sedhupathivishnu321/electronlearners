// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// DHT11: VCC 5V, GND, DATA -> D8
#define BT_RX A0
#define BT_TX A1
#define DHT_PIN 8

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

unsigned long last = 0;

void sendReading() {
  bt.print("T="); bt.print(dht.readTemperature(), 0); bt.print(" C  H="); bt.print(dht.readHumidity(), 0); bt.println(" %");
}

void setup() {
  Serial.begin(9600);
  bt.begin(9600);
  dht.begin();
}

void loop() {
  if (millis() - last >= 3000) { last = millis(); sendReading(); Serial.println("reading sent"); }
  if (btPoll()) { btCmd.toUpperCase(); if (btCmd == "READ") sendReading(); }
}
