// ---- Circuit (Kit 7, NodeMCU) ----
// nRF24L01: VCC 3V3, GND, CE -> D0, CSN -> D8, SCK -> D5, MISO -> D6, MOSI -> D7
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define NRF_CE D0
#define NRF_CSN D8
#define N_LED D3

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_UNO);
  radio.openReadingPipe(1, PIPE_NODE);
  radio.startListening();
}

unsigned long ringUntil = 0;

void setup() {
  pinMode(N_LED, OUTPUT);
  Serial.begin(115200);
  radioBegin();
  Serial.println("doorbell receiver ready");
}

void loop() {
  if (recvText() && rxText == "RING") { ringUntil = millis() + 3000; Serial.println("DING DONG!"); }
  digitalWrite(N_LED, millis() < ringUntil && (millis() / 200) % 2);
}
