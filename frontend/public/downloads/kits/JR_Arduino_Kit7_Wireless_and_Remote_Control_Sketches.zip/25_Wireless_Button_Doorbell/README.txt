Kit 7 - Wireless and Remote Control
Project 25: Wireless Button Doorbell (Intermediate)

The button on the Uno (node A) sends RING over the nRF24 link; the NodeMCU (node B) flashes its red LED for 3 s.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  NRF24L01 Radio x2

Circuit notes:
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-25-doorbell
