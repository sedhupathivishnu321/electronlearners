Kit 7 - Wireless and Remote Control
Project 32: IoT Weather Node over Wi-Fi (Advanced)

The NodeMCU serves a dashboard page at / and a JSON endpoint at /json with the DHT11 data (the sensor runs at 5 V; its data line passes the level converter).

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1
  DHT11 Temp & Humidity x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-32-iot-weather
