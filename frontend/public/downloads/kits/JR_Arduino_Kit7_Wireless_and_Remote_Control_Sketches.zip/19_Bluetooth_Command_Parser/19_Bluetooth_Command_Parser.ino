// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define BT_RX A0
#define BT_TX A1
#define SERVO_PIN 6
#define RELAY_PIN 5
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define RED_LED 3

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Servo.h>
Servo servo;

void reply(String s) { bt.println(s); Serial.println(s); }

void setup() {
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  bt.begin(9600);
  reply("commands: LED1, LED0, SERVO <0-180>, RELAY ON, RELAY OFF");
}

void loop() {
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd == "LED1") { digitalWrite(RED_LED, HIGH); reply("LED on"); }
    else if (btCmd == "LED0") { digitalWrite(RED_LED, LOW); reply("LED off"); }
    else if (btCmd.startsWith("SERVO ")) { int a = constrain(btCmd.substring(6).toInt(), 0, 180); servo.write(a); reply("servo " + String(a)); }
    else if (btCmd == "RELAY ON") { digitalWrite(RELAY_PIN, RELAY_ON); reply("relay on"); }
    else if (btCmd == "RELAY OFF") { digitalWrite(RELAY_PIN, RELAY_OFF); reply("relay off"); }
    else reply("unknown command: " + btCmd);
  }
}
