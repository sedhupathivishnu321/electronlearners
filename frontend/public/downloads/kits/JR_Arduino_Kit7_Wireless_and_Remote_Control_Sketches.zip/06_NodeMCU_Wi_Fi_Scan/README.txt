Kit 7 - Wireless and Remote Control
Project 6: NodeMCU Wi-Fi Scan (Basic)

Scans for Wi-Fi networks and prints name, signal strength and security. The networks "in range" are a property of the NodeMCU (select it in the inspector).

Parts:
  ESP8266 NodeMCU V3 x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-06-wifi-scan
