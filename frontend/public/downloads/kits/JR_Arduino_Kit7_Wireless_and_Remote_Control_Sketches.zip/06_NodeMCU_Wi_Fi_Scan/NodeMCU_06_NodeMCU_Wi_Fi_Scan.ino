// ---- Circuit (Kit 7, NodeMCU) ----


#include <ESP8266WiFi.h>

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);
}

void loop() {
  Serial.println("scanning...");
  int n = WiFi.scanNetworks();
  Serial.print(n); Serial.println(" networks found");
  for (int i = 0; i < n; i++) {
    Serial.print(i + 1); Serial.print(": "); Serial.print(WiFi.SSID(i));
    Serial.print("  ("); Serial.print(WiFi.RSSI(i)); Serial.print(" dBm) ");
    Serial.println(WiFi.encryptionType(i) == ENC_TYPE_NONE ? "open" : "secured");
  }
  delay(5000);
}
