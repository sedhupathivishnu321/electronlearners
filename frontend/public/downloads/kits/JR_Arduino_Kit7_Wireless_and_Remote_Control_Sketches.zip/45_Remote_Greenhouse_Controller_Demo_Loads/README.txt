Kit 7 - Wireless and Remote Control
Project 45: Remote Greenhouse Controller (Demo Loads) (Advanced)

A Wi-Fi dashboard (/) shows the DHT11 climate and switches the relay load: /fan/on, /fan/off or /auto (fan on above 28 C). /json returns the data. The LCD shows climate and the relay mode. Sensor and relay both go through the level converter.

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1
  Relay Module 1 Channel 5V x1
  DHT11 Temp & Humidity x1
  16x2 LCD I2C x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-45-greenhouse
