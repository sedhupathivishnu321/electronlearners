// ---- Circuit (Kit 7, NodeMCU) ----
// DHT11 powered from VIN (5 V); DATA <-> converter HV4 <-> LV4 <-> D7
// Relay IN <- converter HV3 <- LV3 <- D6 (active LOW); relay powered from VIN (5 V)
// 16x2 LCD (I2C 0x27) powered from VIN: SDA -> D2, SCL -> D1
#define N_DHT D7
#define N_RELAY D6
#define RELAY_ON LOW
#define RELAY_OFF HIGH

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);

#define WIFI_SSID "JR_Learners"
#define WIFI_PASS "jr12345"

void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("connecting to "); Serial.println(WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) { delay(250); Serial.print("."); }
  Serial.println();
  Serial.print("connected, IP address "); Serial.println(WiFi.localIP());
}
#include <DHT.h>
DHT dht(N_DHT, DHT11);
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

int mode = 0;                                   // 0 auto, 1 forced on, 2 forced off
bool fan = false;

String modeName() { return mode == 0 ? "AUTO" : (mode == 1 ? "FORCED ON" : "FORCED OFF"); }

void apply() {
  float t = dht.readTemperature();
  fan = (mode == 1) || (mode == 0 && t > 28.0);
  digitalWrite(N_RELAY, fan ? RELAY_ON : RELAY_OFF);
}

String page() {
  String s = "<html><body><h1>Greenhouse</h1><p>" + String(dht.readTemperature(), 1) + " C, " + String(dht.readHumidity(), 0) + " % humidity</p>";
  s += "<p>Fan relay: <b>" + String(fan ? "ON" : "OFF") + "</b> (" + modeName() + ")</p>";
  s += "<a href='/fan/on'>Fan ON</a> | <a href='/fan/off'>Fan OFF</a> | <a href='/auto'>Auto</a></body></html>";
  return s;
}

void handleRoot() { apply(); server.send(200, "text/html", page()); }
void handleOn() { mode = 1; apply(); server.send(200, "text/html", page()); }
void handleOff() { mode = 2; apply(); server.send(200, "text/html", page()); }
void handleAuto() { mode = 0; apply(); server.send(200, "text/html", page()); }
void handleJson() { server.send(200, "application/json", "{\"temperature\": " + String(dht.readTemperature(), 1) + ", \"humidity\": " + String(dht.readHumidity(), 0) + ", \"fan\": " + String(fan ? "true" : "false") + "}"); }

void setup() {
  digitalWrite(N_RELAY, RELAY_OFF);
  pinMode(N_RELAY, OUTPUT);
  Serial.begin(115200);
  dht.begin();
  lcdBegin();
  lcdRow(0, "Connecting...");
  wifiConnect();
  server.on("/", handleRoot);
  server.on("/fan/on", handleOn);
  server.on("/fan/off", handleOff);
  server.on("/auto", handleAuto);
  server.on("/json", handleJson);
  server.begin();
}

unsigned long lastDraw = 0;

void loop() {
  server.handleClient();
  if (millis() - lastDraw > 800) {
    lastDraw = millis();
    apply();
    lcdRow(0, String(dht.readTemperature(), 1) + "C " + String(dht.readHumidity(), 0) + "%");
    lcdRow(1, "Fan " + String(fan ? "ON " : "off") + " " + modeName());
  }
}
