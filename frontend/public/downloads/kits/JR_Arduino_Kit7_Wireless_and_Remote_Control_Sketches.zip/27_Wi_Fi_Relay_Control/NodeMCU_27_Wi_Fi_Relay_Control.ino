// ---- Circuit (Kit 7, NodeMCU) ----
// Relay IN <- converter HV3 <- LV3 <- D6 (active LOW); relay powered from VIN (5 V)
#define N_RELAY D6
#define RELAY_ON LOW
#define RELAY_OFF HIGH

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);

#define WIFI_SSID "JR_Learners"
#define WIFI_PASS "jr12345"

void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("connecting to "); Serial.println(WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) { delay(250); Serial.print("."); }
  Serial.println();
  Serial.print("connected, IP address "); Serial.println(WiFi.localIP());
}

bool on = false;

String page() {
  String s = "<html><body><h1>Relay</h1><p>The relay is <b>";
  s += on ? "ON" : "OFF";
  s += "</b></p><a href='/on'>ON</a> | <a href='/off'>OFF</a></body></html>";
  return s;
}

void setRelay(bool v) {
  on = v;
  digitalWrite(N_RELAY, v ? RELAY_ON : RELAY_OFF);
  server.send(200, "text/html", page());
}
void handleRoot() { server.send(200, "text/html", page()); }
void handleOn() { setRelay(true); }
void handleOff() { setRelay(false); }

void setup() {
  digitalWrite(N_RELAY, RELAY_OFF);
  pinMode(N_RELAY, OUTPUT);
  Serial.begin(115200);
  wifiConnect();
  server.on("/", handleRoot);
  server.on("/on", handleOn);
  server.on("/off", handleOff);
  server.begin();
}

void loop() {
  server.handleClient();
}
