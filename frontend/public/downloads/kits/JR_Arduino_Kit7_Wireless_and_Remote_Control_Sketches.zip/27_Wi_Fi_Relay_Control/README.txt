Kit 7 - Wireless and Remote Control
Project 27: Wi-Fi Relay Control (Intermediate)

A NodeMCU web page switches a 5 V relay; the 3.3 V GPIO drives the relay input through the level converter.

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1
  Relay Module 1 Channel 5V x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-27-wifi-relay
