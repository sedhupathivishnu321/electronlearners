// ---- Circuit (Kit 7, Uno) ----
// DHT11: VCC 5V, GND, DATA -> D8
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
// serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
#define DHT_PIN 8
#define NRF_CE 9
#define NRF_CSN 10
#define LINK_RX A2
#define LINK_TX A3

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}
#include <DHT.h>
DHT dht(DHT_PIN, DHT11);
#include <SoftwareSerial.h>
SoftwareSerial link(LINK_RX, LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

void setup() {
  Serial.begin(9600);
  dht.begin();
  link.begin(9600);
  radioBegin();
}

void loop() {
  static unsigned long last = 0;
  if (millis() - last >= 2000) {
    last = millis();
    String msg = "T=" + String(dht.readTemperature(), 0) + ";H=" + String(dht.readHumidity(), 0);
    bool ok = sendText(msg);
    Serial.println("sensor node sent " + msg + (ok ? "" : "  (NO ACK)"));
  }
  if (linkPoll()) Serial.println("gateway says: " + linkLine);
}
