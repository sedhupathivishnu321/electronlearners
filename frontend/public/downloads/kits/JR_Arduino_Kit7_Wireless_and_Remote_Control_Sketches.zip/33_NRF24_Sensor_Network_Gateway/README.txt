Kit 7 - Wireless and Remote Control
Project 33: NRF24 Sensor Network Gateway (Advanced)

The Uno sensor node radios its DHT11 reading to the NodeMCU gateway, which serves the latest value over Wi-Fi (/ and /json) and echoes each packet back to the Uno through the level converter serial link.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2
  DHT11 Temp & Humidity x1
  Logic Level Converter 4ch x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-33-nrf-gateway
