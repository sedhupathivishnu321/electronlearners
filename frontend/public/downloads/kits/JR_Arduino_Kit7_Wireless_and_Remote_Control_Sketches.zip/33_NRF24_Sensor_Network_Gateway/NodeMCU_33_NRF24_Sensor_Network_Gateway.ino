// ---- Circuit (Kit 7, NodeMCU) ----
// serial link to the Uno through the level converter: NodeMCU D1 (RX) <- LV1, D2 (TX) -> LV2
// nRF24L01: VCC 3V3, GND, CE -> D0, CSN -> D8, SCK -> D5, MISO -> D6, MOSI -> D7
#define N_LINK_RX D1
#define N_LINK_TX D2
#define NRF_CE D0
#define NRF_CSN D8

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_UNO);
  radio.openReadingPipe(1, PIPE_NODE);
  radio.startListening();
}
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);

#define WIFI_SSID "JR_Learners"
#define WIFI_PASS "jr12345"

void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("connecting to "); Serial.println(WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) { delay(250); Serial.print("."); }
  Serial.println();
  Serial.print("connected, IP address "); Serial.println(WiFi.localIP());
}
#include <SoftwareSerial.h>
SoftwareSerial link(N_LINK_RX, N_LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

String latest = "no data yet";
int packets = 0;

void handleRoot() {
  server.send(200, "text/html", "<html><body><h1>Sensor gateway</h1><p>Latest: <b>" + latest + "</b></p><p>Packets: " + String(packets) + "</p></body></html>");
}
void handleJson() {
  server.send(200, "application/json", "{\"latest\": \"" + latest + "\", \"packets\": " + String(packets) + "}");
}

void setup() {
  Serial.begin(115200);
  link.begin(9600);
  radioBegin();
  wifiConnect();
  server.on("/", handleRoot);
  server.on("/json", handleJson);
  server.begin();
}

void loop() {
  if (recvText()) {
    latest = rxText; packets++;
    Serial.println("radio: " + rxText);
    link.println("RX " + rxText);
  }
  server.handleClient();
}
