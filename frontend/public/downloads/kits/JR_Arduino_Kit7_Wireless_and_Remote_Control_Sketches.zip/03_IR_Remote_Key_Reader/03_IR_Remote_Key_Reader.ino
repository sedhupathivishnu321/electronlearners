// ---- Circuit (Kit 7, Uno) ----
// IR receiver: OUT -> D7, VCC 5V, GND
#define IR_PIN 7

#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}

String keyName(unsigned long code) {
  if (code == KEY_CH) return "CH";
  if (code == KEY_PREV) return "PREV";
  if (code == KEY_NEXT) return "NEXT";
  if (code == KEY_PLAY) return "PLAY/PAUSE";
  if (code == KEY_VOLDN) return "VOL-";
  if (code == KEY_VOLUP) return "VOL+";
  if (code == KEY_EQ) return "EQ";
  if (keyDigit(code) >= 0) return "digit " + String(keyDigit(code));
  return "other key";
}

void setup() {
  Serial.begin(9600);
  irrecv.enableIRIn();
  Serial.println("press a key on the remote");
}

void loop() {
  if (irrecv.decode(&ir)) {
    Serial.print("code 0x"); Serial.print(ir.value, HEX); Serial.print("  -> "); Serial.println(keyName(ir.value));
    irrecv.resume();
  }
}
