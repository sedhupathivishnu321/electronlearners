Kit 7 - Wireless and Remote Control
Project 3: IR Remote Key Reader (Basic)

Prints the code of every remote button you press in the IR remote inspector.

Parts:
  IR Remote + Receiver x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-03-ir-reader
