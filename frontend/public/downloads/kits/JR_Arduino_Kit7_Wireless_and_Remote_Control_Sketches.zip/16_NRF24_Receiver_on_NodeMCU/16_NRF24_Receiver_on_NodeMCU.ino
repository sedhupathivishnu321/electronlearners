// ---- Circuit (Kit 7, Uno) ----
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
#define NRF_CE 9
#define NRF_CSN 10

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}

int n = 0;

void setup() {
  Serial.begin(9600);
  radioBegin();
}

void loop() {
  n++;
  String msg = "packet " + String(n);
  bool ok = sendText(msg);
  Serial.print("sent '"); Serial.print(msg); Serial.println(ok ? "' - acknowledged" : "' - no acknowledgement");
  delay(2000);
}
