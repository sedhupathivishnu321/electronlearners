Kit 7 - Wireless and Remote Control
Project 16: NRF24 Receiver on NodeMCU (Intermediate)

The Uno sends a numbered packet every 2 s; the NodeMCU receives and prints it. Two sketches, two boards - select each board to read its code.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-16-nrf-rx-node
