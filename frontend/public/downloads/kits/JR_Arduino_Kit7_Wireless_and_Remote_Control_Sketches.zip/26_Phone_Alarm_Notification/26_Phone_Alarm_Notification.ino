// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// DHT11: VCC 5V, GND, DATA -> D8
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define BT_RX A0
#define BT_TX A1
#define DHT_PIN 8
#define RED_LED 3

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <DHT.h>
DHT dht(DHT_PIN, DHT11);

bool alert = false;

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  bt.begin(9600);
  dht.begin();
}

void loop() {
  float t = dht.readTemperature(), h = dht.readHumidity();
  bool bad = t > 30 || h > 80;
  if (bad && !alert) { alert = true; bt.println("ALERT: T=" + String(t, 0) + " C, H=" + String(h, 0) + " %"); Serial.println("alert sent"); }
  if (!bad && alert) { alert = false; bt.println("all clear"); Serial.println("all clear sent"); }
  digitalWrite(RED_LED, alert);
  delay(500);
}
