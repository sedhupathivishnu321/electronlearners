Kit 7 - Wireless and Remote Control
Project 26: Phone Alarm Notification (Intermediate)

When the temperature goes above 30 C (or humidity above 80 %) the red LED lights and an ALERT text is sent to the phone once; an all-clear follows when it passes.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  DHT11 Temp & Humidity x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  DHT11: VCC 5V, GND, DATA -> D8
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-26-phone-alert
