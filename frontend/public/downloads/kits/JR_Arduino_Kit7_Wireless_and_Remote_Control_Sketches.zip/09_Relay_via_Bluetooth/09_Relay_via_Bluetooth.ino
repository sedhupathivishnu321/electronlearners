// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define BT_RX A0
#define BT_TX A1
#define RELAY_PIN 5
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define RED_LED 3

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}

void setRelay(bool on) {
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, on);
  bt.println(on ? "relay ON" : "relay OFF");
  Serial.println(on ? "relay ON" : "relay OFF");
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  bt.begin(9600);
}

void loop() {
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd == "RELAY ON" || btCmd == "1") setRelay(true);
    else if (btCmd == "RELAY OFF" || btCmd == "0") setRelay(false);
    else bt.println("use RELAY ON / RELAY OFF");
  }
}
