Kit 7 - Wireless and Remote Control
Project 9: Relay via Bluetooth (Basic)

Phone commands RELAY ON / RELAY OFF (or 1 / 0) switch the relay; the red LED mirrors it.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-09-bt-relay
