Kit 7 - Wireless and Remote Control
Project 30: Remote Temperature Display (Intermediate)

The Uno reads the DHT11 and sends the temperature over the nRF24 radio; the NodeMCU shows it on its LCD (and flags "no signal" if packets stop).

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2
  DHT11 Temp & Humidity x1
  16x2 LCD I2C x1

Circuit notes:
  DHT11: VCC 5V, GND, DATA -> D8
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-30-remote-temp
