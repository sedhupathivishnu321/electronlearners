Kit 7 - Wireless and Remote Control
Project 42: Wireless Light Show Controller (Advanced)

Four animations - 1 alternate flash, 2 chase with servo sweep, 3 breathing red, 4 all off - selected by the phone ("SHOW 2") or by the number keys of the IR remote.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  IR Remote + Receiver x1
  SG90 Micro Servo x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  IR receiver: OUT -> D7, VCC 5V, GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  SG90 servo: signal -> D6, red -> 5V, brown -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-42-light-show
