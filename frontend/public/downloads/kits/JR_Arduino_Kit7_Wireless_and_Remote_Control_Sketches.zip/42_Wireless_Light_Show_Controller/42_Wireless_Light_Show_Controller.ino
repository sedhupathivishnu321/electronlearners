// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// IR receiver: OUT -> D7, VCC 5V, GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
#define BT_RX A0
#define BT_TX A1
#define IR_PIN 7
#define RED_LED 3
#define GREEN_LED 4
#define SERVO_PIN 6

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <Servo.h>
Servo servo;

int show = 4;
unsigned long lastStep = 0;
int phase = 0, angle = 0, dir = 5;

void select(int s, String who) {
  show = s; phase = 0;
  Serial.println("show " + String(s) + " (" + who + ")");
  bt.println("show " + String(s));
  digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, LOW);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  bt.begin(9600);
  irrecv.enableIRIn();
}

void loop() {
  if (irrecv.decode(&ir)) { int d = keyDigit(ir.value); if (d >= 1 && d <= 4) select(d, "IR"); irrecv.resume(); }
  if (btPoll()) { btCmd.toUpperCase(); if (btCmd.startsWith("SHOW ")) { int s = btCmd.substring(5).toInt(); if (s >= 1 && s <= 4) select(s, "phone"); } }
  if (millis() - lastStep < 120) return;
  lastStep = millis();
  phase++;
  if (show == 1) { digitalWrite(RED_LED, phase % 2); digitalWrite(GREEN_LED, (phase + 1) % 2); }
  if (show == 2) {
    digitalWrite(RED_LED, (phase / 2) % 2); digitalWrite(GREEN_LED, (phase / 2 + 1) % 2);
    angle += dir; if (angle >= 180 || angle <= 0) dir = -dir;
    servo.write(angle);
  }
  if (show == 3) { int v = phase % 40; analogWrite(RED_LED, (v < 20 ? v : 40 - v) * 12); }
  if (show == 4) { digitalWrite(RED_LED, LOW); digitalWrite(GREEN_LED, LOW); }
}
