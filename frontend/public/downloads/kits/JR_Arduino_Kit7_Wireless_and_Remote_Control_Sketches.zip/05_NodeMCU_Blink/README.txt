Kit 7 - Wireless and Remote Control
Project 5: NodeMCU Blink (Basic)

Blinks the on-board blue LED of the ESP8266 NodeMCU (it is active LOW).

Parts:
  ESP8266 NodeMCU V3 x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-05-nodemcu-blink
