// ---- Circuit (Kit 7, NodeMCU) ----


void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin(115200);
}

void loop() {
  digitalWrite(LED_BUILTIN, LOW);            // active LOW: LOW = lit
  Serial.println("LED on");
  delay(500);
  digitalWrite(LED_BUILTIN, HIGH);
  Serial.println("LED off");
  delay(500);
}
