Kit 7 - Wireless and Remote Control
Project 8: NRF24 Module Check (Basic)

Both nRF24L01 radios run from the 3.3 V AMS1117 (a 5 V supply would destroy them). The sketch initialises each, prints the status registers and sends a ping from radio A that radio B receives.

Parts:
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  second nRF24L01 on the same SPI bus: CE -> A0, CSN -> A1 (3.3 V from the AMS1117)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-08-nrf-check
