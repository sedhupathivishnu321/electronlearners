// ---- Circuit (Kit 7, Uno) ----
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
// second nRF24L01 on the same SPI bus: CE -> A0, CSN -> A1 (3.3 V from the AMS1117)
#define NRF_CE 9
#define NRF_CSN 10
#define NRF2_CE A0
#define NRF2_CSN A1

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radioA(NRF_CE, NRF_CSN);
RF24 radioB(NRF2_CE, NRF2_CSN);
const uint64_t PIPE = 0xE8E8F0F0E1LL;
byte buf[32];
int count = 0;

void setup() {
  Serial.begin(9600);
  Serial.println("radio A:");
  Serial.println(radioA.begin() ? "  begin OK" : "  begin FAILED - check wiring and the 3.3 V supply");
  Serial.println(radioA.isChipConnected() ? "  chip connected" : "  chip NOT connected");
  radioA.printDetails();
  Serial.println("radio B:");
  Serial.println(radioB.begin() ? "  begin OK" : "  begin FAILED");
  Serial.println(radioB.isChipConnected() ? "  chip connected" : "  chip NOT connected");
  radioA.openWritingPipe(PIPE);
  radioA.stopListening();
  radioB.openReadingPipe(1, PIPE);
  radioB.startListening();
}

void loop() {
  count++;
  String msg = "ping " + String(count);
  bool ok = radioA.write(msg.c_str(), msg.length() + 1);
  Serial.print("A sent '"); Serial.print(msg); Serial.println(ok ? "' (acknowledged)" : "' (no answer)");
  if (radioB.available()) {
    radioB.read(buf, 32);
    String s = "";
    for (int i = 0; i < 32 && buf[i] != 0; i++) s += (char)buf[i];
    Serial.print("B received '"); Serial.print(s); Serial.println("'");
  }
  delay(2000);
}
