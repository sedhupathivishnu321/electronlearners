Kit 7 - Wireless and Remote Control
Project 11: Bluetooth LED Dimmer (Intermediate)

The phone sends a brightness 0-100 (like a slider value) and the red LED follows it with PWM.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-11-bt-dimmer
