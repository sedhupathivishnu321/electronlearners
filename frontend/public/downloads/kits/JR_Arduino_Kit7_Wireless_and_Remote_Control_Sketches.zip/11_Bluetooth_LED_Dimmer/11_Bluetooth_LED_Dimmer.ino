// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define BT_RX A0
#define BT_TX A1
#define RED_LED 3

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  bt.begin(9600);
  bt.println("send brightness 0-100");
}

void loop() {
  if (btPoll()) {
    int pct = constrain(btCmd.toInt(), 0, 100);
    analogWrite(RED_LED, pct * 255 / 100);
    bt.print("brightness "); bt.print(pct); bt.println(" %");
    Serial.print("brightness "); Serial.println(pct);
  }
}
