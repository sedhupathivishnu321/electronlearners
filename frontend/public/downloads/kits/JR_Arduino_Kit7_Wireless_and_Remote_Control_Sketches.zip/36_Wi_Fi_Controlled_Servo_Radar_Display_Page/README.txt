Kit 7 - Wireless and Remote Control
Project 36: Wi-Fi Controlled Servo Radar Display Page (Advanced)

A web page sets the servo angle (/angle?deg=NN) and a status endpoint reports the current angle and how many requests were handled. The servo signal passes through the level converter.

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1
  SG90 Micro Servo x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-36-wifi-servo
