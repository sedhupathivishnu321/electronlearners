// ---- Circuit (Kit 7, NodeMCU) ----
// SG90 signal <- converter HV3 <- LV3 <- D5; servo powered from VIN (5 V)
#define N_SERVO D5

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);

#define WIFI_SSID "JR_Learners"
#define WIFI_PASS "jr12345"

void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("connecting to "); Serial.println(WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) { delay(250); Serial.print("."); }
  Serial.println();
  Serial.print("connected, IP address "); Serial.println(WiFi.localIP());
}
#include <Servo.h>
Servo servo;
int angle = 90, requests = 0;

String page() {
  String s = "<html><body><h1>Servo control</h1><p>Angle: <b>" + String(angle) + "</b> degrees (" + String(requests) + " requests)</p>";
  s += "<a href='/angle?deg=0'>0</a> <a href='/angle?deg=45'>45</a> <a href='/angle?deg=90'>90</a> <a href='/angle?deg=135'>135</a> <a href='/angle?deg=180'>180</a></body></html>";
  return s;
}

void handleRoot() { server.send(200, "text/html", page()); }
void handleAngle() {
  requests++;
  if (server.hasArg("deg")) { angle = constrain(server.arg("deg").toInt(), 0, 180); servo.write(angle); }
  server.send(200, "text/html", page());
}
void handleStatus() { server.send(200, "application/json", "{\"angle\": " + String(angle) + ", \"requests\": " + String(requests) + "}"); }

void setup() {
  Serial.begin(115200);
  servo.attach(N_SERVO);
  servo.write(angle);
  wifiConnect();
  server.on("/", handleRoot);
  server.on("/angle", handleAngle);
  server.on("/status", handleStatus);
  server.begin();
}

void loop() {
  server.handleClient();
}
