// ---- Circuit (Kit 7, Uno) ----
// IR receiver: OUT -> D7, VCC 5V, GND
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define IR_PIN 7
#define BT_RX A0
#define BT_TX A1
#define RELAY_PIN 5
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define GREEN_LED 4
#define RED_LED 3

#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

bool on = false;
unsigned long irUntil = 0;

void apply(String who) {
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
  digitalWrite(GREEN_LED, on);
  digitalWrite(RED_LED, millis() < irUntil);
  lcdRow(0, String("Appliance ") + (on ? "ON" : "OFF"));
  lcdRow(1, "by " + who);
  Serial.println(String("appliance ") + (on ? "ON" : "OFF") + " (" + who + ")");
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  bt.begin(9600);
  irrecv.enableIRIn();
  lcdBegin();
  apply("start-up");
}

void loop() {
  if (irrecv.decode(&ir)) {
    if (ir.value == KEY_CH) { on = !on; irUntil = millis() + 10000; apply("IR remote"); }
    irrecv.resume();
  }
  if (btPoll()) {
    btCmd.toUpperCase();
    if (millis() < irUntil) { bt.println("IR override active - refused"); Serial.println("phone command refused (IR priority)"); }
    else if (btCmd == "ON") { on = true; apply("phone"); bt.println("ok, ON"); }
    else if (btCmd == "OFF") { on = false; apply("phone"); bt.println("ok, OFF"); }
  }
  digitalWrite(RED_LED, millis() < irUntil);
}
