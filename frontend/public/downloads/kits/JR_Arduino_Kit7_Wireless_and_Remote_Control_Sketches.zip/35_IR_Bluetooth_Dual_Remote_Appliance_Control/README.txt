Kit 7 - Wireless and Remote Control
Project 35: IR + Bluetooth Dual Remote Appliance Control (Advanced)

Both the IR remote (CH toggles) and the phone (ON / OFF) control the relay. Priority rule: after any IR command the local remote wins for 10 s and phone commands are refused. The LCD shows the state and who has priority.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  IR Remote + Receiver x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-35-dual-remote
