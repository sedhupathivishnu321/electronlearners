Kit 7 - Wireless and Remote Control
Project 40: Wi-Fi Time Display Clock (Advanced)

The NodeMCU joins Wi-Fi, gets the time with NTP (IST, UTC+5:30, taken from the PC clock in the simulator) and sends "TIME hh:mm:ss" to the Uno every second through the level converter; the Uno shows it on the LCD.

Parts:
  ESP8266 NodeMCU V3 x1
  16x2 LCD I2C x1
  Logic Level Converter 4ch x1

Circuit notes:
  serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-40-ntp-clock
