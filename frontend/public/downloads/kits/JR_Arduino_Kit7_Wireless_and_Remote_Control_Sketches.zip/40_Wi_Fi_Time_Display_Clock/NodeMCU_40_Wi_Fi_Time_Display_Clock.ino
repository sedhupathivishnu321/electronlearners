// ---- Circuit (Kit 7, NodeMCU) ----
// serial link to the Uno through the level converter: NodeMCU D1 (RX) <- LV1, D2 (TX) -> LV2
#define N_LINK_RX D1
#define N_LINK_TX D2

#include <ESP8266WiFi.h>
#include <NTPClient.h>
#include <WiFiUdp.h>
#include <SoftwareSerial.h>
SoftwareSerial link(N_LINK_RX, N_LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", 19800);        // 19800 s = UTC + 5:30

void setup() {
  Serial.begin(115200);
  link.begin(9600);
  WiFi.mode(WIFI_STA);
  WiFi.begin("JR_Learners", "jr12345");
  while (WiFi.status() != WL_CONNECTED) { delay(250); }
  link.println("INFO Wi-Fi connected");
  Serial.println("connected");
  timeClient.begin();
}

void loop() {
  timeClient.update();
  link.println("TIME " + timeClient.getFormattedTime());
  delay(1000);
}
