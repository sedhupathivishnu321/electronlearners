// ---- Circuit (Kit 7, Uno) ----
// serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define LINK_RX A2
#define LINK_TX A3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <SoftwareSerial.h>
SoftwareSerial link(LINK_RX, LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

void setup() {
  Serial.begin(9600);
  link.begin(9600);
  lcdBegin();
  lcdRow(0, "Wi-Fi clock");
  lcdRow(1, "waiting for time");
}

void loop() {
  if (linkPoll()) {
    if (linkLine.startsWith("TIME ")) { lcdRow(0, "Wi-Fi clock"); lcdRow(1, linkLine.substring(5)); Serial.println(linkLine); }
    else if (linkLine.startsWith("INFO ")) lcdRow(1, linkLine.substring(5));
  }
}
