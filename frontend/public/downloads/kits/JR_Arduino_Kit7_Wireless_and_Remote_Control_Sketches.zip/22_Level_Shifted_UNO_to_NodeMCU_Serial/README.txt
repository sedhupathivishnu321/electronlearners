Kit 7 - Wireless and Remote Control
Project 22: Level-Shifted UNO to NodeMCU Serial (Intermediate)

The Uno (5 V) and the NodeMCU (3.3 V) exchange text through the level converter: the Uno sends PING n every second and the NodeMCU answers ACK n.

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1

Circuit notes:
  serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-22-level-serial
