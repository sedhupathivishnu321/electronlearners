// ---- Circuit (Kit 7, Uno) ----
// serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
#define LINK_RX A2
#define LINK_TX A3

#include <SoftwareSerial.h>
SoftwareSerial link(LINK_RX, LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

int n = 0;
unsigned long last = 0;

void setup() {
  Serial.begin(9600);
  link.begin(9600);
}

void loop() {
  if (millis() - last >= 1000) { last = millis(); n++; link.println("PING " + String(n)); Serial.println("sent PING " + String(n)); }
  if (linkPoll()) { Serial.println("reply: " + linkLine); }
}
