// ---- Circuit (Kit 7, NodeMCU) ----
// serial link to the Uno through the level converter: NodeMCU D1 (RX) <- LV1, D2 (TX) -> LV2
#define N_LINK_RX D1
#define N_LINK_TX D2

#include <SoftwareSerial.h>
SoftwareSerial link(N_LINK_RX, N_LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

void setup() {
  Serial.begin(115200);
  link.begin(9600);
}

void loop() {
  if (linkPoll()) {
    Serial.println("NodeMCU got: " + linkLine);
    if (linkLine.startsWith("PING ")) link.println("ACK " + linkLine.substring(5));
  }
}
