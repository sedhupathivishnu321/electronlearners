Kit 7 - Wireless and Remote Control
Project 23: NRF24 Two-Way Chat (Intermediate)

Type a message in the Serial Monitor of either board and it appears in the other board's monitor over the radio link.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-23-nrf-chat
