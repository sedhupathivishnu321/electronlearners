// ---- Circuit (Kit 7, NodeMCU) ----
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define N_LED D3

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);

#define WIFI_SSID "JR_Learners"
#define WIFI_PASS "jr12345"

void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("connecting to "); Serial.println(WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) { delay(250); Serial.print("."); }
  Serial.println();
  Serial.print("connected, IP address "); Serial.println(WiFi.localIP());
}

bool ledOn = false;

String page() {
  String s = "<html><body><h1>JR Learners LED</h1><p>The LED is <b>";
  s += ledOn ? "ON" : "OFF";
  s += "</b></p><a href='/on'>Turn ON</a> | <a href='/off'>Turn OFF</a></body></html>";
  return s;
}

void handleRoot() { server.send(200, "text/html", page()); }
void handleOn() { ledOn = true; digitalWrite(N_LED, HIGH); server.send(200, "text/html", page()); }
void handleOff() { ledOn = false; digitalWrite(N_LED, LOW); server.send(200, "text/html", page()); }

void setup() {
  pinMode(N_LED, OUTPUT);
  Serial.begin(115200);
  wifiConnect();
  server.on("/", handleRoot);
  server.on("/on", handleOn);
  server.on("/off", handleOff);
  server.begin();
  Serial.println("web server started");
}

void loop() {
  server.handleClient();
}
