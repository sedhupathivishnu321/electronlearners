Kit 7 - Wireless and Remote Control
Project 17: Wi-Fi Web LED Control (Intermediate)

The NodeMCU joins the Wi-Fi network and hosts a page with ON / OFF links for an LED. Use the "Browser" box in the NodeMCU inspector (GET /, /on, /off).

Parts:
  ESP8266 NodeMCU V3 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-17-wifi-led
