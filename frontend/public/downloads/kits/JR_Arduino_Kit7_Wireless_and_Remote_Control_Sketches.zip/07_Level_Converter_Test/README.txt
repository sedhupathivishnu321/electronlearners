Kit 7 - Wireless and Remote Control
Project 7: Level Converter Test (Basic)

The Uno drives a 5 V signal that passes through the level converter to a NodeMCU input (3.3 V logic). The NodeMCU reports what it sees; the Uno reports what it sends.

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1

Circuit notes:
  serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-07-level-test
