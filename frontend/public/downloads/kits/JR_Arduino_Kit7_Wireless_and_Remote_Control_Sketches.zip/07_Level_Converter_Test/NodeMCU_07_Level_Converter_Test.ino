// ---- Circuit (Kit 7, NodeMCU) ----
// serial link to the Uno through the level converter: NodeMCU D1 (RX) <- LV1, D2 (TX) -> LV2
#define N_LINK_RX D1
#define N_LINK_TX D2

int last = -1;

void setup() {
  pinMode(N_LINK_RX, INPUT);
  Serial.begin(115200);
}

void loop() {
  int v = digitalRead(N_LINK_RX);
  if (v != last) {
    last = v;
    Serial.println(v ? "NodeMCU input sees HIGH (3.3 V side)" : "NodeMCU input sees LOW");
  }
  delay(50);
}
