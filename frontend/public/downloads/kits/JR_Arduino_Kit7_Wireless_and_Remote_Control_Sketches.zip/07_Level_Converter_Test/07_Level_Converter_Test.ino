// ---- Circuit (Kit 7, Uno) ----
// serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
#define LINK_RX A2
#define LINK_TX A3

void setup() {
  pinMode(LINK_TX, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  digitalWrite(LINK_TX, HIGH);
  Serial.println("Uno drives the 5 V line HIGH");
  delay(1500);
  digitalWrite(LINK_TX, LOW);
  Serial.println("Uno drives the 5 V line LOW");
  delay(1500);
}
