// ---- Circuit (Kit 7, Uno) ----
// IR receiver: OUT -> D7, VCC 5V, GND
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define IR_PIN 7
#define BT_RX A0
#define BT_TX A1
#define RELAY_PIN 5
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define SERVO_PIN 6
#define BTN1 2

#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Servo.h>
Servo servo;
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

unsigned long bound[3] = {0, 0, 0};
int learning = -1;                                 // action being learned, -1 = none
int pick = -1;                                     // last action chosen with the button (the next press moves on)
bool relayOn = false;
int macro[8];
int macroLen = 0;
bool recording = false;

String actionName(int a) { if (a == 0) return "relay toggle"; if (a == 1) return "servo 0"; return "servo 180"; }

void run(int a) {
  if (a == 0) { relayOn = !relayOn; digitalWrite(RELAY_PIN, relayOn ? RELAY_ON : RELAY_OFF); }
  if (a == 1) servo.write(0);
  if (a == 2) servo.write(180);
  lcdRow(0, "Action:");
  lcdRow(1, actionName(a));
  Serial.println("run " + actionName(a));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  bt.begin(9600);
  irrecv.enableIRIn();
  lcdBegin();
  lcdRow(0, "Remote hub");
  lcdRow(1, "button = learn");
}

void loop() {
  if (pressed()) {
    pick = (pick + 1) % 3;
    learning = pick;
    lcdRow(0, "Learning:");
    lcdRow(1, actionName(learning) + "?");
    Serial.println("press a remote key for: " + actionName(learning));
  }
  if (irrecv.decode(&ir)) {
    if (learning >= 0) { bound[learning] = ir.value; Serial.println("learned 0x" + String(ir.value, HEX) + " = " + actionName(learning)); lcdRow(0, "Learned!"); lcdRow(1, actionName(learning)); learning = -1; }
    else for (int a = 0; a < 3; a++) if (bound[a] == ir.value) run(a);
    irrecv.resume();
  }
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd == "REC") { recording = true; macroLen = 0; bt.println("recording"); }
    else if (btCmd == "END") { recording = false; bt.println("macro saved: " + String(macroLen) + " steps"); }
    else if (btCmd == "PLAY") { bt.println("playing"); for (int i = 0; i < macroLen; i++) { run(macro[i]); delay(1000); } bt.println("done"); }
    else {
      int a = btCmd == "RELAY" ? 0 : (btCmd == "SERVO0" ? 1 : (btCmd == "SERVO180" ? 2 : -1));
      if (a >= 0) { if (recording && macroLen < 8) { macro[macroLen] = a; macroLen++; bt.println("step " + String(macroLen)); } else run(a); }
    }
  }
}
