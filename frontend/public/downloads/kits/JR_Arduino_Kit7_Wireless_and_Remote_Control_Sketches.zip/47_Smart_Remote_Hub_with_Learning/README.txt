Kit 7 - Wireless and Remote Control
Project 47: Smart Remote Hub with Learning (Advanced)

IR learning: press the button to pick an action (relay toggle / servo 0 / servo 180) and press a remote key to bind it. Bluetooth macros: REC, then action words (RELAY, SERVO0, SERVO180), then END; PLAY runs them one second apart.

Parts:
  Push Button tactile 6x6 x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  IR Remote + Receiver x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-47-remote-hub
