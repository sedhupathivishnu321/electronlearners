// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define BT_RX A0
#define BT_TX A1
#define SERVO_PIN 6
#define GREEN_LED 4
#define RED_LED 3

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Servo.h>
Servo servo;
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

bool locked = true;

void show() {
  servo.write(locked ? 0 : 90);
  digitalWrite(RED_LED, locked);
  digitalWrite(GREEN_LED, !locked);
  lcdRow(0, "Door lock");
  lcdRow(1, locked ? "LOCKED" : "UNLOCKED");
  bt.println(locked ? "locked" : "unlocked");
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  bt.begin(9600);
  lcdBegin();
  show();
}

void loop() {
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd == "LOCK") { locked = true; show(); }
    else if (btCmd == "UNLOCK") { locked = false; show(); }
    else bt.println("use LOCK or UNLOCK");
  }
}
