Kit 7 - Wireless and Remote Control
Project 20: Remote Door Lock (Intermediate)

The phone commands LOCK / UNLOCK move the servo bolt (0 = locked, 90 = unlocked); the LCD and the red / green LEDs show the state.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  SG90 Micro Servo x1
  16x2 LCD I2C x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-20-remote-lock
