Kit 7 - Wireless and Remote Control
Project 37: Wireless Alarm System (Advanced)

A contact sensor (the button on the NodeMCU: pressed = door open) radios OPEN / CLOSED to the Uno. While armed an OPEN triggers the siren (red flashes fast) and an ALERT text to the phone; the phone can ARM / DISARM. Green = armed and secure.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Push Button tactile 6x6 x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  NRF24L01 Radio x2

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-37-wireless-alarm
