// ---- Circuit (Kit 7, Uno) ----
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define NRF_CE 9
#define NRF_CSN 10
#define BT_RX A0
#define BT_TX A1
#define RED_LED 3
#define GREEN_LED 4

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}
#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}

bool armed = true, alarm = false;
bool doorOpen = false;

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  bt.begin(9600);
  radioBegin();
  bt.println("alarm armed - send ARM / DISARM");
}

void loop() {
  if (recvText()) {
    doorOpen = (rxText == "OPEN");
    Serial.println("sensor: " + rxText);
    if (doorOpen && armed && !alarm) { alarm = true; bt.println("ALERT: door opened!"); Serial.println("ALARM!"); }
  }
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd == "ARM") { armed = true; bt.println("armed"); }
    if (btCmd == "DISARM") { armed = false; alarm = false; bt.println("disarmed"); }
  }
  if (alarm && !armed) alarm = false;
  digitalWrite(RED_LED, alarm && (millis() / 120) % 2);
  digitalWrite(GREEN_LED, armed && !alarm && !doorOpen);
}
