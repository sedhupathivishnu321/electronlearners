Kit 7 - Wireless and Remote Control
Project 43: NRF24 Range and Packet-Loss Tester (Advanced)

The Uno sends 50 numbered packets (one every 150 ms) and counts the acknowledgements; the LCD shows sent / acknowledged and the loss percentage per run. The NodeMCU counts what it received and spots sequence gaps. Raise "Packet loss" on a radio to model distance.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  NRF24L01 Radio x2
  16x2 LCD I2C x1

Circuit notes:
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-43-range-tester
