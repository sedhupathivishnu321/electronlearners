Kit 7 - Wireless and Remote Control
Project 14: IR Remote Relay Switch (Intermediate)

The CH key (the remote's power button) toggles the relay; the green LED shows its state.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  IR Remote + Receiver x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-14-ir-relay
