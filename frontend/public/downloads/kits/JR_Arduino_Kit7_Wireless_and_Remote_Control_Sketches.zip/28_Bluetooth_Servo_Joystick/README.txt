Kit 7 - Wireless and Remote Control
Project 28: Bluetooth Servo Joystick (Intermediate)

The phone sends "x,y" pairs (0-180 each, like an on-screen joystick); the servo glides to x in small steps, y is reported back.

Parts:
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  SG90 Micro Servo x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-28-bt-joystick
