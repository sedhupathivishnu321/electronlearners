Kit 7 - Wireless and Remote Control
Project 18: Wi-Fi Temperature Web Page (Intermediate)

The NodeMCU serves the DHT11 temperature and humidity on a local web page (the DHT11 data line goes through the level converter because the sensor runs at 5 V).

Parts:
  ESP8266 NodeMCU V3 x1
  Logic Level Converter 4ch x1
  DHT11 Temp & Humidity x1

Circuit notes:


Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-18-wifi-temp
