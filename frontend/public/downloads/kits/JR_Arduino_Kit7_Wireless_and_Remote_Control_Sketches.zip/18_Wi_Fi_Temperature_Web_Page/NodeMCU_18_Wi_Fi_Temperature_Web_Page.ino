// ---- Circuit (Kit 7, NodeMCU) ----
// DHT11 powered from VIN (5 V); DATA <-> converter HV4 <-> LV4 <-> D7
#define N_DHT D7

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);

#define WIFI_SSID "JR_Learners"
#define WIFI_PASS "jr12345"

void wifiConnect() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("connecting to "); Serial.println(WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) { delay(250); Serial.print("."); }
  Serial.println();
  Serial.print("connected, IP address "); Serial.println(WiFi.localIP());
}
#include <DHT.h>
DHT dht(N_DHT, DHT11);

void handleRoot() {
  String s = "<html><body><h1>Room climate</h1><p>Temperature: " + String(dht.readTemperature(), 1) + " C</p><p>Humidity: " + String(dht.readHumidity(), 0) + " %</p></body></html>";
  server.send(200, "text/html", s);
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  wifiConnect();
  server.on("/", handleRoot);
  server.begin();
}

void loop() {
  server.handleClient();
}
