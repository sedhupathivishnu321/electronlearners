Kit 7 - Wireless and Remote Control
Project 24: IR Remote Number Entry (Intermediate)

Digits typed on the remote are shown on the LCD (up to 8). CH clears, PLAY accepts the number and shows its double.

Parts:
  IR Remote + Receiver x1
  16x2 LCD I2C x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-24-ir-number
