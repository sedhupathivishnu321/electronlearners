// ---- Circuit (Kit 7, Uno) ----
// IR receiver: OUT -> D7, VCC 5V, GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define IR_PIN 7

#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

String entry = "";

void show(String second) {
  lcdRow(0, "Number: " + entry);
  lcdRow(1, second);
}

void setup() {
  Serial.begin(9600);
  irrecv.enableIRIn();
  lcdBegin();
  show("digits, PLAY=enter");
}

void loop() {
  if (irrecv.decode(&ir)) {
    int d = keyDigit(ir.value);
    if (d >= 0 && entry.length() < 8) { entry += String(d); show("digits, PLAY=enter"); }
    else if (ir.value == KEY_CH) { entry = ""; show("cleared"); }
    else if (ir.value == KEY_PLAY && entry.length() > 0) {
      long v = entry.toInt();
      show("x2 = " + String(v * 2));
      Serial.print("entered "); Serial.println(v);
    }
    irrecv.resume();
  }
}
