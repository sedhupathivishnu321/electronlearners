Kit 7 - Wireless and Remote Control
Project 1: Bluetooth LED Control (Basic)

Send 1 / ON or 0 / OFF from the phone terminal (HC-05 inspector) to switch the red LED. The 10k + 20k divider brings the Uno 5 V TX down to the 3.3 V the module accepts.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-01-bt-led
