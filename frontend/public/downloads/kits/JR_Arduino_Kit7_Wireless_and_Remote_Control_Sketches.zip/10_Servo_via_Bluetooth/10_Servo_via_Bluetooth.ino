// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
#define BT_RX A0
#define BT_TX A1
#define SERVO_PIN 6

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Servo.h>
Servo servo;

void setup() {
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.begin(9600);
  bt.begin(9600);
  bt.println("send an angle 0-180");
}

void loop() {
  if (btPoll()) {
    int a = constrain(btCmd.toInt(), 0, 180);
    servo.write(a);
    bt.print("servo at "); bt.println(a);
    Serial.print("servo at "); Serial.println(a);
  }
}
