Kit 7 - Wireless and Remote Control
Project 21: LCD Message Receiver (Intermediate)

Text typed on the phone appears on the LCD (long messages are split over the two rows).

Parts:
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  16x2 LCD I2C x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-21-lcd-receiver
