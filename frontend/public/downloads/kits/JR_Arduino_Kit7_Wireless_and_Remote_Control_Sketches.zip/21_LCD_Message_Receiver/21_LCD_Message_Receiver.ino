// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define BT_RX A0
#define BT_TX A1

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

void setup() {
  Serial.begin(9600);
  bt.begin(9600);
  lcdBegin();
  lcdRow(0, "Waiting for");
  lcdRow(1, "a message...");
}

void loop() {
  if (btPoll()) {
    lcdRow(0, btCmd.substring(0, 16));
    lcdRow(1, btCmd.length() > 16 ? btCmd.substring(16, 32) : "");
    bt.println("shown on the LCD");
    Serial.println(btCmd);
  }
}
