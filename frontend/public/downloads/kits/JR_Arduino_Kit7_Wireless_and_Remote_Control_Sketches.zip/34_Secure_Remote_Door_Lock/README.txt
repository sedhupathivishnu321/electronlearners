Kit 7 - Wireless and Remote Control
Project 34: Secure Remote Door Lock (Advanced)

Two factors open the lock: the PIN (send PIN 1234 from the phone) and a fresh rolling code from the NodeMCU key fob. Every fob code is used once - a replayed (old) code is rejected. The fob sends the next code every 8 s; type R in the fob's monitor to replay the last one.

Parts:
  ESP8266 NodeMCU V3 x1
  AMS1117-3.3V Regulator x1
  Electrolytic Capacitor 100uF 25V x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  NRF24L01 Radio x2
  SG90 Micro Servo x1
  16x2 LCD I2C x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-34-secure-lock
