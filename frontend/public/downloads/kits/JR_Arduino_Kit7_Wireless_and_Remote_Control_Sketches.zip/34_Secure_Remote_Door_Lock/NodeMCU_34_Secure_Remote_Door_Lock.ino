// ---- Circuit (Kit 7, NodeMCU) ----
// nRF24L01: VCC 3V3, GND, CE -> D0, CSN -> D8, SCK -> D5, MISO -> D6, MOSI -> D7
#define NRF_CE D0
#define NRF_CSN D8

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_UNO);
  radio.openReadingPipe(1, PIPE_NODE);
  radio.startListening();
}

unsigned long counter = 0, lastSent = 0, lastCode = 0;
unsigned long codeFor(unsigned long n) { return (n * n * 37 + n * 911 + 4001) % 9973; }

void sendCode(unsigned long n) {
  String msg = "K" + String(n) + ":" + String(codeFor(n));
  bool ok = sendText(msg);
  Serial.println("fob sent " + msg + (ok ? "" : "  (no ack)"));
}

void setup() {
  Serial.begin(115200);
  radioBegin();
  Serial.println("key fob ready: R = replay the last code, S = send the next code now");
}

void loop() {
  if (millis() - lastSent >= 8000) { lastSent = millis(); counter++; sendCode(counter); }
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == 'R' || c == 'r') { Serial.println("replaying the old code"); sendCode(counter); }
    if (c == 'S' || c == 's') { lastSent = millis(); counter++; sendCode(counter); }
  }
}
