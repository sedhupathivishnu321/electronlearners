// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// nRF24L01 radio: VCC 3.3V from the AMS1117 (never 5 V!), GND, CE -> D9, CSN -> D10, SCK -> D13, MOSI -> D11, MISO -> D12
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define BT_RX A0
#define BT_TX A1
#define NRF_CE 9
#define NRF_CSN 10
#define SERVO_PIN 6

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t PIPE_UNO = 0xE8E8F0F0E1LL;     // address the Uno listens on
const uint64_t PIPE_NODE = 0xE8E8F0F0D2LL;    // address the NodeMCU listens on

byte rxBuf[32];
String rxText = "";
bool recvText() {                          // true when a text packet has arrived (in rxText)
  if (!radio.available()) return false;
  radio.read(rxBuf, 32);
  rxText = "";
  for (int i = 0; i < 32 && rxBuf[i] != 0; i++) rxText += (char)rxBuf[i];
  return true;
}
bool sendText(String s) {                  // stop listening, transmit (true = acknowledged), listen again
  radio.stopListening();
  bool ok = radio.write(s.c_str(), s.length() + 1);
  radio.startListening();
  return ok;
}
void radioBegin() {
  if (!radio.begin()) Serial.println("nRF24L01 not found - check the wiring and the 3.3 V supply");
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(PIPE_NODE);
  radio.openReadingPipe(1, PIPE_UNO);
  radio.startListening();
}
#include <Servo.h>
Servo servo;
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

#define PIN_CODE "1234"
unsigned long lastCounter = 0;
unsigned long fobAt = 0, pinAt = 0;
bool locked = true;

unsigned long codeFor(unsigned long n) { return (n * n * 37 + n * 911 + 4001) % 9973; }     // the same formula runs in the fob

void show(String l2) {
  servo.write(locked ? 0 : 90);
  lcdRow(0, locked ? "LOCKED" : "UNLOCKED");
  lcdRow(1, l2);
}

void tryUnlock() {
  bool pin = pinAt > 0 && millis() - pinAt < 15000;
  bool fob = fobAt > 0 && millis() - fobAt < 15000;
  if (pin && fob && locked) { locked = false; pinAt = 0; fobAt = 0; show("PIN + fob OK"); bt.println("UNLOCKED"); Serial.println("UNLOCKED"); }
}

void setup() {
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  bt.begin(9600);
  lcdBegin();
  radioBegin();
  show("PIN + fob needed");
}

void loop() {
  if (btPoll()) {
    btCmd.toUpperCase();
    if (btCmd.startsWith("PIN ")) {
      if (btCmd.substring(4) == PIN_CODE) { pinAt = millis(); bt.println("PIN accepted - waiting for the fob"); show("PIN ok, need fob"); }
      else { bt.println("WRONG PIN"); show("wrong PIN"); }
      tryUnlock();
    } else if (btCmd == "LOCK") { locked = true; show("locked again"); bt.println("LOCKED"); }
  }
  if (recvText()) {                                          // fob packet: K<counter>:<code>
    int colon = rxText.indexOf(':');
    unsigned long n = rxText.substring(1, colon).toInt();
    unsigned long code = rxText.substring(colon + 1).toInt();
    if (n > lastCounter && n <= lastCounter + 5 && code == codeFor(n)) { lastCounter = n; fobAt = millis(); Serial.println("fob code accepted (counter " + String(n) + ")"); show("fob ok"); tryUnlock(); }
    else { Serial.println("REJECTED fob code (replay or wrong code)"); bt.println("ALERT: fob replay rejected"); show("replay blocked"); }
  }
}
