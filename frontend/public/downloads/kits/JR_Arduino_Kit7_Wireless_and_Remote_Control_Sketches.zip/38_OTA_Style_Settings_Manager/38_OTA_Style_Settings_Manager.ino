// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define BT_RX A0
#define BT_TX A1

#include <EEPROM.h>
#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
String hex2(int v) {                        // two hex digits
  String h = "0123456789ABCDEF";
  return String(h.charAt((v >> 4) & 15)) + String(h.charAt(v & 15));
}
int unhex(char c) { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return 0; }

int bri = 128, interval = 5, thr = 30;

int checksum(String s) { int c = 0; for (int i = 0; i < s.length(); i++) c ^= s.charAt(i); return c; }

void save() { EEPROM.write(0, 0xA5); EEPROM.write(1, bri); EEPROM.write(2, interval); EEPROM.write(3, thr); }
void load() { if (EEPROM.read(0) == 0xA5) { bri = EEPROM.read(1); interval = EEPROM.read(2); thr = EEPROM.read(3); } }
void show(String note) { lcdRow(0, "B" + String(bri) + " I" + String(interval) + " T" + String(thr)); lcdRow(1, note); }

void setup() {
  Serial.begin(9600);
  bt.begin(9600);
  lcdBegin();
  load();
  show("settings loaded");
  bt.println("SET <BRI|INT|THR> <value>*<hex xor checksum>, or GET");
}

void loop() {
  if (btPoll()) {
    if (btCmd == "GET") { bt.println("BRI=" + String(bri) + " INT=" + String(interval) + " THR=" + String(thr)); return; }
    int star = btCmd.indexOf('*');
    if (!btCmd.startsWith("SET ") || star < 0) { bt.println("ERR format"); return; }
    String body = btCmd.substring(0, star);
    String cs = btCmd.substring(star + 1);
    cs.toUpperCase();
    if (cs != hex2(checksum(body))) { bt.println("ERR checksum, expected " + hex2(checksum(body))); show("bad checksum"); return; }
    String name = body.substring(4, 7);
    int value = constrain(body.substring(8).toInt(), 0, 255);
    if (name == "BRI") bri = value;
    else if (name == "INT") interval = value;
    else if (name == "THR") thr = value;
    else { bt.println("ERR unknown setting"); return; }
    save();
    show("saved " + name);
    bt.println("OK " + name + "=" + String(value));
  }
}
