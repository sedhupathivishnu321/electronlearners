Kit 7 - Wireless and Remote Control
Project 38: OTA-Style Settings Manager (Advanced)

Settings (BRI brightness, INT interval, THR threshold) are edited over Bluetooth with a checksum: send "SET BRI 120*CS" where CS is the 2-digit hex XOR of the text before the star; bad checksums are refused. GET lists the settings; values are stored in EEPROM.

Parts:
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  16x2 LCD I2C x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-38-settings-manager
