Kit 7 - Wireless and Remote Control
Project 13: IR Remote Controlled Servo (Intermediate)

PREV / NEXT keys turn the servo 15 degrees left / right and PLAY centres it.

Parts:
  IR Remote + Receiver x1
  SG90 Micro Servo x1

Circuit notes:
  IR receiver: OUT -> D7, VCC 5V, GND
  SG90 servo: signal -> D6, red -> 5V, brown -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-13-ir-servo
