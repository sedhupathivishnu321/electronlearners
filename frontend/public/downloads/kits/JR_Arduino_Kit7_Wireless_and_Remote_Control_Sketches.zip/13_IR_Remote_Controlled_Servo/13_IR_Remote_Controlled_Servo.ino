// ---- Circuit (Kit 7, Uno) ----
// IR receiver: OUT -> D7, VCC 5V, GND
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
#define IR_PIN 7
#define SERVO_PIN 6

#include <IRremote.h>
IRrecv irrecv(IR_PIN);
decode_results ir;

#define KEY_CH 0xFF629D
#define KEY_PREV 0xFF22DD
#define KEY_NEXT 0xFF02FD
#define KEY_PLAY 0xFFC23D
#define KEY_VOLDN 0xFFE01F
#define KEY_VOLUP 0xFFA857
#define KEY_EQ 0xFF906F
int keyDigit(unsigned long code) {         // 0-9 for the number keys, -1 for the others
  if (code == 0xFF6897) return 0; if (code == 0xFF30CF) return 1; if (code == 0xFF18E7) return 2; if (code == 0xFF7A85) return 3;
  if (code == 0xFF10EF) return 4; if (code == 0xFF38C7) return 5; if (code == 0xFF5AA5) return 6; if (code == 0xFF42BD) return 7;
  if (code == 0xFF4AB5) return 8; if (code == 0xFF52AD) return 9;
  return -1;
}
#include <Servo.h>
Servo servo;

int angle = 90;

void setup() {
  servo.attach(SERVO_PIN);
  servo.write(angle);
  Serial.begin(9600);
  irrecv.enableIRIn();
}

void loop() {
  if (irrecv.decode(&ir)) {
    if (ir.value == KEY_PREV) angle = max(angle - 15, 0);
    else if (ir.value == KEY_NEXT) angle = min(angle + 15, 180);
    else if (ir.value == KEY_PLAY) angle = 90;
    servo.write(angle);
    Serial.print("servo "); Serial.println(angle);
    irrecv.resume();
  }
}
