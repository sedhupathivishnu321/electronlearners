Kit 7 - Wireless and Remote Control
Project 49: Wi-Fi Access Point Configuration Portal (Advanced)

The NodeMCU starts its own access point "JR_Setup" and serves a form; /set?name=...&val=... forwards "SET name val" to the Uno over the level-shifted serial link, where it is shown on the LCD and stored in EEPROM.

Parts:
  ESP8266 NodeMCU V3 x1
  16x2 LCD I2C x1
  Logic Level Converter 4ch x1

Circuit notes:
  serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-49-ap-portal
