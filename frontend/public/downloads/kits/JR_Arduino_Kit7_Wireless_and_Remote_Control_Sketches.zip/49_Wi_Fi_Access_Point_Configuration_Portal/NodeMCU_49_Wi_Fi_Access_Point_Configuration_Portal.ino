// ---- Circuit (Kit 7, NodeMCU) ----
// serial link to the Uno through the level converter: NodeMCU D1 (RX) <- LV1, D2 (TX) -> LV2
#define N_LINK_RX D1
#define N_LINK_TX D2

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <SoftwareSerial.h>
ESP8266WebServer server(80);
#include <SoftwareSerial.h>
SoftwareSerial link(N_LINK_RX, N_LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

String lastReply = "";

void handleRoot() {
  String s = "<html><body><h1>JR Setup portal</h1><form action='/set'>Name <input name='name'> Value <input name='val'> <input type='submit' value='Save'></form>";
  s += "<p>Last answer from the Uno: " + lastReply + "</p></body></html>";
  server.send(200, "text/html", s);
}

void handleSet() {
  String name = server.arg("name"), val = server.arg("val");
  if (name == "" || val == "") { server.send(400, "text/plain", "name and val are required"); return; }
  link.println("SET " + name + " " + val);
  server.send(200, "text/html", "<html><body>Sent " + name + " = " + val + " to the Uno. <a href='/'>back</a></body></html>");
}

void setup() {
  Serial.begin(115200);
  link.begin(9600);
  WiFi.softAP("JR_Setup");
  Serial.print("access point JR_Setup, address "); Serial.println(WiFi.softAPIP());
  server.on("/", handleRoot);
  server.on("/set", handleSet);
  server.begin();
}

void loop() {
  server.handleClient();
  if (linkPoll()) lastReply = linkLine;
}
