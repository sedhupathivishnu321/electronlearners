// ---- Circuit (Kit 7, Uno) ----
// serial link to the NodeMCU through the level converter: A3 (TX) -> HV1/LV1 -> NodeMCU D1, NodeMCU D2 -> LV2/HV2 -> A2 (RX)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define LINK_RX A2
#define LINK_TX A3

#include <EEPROM.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <SoftwareSerial.h>
SoftwareSerial link(LINK_RX, LINK_TX);
String linkBuf = "", linkLine = "";
bool linkPoll() {                          // true when a whole line has arrived from the other board (in linkLine)
  while (link.available() > 0) {
    char c = link.read();
    if (c == '\r') continue;
    if (c == '\n') { linkLine = linkBuf; linkBuf = ""; return linkLine.length() > 0; }
    linkBuf += c;
  }
  return false;
}

String name = "(none)";
int value = 0;

void show() { lcdRow(0, "Config received"); lcdRow(1, name + "=" + String(value)); }

void setup() {
  Serial.begin(9600);
  link.begin(9600);
  lcdBegin();
  lcdRow(0, "Waiting for the");
  lcdRow(1, "setup portal");
  if (EEPROM.read(0) == 0xA5) { value = EEPROM.read(1); name = "saved"; show(); Serial.println("restored value " + String(value)); }
}

void loop() {
  if (linkPoll() && linkLine.startsWith("SET ")) {
    int sp = linkLine.lastIndexOf(' ');
    name = linkLine.substring(4, sp);
    value = linkLine.substring(sp + 1).toInt();
    EEPROM.write(0, 0xA5); EEPROM.write(1, value & 255);
    show();
    Serial.println("setting " + name + " = " + String(value));
    link.println("STORED " + name);
  }
}
