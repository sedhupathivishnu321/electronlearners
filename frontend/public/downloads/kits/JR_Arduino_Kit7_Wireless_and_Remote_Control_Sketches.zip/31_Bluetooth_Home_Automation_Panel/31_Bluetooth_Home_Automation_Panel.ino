// ---- Circuit (Kit 7, Uno) ----
// HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
// Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
// SG90 servo: signal -> D6, red -> 5V, brown -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5
#define BT_RX A0
#define BT_TX A1
#define RELAY_PIN 5
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define SERVO_PIN 6
#define RED_LED 3
#define GREEN_LED 4

#include <SoftwareSerial.h>
SoftwareSerial bt(BT_RX, BT_TX);           // the Bluetooth module on two spare pins

String btCmd = "";                         // the last complete line from the phone
String btBuf = "";
bool btPoll() {                            // gather characters; true when a whole line has arrived
  while (bt.available() > 0) {
    char c = bt.read();
    if (c == '\r') continue;
    if (c == '\n') { btCmd = btBuf; btBuf = ""; btCmd.trim(); return btCmd.length() > 0; }
    btBuf += c;
  }
  return false;
}
#include <Servo.h>
Servo servo;
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }

bool relayOn = false, redOn = false, greenOn = false;
int angle = 90;

String status() {
  return String("relay ") + (relayOn ? "on" : "off") + ", servo " + String(angle) + ", red " + (redOn ? "on" : "off") + ", green " + (greenOn ? "on" : "off");
}

void apply() {
  digitalWrite(RELAY_PIN, relayOn ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, redOn);
  digitalWrite(GREEN_LED, greenOn);
  servo.write(angle);
  lcdRow(0, String("Relay:") + (relayOn ? "on " : "off") + " Srv:" + String(angle));
  lcdRow(1, String("R:") + (redOn ? "on " : "off") + " G:" + (greenOn ? "on" : "off"));
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  servo.attach(SERVO_PIN);
  Serial.begin(9600);
  bt.begin(9600);
  lcdBegin();
  apply();
  bt.println("panel ready: RELAY ON/OFF, SERVO n, RED ON/OFF, GREEN ON/OFF, STATUS");
}

void loop() {
  if (btPoll()) {
    btCmd.toUpperCase();
    bool known = true;
    if (btCmd == "RELAY ON") relayOn = true;
    else if (btCmd == "RELAY OFF") relayOn = false;
    else if (btCmd == "RED ON") redOn = true;
    else if (btCmd == "RED OFF") redOn = false;
    else if (btCmd == "GREEN ON") greenOn = true;
    else if (btCmd == "GREEN OFF") greenOn = false;
    else if (btCmd.startsWith("SERVO ")) angle = constrain(btCmd.substring(6).toInt(), 0, 180);
    else if (btCmd != "STATUS") known = false;
    if (known) { apply(); bt.println(status()); Serial.println(status()); }
    else bt.println("unknown: " + btCmd);
  }
}
