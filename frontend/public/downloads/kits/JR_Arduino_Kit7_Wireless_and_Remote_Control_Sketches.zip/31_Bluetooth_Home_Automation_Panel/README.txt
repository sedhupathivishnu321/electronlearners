Kit 7 - Wireless and Remote Control
Project 31: Bluetooth Home Automation Panel (Advanced)

One phone-controlled panel: RELAY ON/OFF, SERVO <angle>, RED ON/OFF, GREEN ON/OFF and STATUS (the module replies with everything). The LCD mirrors the state.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Resistor 10k ohm 1/4W x3
  HC-05 Bluetooth x1
  SG90 Micro Servo x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  HC-05: VCC 5V, GND, TXD -> A0 (Uno RX), RXD <- A1 through a 10k + 20k divider (5 V -> 3.3 V)
  Relay module: DC+ 5V, DC- GND, IN <- D5 (active LOW)
  SG90 servo: signal -> D6, red -> 5V, brown -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k7-31-bt-home-panel
