Kit 6 - Smart Safety and Environment
Project 46: Emergency Warning Beacon (Advanced)

Priority-based patterns: FIRE (flame) = fast red flashing + siren + relay beacon on; GAS (over 50 %) = slow red + double beeps + relay beacon flashing; CAUTION (30-50 % gas) = green blinks. The button acknowledges (silences the buzzer; lights stay) - a higher priority event un-acknowledges it.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  Flame Sensor Module x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-46-emergency-beacon
