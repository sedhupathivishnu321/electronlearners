// ---- Circuit (Kit 6) ----
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
#define BUZZER 5
#define RED_LED 3
#define GREEN_LED 4
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2
#define FLAME_DO 10
#define MQ2_PIN A0

int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int level_ = 0, lastLevel = -1;                  // 0 normal, 1 caution, 2 gas, 3 fire
bool acked = false;

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  delay(300);
}

void loop() {
  int gas = level(MQ2_PIN);
  bool flame = digitalRead(FLAME_DO) == LOW;
  level_ = flame ? 3 : (gas >= 50 ? 2 : (gas >= 30 ? 1 : 0));
  if (level_ != lastLevel) {
    if (level_ > lastLevel) acked = false;                    // something worse than before: sound again
    if (level_ == 0) acked = false;
    lastLevel = level_;
    Serial.println(level_ == 3 ? "PRIORITY 1: FIRE" : (level_ == 2 ? "PRIORITY 2: GAS" : (level_ == 1 ? "caution: gas rising" : "normal")));
  }
  if (pressed() && level_ >= 2) { acked = true; Serial.println("acknowledged"); }
  unsigned long ms = millis();
  bool red = false, buz = false, relay = false, green = false;
  if (level_ == 0) green = true;
  if (level_ == 1) green = (ms / 500) % 2;
  if (level_ == 2) { red = (ms / 500) % 2; buz = (ms % 1000) < 120 || (ms % 1000 > 250 && ms % 1000 < 370); relay = (ms / 500) % 2; }
  if (level_ == 3) { red = (ms / 100) % 2; buz = (ms / 150) % 2; relay = true; }
  digitalWrite(RED_LED, red);
  digitalWrite(GREEN_LED, green);
  digitalWrite(BUZZER, buz && !acked);
  digitalWrite(RELAY_PIN, relay ? RELAY_ON : RELAY_OFF);
  delay(10);
}
