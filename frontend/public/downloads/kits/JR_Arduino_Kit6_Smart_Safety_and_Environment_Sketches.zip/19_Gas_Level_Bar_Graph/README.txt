Kit 6 - Smart Safety and Environment
Project 19: Gas Level Bar Graph (Intermediate)

The MQ-2 level is drawn as a 16-character bar on the second LCD row.

Parts:
  MQ-2 Gas Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-19-gas-bargraph
