// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
#define MQ2_PIN A0

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

void setup() {
  lcdBegin();
}

void loop() {
  int g = level(MQ2_PIN);
  String bar = "";
  int filled = g * 16 / 100;
  for (int i = 0; i < 16; i++) bar += (i < filled ? "#" : ".");
  lcdRow(0, "MQ-2 gas: " + String(g) + " %");
  lcdRow(1, bar);
  delay(250);
}
