// ---- Circuit (Kit 6) ----
// DHT22: VCC 5V, GND, DATA -> D7
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define DHT_PIN 7
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int page = 0;
unsigned long lastDraw = 0;

void draw() {
  float t = dht.readTemperature(), h = dht.readHumidity();
  float p = bmp.readPressure() / 100.0;
  if (page == 0) { lcdRow(0, "Temp: " + String(t, 1) + " C"); lcdRow(1, "Humidity: " + String(h, 0) + " %"); }
  if (page == 1) { lcdRow(0, "P " + String(p, 1) + " hPa"); lcdRow(1, "Altitude: " + String(bmp.readAltitude(1013.25), 0) + " m"); }
  if (page == 2) { lcdRow(0, "DHT22: " + String(t, 1) + " C"); lcdRow(1, "BMP280: " + String(bmp.readTemperature(), 1) + " C"); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  dht.begin();
  bmpBegin();
  lcdBegin();
  draw();
}

void loop() {
  if (pressed()) { page = (page + 1) % 3; draw(); }
  if (millis() - lastDraw > 1000) { lastDraw = millis(); draw(); }
}
