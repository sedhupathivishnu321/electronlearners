Kit 6 - Smart Safety and Environment
Project 14: Weather Station Basic (Intermediate)

Three LCD pages, changed with the button: temperature and humidity (DHT22), pressure and altitude (BMP280), and the two temperature readings side by side.

Parts:
  Push Button tactile 6x6 x1
  DHT22 Temp & Humidity x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  DHT22: VCC 5V, GND, DATA -> D7
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-14-weather-basic
