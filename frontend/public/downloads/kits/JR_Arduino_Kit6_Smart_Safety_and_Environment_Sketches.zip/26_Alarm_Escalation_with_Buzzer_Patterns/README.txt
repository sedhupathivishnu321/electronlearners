Kit 6 - Smart Safety and Environment
Project 26: Alarm Escalation with Buzzer Patterns (Intermediate)

Gas levels map to different alarms: 25-50 % LOW (one short beep every 1.5 s), 50-75 % MEDIUM (two beeps a second), over 75 % HIGH (continuous). Green = safe.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-26-alarm-escalation
