// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ2_PIN A0
#define BUZZER 5
#define RED_LED 3
#define GREEN_LED 4

int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

int stage = 0;

void setup() {
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int g = level(MQ2_PIN);
  int now = g >= 75 ? 3 : (g >= 50 ? 2 : (g >= 25 ? 1 : 0));
  if (now != stage) {
    stage = now;
    Serial.print("gas "); Serial.print(g); Serial.print(" % -> ");
    Serial.println(stage == 0 ? "SAFE" : (stage == 1 ? "LOW alarm" : (stage == 2 ? "MEDIUM alarm" : "HIGH alarm")));
  }
  bool beep = false;
  if (stage == 1) beep = (millis() % 1500) < 120;
  if (stage == 2) beep = (millis() % 500) < 150;
  if (stage == 3) beep = true;
  digitalWrite(BUZZER, beep);
  digitalWrite(GREEN_LED, stage == 0);
  digitalWrite(RED_LED, stage > 0);
  delay(10);
}
