Kit 6 - Smart Safety and Environment
Project 6: Barometric Pressure Reader (Basic)

Prints pressure in hPa and the altitude calculated from it.

Parts:
  BMP280 Pressure Sensor x1

Circuit notes:
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-06-bmp280
