// ---- Circuit (Kit 6) ----
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)


#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}

void setup() {
  Serial.begin(9600);
  bmpBegin();
}

void loop() {
  float p = bmp.readPressure() / 100.0;
  Serial.print("Pressure: "); Serial.print(p, 1); Serial.print(" hPa   altitude: ");
  Serial.print(bmp.readAltitude(1013.25), 0); Serial.print(" m   temperature: "); Serial.print(bmp.readTemperature(), 1); Serial.println(" C");
  delay(1000);
}
