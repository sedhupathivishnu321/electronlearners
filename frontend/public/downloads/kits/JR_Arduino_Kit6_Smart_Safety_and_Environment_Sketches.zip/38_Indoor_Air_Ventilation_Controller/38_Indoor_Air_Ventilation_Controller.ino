// ---- Circuit (Kit 6) ----
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// DHT22: VCC 5V, GND, DATA -> D7
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ135_PIN A1
#define DHT_PIN 7
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int mode = 0;                                   // 0 AUTO, 1 forced ON, 2 forced OFF
bool fan = false;
unsigned long lastDraw = 0;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  lcdBegin();
}

void loop() {
  if (pressed()) { mode = (mode + 1) % 3; Serial.println(mode == 0 ? "mode AUTO" : (mode == 1 ? "mode FORCED ON" : "mode FORCED OFF")); }
  int aqi = constrain((level(MQ135_PIN) - 10) * 500 / 90, 0, 500);
  float h = dht.readHumidity();
  bool want = fan;
  if (mode == 1) want = true;
  else if (mode == 2) want = false;
  else {
    if (!fan && (aqi > 60 || h > 75)) want = true;
    if (fan && aqi < 40 && h < 65) want = false;
  }
  if (want != fan) { fan = want; Serial.println(fan ? "fan ON" : "fan OFF"); }
  digitalWrite(RELAY_PIN, fan ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, fan);
  digitalWrite(GREEN_LED, !fan);
  if (millis() - lastDraw > 500) {
    lastDraw = millis();
    lcdRow(0, String(mode == 0 ? "AUTO" : (mode == 1 ? "ON  " : "OFF ")) + " fan " + (fan ? "ON" : "off"));
    lcdRow(1, "AQI" + String(aqi) + " H" + String(h, 0) + "%");
  }
  delay(100);
}
