Kit 6 - Smart Safety and Environment
Project 38: Indoor Air Ventilation Controller (Advanced)

In AUTO the fan relay switches on when the AQI exceeds 60 or humidity exceeds 75 %, and off only when AQI < 40 and humidity < 65 % (hysteresis). The button cycles AUTO / ON / OFF manual overrides. Red = fan running, green = fan off.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  MQ-135 Air Quality x1
  DHT22 Temp & Humidity x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  DHT22: VCC 5V, GND, DATA -> D7
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-38-ventilation
