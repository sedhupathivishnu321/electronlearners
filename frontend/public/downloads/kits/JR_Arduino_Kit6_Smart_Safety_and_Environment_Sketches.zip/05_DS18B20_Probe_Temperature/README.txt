Kit 6 - Smart Safety and Environment
Project 5: DS18B20 Probe Temperature (Basic)

Reads the liquid temperature from the waterproof 1-Wire probe (with its 10k pull-up).

Parts:
  Resistor 10k ohm 1/4W x1
  DS18B20 Waterproof Probe x1

Circuit notes:
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-05-ds18b20
