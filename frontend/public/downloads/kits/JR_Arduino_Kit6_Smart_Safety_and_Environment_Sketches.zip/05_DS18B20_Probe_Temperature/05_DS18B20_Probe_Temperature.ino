// ---- Circuit (Kit 6) ----
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
#define DS_PIN 8

#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}

void setup() {
  Serial.begin(9600);
  ds.begin();
}

void loop() {
  float t = dsTemp();
  if (t == -127) Serial.println("probe not found - check the DATA wire and the pull-up");
  else { Serial.print("Probe temperature: "); Serial.print(t, 2); Serial.println(" C"); }
  delay(1000);
}
