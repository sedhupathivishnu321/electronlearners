// ---- Circuit (Kit 6) ----
// DHT22: VCC 5V, GND, DATA -> D7
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define DHT_PIN 7
#define DS_PIN 8
#define MQ2_PIN A0
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}

unsigned long lastDraw = 0;

bool valid(float t) { return !isnan(t) && t > -20 && t < 60 && t != -127; }

float median3(float a, float b, float c) {
  if ((a >= b && a <= c) || (a <= b && a >= c)) return a;
  if ((b >= a && b <= c) || (b <= a && b >= c)) return b;
  return c;
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin(); ds.begin(); bmpBegin(); lcdBegin();
  delay(300);
}

void loop() {
  float v[3];
  v[0] = dht.readTemperature(); v[1] = dsTemp(); v[2] = bmp.readTemperature();
  bool ok[3]; bool failed[3];
  int good = 0;
  for (int i = 0; i < 3; i++) { failed[i] = !valid(v[i]); ok[i] = !failed[i]; }
  float ref = 0;
  if (ok[0] && ok[1] && ok[2]) ref = median3(v[0], v[1], v[2]);
  else if (ok[0] || ok[1] || ok[2]) {                         // two or fewer healthy: use their mean as the reference
    float s = 0; int n = 0;
    for (int i = 0; i < 3; i++) if (ok[i]) { s += v[i]; n++; }
    ref = s / n;
  }
  float sum = 0;
  for (int i = 0; i < 3; i++) {
    if (ok[i] && (v[i] - ref > 4 || ref - v[i] > 4) && (ok[0] && ok[1] && ok[2])) ok[i] = false;      // plausibility vote
    if (ok[i]) { sum += v[i]; good++; }
  }
  int raw = analogRead(MQ2_PIN);
  bool mqOk = raw > 20 && raw < 1000;
  String bad = "";
  if (!ok[0]) bad += failed[0] ? "DHT-X " : "DHT? ";
  if (!ok[1]) bad += failed[1] ? "DS-X " : "DS? ";
  if (!ok[2]) bad += failed[2] ? "BMP-X " : "BMP? ";
  if (!mqOk) bad += "MQ2-X";
  bool degraded = bad != "";
  digitalWrite(GREEN_LED, !degraded);
  digitalWrite(RED_LED, degraded);
  if (millis() - lastDraw > 800) {
    lastDraw = millis();
    String t = good > 0 ? String(sum / good, 1) + "C" : "--";
    lcdRow(0, "T " + t + " (" + String(good) + "/3 ok)");
    lcdRow(1, degraded ? bad : "all sensors OK");
    Serial.print("temperature "); Serial.print(t); Serial.print("  healthy "); Serial.print(good); Serial.print("/3  "); Serial.println(degraded ? bad : "OK");
  }
  delay(100);
}
