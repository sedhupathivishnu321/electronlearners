Kit 6 - Smart Safety and Environment
Project 44: Fault-Tolerant Sensor Hub (Advanced)

Three sensors measure the temperature. Each is checked for validity and plausibility (a reading more than 4 C from the median of the three is SUSPECT, an impossible value or NaN is FAILED); the hub then averages only the healthy ones and keeps working, naming the bad sensor. The MQ-2 is checked for a stuck-at-rail reading. Green = all healthy, red = degraded.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Resistor 10k ohm 1/4W x1
  MQ-2 Gas Sensor x1
  DHT22 Temp & Humidity x1
  DS18B20 Waterproof Probe x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  DHT22: VCC 5V, GND, DATA -> D7
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-44-fault-tolerant
