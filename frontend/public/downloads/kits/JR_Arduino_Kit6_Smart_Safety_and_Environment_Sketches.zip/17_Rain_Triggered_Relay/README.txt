Kit 6 - Smart Safety and Environment
Project 17: Rain-Triggered Relay (Intermediate)

The relay closes (a "cover" motor) only after rain has been detected for 3 s, and opens again after 3 s without rain. Red = cover closed, green = open.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Rain Sensor Module x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-17-rain-relay
