// ---- Circuit (Kit 6) ----
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define RAIN_PIN A2
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define GREEN_LED 4
#define RED_LED 3

int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

bool closed = false;
unsigned long since = 0;

void setCover(bool c) {
  closed = c;
  digitalWrite(RELAY_PIN, c ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, c);
  digitalWrite(GREEN_LED, !c);
  Serial.println(c ? "cover CLOSED (rain)" : "cover OPEN");
}

void setup() {
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  setCover(false);
}

void loop() {
  bool raining = wetPct() > 40;
  if (raining == closed) since = millis();                   // nothing to change: restart the 3 s timer
  else if (millis() - since >= 3000) setCover(raining);      // the new condition lasted 3 s
  delay(50);
}
