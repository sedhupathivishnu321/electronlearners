// ---- Circuit (Kit 6) ----
// DHT22: VCC 5V, GND, DATA -> D7
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define DHT_PIN 7
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  dht.begin();
  lcdBegin();
}

void loop() {
  float t = dht.readTemperature(), h = dht.readHumidity();
  String why = "";
  if (t > 26) why = "Too hot";
  else if (t < 20) why = "Too cold";
  else if (h > 60) why = "Too humid";
  else if (h < 30) why = "Too dry";
  lcdRow(0, String(t, 1) + "C  " + String(h, 0) + " %");
  lcdRow(1, why == "" ? "Comfortable" : why);
  digitalWrite(GREEN_LED, why == "");
  digitalWrite(RED_LED, why != "");
  delay(2000);
}
