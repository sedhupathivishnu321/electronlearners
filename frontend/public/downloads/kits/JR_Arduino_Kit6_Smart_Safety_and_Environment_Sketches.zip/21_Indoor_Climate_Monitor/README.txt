Kit 6 - Smart Safety and Environment
Project 21: Indoor Climate Monitor (Intermediate)

Comfort rating from the DHT22: 20-26 C and 30-60 % humidity is COMFORTABLE (green); otherwise the LCD names the problem (too hot / cold / humid / dry) and the red LED lights.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  DHT22 Temp & Humidity x1
  16x2 LCD I2C x1

Circuit notes:
  DHT22: VCC 5V, GND, DATA -> D7
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-21-indoor-climate
