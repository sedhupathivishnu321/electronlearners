// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ2_PIN A0
#define MQ135_PIN A1
#define BTN1 2
#define GREEN_LED 4

#include <EEPROM.h>
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define WARMUP_MS 8000UL
int base2 = 0, base135 = 0;
bool calibrated = false;
unsigned long lastPrint = 0;

void saveBaseline() {
  EEPROM.write(0, 0xA5);
  EEPROM.write(1, base2 & 255); EEPROM.write(2, base2 >> 8);
  EEPROM.write(3, base135 & 255); EEPROM.write(4, base135 >> 8);
}

void loadBaseline() {
  if (EEPROM.read(0) != 0xA5) return;
  base2 = EEPROM.read(1) + EEPROM.read(2) * 256;
  base135 = EEPROM.read(3) + EEPROM.read(4) * 256;
  calibrated = true;
  Serial.print("baseline loaded from EEPROM: MQ-2 "); Serial.print(base2); Serial.print(", MQ-135 "); Serial.println(base135);
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  loadBaseline();
}

void loop() {
  if (millis() < WARMUP_MS) {
    digitalWrite(GREEN_LED, (millis() / 250) % 2);
    if (millis() - lastPrint > 1000) { lastPrint = millis(); Serial.print("warming up... "); Serial.print((WARMUP_MS - millis()) / 1000 + 1); Serial.println(" s"); }
    return;
  }
  if (pressed()) {
    long s2 = 0, s135 = 0;
    for (int i = 0; i < 30; i++) { s2 += analogRead(MQ2_PIN); s135 += analogRead(MQ135_PIN); delay(20); }
    base2 = s2 / 30; base135 = s135 / 30;
    calibrated = true;
    saveBaseline();
    Serial.print("CLEAN-AIR BASELINE stored: MQ-2 "); Serial.print(base2); Serial.print(", MQ-135 "); Serial.println(base135);
  }
  digitalWrite(GREEN_LED, calibrated);
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    if (!calibrated) Serial.println("warm-up done - press the button in clean air to calibrate");
    else {
      Serial.print("MQ-2 change "); Serial.print(analogRead(MQ2_PIN) - base2);
      Serial.print("   MQ-135 change "); Serial.println(analogRead(MQ135_PIN) - base135);
    }
  }
}
