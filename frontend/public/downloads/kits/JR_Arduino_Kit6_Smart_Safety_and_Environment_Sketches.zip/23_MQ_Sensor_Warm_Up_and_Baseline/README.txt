Kit 6 - Smart Safety and Environment
Project 23: MQ Sensor Warm-Up and Baseline (Intermediate)

The MQ heaters need a warm-up (8 s here, many minutes in real life - green blinks). Then press the button in clean air: 30 readings of each sensor are averaged and stored in EEPROM as the baseline, and the sketch reports the change from baseline.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  MQ-2 Gas Sensor x1
  MQ-135 Air Quality x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-23-mq-baseline
