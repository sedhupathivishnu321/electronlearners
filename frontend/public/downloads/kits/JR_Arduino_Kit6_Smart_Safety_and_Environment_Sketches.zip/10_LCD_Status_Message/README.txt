Kit 6 - Smart Safety and Environment
Project 10: LCD Status Message (Basic)

A button press toggles the LCD between 'SAFE' and 'DANGER'.

Parts:
  Push Button tactile 6x6 x1
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-10-lcd-status
