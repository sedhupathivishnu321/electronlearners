// ---- Circuit (Kit 6) ----
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
#define DS_PIN 8
#define RAIN_PIN A2
#define PUMP_PIN 9
#define BUZZER 5

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

#define T_LOW 24.0
#define T_HIGH 28.0
#define PUMP_LIMIT_MS 10000UL
bool pumping = false, timeout = false;
unsigned long pumpStart = 0, lastDraw = 0;

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  ds.begin();
  lcdBegin();
}

void loop() {
  float t = dsTemp();
  int lvl = wetPct();
  if (!pumping && !timeout && lvl < 30) { pumping = true; pumpStart = millis(); Serial.println("level low - top-up pump ON"); }
  if (pumping && lvl > 60) { pumping = false; Serial.println("level restored - pump OFF"); }
  if (pumping && millis() - pumpStart > PUMP_LIMIT_MS) { pumping = false; timeout = true; Serial.println("PUMP TIMEOUT - is the reservoir empty?"); }
  if (timeout && lvl > 40) { timeout = false; Serial.println("level recovered - timeout cleared"); }
  digitalWrite(PUMP_PIN, pumping);
  bool tempBad = t < T_LOW || t > T_HIGH;
  digitalWrite(BUZZER, (tempBad || timeout) && (millis() / 500) % 2);
  if (millis() - lastDraw > 500) {
    lastDraw = millis();
    lcdRow(0, "T " + String(t, 1) + "C " + (t > T_HIGH ? "HOT!" : (t < T_LOW ? "COLD!" : "ok")));
    lcdRow(1, "Lvl " + String(lvl) + "% " + (timeout ? "PUMP FAULT" : (pumping ? "pump ON" : "ok")));
  }
  delay(100);
}
