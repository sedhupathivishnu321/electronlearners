Kit 6 - Smart Safety and Environment
Project 39: Aquarium Monitor (Advanced)

The probe watches the water temperature (24-28 C) and the rain-board strip is the water-level gauge. Below 30 % level the top-up pump runs until 60 %. The buzzer sounds for a temperature alarm or a pump timeout (10 s without the level recovering = reservoir empty).

Parts:
  Buzzer Active 5V x1
  Resistor 10k ohm 1/4W x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Rain Sensor Module x1
  DS18B20 Waterproof Probe x1
  Mini Water Pump 5V x1
  16x2 LCD I2C x1

Circuit notes:
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Active buzzer + -> D5, - -> GND (HIGH = beep)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-39-aquarium
