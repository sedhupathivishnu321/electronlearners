Kit 6 - Smart Safety and Environment
Project 50: Safety Compliance Self-Check (Advanced)

At boot every device is tested in turn and the result is shown on the LCD and printed: gas sensors (heated, in range), flame (idle), rain (dry), soil (in range), DHT22, DS18B20, BMP280 (plausible values), then a relay click and a buzzer beep. A PASS / FAIL summary lists the failures.

Parts:
  Buzzer Active 5V x1
  Resistor 10k ohm 1/4W x1
  MQ-2 Gas Sensor x1
  MQ-135 Air Quality x1
  Flame Sensor Module x1
  Rain Sensor Module x1
  Soil Moisture Sensor x1
  DHT22 Temp & Humidity x1
  DS18B20 Waterproof Probe x1
  BMP280 Pressure Sensor x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  DHT22: VCC 5V, GND, DATA -> D7
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-50-self-check
