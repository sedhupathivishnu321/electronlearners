// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// DHT22: VCC 5V, GND, DATA -> D7
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
#define MQ2_PIN A0
#define MQ135_PIN A1
#define FLAME_DO 10
#define RAIN_PIN A2
#define SOIL_PIN A3
#define DHT_PIN 7
#define DS_PIN 8
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 5

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}

int passed = 0, total = 0;
String failures = "";

void report(String name, bool ok) {
  total++;
  if (ok) passed++; else failures += name + " ";
  lcdRow(0, "Check " + String(total) + ": " + name);
  lcdRow(1, ok ? "PASS" : "FAIL");
  Serial.print(name); Serial.println(ok ? ": PASS" : ": FAIL");
  delay(700);
}

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  dht.begin(); ds.begin();
  lcdBegin();
  delay(300);
  Serial.println("=== safety self-check ===");
  lcdRow(0, "Self-check"); lcdRow(1, "starting..."); delay(800);
  if (!bmp.begin(0x76)) report("BMP280", false);
  else { float p = bmp.readPressure() / 100.0; report("BMP280", p > 300 && p < 1100); }
  report("MQ-2", analogRead(MQ2_PIN) > 30 && analogRead(MQ2_PIN) < 1000);
  report("MQ-135", analogRead(MQ135_PIN) > 30 && analogRead(MQ135_PIN) < 1000);
  report("FLAME idle", digitalRead(FLAME_DO) == HIGH);
  report("RAIN dry", analogRead(RAIN_PIN) > 600);
  int soil = analogRead(SOIL_PIN);
  report("SOIL", soil > 60 && soil < 1000);
  float t = dht.readTemperature(), h = dht.readHumidity();
  report("DHT22", !isnan(t) && !isnan(h) && t > -20 && t < 60 && h >= 0 && h <= 100);
  float d = dsTemp();
  report("DS18B20", d != -127 && d > -20 && d < 90);
  digitalWrite(RELAY_PIN, RELAY_ON); delay(400); digitalWrite(RELAY_PIN, RELAY_OFF);
  report("RELAY click", true);
  digitalWrite(BUZZER, HIGH); delay(300); digitalWrite(BUZZER, LOW);
  report("BUZZER beep", true);
  Serial.print("RESULT: "); Serial.print(passed); Serial.print("/"); Serial.print(total); Serial.println(passed == total ? " PASS" : " FAIL");
  if (passed != total) { Serial.print("failed: "); Serial.println(failures); }
}

void loop() {
  lcdRow(0, passed == total ? "SELF-CHECK PASS" : "SELF-CHECK FAIL");
  lcdRow(1, String(passed) + "/" + String(total) + (passed == total ? " ok" : " " + failures));
  delay(1000);
}
