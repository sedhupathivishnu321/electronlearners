Kit 6 - Smart Safety and Environment
Project 35: Fire Detection with Sensor Fusion (Advanced)

A score combines smoke (up to 50), flame (+40) and the temperature rise over the last 10 s (up to +30). 30+ is WATCH; 60+ for 3 samples in a row (1 per second) is a FIRE ALARM (relay, siren, red, latched). A single spike never alarms. The button resets.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  Flame Sensor Module x1
  DHT22 Temp & Humidity x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  DHT22: VCC 5V, GND, DATA -> D7
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-35-fire-fusion
