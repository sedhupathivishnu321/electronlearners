// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// DHT22: VCC 5V, GND, DATA -> D7
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define MQ2_PIN A0
#define FLAME_DO 10
#define DHT_PIN 7
#define BUZZER 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int streak = 0;
bool alarm = false;
float tRef = 0;
unsigned long lastSample = 0, lastRef = 0;
int score = 0;

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  lcdBegin();
  tRef = dht.readTemperature();
}

void loop() {
  if (millis() - lastRef >= 10000) { lastRef = millis(); tRef = dht.readTemperature(); }
  if (millis() - lastSample >= 1000) {
    lastSample = millis();
    int smoke = level(MQ2_PIN);
    bool flame = digitalRead(FLAME_DO) == LOW;
    float rise = dht.readTemperature() - tRef;
    score = smoke / 2 + (flame ? 40 : 0) + constrain((int)(rise * 10), 0, 30);
    streak = score >= 60 ? streak + 1 : 0;                   // false-alarm suppression: it must persist
    if (streak >= 3 && !alarm) { alarm = true; Serial.println("FIRE ALARM"); }
    Serial.print("score "); Serial.print(score); Serial.print("  (smoke "); Serial.print(smoke); Serial.print(", flame "); Serial.print(flame ? 1 : 0);
    Serial.print(", rise "); Serial.print(rise, 1); Serial.print(")  streak "); Serial.println(streak);
    lcdRow(0, "Score " + String(score));
    lcdRow(1, alarm ? "FIRE ALARM!" : (score >= 30 ? "WATCH" : "normal"));
  }
  if (pressed()) { alarm = false; streak = 0; Serial.println("reset"); }
  digitalWrite(RELAY_PIN, alarm ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, alarm || (score >= 30 && (millis() / 400) % 2));
  digitalWrite(BUZZER, alarm && (millis() / 250) % 2);
  delay(10);
}
