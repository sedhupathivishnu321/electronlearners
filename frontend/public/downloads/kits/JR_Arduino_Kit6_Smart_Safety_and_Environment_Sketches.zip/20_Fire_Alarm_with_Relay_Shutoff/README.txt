Kit 6 - Smart Safety and Environment
Project 20: Fire Alarm with Relay Shutoff (Intermediate)

A flame latches the alarm: the relay cuts the power, the siren sounds and the red LED lights. The alarm stays on after the flame is gone until the button is pressed with no flame present.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Flame Sensor Module x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-20-fire-relay
