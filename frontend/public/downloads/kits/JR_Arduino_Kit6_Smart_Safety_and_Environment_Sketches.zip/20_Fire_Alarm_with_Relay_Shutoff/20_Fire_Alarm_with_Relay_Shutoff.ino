// ---- Circuit (Kit 6) ----
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define FLAME_DO 10
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 5
#define BTN1 2
#define RED_LED 3

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool latched = false;

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool flame = digitalRead(FLAME_DO) == LOW;
  if (flame && !latched) { latched = true; Serial.println("FIRE! relay cut, siren on"); }
  if (pressed()) {
    if (latched && !flame) { latched = false; Serial.println("alarm reset"); }
    else if (latched) Serial.println("cannot reset: flame still present");
  }
  digitalWrite(RELAY_PIN, latched ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, latched);
  digitalWrite(BUZZER, latched && (millis() / 300) % 2);                     // siren: on / off
  delay(20);
}
