// ---- Circuit (Kit 6) ----
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Active buzzer + -> D5, - -> GND (HIGH = beep)
#define FLAME_DO 10
#define RED_LED 3
#define BUZZER 5

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool fire = digitalRead(FLAME_DO) == LOW;
  digitalWrite(RED_LED, fire);
  digitalWrite(BUZZER, fire);
  Serial.println(fire ? "FLAME DETECTED" : "no flame");
  delay(250);
}
