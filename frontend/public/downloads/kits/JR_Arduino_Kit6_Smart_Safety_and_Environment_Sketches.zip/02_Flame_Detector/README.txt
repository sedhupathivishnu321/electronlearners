Kit 6 - Smart Safety and Environment
Project 2: Flame Detector (Basic)

When the flame sensor sees a flame its output goes LOW: the red LED lights and the buzzer sounds.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Flame Sensor Module x1

Circuit notes:
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Active buzzer + -> D5, - -> GND (HIGH = beep)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-02-flame-detector
