Kit 6 - Smart Safety and Environment
Project 48: Predictive Maintenance Demo (Advanced)

Each button press waters for 5 s and measures how much the soil moisture rose. The first run sets the baseline; later runs are compared with it. Total run time is tracked, and when the response falls below 50 % of the baseline the red LED and the LCD predict a clogged line.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Soil Moisture Sensor x1
  Mini Water Pump 5V x1
  16x2 LCD I2C x1

Circuit notes:
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-48-predictive-maint
