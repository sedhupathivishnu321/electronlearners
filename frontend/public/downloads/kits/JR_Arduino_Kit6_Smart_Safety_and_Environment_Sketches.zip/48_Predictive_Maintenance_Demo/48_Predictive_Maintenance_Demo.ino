// ---- Circuit (Kit 6) ----
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define PUMP_PIN 9
#define SOIL_PIN A3
#define BTN1 2
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int baseline = 0, runs = 0, lastRise = 0, response = 100;
unsigned long totalSec = 0;
bool clogging = false;

void show() {
  lcdRow(0, "Runs " + String(runs) + " (" + String(totalSec) + " s)");
  lcdRow(1, clogging ? "CLOG PREDICTED!" : (runs == 0 ? "press to water" : "Resp " + String(response) + "% ok"));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  lcdBegin();
  show();
}

void loop() {
  if (pressed()) {
    int before = soilPct();
    Serial.print("run "); Serial.print(runs + 1); Serial.print(": soil before "); Serial.print(before); Serial.println(" %");
    lcdRow(1, "watering...");
    digitalWrite(PUMP_PIN, HIGH);
    delay(5000);
    digitalWrite(PUMP_PIN, LOW);
    delay(500);
    int after = soilPct();
    lastRise = after - before;
    runs++; totalSec += 5;
    if (runs == 1) baseline = max(lastRise, 4);                // the first run is the reference
    response = constrain(lastRise * 100 / baseline, 0, 200);
    clogging = runs > 1 && response < 50;
    Serial.print("  soil after "); Serial.print(after); Serial.print(" %  rise "); Serial.print(lastRise); Serial.print("  response "); Serial.print(response); Serial.println(" % of baseline");
    if (clogging) Serial.println("  PREDICTION: the line is clogging - service the pump");
    digitalWrite(RED_LED, clogging);
    show();
  }
}
