Kit 6 - Smart Safety and Environment
Project 8: Soil Moisture Reader (Basic)

Prints the soil moisture percentage and a DRY / MOIST / WET class.

Parts:
  Soil Moisture Sensor x1

Circuit notes:
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-08-soil-reader
