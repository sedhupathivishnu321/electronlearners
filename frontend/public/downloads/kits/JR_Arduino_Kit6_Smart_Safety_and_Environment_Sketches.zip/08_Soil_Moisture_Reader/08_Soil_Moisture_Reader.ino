// ---- Circuit (Kit 6) ----
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
#define SOIL_PIN A3

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high

void setup() {
  Serial.begin(9600);
}

void loop() {
  int p = soilPct();
  Serial.print("moisture "); Serial.print(p); Serial.print(" %  ");
  if (p < 30) Serial.println("DRY");
  else if (p < 65) Serial.println("MOIST");
  else Serial.println("WET");
  delay(500);
}
