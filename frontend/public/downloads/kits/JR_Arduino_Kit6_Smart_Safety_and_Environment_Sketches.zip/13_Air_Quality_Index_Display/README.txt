Kit 6 - Smart Safety and Environment
Project 13: Air Quality Index Display (Intermediate)

The MQ-135 level is mapped to a 0-500 AQI-like number with a category on the LCD. Green up to AQI 100, red above.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  MQ-135 Air Quality x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-13-aqi-display
