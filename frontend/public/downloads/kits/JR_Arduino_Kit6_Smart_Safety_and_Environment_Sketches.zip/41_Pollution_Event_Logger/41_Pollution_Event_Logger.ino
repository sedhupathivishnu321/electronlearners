// ---- Circuit (Kit 6) ----
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
#define MQ135_PIN A1
#define MQ2_PIN A0
#define BTN1 2
#define BUZZER 5

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define NEV 5
int evPeak[NEV], evDur[NEV], evWho[NEV];          // who: 1 = MQ-135, 2 = MQ-2
int nEv = 0, count = 0, maxPeak = 0, page = 0;
unsigned long totalSec = 0, evStart = 0, lastDraw = 0;
bool inEvent = false;
int curPeak = 0, curWho = 0;

String whoName(int w) { return w == 1 ? "MQ-135" : "MQ-2"; }

void draw() {
  int a = level(MQ135_PIN), b = level(MQ2_PIN);
  if (page == 0) { lcdRow(0, "MQ135 " + String(a) + "%  MQ2 " + String(b) + "%"); lcdRow(1, inEvent ? "EVENT running" : "no event"); }
  if (page == 1) {
    if (nEv == 0) { lcdRow(0, "Last event:"); lcdRow(1, "none yet"); }
    else { lcdRow(0, "Last: " + whoName(evWho[0]) + " " + String(evPeak[0]) + "%"); lcdRow(1, "lasted " + String(evDur[0]) + " s"); }
  }
  if (page == 2) { lcdRow(0, "Events: " + String(count)); lcdRow(1, "peak " + String(maxPeak) + "% tot " + String(totalSec) + "s"); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
  lcdBegin();
  delay(300);
}

void loop() {
  int a = level(MQ135_PIN), b = level(MQ2_PIN);
  int top = max(a, b);
  if (!inEvent && top >= 40) {
    inEvent = true; evStart = millis(); curPeak = top; curWho = a >= b ? 1 : 2;
    digitalWrite(BUZZER, HIGH); delay(100); digitalWrite(BUZZER, LOW);
    Serial.println("event started");
  }
  if (inEvent) {
    if (top > curPeak) { curPeak = top; curWho = a >= b ? 1 : 2; }
    if (top < 30) {
      inEvent = false;
      int dur = (millis() - evStart) / 1000;
      for (int i = NEV - 1; i > 0; i--) { evPeak[i] = evPeak[i - 1]; evDur[i] = evDur[i - 1]; evWho[i] = evWho[i - 1]; }
      evPeak[0] = curPeak; evDur[0] = dur; evWho[0] = curWho;
      if (nEv < NEV) nEv++;
      count++; totalSec += dur; if (curPeak > maxPeak) maxPeak = curPeak;
      Serial.print("event ended: "); Serial.print(whoName(curWho)); Serial.print(" peak "); Serial.print(curPeak); Serial.print(" % for "); Serial.print(dur); Serial.println(" s");
    }
  }
  if (pressed()) { page = (page + 1) % 3; draw(); }
  if (millis() - lastDraw > 400) { lastDraw = millis(); draw(); }
}
