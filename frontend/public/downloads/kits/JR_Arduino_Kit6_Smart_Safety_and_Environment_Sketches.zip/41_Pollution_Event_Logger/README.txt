Kit 6 - Smart Safety and Environment
Project 41: Pollution Event Logger (Advanced)

An EVENT starts when either gas sensor passes 40 % and ends below 30 %. For each event the peak level, which sensor caused it and the duration are logged (last 5 kept) with running statistics. A chirp marks every new event. The button pages: live / last event / statistics.

Parts:
  Push Button tactile 6x6 x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  MQ-135 Air Quality x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Active buzzer + -> D5, - -> GND (HIGH = beep)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-41-pollution-logger
