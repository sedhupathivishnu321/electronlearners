// ---- Circuit (Kit 6) ----
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// DHT22: VCC 5V, GND, DATA -> D7
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define DHT_PIN 7
#define RAIN_PIN A2
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

#define WINDOW_MS 12000UL
float ref = 0, delta = 0;
unsigned long refAt = 0;
int page = 0;

String forecast(float d, float h, int wet) {
  if (wet > 30) return d > 1.0 ? "Rain clearing" : (d < -1.0 ? "Rain worsening" : "Rain now");
  if (d < -2.0) return "STORM LIKELY";
  if (d < -1.0 && h > 70) return "Rain in 12 h";
  if (d > 1.0) return "Fair, clearing";
  if (h > 80) return "Cloudy";
  return "Stable";
}

void draw() {
  float p = bmp.readPressure() / 100.0, h = dht.readHumidity();
  int wet = wetPct();
  if (page == 0) { lcdRow(0, "Forecast:"); lcdRow(1, forecast(delta, h, wet)); }
  else { lcdRow(0, String(p, 1) + "hPa " + (delta >= 0 ? "+" : "") + String(delta, 1)); lcdRow(1, "H" + String(h, 0) + "% T" + String(dht.readTemperature(), 0) + "C R" + String(wet) + "%"); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  dht.begin(); bmpBegin(); lcdBegin();
  ref = bmp.readPressure() / 100.0;
  draw();
}

void loop() {
  if (pressed()) { page = (page + 1) % 2; draw(); }
  if (millis() - refAt >= WINDOW_MS && millis() > 1000) {
    refAt = millis();
    float p = bmp.readPressure() / 100.0;
    delta = p - ref; ref = p;
    Serial.print("pressure change "); Serial.print(delta, 2); Serial.print(" hPa -> "); Serial.println(forecast(delta, dht.readHumidity(), wetPct()));
  }
  static unsigned long lastDraw = 0;
  if (millis() - lastDraw > 700) { lastDraw = millis(); draw(); }
}
