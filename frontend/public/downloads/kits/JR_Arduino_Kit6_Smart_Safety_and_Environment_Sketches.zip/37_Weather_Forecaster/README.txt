Kit 6 - Smart Safety and Environment
Project 37: Weather Forecaster (Advanced)

The pressure change over a 12 s window (standing in for 3 hours), the humidity and the rain sensor combine into a forecast text: STORM LIKELY, RAIN IN 12 h, RAIN NOW / CLEARING, FAIR, CLOUDY or STABLE. The button switches between the forecast and the raw data.

Parts:
  Push Button tactile 6x6 x1
  Rain Sensor Module x1
  DHT22 Temp & Humidity x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  DHT22: VCC 5V, GND, DATA -> D7
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-37-forecaster
