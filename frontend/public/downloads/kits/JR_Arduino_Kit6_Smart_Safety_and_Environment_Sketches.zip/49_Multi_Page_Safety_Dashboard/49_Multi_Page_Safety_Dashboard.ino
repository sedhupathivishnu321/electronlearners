// ---- Circuit (Kit 6) ----
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// DHT22: VCC 5V, GND, DATA -> D7
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define MQ2_PIN A0
#define MQ135_PIN A1
#define FLAME_DO 10
#define DHT_PIN 7
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int page = 0;
unsigned long lastDraw = 0;

void draw() {
  int gas = level(MQ2_PIN), air = level(MQ135_PIN);
  int aqi = constrain((air - 10) * 500 / 90, 0, 500);
  bool flame = digitalRead(FLAME_DO) == LOW;
  float t = dht.readTemperature(), h = dht.readHumidity();
  String alert = "";
  if (flame) alert += "FIRE ";
  if (gas >= 50) alert += "GAS ";
  if (aqi > 150) alert += "AIR ";
  if (h > 90) alert += "HUMID";
  String head = alert == "" ? "" : "! " + alert;
  if (page == 0) { lcdRow(0, alert == "" ? "Gas sensors" : head); lcdRow(1, "MQ2 " + String(gas) + "% AQI " + String(aqi)); }
  if (page == 1) { lcdRow(0, alert == "" ? "Flame / status" : head); lcdRow(1, String(flame ? "FLAME!" : "no flame") + (alert == "" ? "  OK" : "  ALERT")); }
  if (page == 2) { lcdRow(0, alert == "" ? "Climate" : head); lcdRow(1, String(t, 1) + "C  " + String(h, 0) + "% RH"); }
  if (page == 3) { lcdRow(0, alert == "" ? "Pressure" : head); lcdRow(1, String(bmp.readPressure() / 100.0, 1) + " hPa"); }
}

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  dht.begin(); bmpBegin(); lcdBegin();
  delay(300);
  draw();
}

void loop() {
  if (pressed()) { page = (page + 1) % 4; draw(); Serial.print("page "); Serial.println(page + 1); }
  if (millis() - lastDraw > 500) { lastDraw = millis(); draw(); }
}
