Kit 6 - Smart Safety and Environment
Project 49: Multi-Page Safety Dashboard (Advanced)

Four LCD pages (gases, flame and status, climate, pressure) selected with the button. Whenever a danger exists (gas over 50 %, flame, AQI over 150, humidity over 90 %) an alert banner replaces the first row on every page.

Parts:
  Push Button tactile 6x6 x1
  MQ-2 Gas Sensor x1
  MQ-135 Air Quality x1
  Flame Sensor Module x1
  DHT22 Temp & Humidity x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  DHT22: VCC 5V, GND, DATA -> D7
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-49-dashboard
