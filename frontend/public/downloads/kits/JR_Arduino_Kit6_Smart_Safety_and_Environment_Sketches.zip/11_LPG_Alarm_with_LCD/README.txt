Kit 6 - Smart Safety and Environment
Project 11: LPG Alarm with LCD (Intermediate)

The gas level is shown on the LCD. At 50 % the alarm starts (buzzer + red LED) and the relay cuts the gas supply; it only clears again below 30 % (hysteresis).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-11-lpg-alarm
