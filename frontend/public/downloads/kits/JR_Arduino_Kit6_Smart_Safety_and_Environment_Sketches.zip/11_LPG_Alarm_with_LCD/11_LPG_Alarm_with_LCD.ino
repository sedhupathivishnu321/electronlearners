// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define MQ2_PIN A0
#define BUZZER 5
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

bool alarm = false;

void setup() {
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  lcdBegin();
  Serial.begin(9600);
}

void loop() {
  int g = level(MQ2_PIN);
  if (!alarm && g >= 50) { alarm = true; Serial.println("GAS ALARM - supply cut"); }
  if (alarm && g < 30) { alarm = false; Serial.println("gas cleared"); }
  digitalWrite(RELAY_PIN, alarm ? RELAY_ON : RELAY_OFF);          // relay on = gas valve shut
  digitalWrite(RED_LED, alarm);
  digitalWrite(BUZZER, alarm && (millis() / 250) % 2);
  lcdRow(0, "Gas: " + String(g) + " %");
  lcdRow(1, alarm ? "ALARM! valve shut" : "Air OK");
  delay(100);
}
