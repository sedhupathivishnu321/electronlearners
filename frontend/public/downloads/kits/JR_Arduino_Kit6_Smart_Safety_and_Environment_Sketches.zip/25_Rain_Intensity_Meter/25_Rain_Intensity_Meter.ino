// ---- Circuit (Kit 6) ----
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
#define RAIN_PIN A2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

void setup() {
  lcdBegin();
}

void loop() {
  int w = wetPct();
  String name = "NONE";
  if (w >= 65) name = "HEAVY rain";
  else if (w >= 35) name = "MODERATE rain";
  else if (w >= 10) name = "LIGHT rain";
  String bar = "";
  for (int i = 0; i < 6; i++) bar += (i < w * 6 / 100 ? "#" : ".");
  lcdRow(0, "Wet " + String(w) + "% " + bar);
  lcdRow(1, name);
  delay(300);
}
