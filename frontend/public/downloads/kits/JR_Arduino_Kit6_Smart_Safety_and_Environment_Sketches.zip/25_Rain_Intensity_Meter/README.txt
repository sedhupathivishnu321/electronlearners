Kit 6 - Smart Safety and Environment
Project 25: Rain Intensity Meter (Intermediate)

Wetness is quantified as NONE / LIGHT / MODERATE / HEAVY with the percentage and a bar on the LCD.

Parts:
  Rain Sensor Module x1
  16x2 LCD I2C x1

Circuit notes:
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-25-rain-intensity
