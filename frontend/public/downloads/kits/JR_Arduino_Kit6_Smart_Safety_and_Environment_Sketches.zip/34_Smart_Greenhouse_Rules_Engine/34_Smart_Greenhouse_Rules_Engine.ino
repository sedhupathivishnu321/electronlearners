// ---- Circuit (Kit 6) ----
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// DHT22: VCC 5V, GND, DATA -> D7
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
#define SOIL_PIN A3
#define DHT_PIN 7
#define DS_PIN 8
#define PUMP_PIN 9
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high

#define NRULES 6
// sensor: 0 soil %, 1 air C, 2 humidity %, 3 root-zone C     compare: 0 = below, 1 = above     action: 0 pump, 1 fan, 2 alert
int RS[NRULES] = {0, 1, 2, 3, 3, 0};
int RC[NRULES] = {0, 1, 1, 0, 1, 1};
float RT[NRULES] = {35, 30, 85, 12, 32, 85};
int RA[NRULES] = {0, 1, 1, 2, 2, 2};
bool active[NRULES], lastActive[NRULES];
float vals[4];
unsigned long lastDraw = 0;

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  dht.begin(); ds.begin(); lcdBegin();
  delay(300);                                                 // let the sensors settle before the first rule pass
}

void loop() {
  vals[0] = soilPct(); vals[1] = dht.readTemperature(); vals[2] = dht.readHumidity(); vals[3] = dsTemp();
  bool pump = false, fan = false, alert = false, waterlogged = false;
  for (int i = 0; i < NRULES; i++) {
    float v = vals[RS[i]];
    active[i] = (RC[i] == 0) ? (v < RT[i]) : (v > RT[i]);
    if (active[i] != lastActive[i]) {
      lastActive[i] = active[i];
      Serial.print("rule "); Serial.print(i + 1); Serial.println(active[i] ? " ACTIVE" : " cleared");
    }
    if (active[i] && RA[i] == 0) pump = true;
    if (active[i] && RA[i] == 1) fan = true;
    if (active[i] && RA[i] == 2) alert = true;
  }
  if (active[5]) pump = false;                                // rule 6 (waterlogged soil) inhibits the pump
  digitalWrite(PUMP_PIN, pump);
  digitalWrite(RELAY_PIN, fan ? RELAY_ON : RELAY_OFF);
  if (millis() - lastDraw > 500) {
    lastDraw = millis();
    String list = "";
    for (int i = 0; i < NRULES; i++) if (active[i]) list += String(i + 1) + " ";
    lcdRow(0, String("P:") + (pump ? "on" : "off") + " F:" + (fan ? "on" : "off") + (alert ? " ALERT" : ""));
    lcdRow(1, list == "" ? "no rule active" : "rules " + list);
  }
  delay(100);
}
