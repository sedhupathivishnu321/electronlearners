Kit 6 - Smart Safety and Environment
Project 34: Smart Greenhouse Rules Engine (Advanced)

A rule table (sensor, comparison, threshold, action) is evaluated every pass: soil < 35 -> pump; air > 30 C or humidity > 85 % -> fan (relay); root-zone probe < 12 C or > 32 C, or soil > 85 % -> alerts. A waterlogged-soil rule inhibits the pump. The LCD lists the active rules.

Parts:
  Resistor 10k ohm 1/4W x1
  Resistor 220 ohm 1/4W x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Soil Moisture Sensor x1
  DHT22 Temp & Humidity x1
  DS18B20 Waterproof Probe x1
  Mini Water Pump 5V x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  DHT22: VCC 5V, GND, DATA -> D7
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  sensor: 0 soil %, 1 air C, 2 humidity %, 3 root-zone C     compare: 0 = below, 1 = above     action: 0 pump, 1 fan, 2 alert

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-34-greenhouse-rules
