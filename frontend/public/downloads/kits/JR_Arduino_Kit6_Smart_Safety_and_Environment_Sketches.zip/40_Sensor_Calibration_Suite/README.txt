Kit 6 - Smart Safety and Environment
Project 40: Sensor Calibration Suite (Advanced)

A guided two-point calibration: the LCD asks for soil dry / in water, rain board dry / wet, then MQ-2 and MQ-135 in clean air; each button press records the reading (average of 10). The six values are stored in EEPROM, after which calibrated percentages are shown live. HOLD the button 2 s to recalibrate.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  MQ-2 Gas Sensor x1
  MQ-135 Air Quality x1
  Rain Sensor Module x1
  Soil Moisture Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-40-calibration-suite
