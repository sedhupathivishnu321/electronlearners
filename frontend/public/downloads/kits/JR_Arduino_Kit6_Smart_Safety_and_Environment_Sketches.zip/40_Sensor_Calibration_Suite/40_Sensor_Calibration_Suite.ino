// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ2_PIN A0
#define MQ135_PIN A1
#define SOIL_PIN A3
#define RAIN_PIN A2
#define BTN1 2
#define GREEN_LED 4

#include <EEPROM.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

int cal[6];                                      // soil dry, soil wet, rain dry, rain wet, MQ-2 clean, MQ-135 clean
int step = 0;
bool done = false;
unsigned long lastDraw = 0;

String prompt(int s) {
  if (s == 0) return "SOIL: dry/air";
  if (s == 1) return "SOIL: in water";
  if (s == 2) return "RAIN: board dry";
  if (s == 3) return "RAIN: board wet";
  if (s == 4) return "MQ-2: clean air";
  return "MQ-135: clean air";
}

int readStep(int s) {
  int pin = (s < 2) ? SOIL_PIN : (s < 4 ? RAIN_PIN : (s == 4 ? MQ2_PIN : MQ135_PIN));
  long sum = 0;
  for (int i = 0; i < 10; i++) { sum += analogRead(pin); delay(10); }
  return sum / 10;
}

void saveAll() {
  EEPROM.write(0, 0xA5);
  for (int i = 0; i < 6; i++) { EEPROM.write(1 + i * 2, cal[i] & 255); EEPROM.write(2 + i * 2, cal[i] >> 8); }
}

bool loadAll() {
  if (EEPROM.read(0) != 0xA5) return false;
  for (int i = 0; i < 6; i++) cal[i] = EEPROM.read(1 + i * 2) + EEPROM.read(2 + i * 2) * 256;
  return true;
}

int pct(int raw, int a, int b) { if (a == b) return 0; return constrain((long)(raw - a) * 100 / (b - a), 0, 100); }

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  lcdBegin();
  if (loadAll()) { done = true; Serial.println("calibration loaded from EEPROM"); }
  else { lcdRow(0, "Calibration 1/6"); lcdRow(1, prompt(0)); Serial.println("calibration needed: follow the LCD, press the button at each step"); }
}

void loop() {
  digitalWrite(GREEN_LED, done);
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 2000) { }
    if (digitalRead(BTN1) == LOW) {                          // long hold: start over
      done = false; step = 0;
      lcdRow(0, "Recalibrating"); lcdRow(1, prompt(0));
      Serial.println("recalibration started");
      while (digitalRead(BTN1) == LOW) { }
    } else if (!done) {
      cal[step] = readStep(step);
      Serial.print("step "); Serial.print(step + 1); Serial.print(" ("); Serial.print(prompt(step)); Serial.print(") = "); Serial.println(cal[step]);
      step++;
      if (step == 6) { saveAll(); done = true; Serial.println("calibration saved to EEPROM"); lcdRow(0, "Calibration"); lcdRow(1, "SAVED"); delay(1000); }
      else { lcdRow(0, "Calibration " + String(step + 1) + "/6"); lcdRow(1, prompt(step)); }
    }
    delay(40);
  }
  if (done && millis() - lastDraw > 400) {
    lastDraw = millis();
    int soil = pct(analogRead(SOIL_PIN), cal[0], cal[1]);
    int rain = pct(analogRead(RAIN_PIN), cal[2], cal[3]);
    int mq2 = pct(analogRead(MQ2_PIN), cal[4], cal[4] + 600);
    int mq135 = pct(analogRead(MQ135_PIN), cal[5], cal[5] + 600);
    lcdRow(0, "Soil " + String(soil) + "% Rn " + String(rain) + "%");
    lcdRow(1, "MQ2 " + String(mq2) + "% M135 " + String(mq135) + "%");
  }
}
