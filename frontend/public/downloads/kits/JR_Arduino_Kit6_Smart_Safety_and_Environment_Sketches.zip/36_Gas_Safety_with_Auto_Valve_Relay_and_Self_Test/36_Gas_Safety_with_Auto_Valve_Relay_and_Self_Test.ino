// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ2_PIN A0
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 5
#define BTN1 2
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

#define NEV 4
int evCode[NEV];
unsigned long evTime[NEV];
int nEv = 0;
bool valveOpen = true;

String evName(int c) { if (c == 1) return "GAS: valve shut"; if (c == 2) return "valve re-opened"; if (c == 3) return "self-test OK"; return "self-test FAIL"; }

void logEvent(int c) {
  for (int i = NEV - 1; i > 0; i--) { evCode[i] = evCode[i - 1]; evTime[i] = evTime[i - 1]; }
  evCode[0] = c; evTime[0] = millis() / 1000;
  if (nEv < NEV) nEv++;
  Serial.print("[t="); Serial.print(evTime[0]); Serial.print(" s] "); Serial.println(evName(c));
}

void setValve(bool open) {
  valveOpen = open;
  digitalWrite(RELAY_PIN, open ? RELAY_ON : RELAY_OFF);
}

void selfTest() {
  Serial.println("self-test...");
  lcdRow(0, "SELF-TEST"); lcdRow(1, "running...");
  digitalWrite(BUZZER, HIGH); digitalWrite(RED_LED, HIGH); delay(300);
  digitalWrite(BUZZER, LOW); digitalWrite(RED_LED, LOW);
  setValve(false); delay(500); setValve(true); delay(300);          // relay clicks off and on
  int raw = analogRead(MQ2_PIN);
  bool ok = raw > 40 && raw < 1000;                                 // an open or shorted sensor reads at the rails
  logEvent(ok ? 3 : 4);
}

void draw() {
  int g = level(MQ2_PIN);
  lcdRow(0, "Gas " + String(g) + "%  " + (valveOpen ? "OPEN" : "SHUT"));
  lcdRow(1, nEv == 0 ? "no events" : String(evTime[0]) + "s " + evName(evCode[0]));
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_ON);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  lcdBegin();
}

void loop() {
  int g = level(MQ2_PIN);
  if (valveOpen && g >= 60) { setValve(false); logEvent(1); }
  if (digitalRead(BTN1) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN1) == LOW && millis() - t0 < 1500) { }
    if (digitalRead(BTN1) == LOW) { if (valveOpen) selfTest(); while (digitalRead(BTN1) == LOW) { } }
    else if (!valveOpen) {
      if (g < 30) { setValve(true); logEvent(2); } else Serial.println("cannot re-open: gas still present");
    }
    delay(40);
  }
  digitalWrite(GREEN_LED, valveOpen);
  digitalWrite(RED_LED, !valveOpen);
  digitalWrite(BUZZER, !valveOpen && (millis() / 300) % 2);
  draw();
  delay(100);
}
