Kit 6 - Smart Safety and Environment
Project 36: Gas Safety with Auto Valve Relay and Self-Test (Advanced)

The relay holds the gas valve OPEN (fail-safe: no power = shut). Gas over 60 % closes it, with siren and red; a tap re-opens it once the gas is below 30 %. HOLD the button for 1.5 s for a self-test (beep, relay click, sensor plausibility). The last four events are logged with timestamps.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-36-gas-valve
