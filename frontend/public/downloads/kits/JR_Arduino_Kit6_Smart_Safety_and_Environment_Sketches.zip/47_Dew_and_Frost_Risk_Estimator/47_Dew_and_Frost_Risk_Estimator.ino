// ---- Circuit (Kit 6) ----
// DHT22: VCC 5V, GND, DATA -> D7
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define DHT_PIN 7
#define DS_PIN 8
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}

float dewPoint(float t, float h) {              // Magnus approximation
  float a = 17.62, b = 243.12;
  float g = log(h / 100.0) + a * t / (b + t);
  return b * g / (a - g);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin(); ds.begin(); lcdBegin();
}

void loop() {
  float t = dht.readTemperature(), h = dht.readHumidity();
  float surface = dsTemp();
  float td = dewPoint(t, h);
  bool dew = (surface - td) <= 2.0;
  bool frost = dew && surface <= 0.0;
  lcdRow(0, "Td " + String(td, 1) + " Surf " + String(surface, 1));
  lcdRow(1, frost ? "FROST RISK!" : (dew ? "DEW RISK" : "Safe, margin " + String(surface - td, 1)));
  digitalWrite(RED_LED, dew);
  digitalWrite(GREEN_LED, !dew);
  Serial.print("air "); Serial.print(t, 1); Serial.print(" C  RH "); Serial.print(h, 0); Serial.print(" %  dew point "); Serial.print(td, 1);
  Serial.print(" C  surface "); Serial.print(surface, 1); Serial.println(frost ? " C  FROST RISK" : (dew ? " C  DEW RISK" : " C  safe"));
  delay(1500);
}
