Kit 6 - Smart Safety and Environment
Project 47: Dew and Frost Risk Estimator (Advanced)

The DHT22 gives air temperature and humidity, from which the dew point is computed (Magnus formula). The DS18B20 is the surface temperature. Surface within 2 C of the dew point = DEW RISK; the same at or below 0 C = FROST RISK. Green = safe, red = risk.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Resistor 10k ohm 1/4W x1
  DHT22 Temp & Humidity x1
  DS18B20 Waterproof Probe x1
  16x2 LCD I2C x1

Circuit notes:
  DHT22: VCC 5V, GND, DATA -> D7
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-47-dew-frost
