// ---- Circuit (Kit 6) ----
// DHT22: VCC 5V, GND, DATA -> D7
#define DHT_PIN 7

#include <DHT.h>
DHT dht(DHT_PIN, DHT22);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (isnan(t) || isnan(h)) Serial.println("DHT22 read failed - check wiring");
  else { Serial.print("Temperature: "); Serial.print(t, 1); Serial.print(" C   Humidity: "); Serial.print(h, 1); Serial.println(" %"); }
  delay(2000);
}
