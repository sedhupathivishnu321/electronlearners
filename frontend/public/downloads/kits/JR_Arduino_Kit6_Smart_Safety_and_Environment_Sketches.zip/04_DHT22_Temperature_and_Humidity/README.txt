Kit 6 - Smart Safety and Environment
Project 4: DHT22 Temperature and Humidity (Basic)

High-accuracy readings (0.1 degree / 0.1 %) printed every 2 s.

Parts:
  DHT22 Temp & Humidity x1

Circuit notes:
  DHT22: VCC 5V, GND, DATA -> D7

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-04-dht22
