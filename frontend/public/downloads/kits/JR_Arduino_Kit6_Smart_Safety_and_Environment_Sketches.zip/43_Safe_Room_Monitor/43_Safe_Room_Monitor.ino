// ---- Circuit (Kit 6) ----
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
#define MQ135_PIN A1
#define MQ2_PIN A0
#define DS_PIN 8
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 5

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

bool vent = false;
unsigned long lastDraw = 0;

void setup() {
  pinMode(BUZZER, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  ds.begin(); lcdBegin();
  delay(300);
}

void loop() {
  int aqi = constrain((level(MQ135_PIN) - 10) * 500 / 90, 0, 500);
  int gas = level(MQ2_PIN);
  float t = dsTemp();
  if (!vent && (aqi > 55 || t > 30)) { vent = true; Serial.println("ventilation ON"); }
  if (vent && aqi < 40 && t < 28) { vent = false; Serial.println("ventilation OFF"); }
  bool alarm = gas >= 50 || t > 35;
  digitalWrite(RELAY_PIN, vent ? RELAY_ON : RELAY_OFF);
  digitalWrite(BUZZER, alarm && (millis() / 400) % 2);
  if (millis() - lastDraw > 500) {
    lastDraw = millis();
    lcdRow(0, "AQI" + String(aqi) + " " + String(t, 0) + "C" + (vent ? " VENT" : ""));
    lcdRow(1, alarm ? (gas >= 50 ? "ALARM: GAS!" : "ALARM: HOT!") : "Gas " + String(gas) + "%  safe");
  }
  delay(50);
}
