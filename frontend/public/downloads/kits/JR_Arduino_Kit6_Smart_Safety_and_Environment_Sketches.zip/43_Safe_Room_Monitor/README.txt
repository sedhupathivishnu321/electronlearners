Kit 6 - Smart Safety and Environment
Project 43: Safe Room Monitor (Advanced)

An occupancy-agnostic air check: the ventilation relay switches on when the AQI exceeds 55 or the temperature exceeds 30 C (off again below AQI 40 and 28 C). The buzzer alarms for flammable gas over 50 % or a room temperature over 35 C.

Parts:
  Buzzer Active 5V x1
  Resistor 10k ohm 1/4W x1
  MQ-2 Gas Sensor x1
  MQ-135 Air Quality x1
  DS18B20 Waterproof Probe x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Active buzzer + -> D5, - -> GND (HIGH = beep)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-43-safe-room
