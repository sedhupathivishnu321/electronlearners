// ---- Circuit (Kit 6) ----
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// DHT22: VCC 5V, GND, DATA -> D7
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define RAIN_PIN A2
#define DHT_PIN 7
#define BUZZER 5
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

#define WINDOW_MS 15000UL
float ref = 0;
bool dropping = false;
unsigned long refAt = 0, lastDraw = 0;
int lastFactors = -1;

void setup() {
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin(); bmpBegin(); lcdBegin();
  ref = bmp.readPressure() / 100.0;
}

void loop() {
  if (millis() - refAt >= WINDOW_MS && millis() > 1000) {
    refAt = millis();
    float p = bmp.readPressure() / 100.0;
    dropping = (ref - p) >= 1.5;
    Serial.print("pressure change "); Serial.print(p - ref, 2); Serial.println(" hPa");
    ref = p;
  }
  bool rain = wetPct() > 30;
  bool humid = dht.readHumidity() > 75;
  int factors = (dropping ? 1 : 0) + (rain ? 1 : 0) + (humid ? 1 : 0);
  if (factors != lastFactors) {
    lastFactors = factors;
    Serial.print("factors "); Serial.print(factors); Serial.println(factors == 3 ? " -> STORM WARNING" : (factors == 2 ? " -> STORM WATCH" : " -> calm"));
  }
  digitalWrite(GREEN_LED, factors < 2);
  digitalWrite(RED_LED, factors == 3 ? HIGH : (factors == 2 ? (millis() / 400) % 2 : LOW));
  digitalWrite(BUZZER, factors == 3 && (millis() / 300) % 2);
  if (millis() - lastDraw > 500) {
    lastDraw = millis();
    lcdRow(0, String(dropping ? "P-fall " : "P-ok   ") + (rain ? "RAIN " : "dry ") + (humid ? "HUM" : "hum"));
    lcdRow(1, factors == 3 ? "STORM WARNING!" : (factors == 2 ? "Storm watch" : "Calm"));
  }
  delay(50);
}
