Kit 6 - Smart Safety and Environment
Project 42: Storm Alert System (Advanced)

Three storm factors: pressure fell by 1.5 hPa or more in the last 15 s window (standing in for 3 h), the rain board is over 30 % wet, humidity is over 75 %. Two factors = WATCH (red blinks), all three = STORM WARNING (red steady + siren). Green = calm.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  Rain Sensor Module x1
  DHT22 Temp & Humidity x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  DHT22: VCC 5V, GND, DATA -> D7
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-42-storm-alert
