// ---- Circuit (Kit 6) ----
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// DHT22: VCC 5V, GND, DATA -> D7
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define MQ135_PIN A1
#define DHT_PIN 7
#define DS_PIN 8
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float pHist[6];
int nHist = 0, page = 0;
unsigned long lastLog = 0;
float t = 0, h = 0, p = 0, probe = 0;
int aqi = 0;

String trendArrow() {
  if (nHist < 6) return "?";
  float d = pHist[5] - pHist[0];
  if (d > 0.5) return "^";
  if (d < -0.5) return "v";
  return "-";
}

void draw() {
  if (page == 0) { lcdRow(0, "AQI " + String(aqi) + (aqi > 150 ? " !" : "")); lcdRow(1, "Air " + String(t, 1) + "C " + String(h, 0) + "%" + (t > 35 || h > 85 ? " !" : "")); }
  if (page == 1) { lcdRow(0, "P " + String(p, 1) + " hPa " + trendArrow()); lcdRow(1, "Alt " + String(bmp.readAltitude(1013.25), 0) + " m"); }
  if (page == 2) { lcdRow(0, "Probe " + String(probe, 1) + " C"); lcdRow(1, "BMP " + String(bmp.readTemperature(), 1) + " C"); }
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  dht.begin(); ds.begin(); bmpBegin(); lcdBegin();
  Serial.println("time_s,aqi,air_C,hum_pct,pressure_hPa,probe_C");
}

void loop() {
  if (pressed()) { page = (page + 1) % 3; draw(); }
  if (millis() - lastLog >= 2000) {
    lastLog = millis();
    aqi = constrain((level(MQ135_PIN) - 10) * 500 / 90, 0, 500);
    t = dht.readTemperature(); h = dht.readHumidity();
    p = bmp.readPressure() / 100.0; probe = dsTemp();
    for (int i = 0; i < 5; i++) pHist[i] = pHist[i + 1];
    pHist[5] = p;
    if (nHist < 6) nHist++;
    Serial.print(millis() / 1000); Serial.print(","); Serial.print(aqi); Serial.print(","); Serial.print(t, 1); Serial.print(",");
    Serial.print(h, 0); Serial.print(","); Serial.print(p, 1); Serial.print(","); Serial.println(probe, 1);
    if (aqi > 150) Serial.println("ALARM: poor air quality");
    if (t > 35) Serial.println("ALARM: high temperature");
    if (h > 85) Serial.println("ALARM: high humidity");
    draw();
  }
}
