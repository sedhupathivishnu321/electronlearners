Kit 6 - Smart Safety and Environment
Project 32: Environmental Monitoring Station (Advanced)

Logs air quality, air temperature, humidity, pressure and probe temperature every 2 s. The button changes the LCD page; the pressure trend arrow (over the last 6 samples) and alarm thresholds (AQI over 150, temperature over 35 C, humidity over 85 %) are marked with "!".

Parts:
  Push Button tactile 6x6 x1
  Resistor 10k ohm 1/4W x1
  MQ-135 Air Quality x1
  DHT22 Temp & Humidity x1
  DS18B20 Waterproof Probe x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  DHT22: VCC 5V, GND, DATA -> D7
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-32-env-station
