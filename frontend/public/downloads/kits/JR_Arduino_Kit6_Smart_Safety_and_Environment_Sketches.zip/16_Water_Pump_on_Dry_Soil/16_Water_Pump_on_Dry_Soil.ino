// ---- Circuit (Kit 6) ----
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define SOIL_PIN A3
#define PUMP_PIN 9
#define GREEN_LED 4

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high

bool pumping = false;
unsigned long lastPrint = 0;

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int m = soilPct();
  if (!pumping && m < 30) { pumping = true; Serial.println("soil dry - pump ON"); }
  if (pumping && m > 50) { pumping = false; Serial.println("soil moist - pump OFF"); }
  digitalWrite(PUMP_PIN, pumping);
  digitalWrite(GREEN_LED, pumping);
  if (millis() - lastPrint > 1000) { lastPrint = millis(); Serial.print("moisture "); Serial.print(m); Serial.println(" %"); }
  delay(50);
}
