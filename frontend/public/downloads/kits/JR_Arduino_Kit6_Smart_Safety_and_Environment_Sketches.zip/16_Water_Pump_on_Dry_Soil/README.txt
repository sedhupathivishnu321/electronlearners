Kit 6 - Smart Safety and Environment
Project 16: Water Pump on Dry Soil (Intermediate)

The pump (TIP122 + flyback diode) starts when the soil falls below 30 % and stops above 50 %. The green LED shows the pump is running.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Green x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Soil Moisture Sensor x1
  Mini Water Pump 5V x1

Circuit notes:
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-16-pump-dry-soil
