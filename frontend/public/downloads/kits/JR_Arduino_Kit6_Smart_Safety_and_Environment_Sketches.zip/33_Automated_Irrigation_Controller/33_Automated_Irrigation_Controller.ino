// ---- Circuit (Kit 6) ----
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// DHT22: VCC 5V, GND, DATA -> D7
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define SOIL_PIN A3
#define RAIN_PIN A2
#define DHT_PIN 7
#define PUMP_PIN 9
#define GREEN_LED 4
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

#define RUN_MAX_MS 6000UL
#define MIN_GAP_MS 15000UL
#define FAULT_MS 20000UL
int state = 0;                                  // 0 idle, 1 watering, 2 fault
String status = "idle";
int startMoisture = 0;
unsigned long runStart = 0, lastRunEnd = 0, faultAt = 0, lastDraw = 0;

void stopPump(String why) {
  digitalWrite(PUMP_PIN, LOW);
  lastRunEnd = millis();
  Serial.println(why);
}

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  lcdBegin();
  lastRunEnd = 0;
}

void loop() {
  int m = soilPct(), rain = wetPct();
  float t = dht.readTemperature();
  if (state == 0) {
    bool dry = m < 30, gapOk = lastRunEnd == 0 || millis() - lastRunEnd >= MIN_GAP_MS;
    if (!dry) status = "soil ok";
    else if (rain > 20) status = "wait: rain";
    else if (t > 35) status = "wait: too hot";
    else if (m > 85) status = "flood risk";
    else if (!gapOk) status = "wait: gap";
    else { state = 1; startMoisture = m; runStart = millis(); digitalWrite(PUMP_PIN, HIGH); status = "WATERING"; Serial.println("watering started"); }
  } else if (state == 1) {
    if (m >= 55) { state = 0; stopPump("target reached - pump stopped"); status = "done"; }
    else if (m > 85 || rain > 60) { state = 2; faultAt = millis(); stopPump("FLOOD PROTECTION - pump stopped"); status = "FLOOD LOCK"; }
    else if (millis() - runStart > RUN_MAX_MS) {
      if (m < startMoisture + 3) { state = 2; faultAt = millis(); stopPump("DRY-RUN PROTECTION - no response, pump locked"); status = "DRY-RUN LOCK"; }
      else { startMoisture = m; runStart = millis(); }
    }
  } else if (millis() - faultAt > FAULT_MS) { state = 0; status = "retry"; Serial.println("lock-out ended"); }
  digitalWrite(GREEN_LED, state == 1);
  digitalWrite(RED_LED, state == 2);
  if (millis() - lastDraw > 400) {
    lastDraw = millis();
    lcdRow(0, "S" + String(m) + "% R" + String(rain) + "% " + String(t, 0) + "C");
    lcdRow(1, status);
  }
  delay(50);
}
