Kit 6 - Smart Safety and Environment
Project 33: Automated Irrigation Controller (Advanced)

Waters when the soil is below 30 %, but not if it is raining (over 20 % wet), too hot (over 35 C, evaporation) or within 15 s of the last run. Stops at 55 %. Flood protection (soil over 85 %) and dry-run protection (no 3 % rise within 6 s) lock the pump (red).

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Rain Sensor Module x1
  Soil Moisture Sensor x1
  DHT22 Temp & Humidity x1
  Mini Water Pump 5V x1
  16x2 LCD I2C x1

Circuit notes:
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  DHT22: VCC 5V, GND, DATA -> D7
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-33-irrigation
