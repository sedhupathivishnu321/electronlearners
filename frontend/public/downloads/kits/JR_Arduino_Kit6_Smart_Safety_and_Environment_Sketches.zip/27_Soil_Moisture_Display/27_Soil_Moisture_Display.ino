// ---- Circuit (Kit 6) ----
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define SOIL_PIN A3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  lcdBegin();
}

void loop() {
  int m = soilPct();
  String bar = "";
  for (int i = 0; i < 8; i++) bar += (i < m * 8 / 100 ? "#" : ".");
  lcdRow(0, "Moisture " + String(m) + " %");
  lcdRow(1, m < 35 ? "WATER ME  " + bar : "Soil OK   " + bar);
  digitalWrite(GREEN_LED, m < 35);
  delay(300);
}
