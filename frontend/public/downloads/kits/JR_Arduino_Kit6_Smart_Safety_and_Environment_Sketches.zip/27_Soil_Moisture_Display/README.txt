Kit 6 - Smart Safety and Environment
Project 27: Soil Moisture Display (Intermediate)

The moisture percentage and a short bar are shown on the LCD; the green "water" LED lights when the soil drops below 35 %.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Green x1
  Soil Moisture Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-27-soil-display
