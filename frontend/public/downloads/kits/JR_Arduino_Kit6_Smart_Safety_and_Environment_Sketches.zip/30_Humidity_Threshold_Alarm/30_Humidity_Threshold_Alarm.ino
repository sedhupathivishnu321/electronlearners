// ---- Circuit (Kit 6) ----
// DHT22: VCC 5V, GND, DATA -> D7
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define DHT_PIN 7
#define BUZZER 5
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);

#define H_LOW 30.0
#define H_HIGH 70.0

void setup() {
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  dht.begin();
  lcdBegin();
}

void loop() {
  float h = dht.readHumidity();
  bool dry = h < H_LOW, wet = h > H_HIGH;
  lcdRow(0, "Humidity: " + String(h, 0) + " %");
  lcdRow(1, wet ? "TOO HUMID!" : (dry ? "TOO DRY!" : "Range 30-70: OK"));
  digitalWrite(RED_LED, dry || wet);
  digitalWrite(BUZZER, (dry || wet) && (millis() % 2000) < 200);
  delay(500);
}
