Kit 6 - Smart Safety and Environment
Project 30: Humidity Threshold Alarm (Intermediate)

The humidity must stay between 30 % and 70 % (fixed limits, no pot). Outside the range the LCD says TOO DRY / TOO HUMID, the red LED lights and the buzzer chirps.

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  DHT22 Temp & Humidity x1
  16x2 LCD I2C x1

Circuit notes:
  DHT22: VCC 5V, GND, DATA -> D7
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-30-humidity-alarm
