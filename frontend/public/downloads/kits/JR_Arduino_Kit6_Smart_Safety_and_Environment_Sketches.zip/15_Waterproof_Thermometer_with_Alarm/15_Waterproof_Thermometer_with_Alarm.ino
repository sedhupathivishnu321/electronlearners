// ---- Circuit (Kit 6) ----
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define DS_PIN 8
#define BUZZER 5
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}

#define T_LOW 18.0
#define T_HIGH 30.0

void setup() {
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  ds.begin();
  lcdBegin();
  Serial.begin(9600);
}

void loop() {
  float t = dsTemp();
  bool cold = t < T_LOW, hot = t > T_HIGH;
  lcdRow(0, "Probe: " + String(t, 1) + " C");
  lcdRow(1, hot ? "TOO HOT!" : (cold ? "TOO COLD!" : "OK (18-30 C)"));
  digitalWrite(RED_LED, hot || cold);
  digitalWrite(BUZZER, (hot || cold) && (millis() / 400) % 2);
  Serial.println(t, 1);
  delay(500);
}
