Kit 6 - Smart Safety and Environment
Project 15: Waterproof Thermometer with Alarm (Intermediate)

The probe temperature is shown on the LCD. Outside the 18-30 C window the red LED and buzzer alarm (TOO COLD / TOO HOT).

Parts:
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1
  Buzzer Active 5V x1
  Resistor 10k ohm 1/4W x1
  DS18B20 Waterproof Probe x1
  16x2 LCD I2C x1

Circuit notes:
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-15-thermometer-alarm
