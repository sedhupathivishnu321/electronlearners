// ---- Circuit (Kit 6) ----
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Green LED anode -> 220 ohm -> D4, cathode -> GND
// Red LED anode -> 220 ohm -> D3, cathode -> GND
#define RAIN_PIN A2
#define SOIL_PIN A3
#define PUMP_PIN 9
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define GREEN_LED 4
#define RED_LED 3

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

int tankPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // wetter probe = fuller tank

bool inlet = false, pumping = false, locked = false;
int tankAtStart = 0;
unsigned long windowStart = 0, lockedAt = 0, lastDraw = 0;

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  lcdBegin();
  delay(300);
}

void loop() {
  int rain = wetPct(), tank = tankPct();
  bool wantInlet = rain > 30 && tank < 90;
  if (wantInlet != inlet) { inlet = wantInlet; Serial.println(inlet ? "raining: inlet valve OPEN" : "inlet valve closed"); }
  digitalWrite(RELAY_PIN, inlet ? RELAY_ON : RELAY_OFF);

  if (!locked && !pumping && tank > 60) { pumping = true; tankAtStart = tank; windowStart = millis(); Serial.println("tank high - transfer pump ON"); }
  if (pumping && tank < 25) { pumping = false; Serial.println("tank low - pump OFF"); }
  if (pumping && millis() - windowStart > 8000) {
    if (tank > tankAtStart - 3) { pumping = false; locked = true; lockedAt = millis(); Serial.println("DRY-RUN LOCK: the tank is not emptying"); }
    else { tankAtStart = tank; windowStart = millis(); }
  }
  if (locked && millis() - lockedAt > 15000) { locked = false; Serial.println("lock released"); }
  digitalWrite(PUMP_PIN, pumping);
  digitalWrite(GREEN_LED, pumping);
  digitalWrite(RED_LED, locked || tank > 90);
  if (millis() - lastDraw > 500) {
    lastDraw = millis();
    lcdRow(0, "Rain " + String(rain) + "% Tank " + String(tank) + "%");
    lcdRow(1, String(inlet ? "IN:open " : "IN:shut ") + (locked ? "PUMP LOCK" : (pumping ? "PUMP on" : "pump off")));
  }
  delay(50);
}
