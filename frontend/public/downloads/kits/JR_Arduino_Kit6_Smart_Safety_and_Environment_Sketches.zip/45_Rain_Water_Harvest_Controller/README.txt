Kit 6 - Smart Safety and Environment
Project 45: Rain Water Harvest Controller (Advanced)

The rain board decides when to collect: the inlet relay opens while it is raining and the tank (the soil probe as level gauge) is below 90 %. The pump transfers water to storage when the tank is above 60 % until it is below 25 %. If the pump runs 8 s without the tank falling by 3 %, the dry-run lock stops it (red). Tank over 90 % shows overflow (red).

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Rain Sensor Module x1
  Soil Moisture Sensor x1
  Mini Water Pump 5V x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Green LED anode -> 220 ohm -> D4, cathode -> GND
  Red LED anode -> 220 ohm -> D3, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-45-rain-harvest
