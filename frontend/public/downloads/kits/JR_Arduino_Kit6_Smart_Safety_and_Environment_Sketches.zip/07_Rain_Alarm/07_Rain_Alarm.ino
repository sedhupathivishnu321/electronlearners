// ---- Circuit (Kit 6) ----
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
#define RAIN_PIN A2
#define BUZZER 5

int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high

void setup() {
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int w = wetPct();
  bool rain = w > 30;
  digitalWrite(BUZZER, rain);
  Serial.print("wetness "); Serial.print(w); Serial.println(rain ? " %  RAIN!" : " %  dry");
  delay(300);
}
