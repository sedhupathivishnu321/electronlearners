Kit 6 - Smart Safety and Environment
Project 7: Rain Alarm (Basic)

The buzzer sounds while the rain board is more than 30 % wet.

Parts:
  Buzzer Active 5V x1
  Rain Sensor Module x1

Circuit notes:
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  Active buzzer + -> D5, - -> GND (HIGH = beep)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-07-rain-alarm
