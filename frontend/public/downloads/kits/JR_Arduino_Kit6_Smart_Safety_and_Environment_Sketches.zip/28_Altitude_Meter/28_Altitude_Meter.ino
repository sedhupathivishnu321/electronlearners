// ---- Circuit (Kit 6) ----
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
#define BTN1 2

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

float zero = 0;

float altitude() {
  float sum = 0;
  for (int i = 0; i < 8; i++) { sum += bmp.readAltitude(1013.25); delay(5); }
  return sum / 8.0;
}

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  Serial.begin(9600);
  bmpBegin();
  lcdBegin();
  zero = altitude();
}

unsigned long lastDraw = 0;

void loop() {
  if (pressed()) { zero = altitude(); Serial.println("altitude zeroed"); }       // the button is polled on every pass
  if (millis() - lastDraw >= 300) {
    lastDraw = millis();
    float rel = altitude() - zero;
    lcdRow(0, "Rel. alt: " + String(rel, 1) + " m");
    lcdRow(1, String(bmp.readPressure() / 100.0, 1) + " hPa");
  }
}
