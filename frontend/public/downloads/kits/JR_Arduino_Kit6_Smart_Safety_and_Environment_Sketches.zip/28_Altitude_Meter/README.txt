Kit 6 - Smart Safety and Environment
Project 28: Altitude Meter (Intermediate)

Relative altitude from the BMP280 pressure (average of 8 readings). Press the button to zero it at the current height; change the pressure slider to climb (about -0.12 hPa per metre).

Parts:
  Push Button tactile 6x6 x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-28-altitude-meter
