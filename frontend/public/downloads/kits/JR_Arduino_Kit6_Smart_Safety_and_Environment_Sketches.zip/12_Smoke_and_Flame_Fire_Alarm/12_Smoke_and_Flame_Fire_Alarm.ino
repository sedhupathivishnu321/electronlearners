// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ2_PIN A0
#define FLAME_DO 10
#define BUZZER 5
#define RED_LED 3
#define GREEN_LED 4

int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

int state = 0;                                 // 0 clear, 1 warning, 2 fire

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  bool flame = digitalRead(FLAME_DO) == LOW;
  bool smoke = level(MQ2_PIN) > 45;
  int now = (flame && smoke) ? 2 : ((flame || smoke) ? 1 : 0);
  if (now != state) {
    state = now;
    Serial.println(state == 2 ? "FIRE ALARM: smoke and flame" : (state == 1 ? (flame ? "warning: flame only" : "warning: smoke only") : "all clear"));
  }
  digitalWrite(GREEN_LED, state == 0);
  digitalWrite(RED_LED, state == 2 ? HIGH : (state == 1 ? (millis() / 300) % 2 : LOW));
  digitalWrite(BUZZER, state == 2 ? HIGH : (state == 1 ? (millis() % 1500) < 150 : LOW));
  delay(20);
}
