Kit 6 - Smart Safety and Environment
Project 12: Smoke and Flame Fire Alarm (Intermediate)

Flame alone (or smoke alone) is a WARNING (red blinks, slow beeps). Smoke AND flame together is a FIRE ALARM (red steady, continuous buzzer). Green = all clear.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  Flame Sensor Module x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-12-fire-alarm
