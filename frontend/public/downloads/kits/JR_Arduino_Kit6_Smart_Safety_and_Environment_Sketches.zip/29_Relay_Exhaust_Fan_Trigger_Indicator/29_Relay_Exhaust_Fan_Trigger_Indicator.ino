// ---- Circuit (Kit 6) ----
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ135_PIN A1
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define RED_LED 3
#define GREEN_LED 4

int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

bool fanOn = false;

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int l = level(MQ135_PIN);
  if (!fanOn && l > 55) { fanOn = true; Serial.println("air poor - fan ON"); }
  if (fanOn && l < 40) { fanOn = false; Serial.println("air good - fan OFF"); }
  digitalWrite(RELAY_PIN, fanOn ? RELAY_ON : RELAY_OFF);
  digitalWrite(RED_LED, fanOn);
  digitalWrite(GREEN_LED, !fanOn);
  delay(200);
}
