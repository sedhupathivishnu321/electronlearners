Kit 6 - Smart Safety and Environment
Project 29: Relay Exhaust Fan Trigger (Indicator) (Intermediate)

The relay (the exhaust fan) switches on when the MQ-135 air quality level exceeds 55 % and off again below 40 %. Red = fan running, green = air good.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  MQ-135 Air Quality x1
  Relay Module 1 Channel 5V x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-29-exhaust-fan
