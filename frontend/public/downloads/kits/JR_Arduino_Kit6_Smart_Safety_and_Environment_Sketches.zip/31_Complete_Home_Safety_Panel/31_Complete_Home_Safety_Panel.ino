// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
// Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
// DHT22: VCC 5V, GND, DATA -> D7
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define MQ2_PIN A0
#define FLAME_DO 10
#define RAIN_PIN A2
#define DHT_PIN 7
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BUZZER 5
#define BTN1 2
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);
int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}
int wetPct() { return constrain(map(analogRead(RAIN_PIN), 1023, 0, 0, 100), 0, 100); }       // dry board reads high
int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool latchGas = false, latchFire = false, latchHot = false, silenced = false;
unsigned long lastDraw = 0;

void setup() {
  pinMode(FLAME_DO, INPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  lcdBegin();
}

void loop() {
  int gas = level(MQ2_PIN), wet = wetPct();
  bool flame = digitalRead(FLAME_DO) == LOW;
  float t = dht.readTemperature();
  if (gas >= 50 && !latchGas) { latchGas = true; Serial.println("ALARM: gas"); }
  if (flame && !latchFire) { latchFire = true; Serial.println("ALARM: fire"); }
  if (t > 45 && !latchHot) { latchHot = true; Serial.println("ALARM: high temperature"); }
  bool any = latchGas || latchFire || latchHot;
  bool active = gas >= 50 || flame || t > 45;
  if (pressed() && any) {
    if (active) { silenced = true; Serial.println("buzzer silenced (cause still present)"); }
    else { latchGas = latchFire = latchHot = false; silenced = false; Serial.println("alarms reset"); }
  }
  digitalWrite(RELAY_PIN, (latchGas || latchFire) ? RELAY_ON : RELAY_OFF);          // cut-off for gas / fire
  digitalWrite(RED_LED, any);
  digitalWrite(GREEN_LED, !any);
  bool beep = false;
  if (any && !silenced) beep = latchFire ? true : (latchGas ? (millis() % 600) < 300 : (millis() % 1500) < 200);
  digitalWrite(BUZZER, beep);
  if (millis() - lastDraw > 400) {
    lastDraw = millis();
    lcdRow(0, "G" + String(gas) + " F" + (flame ? "!" : "-") + " R" + String(wet) + " T" + String(t, 0));
    String msg = "";
    if (latchGas) msg += "GAS ";
    if (latchFire) msg += "FIRE ";
    if (latchHot) msg += "HOT ";
    lcdRow(1, any ? msg + (silenced ? "(muted)" : "") : (wet > 40 ? "All clear - rain" : "All clear"));
  }
}
