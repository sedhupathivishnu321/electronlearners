Kit 6 - Smart Safety and Environment
Project 31: Complete Home Safety Panel (Advanced)

Four zones: gas, fire, high temperature (over 45 C) and rain (information only). Gas and fire alarms are LATCHED and cut the supply with the relay. The button silences the buzzer; once the cause has cleared a second press resets the latches. Green = all clear.

Parts:
  Push Button tactile 6x6 x1
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1
  Flame Sensor Module x1
  Rain Sensor Module x1
  DHT22 Temp & Humidity x1
  Relay Module 1 Channel 5V x1
  16x2 LCD I2C x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  Flame sensor: VCC 5V, GND, DO -> D10 (LOW when a flame is seen; the board pot sets the threshold)
  Rain sensor: VCC 5V, GND, AO -> A2 (dry = high reading)
  DHT22: VCC 5V, GND, DATA -> D7
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Active buzzer + -> D5, - -> GND (HIGH = beep)
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-31-safety-panel
