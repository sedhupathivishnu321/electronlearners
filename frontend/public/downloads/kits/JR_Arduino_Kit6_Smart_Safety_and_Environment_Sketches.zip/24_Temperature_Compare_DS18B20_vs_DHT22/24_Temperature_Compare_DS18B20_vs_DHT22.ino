// ---- Circuit (Kit 6) ----
// DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
// DHT22: VCC 5V, GND, DATA -> D7
#define DS_PIN 8
#define DHT_PIN 7

#include <OneWire.h>
#include <DallasTemperature.h>
OneWire oneWire(DS_PIN);
DallasTemperature ds(&oneWire);

float dsTemp() {                           // degrees C, -127 = sensor not answering
  ds.requestTemperatures();
  return ds.getTempCByIndex(0);
}
#include <DHT.h>
DHT dht(DHT_PIN, DHT22);

float offsetSum = 0;
int n = 0;

void setup() {
  Serial.begin(9600);
  ds.begin();
  dht.begin();
  Serial.println("DS18B20, DHT22, difference (DHT - DS), average offset");
}

void loop() {
  float a = dsTemp(), b = dht.readTemperature();
  if (a == -127 || isnan(b)) { Serial.println("a sensor is not answering"); delay(2000); return; }
  float diff = b - a;
  offsetSum += diff; n++;
  Serial.print(a, 2); Serial.print(", "); Serial.print(b, 1); Serial.print(", ");
  Serial.print(diff >= 0 ? "+" : ""); Serial.print(diff, 2); Serial.print(", avg offset ");
  Serial.println(offsetSum / n, 2);
  delay(2000);
}
