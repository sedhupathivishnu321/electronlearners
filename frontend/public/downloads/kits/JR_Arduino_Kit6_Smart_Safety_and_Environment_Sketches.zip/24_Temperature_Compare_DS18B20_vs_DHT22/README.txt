Kit 6 - Smart Safety and Environment
Project 24: Temperature Compare DS18B20 vs DHT22 (Intermediate)

Both sensors are logged every 2 s with their difference and the running average offset (the DS18B20 is the reference).

Parts:
  Resistor 10k ohm 1/4W x1
  DHT22 Temp & Humidity x1
  DS18B20 Waterproof Probe x1

Circuit notes:
  DS18B20 probe: VCC 5V, GND, DATA -> D8 with a 10k pull-up from DATA to 5V
  DHT22: VCC 5V, GND, DATA -> D7

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-24-temp-compare
