// ---- Circuit (Kit 6) ----
// BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
// 16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define RED_LED 3
#define GREEN_LED 4

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void lcdRow(int row, String s) {           // write one full 16-character row (pads with spaces)
  while (s.length() < 16) s += " ";
  lcd.setCursor(0, row);
  lcd.print(s);
}
void lcdBegin() { lcd.init(); lcd.backlight(); }
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 bmp;

void bmpBegin() {
  if (!bmp.begin(0x76)) { Serial.println("BMP280 not found - check SDA/SCL"); while (true) { } }
}

#define WINDOW_MS 15000UL
float ref = 0, delta = 0;
unsigned long refAt = 0;
String forecast = "collecting...";

void show() {
  float p = bmp.readPressure() / 100.0;
  lcdRow(0, String(p, 1) + " hPa " + (delta >= 0 ? "+" : "") + String(delta, 1));
  lcdRow(1, forecast);
}

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
  bmpBegin();
  lcdBegin();
  ref = bmp.readPressure() / 100.0;
  show();
}

void loop() {
  if (millis() - refAt >= WINDOW_MS && millis() > 1000) {
    refAt = millis();
    float p = bmp.readPressure() / 100.0;
    delta = p - ref;
    ref = p;
    if (delta < -1.0) forecast = "RAIN LIKELY";
    else if (delta > 1.0) forecast = "FAIR, clearing";
    else forecast = "STEADY";
    digitalWrite(RED_LED, delta < -1.0);
    digitalWrite(GREEN_LED, delta > 1.0);
    Serial.print("change "); Serial.print(delta, 2); Serial.print(" hPa -> "); Serial.println(forecast);
  }
  show();
  delay(500);
}
