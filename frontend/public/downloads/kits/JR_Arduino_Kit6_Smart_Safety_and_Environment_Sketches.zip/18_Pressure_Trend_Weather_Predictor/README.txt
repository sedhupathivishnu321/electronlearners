Kit 6 - Smart Safety and Environment
Project 18: Pressure Trend Weather Predictor (Intermediate)

Every 15 s (a demo for 3 hours) the pressure is compared with the previous sample: falling more than 1 hPa = RAIN LIKELY (red), rising = FAIR (green), otherwise STEADY. Move the pressure slider to try it.

Parts:
  Resistor 220 ohm 1/4W x2
  LED 5mm Red x1
  LED 5mm Green x1
  BMP280 Pressure Sensor x1
  16x2 LCD I2C x1

Circuit notes:
  BMP280: VCC 5V, GND, SDA -> A4, SCL -> A5 (I2C 0x76)
  16x2 LCD (I2C 0x27): VCC 5V, GND, SDA -> A4, SCL -> A5 (shared with the BMP280)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-18-pressure-trend
