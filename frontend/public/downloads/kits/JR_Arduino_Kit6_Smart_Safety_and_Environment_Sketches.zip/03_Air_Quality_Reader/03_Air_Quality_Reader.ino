// ---- Circuit (Kit 6) ----
// MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)
#define MQ135_PIN A1

int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

void setup() {
  Serial.begin(9600);
}

void loop() {
  int raw = analogRead(MQ135_PIN);
  int l = level(MQ135_PIN);
  Serial.print("raw "); Serial.print(raw); Serial.print("  level "); Serial.print(l); Serial.print(" %  -> ");
  if (l < 25) Serial.println("CLEAN");
  else if (l < 50) Serial.println("MODERATE");
  else if (l < 75) Serial.println("POOR");
  else Serial.println("HAZARDOUS");
  delay(500);
}
