Kit 6 - Smart Safety and Environment
Project 3: Air Quality Reader (Basic)

Prints the MQ-135 reading with a CLEAN / MODERATE / POOR / HAZARDOUS classification.

Parts:
  MQ-135 Air Quality x1

Circuit notes:
  MQ-135: VCC 5V, GND, AO -> A1 (higher = worse air)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-03-air-quality
