// ---- Circuit (Kit 6) ----
// MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
// Active buzzer + -> D5, - -> GND (HIGH = beep)
#define MQ2_PIN A0
#define BUZZER 5

int level(int pin) {                         // 0-100 %: the MQ modules swing about 0.5 V (clean air) to 4.6 V (heavy gas)
  return constrain(map(analogRead(pin), 100, 920, 0, 100), 0, 100);
}

void setup() {
  pinMode(BUZZER, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int g = level(MQ2_PIN);
  bool leak = g > 40;
  digitalWrite(BUZZER, leak);
  Serial.print("gas level "); Serial.print(g); Serial.println(leak ? " %  LEAK!" : " %  ok");
  delay(300);
}
