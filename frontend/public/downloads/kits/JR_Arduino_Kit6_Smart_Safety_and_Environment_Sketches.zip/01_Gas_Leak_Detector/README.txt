Kit 6 - Smart Safety and Environment
Project 1: Gas Leak Detector (Basic)

The MQ-2 analog level above 40 % sounds the buzzer. Raise "Gas concentration" in the inspector.

Parts:
  Buzzer Active 5V x1
  MQ-2 Gas Sensor x1

Circuit notes:
  MQ-2: VCC 5V, GND, AO -> A0 (higher = more gas / smoke)
  Active buzzer + -> D5, - -> GND (HIGH = beep)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-01-gas-leak
