Kit 6 - Smart Safety and Environment
Project 22: Pump Dry-Run Protection (Intermediate)

The pump runs when the soil is dry. If after 8 s of running the soil has not become at least 5 % wetter (empty tank, blocked pipe) the pump is stopped, the red LED locks out and it retries after a 20 s cool-down.

Parts:
  Resistor 220 ohm 1/4W x3
  LED 5mm Red x1
  LED 5mm Green x1
  TIP122 Darlington x1
  Diode 1N4007 x1
  Soil Moisture Sensor x1
  Mini Water Pump 5V x1

Circuit notes:
  Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
  Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
  Red LED anode -> 220 ohm -> D3, cathode -> GND
  Green LED anode -> 220 ohm -> D4, cathode -> GND

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-22-pump-dryrun
