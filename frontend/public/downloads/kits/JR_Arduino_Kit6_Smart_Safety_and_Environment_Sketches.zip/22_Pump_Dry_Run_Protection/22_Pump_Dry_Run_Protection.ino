// ---- Circuit (Kit 6) ----
// Pump: + -> 5V, - -> TIP122 collector; base <- D9 via 1k, emitter -> GND; 1N4007 across the pump (flyback)
// Soil moisture probe: VCC 5V, GND, AO -> A3 (dry = high reading)
// Red LED anode -> 220 ohm -> D3, cathode -> GND
// Green LED anode -> 220 ohm -> D4, cathode -> GND
#define PUMP_PIN 9
#define SOIL_PIN A3
#define RED_LED 3
#define GREEN_LED 4

int soilPct() { return constrain(map(analogRead(SOIL_PIN), 1023, 0, 0, 100), 0, 100); }     // dry soil reads high

#define RUN_LIMIT_MS 8000UL
#define COOLDOWN_MS 20000UL
int state = 0;                                  // 0 idle, 1 running, 2 locked out
int startMoisture = 0;
unsigned long windowStart = 0, lockedAt = 0;

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int m = soilPct();
  if (state == 0 && m < 30) {
    state = 1; startMoisture = m; windowStart = millis();
    digitalWrite(PUMP_PIN, HIGH);
    Serial.println("soil dry - pump ON");
  } else if (state == 1) {
    if (m >= 50) { state = 0; digitalWrite(PUMP_PIN, LOW); Serial.println("soil wet enough - pump OFF"); }
    else if (millis() - windowStart > RUN_LIMIT_MS) {
      if (m < startMoisture + 5) {
        state = 2; lockedAt = millis();
        digitalWrite(PUMP_PIN, LOW);
        Serial.println("DRY-RUN PROTECTION: soil did not respond - pump locked out");
      } else { startMoisture = m; windowStart = millis(); Serial.println("soil is responding - keep watering"); }
    }
  } else if (state == 2 && millis() - lockedAt > COOLDOWN_MS) {
    state = 0;
    Serial.println("cool-down over - retrying");
  }
  digitalWrite(GREEN_LED, state == 1);
  digitalWrite(RED_LED, state == 2);
  delay(50);
}
