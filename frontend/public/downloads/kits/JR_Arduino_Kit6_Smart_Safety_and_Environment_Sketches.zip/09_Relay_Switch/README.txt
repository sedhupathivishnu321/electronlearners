Kit 6 - Smart Safety and Environment
Project 9: Relay Switch (Basic)

The button toggles the relay; the red LED on the relay contacts shows the switched circuit.

Parts:
  Push Button tactile 6x6 x1
  Relay Module 1 Channel 5V x1
  Resistor 220 ohm 1/4W x1
  LED 5mm Red x1

Circuit notes:
  Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
  Red LED branch on the relay contacts: COM <- 5V, NO -> 220 ohm -> LED -> GND
  Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)

Try it first in the simulator: https://jrlearners.com/arduinoforge/?example=k6-09-relay-switch
