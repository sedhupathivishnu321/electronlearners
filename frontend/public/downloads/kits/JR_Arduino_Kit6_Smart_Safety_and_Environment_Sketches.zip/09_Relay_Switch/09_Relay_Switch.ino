// ---- Circuit (Kit 6) ----
// Relay module: DC+ 5V, DC- GND, IN <- D6 (active LOW: LOW = relay on)
// Red LED branch on the relay contacts: COM <- 5V, NO -> 220 ohm -> LED -> GND
// Push button between D2 and GND (INPUT_PULLUP, pressed = LOW)
#define RELAY_PIN 6
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define BTN1 2

int lastBtn = HIGH;
bool pressed() {                           // true once per button press (debounced)
  int now = digitalRead(BTN1);
  bool hit = (lastBtn == HIGH && now == LOW);
  lastBtn = now;
  if (hit) delay(25);
  return hit;
}

bool on = false;

void setup() {
  pinMode(BTN1, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (pressed()) {
    on = !on;
    digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
    Serial.println(on ? "relay ON" : "relay OFF");
  }
}
